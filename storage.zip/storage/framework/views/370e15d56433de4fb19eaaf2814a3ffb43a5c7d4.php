<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-end">

                            </div>
                            <h4 class="page-title">النتائج</h4>
                        </div>
                        <!--end page-title-box-->
                    </div>
                    <!--end col-->
                </div>
                <?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <div class="row">
                    <div class="col-12">
                        <div class="card">


                            <div class="card-body">

                                <div class="button-container">


                                    <a href="<?php echo e(route('admin.orders')); ?>">
                                        <button class="button primary">الطلبات الجديده</button>
                                    </a>
                                    <a href="<?php echo e(route('orderss.list')); ?>">
                                        <button class="button secondary">طلبات تم شحنها</button>
                                    </a>
                                    <a href="<?php echo e(route('sh.admin.orders')); ?>">
                                        <button class="button primary">الطلبات تم تسليمها</button>
                                    </a>
                                    <a href="<?php echo e(route('shs.admin.orders')); ?>">
                                        <button class="button tertiary">طلبات تم الغائها</button>
                                    </a>


                                </div>


                                <div class="tab-content">
                                    <div class="tab-pane p-3 active" id="Post" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="myDataTable" class="table table-hover align-middle mb-0"
                                                style="width:90%;">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>المجموع</th>
                                                        <th>اسم المستخدم</th>
                                                        <th>حالة الطلب</th>
                                                        <th>عدد المنتجات</th>
                                                        <th>حالة الدفع</th>
                                                        <th>التاريخ</th>
                                                        <th>تفاصيل</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="R_user<?php echo e($c->id); ?>">
                                                            <td><?php echo e($c->id); ?> </td>
                                                            <td><?php echo e($c->total); ?>د.إ </td>
                                                            <td>
                                                                <?php if($c->user->id): ?>
                                                                    <a
                                                                        href="<?php echo e(route('admin.user.profile', $c->user->id)); ?>">
                                                                        <i>
                                                                        </i>
                                                                        <?php echo e($c->user->fname); ?></a>
                                                                <?php else: ?>
                                                                    <?php echo e(@$c->address->name); ?>

                                                                <?php endif; ?>
                                                            </td>


                                                            <td>
                                                                <div class="dropdown">
                                                                    <button class="btn btn-secondary dropdown-toggle"
                                                                        type="button" id="statusDropdown"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        <?php if($c->status == 1): ?>
                                                                            <span class="badge bg-info">طلب جديد
                                                                            <?php elseif($c->status == 2): ?>
                                                                                <span class="badge bg-primary">تم
                                                                                    الشحن</span>
                                                                            <?php elseif($c->status == 3): ?>
                                                                                <span class="badge bg-success">تم
                                                                                    التسليم</span>
                                                                            <?php else: ?>
                                                                                <span class="badge bg-danger">طلب
                                                                                    ملغي</span>
                                                                        <?php endif; ?>
                                                                    </button>
                                                                    <ul class="dropdown-menu"
                                                                        aria-labelledby="statusDropdown">
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.order', [$c->id, 1])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">طلب جديد</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.order', [$c->id, 2])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">تم الشحن</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.order', [$c->id, 3])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">تم
                                                                                    التسليم</button></form>
                                                                        </li>
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.order', [$c->id, 0])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">طلب ملغي</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </td>



                                                            
                                                            <td><?php echo e($c->items->count()); ?> </td>




                                                            <td>
                                                                <div class="dropdown">
                                                                    <button class="btn btn-secondary dropdown-toggle"
                                                                        type="button" id="statusDropdown"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        <?php if($c->payment_method == 'pending'): ?>
                                                                            <span class="badge bg-info">في انتظار
                                                                                الدفع</span>
                                                                        <?php elseif($c->payment_method == 'completed'): ?>
                                                                            <span class="badge bg-primary">تم الدفع</span>
                                                                        <?php elseif($c->payment_method == 'failed'): ?>
                                                                            <span class="badge bg-success">تم الغاء
                                                                                الدفع</span>
                                                                        <?php else: ?>
                                                                            <span class="badge bg-danger">الدفع عند
                                                                                الاستلام</span>
                                                                        <?php endif; ?>
                                                                    </button>
                                                                    <ul class="dropdown-menu"
                                                                        aria-labelledby="statusDropdown">
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.orderpay', [$c->id, 'pending'])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">في انتظار
                                                                                    الدفع</button></form>
                                                                        </li>
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.orderpay', [$c->id, 'completed'])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">تم الدفع</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.orderpay', [$c->id, 'failed'])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">تم الغاء
                                                                                    الدفع</button></form>
                                                                        </li>
                                                                        <li>
                                                                            <form method="POST"
                                                                                action="<?php echo e(route('update.orderpay', [$c->id, 'cash'])); ?>">
                                                                                <?php echo csrf_field(); ?> <button type="submit"
                                                                                    class="dropdown-item">الدفع عند
                                                                                    الاستلام</button></form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </td>






                                                            <td><?php echo e($c->created_at->format('d/m/Y')); ?> </td>
                                                            <td> 



                                                                <a href=" " class="deletem_b"
                                                                    deletem_b="<?php echo e($c->id); ?>"> <i
                                                                        class="icofont-trash text-danger font-20"></i></a>



                                                                        <a href="<?php echo e(route('admin.order.profile', $c->id)); ?>"><i
                                                                            class="icofont-eye  text-secondary font-20"></i></a>

                                                                


                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->


        </div><!-- container -->


    </div>

    </div>
    <!-- end page-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.0.min.js"
        integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>
    <script src="<?php echo e(url('/')); ?>/cp/assets/bundles/dataTables.bundle.js"></script>

    <script>
        function updateAction() {
            var form = document.getElementById("payment-form");
            var selectedValue = document.querySelector('select[name="status"]').value;
            form.action = "<?php echo e(route('update.orderpay', [$c->id, ''])); ?>/" + selectedValue;
            form.submit();
        }
    </script>
    <script>
        $('#myDataTable')
            .addClass('nowrap')
            .dataTable({
                order: [
                    [0, 'desc']
                ],
                responsive: true,
                columnDefs: [{
                    targets: [-1, -3],
                    className: 'dt-body-right'
                }]
            });

        $('.deletem_b').on("click", function(e) {
            e.preventDefault();

            var id = $(this).attr('deletem_b');


            $.ajax({
                type: "post",
                url: "<?php echo e(route('delete_category')); ?>",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    "id": id
                },
                dataType: 'json', // let's set the expected response format
                success: function(data) {
                    $(".R_category" + data.id).remove();

                },
                error: function(err) {
                    if (err.status == 422) { // when status code is 422, it's a validation issue
                        console.log(err.responseJSON);
                        $('#success_message_notifications').fadeIn().html(
                            '<div class="alert alert-danger border-0 alert-dismissible">' + err
                            .responseJSON.message + '</div>');


                    }
                }
            });

        });

        $(document).on("click", ".deletem_b", function(e) {
            e.preventDefault();
            if (confirm(`  Are you sure? `)) {
                var deletem_b = $(this).attr("deletem_b");
                $.ajax({
                    type: "post",
                    url: "<?php echo e(route('admin.order.delete')); ?>",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        id: deletem_b,
                    },
                    success: function(data) {
                        if (data.status == true) {


                        }
                        flashBox('success', ' تم الحذف');

                        $(".R_user" + data.id).remove();
                    },
                    error: function(reject) {},
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<!-- end page content -->

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/admin/orders/list.blade.php ENDPATH**/ ?>