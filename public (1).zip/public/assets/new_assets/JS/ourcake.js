
/************************************ start swiper *****************************************/
var swiper = new Swiper(".mySwiper", {
  pagination: {

  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});
/************************************ end swiper *****************************************/
