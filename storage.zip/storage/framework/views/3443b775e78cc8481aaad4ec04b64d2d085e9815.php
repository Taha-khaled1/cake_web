<?php $__env->startSection('content'); ?>


    <div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                             
                            <h4 class="page-title">الاقسام</h4>
                        </div>
                        <!--end page-title-box-->
                    </div>
                    <!--end col-->
                </div>
               <?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                

                <div class="row">
                    <div class="col-12">
                        <div class="card">


                            <div class="card-body">
                            <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-bs-toggle="tab" href="#Post" role="tab"
                                           aria-selected="true">الاقسام</a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#Settings" role="tab"
                                           aria-selected="false"> اضف قسم</a>
                                    </li>
                                </ul>

                            <div class="tab-content">
                              <div class="tab-pane p-3 active" id="Post" role="tabpanel">
                                <div class="table-responsive">
                                 <table id="example" class="table table-striped table-bordered" style="width:70%;">
                                    <thead>
                                    <tr>
                                        <th>الترتيب</th>
                                        <th>القسم</th>
                                         <th>العمليات</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="R_category<?php echo e($c->id); ?>">
                                        <td><?php echo e($c->ord); ?>  </td>
                                        <td><?php echo e($c->name); ?> </td>
                                         <td>  <a href="<?php echo e(route('admin.category.profile', $c->id)); ?>"><i class="icofont-edit  text-secondary font-40"></i></a>
                                        <a href=" " class="deletem_b" deletem_b="<?php echo e($c->id); ?>"><i class="icofont-trash  text-danger  "></i></a>
                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                 </table>
                                 </div>
                                 </div>
                                 <div class="tab-pane p-3" id="Settings" role="tabpanel">
                                        <div class="row">
                                        <div class="card">
                                        <form name="" method="post" action="<?php echo e(route('admin.category.save')); ?>"   enctype= "multipart/form-data" >
                                     <?php echo csrf_field(); ?>
 
                                        <div class="row">
                                            <br>
                                             <div class="mb-3 row">
                                             <div class="col-sm-9">
                                            <div class="form-check form-switch form-switch-success">
                                            <input class="form-check-input" value="1" name="featured" type="checkbox"  >
                                            <label class="form-check-label" for="customSwitchSuccess">عرض في الصفحة الرئيسية</label>
                                        </div>
                                        <div class="mb-4 row">
                                            <label for="example-text-input" class="col-sm-2 col-form-label text-end">الاسم</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" name="name" type="text" maxlength="50" id="example-text-input">
                                            </div>
                                        </div>
                                        <div class="mb-4 row">
                                            <label for="example-text-input" class="col-sm-2 col-form-label text-end">الاسم بالغة الانجليزية</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" name="name_en" type="text" maxlength="50" id="example-text-input">
                                            </div>
                                        </div>
                                         
                                            <div class="mb-4 row">
                                            <label for="example-text-input" class="col-sm-2 col-form-label text-end">الترتيب</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" name="ord" type="number" maxlength="50" id="example-text-input">
                                            </div>
                                        </div>
                                           <div class="mb-3 row">
                                       
                                            <label   class="col-sm-3 col-form-label text-end">الصورة الرئيسية</label>
                                            <div class="col-sm-9">
                                            <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <input type="file" name="img" class="form-control" value="<?php echo e(old('img')); ?>" />   
                                             </div>
                                        </div>
                                        </div>  
                                        </div><!--end row-->
                                        <div class="form-group mb-3 row">
                                        <div class="col-lg-9 col-xl-8 offset-lg-3">
                                            <button type="submit" class="btn btn-primary">
                                                حفظ
                                            </button>
                                             
                                        </div>
                                        </div>
                                    </form>
                                                </div>

                                            </div><!--end col-->
                                        </div><!--end row-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->


            </div><!-- container -->


        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.0.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>
 
<script>
$('.deletem_b').on("click", function (e) {
            e.preventDefault();
               
         var id = $(this).attr('deletem_b');
         
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('delete_category')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "id" : id },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                        $(".R_category"+ data.id).remove();
                       
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });
 </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/admin/categories/list.blade.php ENDPATH**/ ?>