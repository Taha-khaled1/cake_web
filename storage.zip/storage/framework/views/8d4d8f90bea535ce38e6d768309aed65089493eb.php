<?php $__env->startSection('title','تسجيل الدخول'); ?>
<?php $__env->startSection('content'); ?>

 
<!-- breadcrumb area start -->

<section class="content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-sm-10 col-10 text-center">
                <h1> <?php echo e(__('Create an account')); ?></h1>
                <form method="POST" action="<?php echo e(route('register')); ?>" class="ltn__form-box contact-form-box">
                    <?php echo csrf_field(); ?>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(\Session::has('error')): ?>
                                <small class="form-text text-danger">
                                    <?php echo e(\Session::get('error')); ?>

                                </small>
                                <?php endif; ?>
                    <input type="text" name="email" class="w-100 text-end p-2" id="user-name-or-email"  value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email')); ?>">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="phone"  class="w-100 text-end p-2 my-2" id="user-mobile"  value="<?php echo e(old('phone')); ?>" placeholder="<?php echo e(__('Mobile number')); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                
                    <input type="password" class="w-100 text-end p-2 my-2" name="password" aria-label="user-password" aria-describedby="user-password" placeholder="<?php echo e(__('Password')); ?>">
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="password" class="w-100 text-end p-2 my-2" name="password_confirmation" aria-label="user-password" aria-describedby="user-password" placeholder="<?php echo e(__('Confirm password')); ?>">
                    <a >
                        <button type="submit"><?php echo e(__('Create an account')); ?></button>
                    </a>
                </form>
                <p class="h6 pb-10"> <?php echo e(__('or')); ?> </p>
                <a href="<?php echo e(route('login')); ?>" class="btn"> <?php echo e(__('Return to the login page')); ?></a>
                    
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/auth/registerPage.blade.php ENDPATH**/ ?>