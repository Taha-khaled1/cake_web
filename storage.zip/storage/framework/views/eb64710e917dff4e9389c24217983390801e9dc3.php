<?php $__env->startSection('content'); ?>
 
<!-- breadcrumb area start -->

<!-- start boards -->
<section dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" >
<div class="container pr-60 pl-60">
    <div class="row">
             
        <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
        <?php echo $data; ?>

        <?php else: ?>
        <?php echo $data_en; ?>

        <?php endif; ?>
            
 
</div>
</div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('SitePage/js/plugins.js ')); ?>"></script>
<script src="<?php echo e(asset('SitePage/js/main.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/questions.blade.php ENDPATH**/ ?>