<!DOCTYPE html>
<html  dir="rtl">

<head>
    <title>فاتورة</title>
    <style> 
    body {
        font-family: Arial, sans-serif;
        font-size: 14px;
        line-height: 1.4;
        padding: 20px;
        direction: rtl;
    }

.container {
    max-width: 800px;
    margin: 0 auto;
    border: 1px solid #ddd;
    padding: 20px;
}

h1 {
    font-size: 24px;
    margin-bottom: 10px;
    text-align: center;
}

h2 {
    font-size: 20px;
    margin-top: 0;
    text-align: right;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th,
td {
    padding: 10px;
    text-align: right;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #f2f2f2;
}

.text-right {
    text-align: right;
}

.text-center {
    text-align: center;
}

.total td {
    border-top: 2px solid #333;
    font-weight: bold;
}

.invoice-details {
    margin-top: 20px;
}

.invoice-details p {
    margin: 0;
    text-align: right;
}

.invoice-details .address {
    margin-top: 10px;
    font-size: 16px;
    font-weight: bold;
    text-align: right;
}

@media  print {
    body {
        padding: 0;
    }

    .container {
        border: none;
    }

    h1 {
        margin-top: 0;
    }

    table {
        margin-top: 10px;
    }

    .invoice-details {
        margin-top: 20px;
    }

    .invoice-details .address {
        font-size: 14px;
    }
}
</style>
</head>

<body>
    <div class="container">
        <h1>فاتورة</h1>
        <h2>تفاصيل الفاتورة</h2>
        <table>
            <thead>
                <tr>
                    <th>اسم المنتج</th>
                    <th>الكميه</th>
                    <th>السعر</th>
                    <th>المجموع</th>
                </tr>
            </thead>





            

            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr  >
                <td><?php echo e($item->product_name); ?> </td> 
            
               
               
                <td><?php echo e($item->quantity); ?> </td>
                <td><?php echo e($item->product->price); ?></td>
                <td><?php echo e($item->product->price * $item->quantity); ?> </td>
                
            
                 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>














            <tfoot>
                <tr class="total">
                    <td colspan="3" class="text-right">المجموع الفرعي</td>
                    <td> <?php echo e($order->total + $order->discount - $order->shipping); ?> AED</td>
                </tr>
                <tr class="total">
                    <td colspan="3" class="text-right">شحن</td>
                    <td><?php echo e($order->shipping); ?> AED</td>
                </tr>
                <tr class="total">
                    <td colspan="3" class="text-right">الخصم</td>
                    <td><?php echo e($order->discount); ?>  AED</td>
                </tr>
                <tr class="total">
                    <td colspan="3" class="text-right">المجموع الإجمالي</td>
                    <td><?php echo e($order->total); ?> AED</td>
                </tr>
            </tfoot>
        </table>
        <div class="invoice-details">
            <p><strong>طريقة الدفع  : . </strong>  
            
            
            
            
            
                <?php if($order->payment_method == "cash"): ?>
                الدفع عند الاستلام
                <?php else: ?>
                بطاقة ائتمان
                <?php if($order->payment ): ?>
<?php if($order->payment->status == 'pending' ): ?>                                                                              
<span class="badge bg-primary"> في انتظار الدفع</span>
<?php elseif($order->payment->status == 'completed'): ?>
<span class="badge bg-success">  تم الدفع</span>
<?php elseif($order->payment->status == 'failed'): ?>
<span class="badge bg-danger"> تم الغاء الدفع</span>
<?php else: ?>
<span class="badge bg-danger"> فشل الدفع</span>
<?php endif; ?>
<?php endif; ?>  <?php endif; ?>
            
            
            
            
            
            
            
            
            
            
            </p>



            <div class="address">
                <p><strong>اسم العميل:</strong> <?php echo e($address->name); ?></p>
                <p><strong>البريد الاكتروني:</strong> <?php echo e($address->email); ?></p>
                <p><strong>الاماره:</strong> <?php echo e($address->area); ?></p>
                <p><strong>الشارع:</strong> <?php echo e($address->street); ?></p>
                <p><strong>الجادة:</strong> <?php echo e($address->Blvd); ?></p>
                <p><strong>رقم الهاتف:</strong> <?php echo e($address->phone); ?>  </p>
            </div>



        </div>
        <span>
            <img src="<?php echo e(asset('storage/users/' . $header_logo)); ?>" alt="logo-small" width="180px" height="100px">
        </span>
    </div>
    <script>
      window.print();
    </script>

</body>

</html>






<?php /**PATH /home/limogesd/public_html/resources/views/print.blade.php ENDPATH**/ ?>