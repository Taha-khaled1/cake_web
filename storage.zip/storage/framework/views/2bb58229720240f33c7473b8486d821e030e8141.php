<?php $__env->startSection('title','تواصل معنا'); ?>
<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/assets/new_assets/css/contact.css?'. time() )); ?>" rel="stylesheet" />

    <!-- BREADCRUMB AREA START -->
    
    <!-- BREADCRUMB AREA END -->

    <!-- CONTACT ADDRESS AREA START -->
    <section class="contact">
        <div class="hero">
            <div class="overlay"></div>
            <h1 class="text-light"><?php echo e(__('Contact Us')); ?></h1>
        </div>
    </section>
    
    <!-- CONTACT ADDRESS AREA END -->

    <!-- CONTACT MESSAGE AREA START -->
    <div class="container">
        <section class="details">
        <div class="row">
            <div class="address mt-5 text-lg-center text-center col-lg-8 col-md-6">
                <img src="<?php echo e(asset('storage/users/'. $header_logo )); ?>" alt="" style="width: 300px;height: 175px;">
                <div class="infoos">
                    <h4 class="text-secondary"> <?php echo e(__('Contact Us')); ?></h4>
                    <div class="flex align-items-center flex-column">
                        <h5><i class="fa-solid fa-envelope"></i> <?php echo e(__('Email')); ?>: </h5>
                        <span><?php echo e($setting->where('key','email')->first()->value); ?></span>
                    </div>
                    <div class="flex align-items-center flex-column">
                        <h5><i class="fa-solid fa-phone"></i> <?php echo e(__('phone')); ?>: </h5>
                        <span><?php echo e($setting->where('key','phone1')->first()->value); ?></span>
                    </div>
                    <div class="flex align-items-center flex-column">
                        <h5><i class="fa-solid fa-location-dot"></i> <?php echo e(__('Address')); ?>: </h5>
                        <span><?php echo e(strip_tags($setting->where('key','address')->first()->value)); ?></span>
                    </div>
                </div>
                <ul class="list-unstyled d-flex gap-2 justify-content-lg-center justify-content-center">
                    <li>
                        <a href="<?php echo e($setting->where('key','facebook_link')->first()->value); ?>">
                            <i class="fab fa-facebook mt-3"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($setting->where('key','twitter_link')->first()->value); ?>">
                            <i class="fab fa-twitter mt-3"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($setting->where('key','instagram_link')->first()->value); ?>">
                            <i class="fab fa-instagram mt-3"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($setting->where('key','Linkedin_link')->first()->value); ?>">
                            <i class="fa-brands fa-linkedin mt-3"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($setting->where('key','youtube_link')->first()->value); ?>">
                            <i class="fa-brands fa-youtube mt-3"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo e(session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <form id="#" action="<?php echo e(route('storeMessage')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="d-flex gap-2 mb-2">
                        <div class="relative mb-4">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input class="p-2 w-100 text-end" type="text" name="name" maxlength="100" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="relative mb-4">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input class="p-2 w-100 text-end" type="email" name="email" maxlength="100" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email')); ?>">
                        </div>
                    </div>
                    <div class="relative mb-4">
                        <?php $__errorArgs = ['type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <select class="select-2 w-100 p-2 mb-4 text-end" name="city">
                            <option><?php echo e(__('Choose the region')); ?></option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </select>
                    </div>
                    <div class="relative mb-4 w-100 d-flex flex-column">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="w-100 mb-2 d-flex">
                            <input class="p-2 w-100" type="text" name="phone" maxlength="80" placeholder="<?php echo e(__('phone')); ?>"  value="<?php echo e(old('phone')); ?>">
                        </div>
                    </div>
                    <div class="relative mb-4">
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <textarea name="message" rows="10" class="p-2 w-100" maxlength="300" placeholder=" <?php echo e(__('Message')); ?>"><?php echo e(old('message')); ?></textarea>
                    </div>
                    <div class="text-center">
                        <button class="btn btn-secondary w-25 mt-3" type="submit"><?php echo e(__('Send')); ?></button>
                    </div>
                    <p class="form-messege mb-0 mt-20"></p>
                </form>
            </div>
        </div>
        </section>
    </div>
    
    <!-- CONTACT MESSAGE AREA END -->
    
    <!-- GOOGLE MAP AREA START -->
    <div class="map" style="margin-top: 120px;">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9334.271551495209!2d-73.97198251485975!3d40.668170674982946!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25b0456b5a2e7:0x68bdf865dda0b669!2sBrooklyn%20Botanic%20Garden%20Shop!5e0!3m2!1sen!2sbd!4v1590597267201!5m2!1sen!2sbd" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <!-- GOOGLE MAP AREA END -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>   

<script src="<?php echo e(asset('SitePage/js/plugins.js ')); ?>"></script>
<script src="<?php echo e(asset('SitePage/js/main.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/contact.blade.php ENDPATH**/ ?>