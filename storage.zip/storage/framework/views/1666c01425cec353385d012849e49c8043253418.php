 <?php $__env->startSection('content'); ?>

 <!-- breadcrumb area start -->

<!-- end breadcrumb -->
<?php if($errors->any()): ?>
    <div class="alert alert-danger col-md-4">
        <?php echo e(__('Verify the information entered')); ?>

    </div>
<?php endif; ?> 
 <!-- my account wrapper start -->
 <div class="my-account-wrapper section-padding" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
            <div class="container">
                <div class="section-bg-color">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- My Account Page Start -->
                            <div class="myaccount-page-wrapper">
                                <!-- My Account Tab Menu Start -->
                                <div class="row">
                                    <div class="col-lg-3 col-md-4">
                                        <div class="myaccount-tab-menu nav" role="tablist">
                                            <a href="#dashboad" class="active" data-bs-toggle="tab"><i class="fa fa-dashboard"></i>
                                            <?php echo e(__('Control Board')); ?></a>
                                            <a href="#orders" data-bs-toggle="tab"><i class="fa fa-cart-arrow-down"></i>
                                            <?php echo e(__('Requests')); ?></a>
                                            <a href="#download" data-bs-toggle="tab"><i class="fa fa-map-marker"></i>
                                            <?php echo e(__('Addresses')); ?></a> 
                                            <a href="#address-edit" data-bs-toggle="tab"><i class="fa fa-map-marker"></i>
                                            <?php echo e(__('Add an address')); ?></a>
                                            <a href="#account-info" data-bs-toggle="tab"><i class="fa fa-user"></i>  <?php echo e(__('Account details')); ?></a>
                                             <form method="POST" action="<?php echo e(route('logout')); ?>" class="mr-70 ml-70" >
                                              <?php echo csrf_field(); ?>
                                          <a href="<?php echo e(route('logout')); ?>" class="nav-link pr-40 pl-40"
                                              onclick="event.preventDefault();
                                              this.closest('form').submit();"><i class="fa fa-sign-out"></i>
                                            <?php echo e(__('Sign Out')); ?> </a> 
                                          </form> 
                                        </div>
                                    </div>
                                    <!-- My Account Tab Menu End -->

                                    <!-- My Account Tab Content Start -->
                                    <div class="col-lg-9 col-md-8">
                                        <div class="tab-content" id="myaccountContent">
                                            <!-- Single Tab Content Start -->
                                            <div class="tab-pane fade show active" id="dashboad" role="tabpanel">
                                                <div class="myaccount-content">
                                                    <h5><?php echo e(__('Control Board')); ?></h5>
                                                    <div class="welcome">
                                                        <p> <?php echo e(__('Hello!')); ?> <strong> <?php echo e(\Illuminate\Support\Facades\Auth::user()->fname); ?></strong>  </p> 
                                                          <p>   <?php echo e(__('From your account dashboard, you can view and manage your recent orders, shipping and billing addresses, and edit your password and account details.')); ?> </p>
                                                </div></div>
                                            </div>
                                            <!-- Single Tab Content End -->

                                            <!-- Single Tab Content Start -->
                                            <div class="tab-pane fade" id="orders" role="tabpanel">
                                                <div class="myaccount-content">
                                                    <h5><?php echo e(__('Requests')); ?></h5>
                                                    <div class="myaccount-table table-responsive text-center">
                                                        <table class="table table-bordered">
                                                            <thead class="thead-light">
                                                              <tr>
                                                                <th scope="col"> <?php echo e(__('Order number')); ?></th>
                                                                <th scope="col"> <?php echo e(__('Total')); ?></th>
                                                                <th scope="col"> <?php echo e(__('Quantity')); ?> </th>
                                                                <th scope="col"> <?php echo e(__('Status')); ?> </th>
                                                                <th scope="col"> <?php echo e(__('Cancel order')); ?></th>
                                                                <th scope="col"> <?php echo e(__('Payment status')); ?></th>
                                                                <th scope="col"> <?php echo e(__('View')); ?></th>
                                                                
                                                              </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = \Illuminate\Support\Facades\Auth::user()->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <tr class="R_order<?php echo e($order->id); ?>">
                                                              <th scope="row"><?php echo e($order->id); ?></th>
                                                              <td>  <?php echo e($order->total); ?>  <?php echo e(__('AED')); ?></td>
                                                              <td>    <?php echo e($order->items->count()); ?> </td>
                                                                
                                                                <th > <?php if($order->status == 0): ?> <?php echo e(__('Rejected')); ?><?php endif; ?> <?php if($order->status == 1): ?> <?php echo e(__('Requested')); ?> <?php endif; ?> <?php if($order->status == 2): ?>  <?php echo e(__('is shipped')); ?> <?php endif; ?> <?php if($order->status == 3): ?> <?php echo e(__('Delivered')); ?> <?php endif; ?> </th>
                                                                <th> <?php if($order->payment_method == "cash"): ?> <?php if($order->status == 1): ?><a href="" class="deletem_order" deletem_order="<?php echo e($order->id); ?>" > <?php echo e(__('cancel')); ?></a><?php endif; ?> <?php endif; ?></th>
                                                                <td>    <?php if($order->payment_method == "cash"): ?>
                                                                        الدفع عند الاستلام
                                                                        <?php else: ?>
                                                                        بطاقة ائتمان
                                                                        <?php if($order->payment ): ?>
                                                                        <?php if($order->payment->status == 'pending' ): ?>                                                                              
                                                                        <span class="badge bg-primary"> في انتظار الدفع</span>
                                                                        <?php elseif($order->payment->status == 'completed'): ?>
                                                                        <span class="badge bg-success">  تم الدفع</span>
                                                                        <?php elseif($order->payment->status == 'failed'): ?>
                                                                        <span class="badge bg-danger"> تم الغاء الدفع</span>
                                                                        <?php else: ?>
                                                                        <span class="badge bg-danger"> فشل الدفع</span>
                                                                        <?php endif; ?>
                                                                        <?php endif; ?>  <?php endif; ?> </td>
                                                                <th ><a href="showorder/<?php echo e($order->id); ?>" > <?php echo e(__('show')); ?></a> </th>
                                                              </tr>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <h5><?php echo e(__('Special orders')); ?></h5>
                                                    <div class="myaccount-table table-responsive text-center">
                                                        <table class="table table-bordered">
                                                            <thead class="thead-light">
                                                              <tr>
                                                                <th scope="col"> <?php echo e(__('Order number')); ?></th>
                                                                <th scope="col"> <?php echo e(__('Flavor')); ?></th>
                                                                <th scope="col"> <?php echo e(__('Weight')); ?> </th>
                                                                <th scope="col"> <?php echo e(__('Status')); ?> </th>
                                                                <th scope="col"> <?php echo e(__('Cancel order')); ?></th>
                                                                <th scope="col"> <?php echo e(__('image')); ?></th>
                                                                <th scope="col"> <?php echo e(__('design')); ?></th>
                                                                
                                                              </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = \Illuminate\Support\Facades\Auth::user()->Special_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <tr class="R_sorder<?php echo e($order->id); ?>">
                                                              <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                              <td>  <?php echo e($order->flavor); ?> </td>
                                                              <td>   <?php echo e($order->Weight); ?> </td>
                                                                
                                                                <th > <?php if($order->status == 0): ?> <?php echo e(__('Rejected')); ?><?php endif; ?> <?php if($order->status == 1): ?> <?php echo e(__('Requested')); ?> <?php endif; ?> <?php if($order->status == 2): ?>  <?php echo e(__('is shipped')); ?> <?php endif; ?> <?php if($order->status == 3): ?> <?php echo e(__('Delivered')); ?> <?php endif; ?> </th>
                                                                <th>   <?php if($order->status == 1): ?><a href="" class="deletem_sorder" deletem_order="<?php echo e($order->id); ?>" > <?php echo e(__('cancel')); ?></a><?php endif; ?> </th>
                                                                <td>    <?php if($order->img): ?>
                                                                <img src="<?php echo e(asset('/storage/property/'.$order->img)); ?>"   alt="<?php echo e($order->id); ?>" width="100">
                                                                <?php endif; ?>  </td>
                                                                                        <th >   <?php if($order->design): ?>
                                                                <img src="<?php echo e(asset('/storage/property/'.$order->design)); ?>"   alt="<?php echo e($order->id); ?>" width="100">
                                                                <?php endif; ?>  </th>
                                                              </tr>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Single Tab Content End -->

                                            <!-- Single Tab Content Start -->
                                            <div class="tab-pane fade" id="download" role="tabpanel">
                                                <div class="myaccount-content">
                                                    <h5><?php echo e(__('Addresses')); ?></h5>
                                                    <div class="myaccount-table table-responsive text-center">
                                                        <table class="table table-bordered">
                                                            <thead class="thead-light">
                                                             <tr>
                                                              <th scope="col"> <?php echo e(__('Name')); ?> </th>
                                                              <th scope="col">   <?php echo e(__('Email')); ?> </th>
                                                              <th scope="col">   <?php echo e(__('Region')); ?></th>
                                                              <th scope="col"> <?php echo e(__('Street')); ?></th>
                                                              <th scope="col"> <?php echo e(__('Mobile number')); ?></th>
                                                              <th scope="col"> <?php echo e(__('Apartment/House')); ?> </th>
                                                              <th scope="col">  <?php echo e(__('Blvd')); ?> </th>
                                                              <th scope="col">  <?php echo e(__('delete')); ?> </th>
                                                            </tr>
                                                          </thead>
                                                          <tbody>
                                                              <?php $__currentLoopData = \Illuminate\Support\Facades\Auth::user()->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="R_address<?php echo e($address->id); ?>">
                                                            <th scope="row"><?php echo e($address->name); ?></th>
                                                              <td><?php echo e($address->email); ?></td>
                                                              <td ><?php echo e($address->area); ?></td>
                                                              <th ><?php echo e($address->street); ?></th>
                                                              <td><?php echo e($address->phone); ?></td>
                                                              <td><?php echo e($address->house); ?></td>
                                                              <td><?php echo e($address->Blvd); ?></td>
                                                              <td><a href="" class="deletem_b" deletem_b="<?php echo e($address->id); ?>" ><?php echo e(__('delete')); ?></a></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Single Tab Content End -->

                                            <!-- Single Tab Content Start -->
                                             
                                            <!-- Single Tab Content End -->

                                            <!-- Single Tab Content Start -->
                                            <div class="tab-pane fade" id="address-edit" role="tabpanel">
                                                <div class="myaccount-content">
                                                    <h5><?php echo e(__('The following addresses will be used on the checkout page by default')); ?></h5>
                                                    <form method="POST" action="<?php echo e(route('user.location.save')); ?>"  >
                            <?php echo csrf_field(); ?>
                            <div class="pb-8">
            <p style="color:red">* <label style="color:black" > <?php echo e(__('Name')); ?></label></p> 
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" class="form-control" name="name"  value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Name')); ?> " maxlength="100" required>
              </div><br>
      <div class="pb-8">
            <p style="color:red">* <label style="color:black" > <?php echo e(__('Email')); ?></label></p> 
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" class="form-control" name="email"  value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email')); ?>" maxlength="100" required>
              </div><br>
         <div >
            <p style="color:red">* <label style="color:black" >  <?php echo e(__('Region')); ?> </label></p> 
                <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <select name="area"  >
                                                     
                                                     <?php if( old('area') ): ?>
                                                     <option value="<?php echo e(old('area')); ?>" selected><?php echo e(old('area')); ?></option><?php endif; ?>
                                                     <option value=""> <?php echo e(__('Choose the regioan')); ?> </option>
                                                     <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option value="<?php echo e($ca->id); ?>"> <?php echo e($ca->name); ?></option>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                 </select>               </div><br><br>
              <div class="pb-8">
            <p style="color:red">* <label style="color:black" > <?php echo e(__('Street')); ?> </label></p> 
                <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" class="form-control" name="street"  value="<?php echo e(old('street')); ?>" placeholder=" <?php echo e(__('Street')); ?>   " maxlength="100" required>
              </div><br>
              <div class="pb-8">
             <label style="color:black" >  <?php echo e(__('Add an address')); ?> </label><br>
          
                <input type="text" class="form-control" name="Blvd"  value="<?php echo e(old('Blvd')); ?>" placeholder=" <?php echo e(__('Blvd')); ?>   " maxlength="100"  ><br>
              </div><br>
              <div class="pb-8">
            <label style="color:black" > <?php echo e(__('Apartment/House')); ?>  </label> 
               
                <input type="text" class="form-control" name="house"  value="<?php echo e(old('house')); ?>" placeholder=" <?php echo e(__('Apartment/House')); ?>   " maxlength="100" >
              </div><br>
        <div class="pb-8">
        <p style="color:red">* <label style="color:black" >  <?php echo e(__('Mobile number')); ?> </label></p> 
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="form-text text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="<?php echo e(__('Mobile number')); ?> " maxlength="100" required >
          </div><br>
          <input type="submit" class="btn btn-sqr" value=" <?php echo e(__('Add an address')); ?>  ">

</form>
                                                     
                                                </div>
                                            </div>
                                            <!-- Single Tab Content End -->

                                            <!-- Single Tab Content Start -->
                                            <div class="tab-pane fade" id="account-info" role="tabpanel">
                                                <div class="myaccount-content">
                                                    <h6><?php echo e(__('The following addresses will be used on the checkout page by default')); ?> </h6><hr><br>
                                                    <div class="account-details-form">
                                                    <form  name="learner_security" id="learner_security" enctype="multipart/form-data" method="post" action="">
                        <?php echo csrf_field(); ?>
                        <div class="pb-8">
                           <p style="color:red">* <label style="color:black" > <?php echo e(__('First name')); ?></label></p>
                           <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="form-text text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           <input type="text" class="form-control" name="fname"  value="<?php echo e(Auth::user()->fname); ?>" placeholder=" <?php echo e(__('First name')); ?> " maxlength="100" required>
                        </div>
                        <br>
                        <div class="pb-8">
                           <p style="color:red">* <label style="color:black" > <?php echo e(__('Second name')); ?></label></p>
                           <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="form-text text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           <input type="text" class="form-control"  name="lname"  value="<?php echo e(Auth::user()->lname); ?>" placeholder=" <?php echo e(__('Second name')); ?> " maxlength="100" required>
                        </div>
                        <br>
                        <div class="pb-8">
                           <p style="color:red">* <label style="color:black" > <?php echo e(__('Email')); ?></label></p>
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="form-text text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           <input type="text" class="form-control" name="email"   value="<?php if(Auth::user()->email): ?> <?php echo e(Auth::user()->email); ?> <?php endif; ?>" placeholder=" <?php echo e(__('Email')); ?>" maxlength="100" required>
                        </div>
                        <br> 
                        <label for="user-password" class="form-label"> <?php echo e(__('Change Password')); ?> </label>
                        <div class="input-group">
                           <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="form-text text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="password" class="form-control" class="form-control" name="old_password" aria-label="user-password" aria-describedby="user-password" placeholder="<?php echo e(__('Old Password')); ?> ">
                        </div>
                        <br>
                        <div class="input-group">
                           <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="form-text text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="password" class="form-control" class="form-control" name="new_password" aria-label="user-password" aria-describedby="user-password" placeholder=" <?php echo e(__('New password')); ?> ">
                        </div>
                        <br>
                        <div class="mb-3">
                           <div class="input-group">
                              <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <small class="form-text text-danger"><?php echo e($message); ?></small>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               <input type="password" class="form-control" class="form-control" name="password_confirmation" aria-label="user-password" aria-describedby="user-password" placeholder=" <?php echo e(__('Confirm password')); ?> ">
                           </div>
                        </div><br>
                        <button id="learner_security_btn" class="btn btn-sqr"> <?php echo e(__('Save changes')); ?>  </button>

                   </div>
                  </form>
                                                    </div>
                                                </div>
                                            </div> <!-- Single Tab Content End -->
                                        </div>
                                    </div> <!-- My Account Tab Content End -->
                                </div>
                            </div> <!-- My Account Page End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- my account wrapper end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script src="https://code.jquery.com/jquery-3.5.0.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>
 
<script>
$('.deletem_b').on("click", function (e) {
            e.preventDefault();
               
         var id = $(this).attr('deletem_b');
         
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('delete_address')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "id" : id },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                        $(".R_address"+ data.id).remove();
                        flashBox('success', ' تم الحذف');

                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });
    

    $('.deletem_order').on("click", function (e) {
            e.preventDefault();
            
        if (confirm("هل انت متأكد من الغاء الطلب") == true) {

         var id = $(this).attr('deletem_order');
         
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('delete_order')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "id" : id },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                        $(".R_order"+ data.id).remove();
                        flashBox('success', ' تم الحذف');

                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
              }
    });


    $('.deletem_sorder').on("click", function (e) {
            e.preventDefault();
            
        if (confirm("هل انت متأكد من الغاء الطلب") == true) {

         var id = $(this).attr('deletem_order');
         
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('delete_sorder')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "id" : id },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                        $(".R_sorder"+ data.id).remove();
                        flashBox('success', ' تم الحذف');

                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
              }
    });


$('#learner_security_btn').on('click' , function (e) {
            e.preventDefault();
            $(document).find('#err').remove();
            $.ajax({
                type: "post",
                url: "<?php echo e(route('user.settings_security.save')); ?>",
                data: $("#learner_security").serialize(),
                dataType: 'json',              // let's set the expected response format
                success: function (data) {
                    //console.log(data);
                    flashBox('success', 'تم تحديث البيانات');

                     
                },
                error: function (err) {
                    if (err.status == 422) { // when status code is 422, it's a validation issue
                        console.log(err.responseJSON);
                        $('#success_message_security').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible"> تأكد من البيانات المدخلة</div>');
                        document.body.scrollTop = document.documentElement.scrollTop = 0;

                        // you can loop through the errors object and show it to the user
                        console.warn(err.responseJSON.errors);
                        // display errors on each form field
                        $.each(err.responseJSON.errors, function (i, error) {
                            var el = $(document).find('[name="' + i + '"]');
                            //el.nextAll().remove();
                            el.after($(' <div id="err" class="input-group"><span  style="color: red;">' + error[0] + '</span> </div>'));
                        });
                    }
                }
            });

        });



 </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/userPages/myAccount.blade.php ENDPATH**/ ?>