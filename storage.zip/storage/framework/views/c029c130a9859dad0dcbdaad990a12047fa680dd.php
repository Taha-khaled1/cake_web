<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/assets/new_assets/css/who-us.css?'. time() )); ?>" rel="stylesheet" />

<!-- breadcrumb area start -->

<!-- start boards -->
<section dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" >
<div class="container pr-60 pl-60">
    <div class="row"> 
    
        <div class="about">
            <div class="container">
                <h1 class="text-end mt-4"><?php echo e(__('Delivery Policy')); ?></h1>
                <p>
                    <?php echo e(__('Method used for delivery We use chiller car delivery any place in UAE, not accept same day order (need order at least one day advance)')); ?>

                </p>
                <p>
                    <?php echo e(__('Delivery Locations We do delivery all over UAE | Dubai, Abu Dhabi, Sharjah, Ajman, Al Ain, Ras Al Khaimah, Fujairah, Umm al Quwain.')); ?>

                </p>
                <p>
                    <?php echo e(__('Delivery Fees')); ?>

                </p>
                <p>
                    <?php echo e(__('Delivery cost to the customer')); ?>

                </p>
            </div>
        </div>
</div>
</div>
</section> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('SitePage/js/plugins.js ')); ?>"></script>
<script src="<?php echo e(asset('SitePage/js/main.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/Shipping.blade.php ENDPATH**/ ?>