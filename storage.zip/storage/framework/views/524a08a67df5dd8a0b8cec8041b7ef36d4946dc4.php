<?php echo e($slot); ?>

<?php /**PATH /home/limogesd/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>