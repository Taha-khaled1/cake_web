<?php $__env->startSection('content'); ?>
<!-- hero slider area start -->
<div style="width: 96%;margin: auto;">
    <section class="slider">
        <div class="hero-slider-active">
        <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- single slider item start -->
            <div class="hero-single-slide hero-overlay">
            
                <div class="hero-slider-item bg-img" data-bg="<?php echo e(asset('storage/property/'.$carousel->image)); ?>" style="height:650px;border-radius:15px;object-fit:cover;background-repeat:no-repeat;width:100%;background-size:cover;">
                    
                </div>
            </div>
            <!-- single slider item start -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </section>
</div>
<!-- hero slider area end -->
    <section class="shop mt-5"> 
        <div class="container">
            <div class="text-center">
                <h2><?php echo e(__('Make your event special with us')); ?></h2>
                <h6><?php echo e(__('We cater to your requests for all occasions')); ?></h6>
                <button class="btn btn-secondary mt-4"><a href="<?php echo e(route('specialorder')); ?>" class="text-decoration-none text-light">تسوق الان</a></button>
            </div>
        </div>
    </section>
 <!-- product area start -->
 <br> <br>
 <section class="last-product">
            <div class="container">
                <div class="row">
                    <div class="col-12" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
                        <!-- section title start -->
                            <h1 class="text-center me-4"><?php echo e(__('Latest products')); ?></h1>
                        <!-- section title start -->
                        <div class="products owl-carousel owl-theme">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item product text-center mb-4">
                                
                                <a href="<?php echo e(route('viewProperty',$product->id)); ?>">
                                    <img class="pri-image" src="<?php echo e(asset('/storage/property/'.$product->image)); ?>" alt="product">
                                </a>
                                <a href="<?php echo e(route('viewProperty',$product->id)); ?>" class="text-decoration-none">

                                    <h2 class="fs-5 m-3">
                                        <?php if($product->name_en != null): ?>
                                                            <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
                                                            <?php echo e($product->name); ?>

                                                            <?php else: ?>
                                                            <?php echo e($product->name_en); ?>

                                                            <?php endif; ?> <?php else: ?>
                                                            <?php echo e($product->name); ?>

                                                            <?php endif; ?>
                                    </h2>
                                </a>
                                <div class="d-flex align-items-center justify-content-center gap-4">
                                    <p class="text-secondary m-0"><?php echo e($product->price); ?> <?php echo e(__('AED')); ?></p>
                                    <div class="cart-hover">
                                        <button class="btn btn-sm btn-cart add_cart border rounded" product_id="<?php echo e($product->id); ?>" href="#"><?php echo e(__('Add to cart')); ?></button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </section>
        <!-- product area end -->
        <!--== Add Swiper Pagination ==-->
        <!-- <div class="swiper-pagination"></div> -->
      </div>
    </section>
    <!--== End Hero Area Wrapper ==-->

 <!-- latest blog area start -->
 <div class="container">
    <section class="best-seller">
                    <div dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
                        <!-- section title start -->
                        <div class=""   >
                            <h1 ><?php echo e(__('Categories')); ?></h2>
                         </div>
                        <!-- section title start -->
                    </div>
                </div>
                <div class="">
                    <div class="col-12">
                        <div class="blog-carousel-active slick-row-10 slick-arrow-style">
                        <?php $__currentLoopData = $categores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ca->img): ?>
                            <!-- blog post item start -->
                            <div class="blog-post-item">
                                <figure class="blog-thumb">
                                    <a href="<?php echo e(route('category_property',$ca->id)); ?>" class="d-flex justify-content-center">
                                        <img src="<?php echo e(asset('/storage/property/'.$ca->img)); ?>" alt="ca image">
                                    </a>
                                </figure>
                                <div class="blog-content"> 
                                    <h5 class="text-center" >
                                        <a href="<?php echo e(route('category_property',$ca->id)); ?>" style="color:#F3AABB;"><?php if($ca->name_en != null): ?>
                                        <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
                                        <?php echo e($ca->name); ?>

                                        <?php else: ?>
                                        <?php echo e($ca->name_en); ?>

                                        <?php endif; ?> <?php else: ?>
                                        <?php echo e($ca->name); ?>

                                        <?php endif; ?></a>
                                    </h5>
                                </div>
                            </div>
                            <!-- blog post item end -->
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </div>
                    </div>
            </section>
        </div>
        <!-- latest blog area end --> 

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?> 

  <script>
$('.liked').click(function(anyothername) {
        //  e.preventDefault();
               
         var id = $(this).attr('property');
         var val = $(this).val();
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('property.like')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "id" : id 
                      },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                         
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });

    
$('.add_cart').on("click", function (e) {
            e.preventDefault();
               
         var id = $(this).attr('product_id');
         
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('cart.store')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "product_id" : id,
                     "quantity" : 1},
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                      flashBox('success', '<?php echo e(__('Added to cart')); ?>');
                       
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });
</script>
<?php $__env->stopPush(); ?>
 
<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/homePage.blade.php ENDPATH**/ ?>