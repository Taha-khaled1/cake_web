<?php $__env->startSection('content'); ?> 









<div style="width:100%; height:200 ">
    <?php echo $chartjs->render(); ?>

</div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/charts2.blade.php ENDPATH**/ ?>