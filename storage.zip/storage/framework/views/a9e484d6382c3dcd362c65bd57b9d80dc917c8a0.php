
    <!-- Scroll to top start -->
    <div class="scroll-top not-visible">
        <i class="fa fa-angle-up"></i>
    </div>
    <!-- Scroll to Top End -->

    <!-- footer area start -->
    <footer dir="rtl">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center flex-column">
                        <a href="<?php echo e(route('viewHomePage')); ?>">
                            <img src="<?php echo e(asset('storage/users/'. $header_logo )); ?>" alt=" logo">
                        </a>
                        <p style="
                                font-size: 14px;
                                color: #975d8d;
                                margin: 10px 0 20px;
                            "><?php echo e(__('We are Limoges Foundation for Cake and Sweets, we are distinguished by the best skilled hands in making cakes, decorating them and extracting the best international flavors in the world of cakes')); ?></p>
                    </div>
                    <div class="text-end col-lg-2 col-md-4 col-6">
                        <ul class="list-unstyled">
                            <li><?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?> <?php echo $address; ?> <?php else: ?> <?php echo $addressen; ?> <?php endif; ?> </li>
                        </ul>
                    </div>
                    <div class="text-end col-lg-2 col-md-4 col-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('questions')); ?>" class="text-decoration-none"><?php echo e(__('Common questions')); ?></a></li>
                            <li><a href="<?php echo e(route('register')); ?>" class="text-decoration-none"><?php echo e(__('Register')); ?></a></li>
                            <li><a href="<?php echo e(route('login')); ?>" class="text-decoration-none"><?php echo e(__('Sign In')); ?></a></li>
                            <li><a href="<?php echo e(route('about')); ?>" class="text-decoration-none"><?php echo e(__('About Us')); ?></a></li>
                        </ul>
                    </div>
                    <div class="text-end col-lg-2 col-md-4 col-6 mb-3">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('Shipping')); ?>" class="text-decoration-none"><?php echo e(__('Shipping and receiving')); ?></a></li>
                            <li><a href="<?php echo e(route('policy')); ?>" class="text-decoration-none"><?php echo e(__('Privacy policy')); ?></a></li>
                            <li><a href="<?php echo e(route('conditions')); ?>" class="text-decoration-none"><?php echo e(__('Terms and Conditions')); ?></a></li>
                            <li><a href="<?php echo e(route('viewContact')); ?>" class="text-decoration-none"><?php echo e(__('Contact Us')); ?></a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-4 text-end row">
                        <ul class="list-unstyled col-6 col-md-12">
                            <li>
                                <a class="text-decoration-none fs-6"><?php echo e(__('Newsletter subscription')); ?></a>
                            </li>
                            <li class="mt-2">
                                <form name="subscriber" id="subscriber" enctype="multipart/form-data" method="post" action="" class="newsletter-inner"  >
                                <?php echo csrf_field(); ?>
                                <input type="email" class="news-field" id="mc-email" type="email" name="email" maxlength="90" id="a1" placeholder="<?php echo e(__('Enter email')); ?>">
                                <div id="success_message_subscriber d-none"></div>
                                </form>
                            </li>
                        </ul>
                        
                        <div class="d-flex justify-content-start mb-3 col-6  col-md-12">
                            <ul class="icon list-unstyled d-flex gap-2 ">
                                <li>
                                    <a href="<?php echo e($facebook_link); ?>"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="<?php echo e($twitter_link); ?>"><i class="fa fa-twitter"></i></a>&nbsp; 
                                </li>
                                <li>
                                    <a href="<?php echo e($instagram_link); ?>"><i class="fa fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
                <div class="line"></div>
                <div class="mt-4">
                    <p class="text-center" style="margin: -20px 0px 3px;">Copyright © <a target="_blank" href="https://instagram.com/nanots.ae?igshid=Yzg5MTU1MDY=" class="text-decoration-none"><?php echo e(__('NTS')); ?> </a></p>
                </div>
    </footer>
    <!-- footer area end -->
<?php /**PATH /home/limogesd/public_html/resources/views/layouts/layoutSite/Footer.blade.php ENDPATH**/ ?>