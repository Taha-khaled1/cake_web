<?php if(\Session::has('error')): ?>



    <div class="alert alert-danger border-0 alert-dismissible">
        <?php echo \Session::get('error'); ?>

    </div>
<?php endif; ?><?php /**PATH /home/limogesd/public_html/resources/views/layouts/error.blade.php ENDPATH**/ ?>