<?php if(\Session::has('success')): ?>



    <div class="alert alert-success border-0 alert-dismissible">
        <?php echo \Session::get('success'); ?>

    </div>
<?php endif; ?><?php /**PATH /home/limogesd/public_html/resources/views/layouts/success.blade.php ENDPATH**/ ?>