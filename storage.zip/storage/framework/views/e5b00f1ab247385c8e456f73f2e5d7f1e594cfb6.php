<?php $__env->startSection('title','نتائج البحث'); ?>

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/assets/new_assets/css/ourcake.css?'. time() )); ?>" rel="stylesheet" />

 <!-- breadcrumb area start -->
 
        <!-- breadcrumb area end -->
             <!-- page main wrapper start -->
             <div class="shop-main-wrapper section-padding">
            <div class="container">
                <div class="row">
                <?php if( $products->count() == 0 ): ?> <h3 class="mb-30 text-center">    <?php echo e(__('No results found.')); ?> </h3><?php endif; ?>

                    <!-- shop main wrapper start -->
                    <div class="col-lg-12" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
                        <div class="shop-product-wrapper">
                            <!-- shop product top wrap start -->
                            
                            <!-- shop product top wrap start -->

                            <!-- product item list wrapper start -->
                            <div class="sorts">
                                <div class="container">
                                    <h1 class="text-center mb-5"><?php echo e(__('Our products')); ?></h1>
                                    <div class="photos d-flex flex-wrap gap-5 justify-content-center">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                            <!-- product single item start -->
                                            <div class="sort text-center relative">
                                                <!-- product grid start -->
                                                    <a href="<?php echo e(route('viewProperty',$product->id)); ?>">
                                                        <img class="pri-img" src="<?php echo e(asset('/storage/property/'.$product->image)); ?>" alt="product">
                                                    </a> 
                                                    <h4 >
                                                        <?php if($product->name_en != null): ?>
                                                        <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
                                                        <?php echo e($product->name); ?>

                                                        <?php else: ?>
                                                        <?php echo e($product->name_en); ?>

                                                        <?php endif; ?> <?php else: ?>
                                                        <?php echo e($product->name); ?>

                                                        <?php endif; ?>
                                                    </h4>
                                                    <div class="d-flex justify-content-between mt-3 px-5 buttons-dev">
                                                        <p class="price-regular"><?php echo e($product->price); ?> <?php echo e(__('AED')); ?></p>
                                                        <a class="btn btn-cart add_cart" product_id="<?php echo e($product->id); ?>" href="#"><?php echo e(__('Add to cart')); ?></a>
                                                        <a class="add-wishlist liked"  property="<?php echo e($product->id); ?>" value="1" name="like" >
                                                            <i class="pe-7s-like" <?php if(Auth::user()): ?> <?php if( Auth::user()->like->where('property_id', $product->id)->first() ): ?> style="color:red;" onclick="style.color = 'black' "<?php else: ?> onclick="style.color = 'red' "  <?php endif; ?>  <?php else: ?> onclick="style.color = 'red' "  <?php endif; ?>   ></i>
                                                        </a>
                                                    </div>
                                                
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                    <!-- product grid end -->
                                        
                                    <!-- product list item end -->
                                    <!-- product list item end -->
                                </div>
                                <!-- product single item start -->

                                
                            </div>
                            <!-- product item list wrapper end -->

                            
                            <!-- end pagination area -->
                        </div>
                    </div>
                    <!-- shop main wrapper end -->
                </div>
            </div>
        </div>
    <!--== End Product Area Wrapper ==-->

 <!-- end boards -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?> 

  <script>
$('.liked').click(function(anyothername) {
              //  e.preventDefault();
               
         var id = $(this).attr('property');
         var val = $(this).val();
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('property.like')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "id" : id 
                      },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                         
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });

    
$('.add_cart').on("click", function (e) {
            e.preventDefault();
               
         var id = $(this).attr('product_id');
         
         
         $.ajax({
                type: "post",
                url: "<?php echo e(route('cart.store')); ?>",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                     "product_id" : id,
                     "quantity" : 1},
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                      flashBox('success', 'تمت الاضافة الى السلة');
                       
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#success_message_notifications').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/products.blade.php ENDPATH**/ ?>