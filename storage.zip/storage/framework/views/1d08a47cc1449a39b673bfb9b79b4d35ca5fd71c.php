<!doctype html>
<html class="no-js" lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>  A elle :: dashboard  </title>
    <link rel="icon" href="<?php echo e(url('/')); ?>/cp/favicon.ico" type="image/x-icon"> <!-- Favicon-->
    <?php echo notifyCss(); ?>

    <!-- plugin css file  -->
    <style>
    
    
    
    
    .container {
  margin: 20px auto;
  padding: 20px;
  max-width: 900px;
  font-size: 16px;
  line-height: 1.5;
}

.order-title {
  text-align: center;
  font-size: 24px;
  margin-bottom: 30px;
}

.order-details,
.order-address {
  margin-bottom: 50px;
}

.address-title {
  font-size: 20px;
  margin-bottom: 20px;
}

.order-address p {
  margin-bottom: 10px;
}

.order-address hr {
height: 1px;
background-color: #ccc;
border: none;
margin: 20px 0;
}
    
    
    
    
    
    .button-container {
        display: flex;
        gap: 10px;
      }
      .dropdown-menu {
  background-color: #000;
}
.dropdown-toggle {
  background-color: white;
  color: black;
}
      .button {
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.2s ease-in-out;
      }
      
      .primary {
        background-color: #4CAF50;
        color: white;
      }
      
      .secondary {
        background-color: #008CBA;
        color: white;
      }
      
      .tertiary {
        background-color: #f44336;
        color: white;
      }
      
      .button:hover {
        transform: translateY(-2px);
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
      }
      
      .button:active {
        transform: translateY(0px);
        box-shadow: none;
      }
      </style>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/cp/assets/plugin/datatables/responsive.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/cp/assets/plugin/datatables/dataTables.bootstrap5.min.css">

    <!-- project css file  -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/cp/assets/css/ebazar.style.min.css">
</head>
<body class="rtl_mode">
    <div id="ebazar-layout" class="theme-">
        
        
    <?php echo $__env->make('layouts.admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- main body area -->
        <div class="main px-lg-4 px-md-4">
        <?php echo $__env->make('layouts.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



           

            <!-- Body: Body -->
            <?php if (isset($component)) { $__componentOriginal50729b3bb9bfcf31db82c3fbae295e7a36237dc2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Codemenco\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50729b3bb9bfcf31db82c3fbae295e7a36237dc2)): ?>
<?php $component = $__componentOriginal50729b3bb9bfcf31db82c3fbae295e7a36237dc2; ?>
<?php unset($__componentOriginal50729b3bb9bfcf31db82c3fbae295e7a36237dc2); ?>
<?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
            <!-- Modal Custom Settings-->
             
            
        </div>
    
    </div>
    <?php echo notifyJs(); ?>

        <?php echo $__env->yieldPushContent('js'); ?>

    <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</body>
</html> <?php /**PATH /home/limogesd/public_html/resources/views/layouts/admin/main.blade.php ENDPATH**/ ?>