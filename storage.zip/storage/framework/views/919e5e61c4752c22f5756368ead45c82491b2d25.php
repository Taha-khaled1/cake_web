<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-end">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active">Mentors</li>
                                </ol>
                            </div>
                            <h4 class="page-title">Mentors</h4>
                        </div>
                        <!--end page-title-box-->
                    </div>
                    <!--end col-->
                </div>

                <div class="row">
                    
                    <div class="table-responsive">
                                 <table id="example" class="table table-striped table-bordered" style="width:90%;">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Type</th>
                                        <th>phone</th>
                                        <th>Message</th>
                                        <th>Actions</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="R_user<?php echo e($c->id); ?>">
                                        <td><?php echo e($loop->iteration); ?> </td>
                                        <td><?php echo e($c->name); ?></td>
                                        <td><?php echo e($c->email); ?> </td>
                                        <td><?php if($c->type): ?><?php echo e($c->type->name); ?><?php endif; ?> </td>
                                        <td><?php echo e($c->phone); ?> </td>
                                        <td><?php echo e($c->message); ?> </td>
                                        <td>
                                         <a  href=" " class="deletem_b" onclick=" return confirm( `  Are you sure? ` )" deletem_b="<?php echo e($c->id); ?>"><i class=" las la-trash text-danger font-20"></i></a>
                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                 </table>
                                 </div>
                </div><!--end row-->

            </div><!-- container -->



        </div>
        <!-- end page content -->
    </div>

<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.5.0.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>

<script>

$(document).on("click", ".deletem_b", function (e) {
        e.preventDefault();
        var deletem_b = $(this).attr("deletem_b");
        $.ajax({
            type: "post",
            url: "<?php echo e(route('admin.contact.delete')); ?>",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                id: deletem_b,
            },
            success: function (data) {
                if (data.status == true) {
                  
                 
                }

                $(".R_user" + data.id).remove();
            },
            error: function (reject) {},
        });
    });
    </script>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/admin/contact/index.blade.php ENDPATH**/ ?>