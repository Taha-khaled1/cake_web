 

<?php $__env->startSection('content'); ?>

<!-- breadcrumb area start -->

<!-- cart main wrapper start -->
        <div class="content">
            <div class="container">
                        <?php if($cart->get()->count()== 0 ): ?> <h1><?php echo e(__('The cart is empty')); ?></h1><br><a href="<?php echo e(route('viewHomePage')); ?>"><?php echo e(__('Home')); ?></a>   <?php else: ?>

                            <!-- Cart Table Area -->
                                <table>
                                    <thead>
                                        <tr>
                                            <td ><?php echo e(__('Image')); ?></td>
                                            <td><?php echo e(__('Product')); ?></td>
                                            <td ><?php echo e(__('Price')); ?></td>
                                            <td><?php echo e(__('Quantity')); ?></td>
                                            <td ><?php echo e(__('Remove')); ?></td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $cart->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="a<?php echo e($item->id); ?>">
                                            <td ><img class="img-fluid" src="<?php echo e(asset('/storage/property/'.$item->product->image)); ?>" alt="Product" /></td>
                                            <td ><span href="<?php echo e(route('viewProperty',$item->product->id)); ?>"> <?php echo e($item->product->name); ?>  </span></td>
                                            <td ><span><?php echo e($item->product->price); ?>  <?php echo e(__('AED')); ?></span></td>
                                            <td >
                                                <div ><input type="text" product_id="<?php echo e($item->product->id); ?>" dataa_id="<?php echo e($item->id); ?>" dataa_total="<?php echo e($item->quantity * $item->product->price); ?>" dataa_price="<?php echo e($item->product->price); ?>"  value="<?php echo e($item->quantity); ?>" style="width:75px"></div>
                                            </td>
                                             <td ><span class="remove-item" data_id="<?php echo e($item->id); ?>"  href="javascript:void(0)"><i class="fa fa-trash-o"></i></span></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <a class="btn btn-sqr" href="<?php echo e(route('cartempty')); ?>" ><?php echo e(__('Empty the cart')); ?></a>
                            <!-- Cart Update Option -->
                                    <p class="text-end me-2">
                                    <?php echo e(__('Do you have a discount code?')); ?>

                                    </p>
                                    <!-- <p class="h4">
                                        <?php echo e(__('Discount code')); ?>

                                    </p>  -->
                                    <div class="d-flex justify-content-end">
                                        <input type="text" name="code" total="<?php echo e($cart->total()); ?>" class="text-end me-2 d-flex justify-content-end" maxlength="100" required placeholder="<?php echo e(__('Enter the discount code')); ?> " >
                                    </div>
                        </div>
                    </div>
                    
                        <div class="prize" >
                            <div class="container">
                                <div class="row justify-content-end">
                                    <div class="col-lg-8 col-md-8 col-sm-10 col-10">
                                        <form action="<?php echo e(route('indexorder')); ?>" method="GET" >
                                        <?php echo csrf_field(); ?> 
                                            <div class="table-responsive">
                                                <table>
                                                    <tr>
                                                        <?php if(Auth::user()): ?>
                                                        <td><?php echo e(__('Addresses saved by the user')); ?></td>
                                                        <td><select id="frm_country" class="form-control" name="address_id"  >
                                                        <option value=""  > <?php echo e(__('Choose the region')); ?></option>
            
                                                        <?php $__currentLoopData = \Illuminate\Support\Facades\Auth::user()->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                                        <option value="<?php echo e($address->id); ?>" selected><?php echo e($address->name); ?> / <?php echo e($address->area); ?></option>
            
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select></td>
                                                         
                                                            <?php endif; ?> 
                                                    </tr>
                                                    <tr>
                                                        <td> <div id="totalq" class="d-flex align-items-center justify-content-end gap-2">
                                                            <span><?php echo e(__('AED')); ?></span>
                                                            <span  id="totals"><?php echo e($cart->total()); ?></span>
                                                        </div></td>
                                                        <td><?php echo e(__('Partial total')); ?></td>
                                                    </tr>
                                                    <tr class="total">
                                                        <td class="total-amount"><div class="d-flex align-items-center justify-content-end gap-2">
                                                        <span><?php echo e(__('AED')); ?></span>
                                                          <span  id="discount"> 0 </span>
                                                          
                                                      </div></td>
                                                        <td><?php echo e(__('Discount')); ?></td>
                                                    </tr>
                                                       <?php if($offer >= 1): ?>
                                                       <?php if($offer <= $cart->total()): ?>
                                                    <tr class="total">
                                                        <td><?php echo e(__('Free shipping')); ?></td>
                                                        <td class="total-amount"><?php echo e(__('After the price of products exceeds')); ?> <?php echo e($offer); ?></td>
                                                    </tr> <?php endif; ?> <?php endif; ?>
                                                </table>
                                            </div>
                                            <input type="text"  name="rate" value="0" style="display:none"   >
                                            <a ><button class="text-white" type="submit"><?php echo e(__('Continue to complete the purchase')); ?> </button></a>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
            </div>
        </div>
        <!-- cart main wrapper end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>  
<script>   
     
   $('.remove-item').on("click", function (e) {
              //  e.preventDefault();
               
         var id = $(this).attr('data_id');
         
         
         $.ajax({
                type: "post",
                url: "/cart/" + id,
                method: "delete",
                data: { _token: '<?php echo e(csrf_token()); ?>'
                     },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                        $("#a"+ id).remove();
                        $("#totals").remove();
                        $("#totalq").fadeIn().html( '<span id="totals">' + data.totala +'</span> <?php echo e(__('AED')); ?>' );
                        $("#totals1").remove();
                        $("#totalq1").fadeIn().html( '<span id="totals1">' + data.totala +'</span> <?php echo e(__('AED')); ?>' );
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#axaa').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });

    
    $('.item-quantity').on("change", function (e) {
              //  e.preventDefault();
               
         var id = $(this).attr('dataa_id');
         var product_id = $(this).attr('product_id');
         var total = $(this).attr('dataa_total') + $(this).attr('dataa_price');
         

         
         $.ajax({
                type: "post",
                url: "/cart/" + id,
                method: "put",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                quantity: $(this).val(),
                product_id: product_id,
                xx: 'x',
                     },
                               // let's set the expected response format
                    success: function (data) {
                        if(data.message == 1){
                              
                            flashBox('error', 'نفذت الكمية');


                        }else{
                        $("#totals").remove();
                        $("#totalq").fadeIn().html( '<span id="totals">' + data.totalx +'</span> <?php echo e(__('AED')); ?>' );
                        $("#totals1").remove();
                        $("#totalq1").fadeIn().html( '<span id="totals1">' + data.totalx +'</span> <?php echo e(__('AED')); ?>' );
                   
                        }
 
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#axaa').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });
    $(document).ready(function () {
        $('input[name="code"]').on('change', function () {
            var code = $(this).val();
            var total = $(this).attr('total');

            if (code) {
                $.ajax({
                    url: "<?php echo e(URL::to('get_discount')); ?>/" + code,
                    type: "GET",
                    dataType: "json",
                    success: function (data) {
                        $('#discount').empty(); 
                        $('#discount').append( total * data.rate / 100 );
                        $('input[name="rate"]').val(data.rate / 100);

                        flashBox('success', '<?php echo e(__('Discount done')); ?>');

                    },
                });
            }

            else {
                console.log('AJAX load did not work');
            }
        });
    });

    </script>
     
    <?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/cart.blade.php ENDPATH**/ ?>