<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

<?php $__env->startSection('content'); ?>


    <div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-8">
                        <div class="page-title-box">
                         
                            <h4 class="page-title">المنتجات</h4> 
                        </div> 
                    </div>
                   
                    <!--end col-->
                </div><br>
                <div class="row">
                    <div class="col-3">
<?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="datatable_pro1">
                                        <thead class="thead-light">
                                        <tr>
                                            <th>Id</th>
                                            <th>اسم المنتج</th>
                                            <th>السعر</th>
                                            <th>تاريخ الاضافة</th>
                                            <th>الصورة</th>
                                             <th>الكمية</th>
                                            <th>العمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->


            </div><!-- container -->


        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
    <script src=" /cp/assets/plugins/datatables/datatables.min.js"></script>
    <script src=" /cp/assets/plugins/datatables/datatables_advanced.js"></script>

    <script>
        
       $(document).ready(function(){


            var pTable = $('#datatable_pro1').DataTable({
                processing: true,
                searching: true,
                serverSide: true,
                ajax: {
                    url: '<?php echo e(route('admin.productsajax')); ?>',
                    type: 'get',
                    data: function(d){
                        d._token = "<?php echo e(csrf_token()); ?>"

                    }
                },

                columns: [
                    { data: 'id' },
                    { data: 'name' },
                    { data: 'price' },
                    { data: 'created_at' },
                    { data: 'image' },
                    { data: 'quantity' },
                    { data: 'actions' },
                ],
                "columnDefs": [
                    { "orderable": false, "targets": 6,
                         "width": "8%", "targets": 6,
                        "width": "5%", "targets": 0
                    }
                ]


            });


        });
 
 
   
</script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/admin/products/list.blade.php ENDPATH**/ ?>