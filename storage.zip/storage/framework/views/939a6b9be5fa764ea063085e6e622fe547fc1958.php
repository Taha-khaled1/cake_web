 

<?php $__env->startSection('content'); ?>
<!-- start breadcrumb -->

 
<!-- end breadcrumb -->
<section class="container py-3 section-continue" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" >
    <div class="row">
        <div class="col-md-6 payment-details">
            <p class="h4"> 
            <?php echo e(__('Payment details')); ?>  
             </p>
            <br>
            <form action="<?php echo e(route('storeorder')); ?>" method="post">
            <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="full-name" class="form-label"> <?php echo e(__('Full Name')); ?></label>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="name" class="form-control" id="full-name" value="<?php if($add == 1): ?> <?php echo e($address->name); ?> <?php else: ?> <?php echo e(old('name')); ?> <?php endif; ?>" maxlength="100" required>
                  </div>
                  <div class="mb-3">
                    <label for="email-address" class="form-label"> <?php echo e(__('Email')); ?></label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="email" name="email" class="form-control" id="email-address" value="<?php if($add == 1): ?> <?php echo e($address->email); ?> <?php else: ?> <?php echo e(old('email')); ?>  <?php endif; ?>" maxlength="100" required>
                  </div>
                  <div class="my-3">
                    <label for="choose-region"  > <?php echo e(__('المنطقة')); ?></label><br>
                    <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <select name="area" class="form-control" id="choose-region" aria-label="Default select example" maxlength="100" required 
                  <?php if(isset($rate)): ?>  <?php if(isset($address)): ?> total= "<?php echo e($cart->total() - ($cart->total() * $rate) + $address->Shipping); ?>" shipping="<?php echo e($address->Shipping); ?>" <?php else: ?> total=" <?php echo e($cart->total() - ($cart->total() * $rate)); ?>" shipping="0" <?php endif; ?> <?php else: ?> <?php if(isset($address)): ?> total=" <?php echo e($cart->total() + $address->Shipping); ?>" shipping="<?php echo e($address->Shipping); ?>" <?php else: ?> total="<?php echo e($cart->total()); ?>" shipping="0" <?php endif; ?> <?php endif; ?>>
                  <option value=""> <?php echo e(__('Choose the region')); ?></option>  
                  <option selected value="<?php if($add == 1): ?> <?php echo e($address->area); ?> <?php else: ?> <?php echo e(old('area')); ?> <?php endif; ?>">    <?php if($add == 1): ?> <?php echo e($address->area); ?> <?php else: ?> <?php echo e(old('area')); ?>  <?php endif; ?> </option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ca->name); ?>"> <?php echo e($ca->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select> <br>
                </div>
                <div class="mb-3">
                    <label for="street"   > <?php echo e(__('Street')); ?></label>
                    <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="street" class="form-control" id="street" placeholder="أدخل اسم الشارع" value="<?php if($add == 1): ?> <?php echo e($address->street); ?> <?php else: ?> <?php echo e(old('street')); ?> <?php endif; ?>" maxlength="100"   >
                  </div>
                  <div class="mb-3">
                    <label for="District"  > <?php echo e(__('Blvd')); ?></label>
                    <input type="text" name="Blve" class="form-control" id="أدخل رقم الجادة" value="<?php if($add == 1): ?> <?php echo e($address->Blve); ?> <?php else: ?> <?php echo e(old('Blve')); ?>  <?php endif; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="flat"  > <?php echo e(__('Apartment/House')); ?></label>
                    <input type="text" name="house" class="form-control" id="flat" placeholder="أدخل رقم/اسم الشقة/المنزل" value="<?php if($add == 1): ?> <?php echo e($address->house); ?> <?php else: ?> <?php echo e(old('house')); ?>  <?php endif; ?>" maxlength="100"  >
                  </div>
                  <div class="mb-3">
                    <label for="mobile-number"  > <?php echo e(__('Mobile number')); ?></label>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="phone" class="form-control" id="mobile-number" value="<?php if($add == 1): ?> <?php echo e($address->phone); ?> <?php else: ?> <?php echo e(old('phone')); ?>  <?php endif; ?>" maxlength="100" required>
                  </div> 
                   <?php if(Auth::user()): ?><?php else: ?>
                  <div class="mb-1 ">
                    <input class="form-check-input" type="checkbox" value="1" name="make_user"  id="accept">
                    <label class="form-check-label" for="accept">
                       <?php echo e(__('Create an account')); ?>

                     </label>
                  </div>
                  <div class="mb-3">
                  <label for="user-password"  > <?php echo e(__('Password')); ?></label>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group">
                         <input type="password" class="form-control" name="password" aria-label="user-password" aria-describedby="user-password">
                    </div></div>
                  <div class="mb-3">
                  <label for="user-password"  > <?php echo e(__('Confirm password')); ?></label>
                     <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group">
                     <input type="password" class="form-control" name="password_confirmation" aria-label="user-password" aria-describedby="user-password">
                    </div></div>
                    <?php endif; ?>
                  <div class="mb-3">
                    <label for="add-nots"  > <?php echo e(__('Notes with the order')); ?></label>
                    <textarea class="form-control" name="nots" id="add-nots" cols="10" maxlength="300"  rows="5"></textarea>
                  </div>

                  <div class="mb-1  ">
                    <input class="form-check-input" type="checkbox" value="" id="accept-terms"  required >
                    <label for="accept-terms">
                             <?php echo e(__('I agree to the terms and conditions')); ?>

                    </label>
                  </div>
           
        </div>
        <div class="col-md-2 payment-details"></div>
        <div class="col-md-4 do-you-have-discount-code  bg-gray">
      
            
            <div class="cart-sum my-5">
                <p class="h5 my-3 text-center" ><?php echo e(__('Shopping cart')); ?></p>
                
                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th class="pro-thumbnail"><?php echo e(__('Image')); ?></th>
                                            <th class="pro-title"><?php echo e(__('Product')); ?></th>
                                            <th class="pro-price"><?php echo e(__('Price')); ?></th> 
                                            <th class="pro-price"><?php echo e(__('Quantity')); ?></th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $cart->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="a<?php echo e($item->id); ?>">
                                            <td class="pro-thumbnail"><a href="<?php echo e(route('viewProperty',$item->product->id)); ?>"><img class="img-fluid" src="<?php echo e(asset('/storage/property/'.$item->product->image)); ?>" alt="Product" width="100"/></a></td>
                                            <td class="pro-title"><a href="<?php echo e(route('viewProperty',$item->product->id)); ?>"> <?php echo e($item->product->name); ?>  </a></td>
                                            <td class="pro-price"><span><?php echo e($item->product->price); ?>  <?php echo e(__('AED')); ?></span></td>
                                            <td class="pro-price"><span><?php echo e($item->quantity); ?></span></td>

                                         </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table> 
               <hr>
                <div class="d-flex justify-content-between mt-5">
                    <span> <?php echo e(__('Partial total')); ?></span>
                    <div>
                        <span>  <?php echo e($cart->total()); ?>    </span>
                        <?php echo e(__('AED')); ?>

                    </div>
                </div>
                <hr>
                <?php if(isset($rate)): ?>
                <div class="d-flex justify-content-between">
                    <span><?php echo e(__('Discount')); ?></span>
                    <div>
                        <span><?php echo e($cart->total() * $rate); ?></span>
                        <?php echo e(__('AED')); ?>

                    </div>
                </div> <hr>
                <?php endif; ?>
                
                <div class="d-flex justify-content-between">
                    <span><?php echo e(__('Shipping')); ?></span>
                    <div>
                    <?php if($offer >= 1 && $offer <= $cart->total()): ?>
                    <span id="shipping"><?php echo e(__('Free')); ?></span>

                       <?php else: ?>
                        <span id="shipping"><?php if(isset($address)): ?><?php echo e($address->Shipping); ?> <?php endif; ?></span>
                        <?php echo e(__('AED')); ?>

                        <?php endif; ?>
                    </div>
                </div>

                    <hr>
                    <div class="d-flex justify-content-between">
                        <span> <?php echo e(__('Total summation')); ?></span>
                        <bold>
                            <span id="total_sh"><?php if(isset($rate)): ?>  <?php if(isset($address)): ?> <?php echo e($cart->total() - ($cart->total() * $rate) + $address->Shipping); ?> <?php else: ?> <?php echo e($cart->total() - ($cart->total() * $rate)); ?> <?php endif; ?> <?php else: ?> <?php if(isset($address)): ?> <?php echo e($cart->total() + $address->Shipping); ?> <?php else: ?> <?php echo e($cart->total()); ?> <?php endif; ?> <?php endif; ?></span>
 
                            <?php echo e(__('AED')); ?>

                        </bold>
                    </div>
                    
                
                
                
                </div>
                
                <div class="mb-3 form-check">
                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input name="payment_method" class="form-check-input" type="radio" checked value="cash" id="buy-cash" >
                    <label class="form-check-label" for="buy-cash">
                        <img src="<?php echo e(asset('images/cach.png')); ?>" width="50px" height="20px" alt="buy cash">
                             <?php echo e(__('Cash on delivery')); ?>

                    </label>
                  </div>
                  <div class="mb-3 form-check">
                    <input name="payment_method" class="form-check-input" type="radio" value="check" id="buy-check">
                    <label class="form-check-label" for="buy-check">
                    <img src="<?php echo e(asset('images/chech.png')); ?>" width="60px" height="20px" alt="buy cash">
                        <?php echo e(__('Pay by credit card')); ?>

                    </label>
                  </div>
                   
                  <input type="text"  name="total" value="<?php if(isset($rate)): ?>  <?php if(isset($address)): ?> <?php echo e($cart->total() - ($cart->total() * $rate) + $address->Shipping); ?> <?php else: ?> <?php echo e($cart->total() - ($cart->total() * $rate)); ?> <?php endif; ?> <?php else: ?> <?php if(isset($address)): ?> <?php echo e($cart->total() + $address->Shipping); ?> <?php else: ?> <?php echo e($cart->total()); ?> <?php endif; ?> <?php endif; ?>" style="display:none"   >
                  <input type="text" value="<?php if(isset($rate)): ?> <?php echo e($cart->total() * $rate); ?> <?php else: ?> 0 <?php endif; ?>" name="discount" style="display:none" >
                     <?php if($offer >= 1 && $offer <= $cart->total()): ?>
                     <input type="text"  name="shipping" value="0" style="display:none"   >
                      <?php else: ?>
                      <input type="text"  name="shipping" value="  <?php if(isset($address)): ?> <?php echo e($address->Shipping); ?> <?php else: ?> 0 <?php endif; ?>" style="display:none"   >
                      <?php endif; ?>

                  <hr class="my-4 hr-blue">

                <input type="submit" class="btn btn-sqr" value=" <?php echo e(__('Confirmation')); ?> ">

        </div> </form> 
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>  
<script>   
     
   $('.remove-item').on("click", function (e) {
              //  e.preventDefault();
               
         var id = $(this).attr('data_id');
         
         
         $.ajax({
                type: "post",
                url: "/cart/" + id,
                method: "delete",
                data: { _token: '<?php echo e(csrf_token()); ?>'
                     },
                    dataType: 'json',              // let's set the expected response format
                    success: function (data) {
                        $("#"+ data.id).remove();
                        $("#totals").remove();
                        $("#totalq").fadeIn().html( '<span id="totals">' + data.totala +'</span> <?php echo e(__('AED')); ?>' );
                        $("#totals1").remove();
                        $("#totalq1").fadeIn().html( '<span id="totals1">' + data.totala +'</span> <?php echo e(__('AED')); ?>' );
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#axaa').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });

    
    $('.item-quantity').on("change", function (e) {
              //  e.preventDefault();
               
         var id = $(this).attr('dataa_id');
         var total = $(this).attr('dataa_total') + $(this).attr('dataa_price');
         

         
         $.ajax({
                type: "post",
                url: "/cart/" + id,
                method: "put",
                data: { _token: '<?php echo e(csrf_token()); ?>',
                quantity: $(this).val(),
                xx: 'x',
                     },
                               // let's set the expected response format
                    success: function (data) {
                         $("#totals").remove();
                        $("#totalq").fadeIn().html( '<span id="totals">' + data.totalx +'</span> <?php echo e(__('AED')); ?>' );
                        $("#totals1").remove();
                        $("#totalq1").fadeIn().html( '<span id="totals1">' + data.totalx +'</span> <?php echo e(__('AED')); ?>' );
                        $("#totalq1").fadeIn().html( '<span id="totals1">' + data.totalx +'</span> <?php echo e(__('AED')); ?>' );

 
                    },
                    error: function (err) {
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            $('#axaa').fadeIn().html('<div class="alert alert-danger border-0 alert-dismissible">' + err.responseJSON.message +'</div>');


                        }
                    }
                });   
          
    });
    </script>

    <?php if($offer >= 1 && $offer <= $cart->total()): ?>
                       <?php else: ?>
 <script>              
    $(document).ready(function () {
        $('select[name="area"]').on('change', function () {
            var country = $(this).val();
            var total = $(this).attr('total');
            var shipping = $(this).attr('shipping');

            if (country) {
                $.ajax({
                    url: "<?php echo e(URL::to('get_shipping')); ?>/" + country,
                    type: "GET",
                    dataType: "json",
                    success: function (data) {
                        $('#shipping').empty();
                        $('#shipping').append(data.price);
                        $('#total_sh').empty();
                        $('#total_sh').append(total - shipping + data.price);
                        $('input[name="total"]').val(total - shipping + data.price);
                        $('input[name="shipping"]').val(data.price);
                       

                    },
                });
            }

            else {
                console.log('AJAX load did not work');
            }
        });
    });</script>
<?php endif; ?>
    
    
    <?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/order.blade.php ENDPATH**/ ?>