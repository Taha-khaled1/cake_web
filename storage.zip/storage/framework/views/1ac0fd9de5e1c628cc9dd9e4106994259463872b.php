<?php if(Auth::user()): ?><?php else: ?>
<div class="top-head d-flex flex-wrap">
    <div class="dropdown">
        <button class="dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style="color: #975d8d;">
        <?php echo e(LaravelLocalization::getCurrentLocaleNative()); ?>

        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a a class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
            <?php echo e($properties['native']); ?>

            </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="">
        <form class="" action="<?php echo e(route('search_property')); ?>" method="GET">
            <input type="text" name="title" placeholder="<?php echo e(__('Search entire store hire')); ?>" class="fs-6">
            <button type="submit" class=""><i class="pe-7s-search"></i></button>
        </form>
    </div>
    <div class="login me-4">
        <a href="<?php echo e(route('login')); ?>" style="color:#975D8D" >
            <?php echo e(__('Sign In')); ?>

        </a>  &nbsp;
            / &nbsp; 
        <a  href="<?php echo e(route('register')); ?>" style="color:#975D8D">
            <?php echo e(__('Register')); ?>

        </a>  
        
        
        
    </div>
    
</div>
      <?php endif; ?>
      

        <!-- main header start -->
        
            <!-- header top start -->
            <!-- <div class="header-top bdr-bottom">
                <div class="container">
                    <div class="row align-items-center">
                    <div class="col-lg-6">
                          
                          </div>
                        <div class="col-lg-6 text-right">
                            <div class="header-top-settings">
                                <ul class="nav align-items-center justify-content-end">
                                    <li class="language">
                                       <?php echo e(LaravelLocalization::getCurrentLocaleNative()); ?>

                                        <i class="fa fa-angle-down"></i>
                                        <ul class="dropdown-list curreny-list">
                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                          <li><a a class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                          <?php echo e($properties['native']); ?>

                                          </a></li>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                         </ul>
                                    </li>
                                    <li>   
                                    </li>
                                    <li> 
                                    </li>
                                    <li> 
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- header top end -->

            <!-- header middle area start -->
            <header class="header-main-area sticky">
                <div class="d-flex justify-content-between">
                   

                        <!-- start logo area -->
                        <div class="icons">
                            <ul class="list-unstyled d-flex fs-3">
                                <li>
                                    <a href="<?php echo e(route('cart.index')); ?>" >
                                        <i class="fas fa-bag-shopping"></i> 
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('wishlist')); ?>">
                                        <i class="far fa-heart"></i> 
                                    </a> 
                                </li>
                                <li >
                                    <a href="<?php echo e(route('viewMyAccount')); ?>">
                                        <i class="fas fa-user-circle"></i> 
                                    </a>
                                </li>
                            </ul>
                            
                        </div>
                        <!-- start logo area -->

                        <!-- main menu area start -->
                        <div class="links">
                            <ul class="list-unstyled d-flex">
                            
                                <li><a href="<?php echo e(url('/'. LaravelLocalization::getCurrentLocale() .'')); ?>"class="text-decoration-none"><?php echo e(__('Home')); ?></a></li> 
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('category_property',$category->id)); ?>" class="text-decoration-none"><?php if($category->name_en != null): ?>
                                                <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
                                                <?php echo e($category->name); ?>

                                                <?php else: ?>
                                                <?php echo e($category->name_en); ?>

                                                <?php endif; ?> <?php else: ?>
                                                <?php echo e($category->name); ?>

                                                <?php endif; ?></a></li>
                                             
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             
                                        </li>
                                        <li>
                                            <div class="logo">
                                                <a href="<?php echo e(route('viewHomePage')); ?>">
                                                    <img src="<?php echo e(asset('storage/users/'. $header_logo )); ?>" alt=" logo"  class="m-0">
                                                </a>
                                            </div>
                                        </li>
                                        <!-- <li><a href="<?php echo e(route('products')); ?>"><?php echo e(__('Our products')); ?></a></li> -->
                                        <li><a href="<?php echo e(route('specialorder')); ?>" class="text-decoration-none"><?php echo e(__('Special order')); ?></a></li> 
                                        <li><a href="<?php echo e(route('viewContact')); ?>" class="text-decoration-none"><?php echo e(__('Contact Us')); ?></a></li> 
                            </ul>
                            
                        </div>
                        <div class="logo2">
                                <a href="<?php echo e(route('viewHomePage')); ?>">
                                    <img src="<?php echo e(asset('storage/users/'. $header_logo )); ?>" alt=" logo" class="mt-4">
                                </a>
                        </div>
                        <!-- main menu area end -->
                        <!-- mini cart area start -->
                        
                        <!-- mini cart area end -->

                    
                </div>
                <!-- mobile menu start  -->
                    <div class="fix-head px-2 position-fixed">
                        <ul class="list-unstyled d-flex justify-content-center gap-3">
                        <li class="text-center">
                                <a href="<?php echo e(route('viewHomePage')); ?>">
                                    <i class="fas fa-home"></i>
                                    <p><?php echo e(__('Home')); ?></p>
                                </a>
                            </li>
                            <!-- <li class="text-center">
                                <a href="our-cake.html">
                                    <i class="	far fa-heart">
                                    </i>
                                    <p>Cake</p>
                                </a>
                            </li> -->
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-center">
                                    <a href="<?php echo e(route('category_property',$category->id)); ?>"><?php if($category->name_en != null): ?>
                                        <i class="far fa-heart">
                                            </i><p><?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?> <?php echo e($category->name); ?> <?php else: ?> <?php echo e($category->name_en); ?> <?php endif; ?> <?php else: ?> <?php echo e($category->name); ?> <?php endif; ?></p>
                                    </a>
                                </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <li class="text-center">
                                <a href="<?php echo e(route('specialorder')); ?>">
                                    <i class="	fas fa-phone-alt"></i>
                                    <p><?php echo e(__('Special order')); ?></p>
                                </a>
                            </li>
                        </ul>
                    </div>
                <!-- mobile menu end  -->
            </header>
            <!-- header middle area end -->
        
        <!-- main header start -->

        <!-- mobile header start -->
        <!-- mobile header start -->
        


        
        <!-- mobile header end -->
        <!-- mobile header end -->

        <!-- offcanvas mobile menu start -->
        <!-- off-canvas menu start -->
        
        <!-- off-canvas menu end -->
        <!-- offcanvas mobile menu end -->
    <!-- end Header Area -->
    <?php /**PATH /home/limogesd/public_html/resources/views/layouts/layoutSite/Header.blade.php ENDPATH**/ ?>