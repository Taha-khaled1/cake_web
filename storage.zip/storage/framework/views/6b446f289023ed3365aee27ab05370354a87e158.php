
 <!-- Jquery Core Js -->
<script src="<?php echo e(url('/')); ?>/cp/assets/bundles/libscripts.bundle.js"></script>

<!-- Plugin Js -->
<script src="<?php echo e(url('/')); ?>/cp/assets/bundles/apexcharts.bundle.js"></script>
<script src="<?php echo e(url('/')); ?>/cp/assets/bundles/dataTables.bundle.js"></script>  

<!-- Jquery Page Js -->
<script src="<?php echo e(url('/')); ?>/cp/js/template.js?<?=time()?>"></script>
<script src="<?php echo e(url('/')); ?>/cp/js/page/index.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script>
<?php /**PATH /home/limogesd/public_html/resources/views/layouts/admin/footer.blade.php ENDPATH**/ ?>