/* ===================================================
>>> TABLE OF CONTENTS:
======================================================
1. Avoid `console` errors in browsers that lack a console.
2. jQuery v3.4.1
3. Popper Bootstrap
4. Bootstrap v4.3.1
5. Slick slider jQuery
6. Isotope jQuery
7. imagesLoaded jQuery
8. Lightcase - Popup jQuery
9. CounterUp jQuery
10. Countdown jQuery
11. Instafeed jQuery
12. Waypoints jQuery
13. Nice Select
14. jQuery UI / price range 
15. scrollup jquery 
16. One Page Navigation ( jQuery Easing Plugin )
17. WOW jQuery 
18. Parallax jQuery
19. Maplace.js

 
=================================================== */

/*-------------------------------------------------------------
  1. Avoid `console` errors in browsers that lack a console.
---------------------------------------------------------------*/
(function () {
    var method;
    var noop = function () {};
    var methods = [
        "assert",
        "clear",
        "count",
        "debug",
        "dir",
        "dirxml",
        "error",
        "exception",
        "group",
        "groupCollapsed",
        "groupEnd",
        "info",
        "log",
        "markTimeline",
        "profile",
        "profileEnd",
        "table",
        "time",
        "timeEnd",
        "timeline",
        "timelineEnd",
        "timeStamp",
        "trace",
        "warn",
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
})();

// Place any jQuery/helper plugins in here.

/*-------------------------------------------------------------
  # Modernizr
---------------------------------------------------------------*/
/* Modernizr 2.8.3 (Custom Build) | MIT & BSD
 * Build: http://modernizr.com/download/#-fontface-backgroundsize-borderimage-borderradius-boxshadow-flexbox-hsla-multiplebgs-opacity-rgba-textshadow-cssanimations-csscolumns-generatedcontent-cssgradients-cssreflections-csstransforms-csstransforms3d-csstransitions-applicationcache-canvas-canvastext-draganddrop-hashchange-history-audio-video-indexeddb-input-inputtypes-localstorage-postmessage-sessionstorage-websockets-websqldatabase-webworkers-geolocation-inlinesvg-smil-svg-svgclippaths-touch-webgl-shiv-mq-cssclasses-addtest-prefixed-teststyles-testprop-testallprops-hasevent-prefixes-domprefixes-load
 */
(window.Modernizr = (function (a, b, c) {
    function D(a) {
        j.cssText = a;
    }
    function E(a, b) {
        return D(n.join(a + ";") + (b || ""));
    }
    function F(a, b) {
        return typeof a === b;
    }
    function G(a, b) {
        return !!~("" + a).indexOf(b);
    }
    function H(a, b) {
        for (var d in a) {
            var e = a[d];
            if (!G(e, "-") && j[e] !== c) return b == "pfx" ? e : !0;
        }
        return !1;
    }
    function I(a, b, d) {
        for (var e in a) {
            var f = b[a[e]];
            if (f !== c) return d === !1 ? a[e] : F(f, "function") ? f.bind(d || b) : f;
        }
        return !1;
    }
    function J(a, b, c) {
        var d = a.charAt(0).toUpperCase() + a.slice(1),
            e = (a + " " + p.join(d + " ") + d).split(" ");
        return F(b, "string") || F(b, "undefined") ? H(e, b) : ((e = (a + " " + q.join(d + " ") + d).split(" ")), I(e, b, c));
    }
    function K() {
        (e.input = (function (c) {
            for (var d = 0, e = c.length; d < e; d++) u[c[d]] = c[d] in k;
            return u.list && (u.list = !!b.createElement("datalist") && !!a.HTMLDataListElement), u;
        })("autocomplete autofocus list placeholder max min multiple pattern required step".split(" "))),
            (e.inputtypes = (function (a) {
                for (var d = 0, e, f, h, i = a.length; d < i; d++)
                    k.setAttribute("type", (f = a[d])),
                        (e = k.type !== "text"),
                        e &&
                            ((k.value = l),
                            (k.style.cssText = "position:absolute;visibility:hidden;"),
                            /^range$/.test(f) && k.style.WebkitAppearance !== c
                                ? (g.appendChild(k), (h = b.defaultView), (e = h.getComputedStyle && h.getComputedStyle(k, null).WebkitAppearance !== "textfield" && k.offsetHeight !== 0), g.removeChild(k))
                                : /^(search|tel)$/.test(f) || (/^(url|email)$/.test(f) ? (e = k.checkValidity && k.checkValidity() === !1) : (e = k.value != l))),
                        (t[a[d]] = !!e);
                return t;
            })("search tel url email datetime date month week time datetime-local number range color".split(" ")));
    }
    var d = "2.8.3",
        e = {},
        f = !0,
        g = b.documentElement,
        h = "modernizr",
        i = b.createElement(h),
        j = i.style,
        k = b.createElement("input"),
        l = ":)",
        m = {}.toString,
        n = " -webkit- -moz- -o- -ms- ".split(" "),
        o = "Webkit Moz O ms",
        p = o.split(" "),
        q = o.toLowerCase().split(" "),
        r = { svg: "http://www.w3.org/2000/svg" },
        s = {},
        t = {},
        u = {},
        v = [],
        w = v.slice,
        x,
        y = function (a, c, d, e) {
            var f,
                i,
                j,
                k,
                l = b.createElement("div"),
                m = b.body,
                n = m || b.createElement("body");
            if (parseInt(d, 10)) while (d--) (j = b.createElement("div")), (j.id = e ? e[d] : h + (d + 1)), l.appendChild(j);
            return (
                (f = ["&#173;", '<style id="s', h, '">', a, "</style>"].join("")),
                (l.id = h),
                ((m ? l : n).innerHTML += f),
                n.appendChild(l),
                m || ((n.style.background = ""), (n.style.overflow = "hidden"), (k = g.style.overflow), (g.style.overflow = "hidden"), g.appendChild(n)),
                (i = c(l, a)),
                m ? l.parentNode.removeChild(l) : (n.parentNode.removeChild(n), (g.style.overflow = k)),
                !!i
            );
        },
        z = function (b) {
            var c = a.matchMedia || a.msMatchMedia;
            if (c) return (c(b) && c(b).matches) || !1;
            var d;
            return (
                y("@media " + b + " { #" + h + " { position: absolute; } }", function (b) {
                    d = (a.getComputedStyle ? getComputedStyle(b, null) : b.currentStyle)["position"] == "absolute";
                }),
                d
            );
        },
        A = (function () {
            function d(d, e) {
                (e = e || b.createElement(a[d] || "div")), (d = "on" + d);
                var f = d in e;
                return (
                    f || (e.setAttribute || (e = b.createElement("div")), e.setAttribute && e.removeAttribute && (e.setAttribute(d, ""), (f = F(e[d], "function")), F(e[d], "undefined") || (e[d] = c), e.removeAttribute(d))), (e = null), f
                );
            }
            var a = { select: "input", change: "input", submit: "form", reset: "form", error: "img", load: "img", abort: "img" };
            return d;
        })(),
        B = {}.hasOwnProperty,
        C;
    !F(B, "undefined") && !F(B.call, "undefined")
        ? (C = function (a, b) {
              return B.call(a, b);
          })
        : (C = function (a, b) {
              return b in a && F(a.constructor.prototype[b], "undefined");
          }),
        Function.prototype.bind ||
            (Function.prototype.bind = function (b) {
                var c = this;
                if (typeof c != "function") throw new TypeError();
                var d = w.call(arguments, 1),
                    e = function () {
                        if (this instanceof e) {
                            var a = function () {};
                            a.prototype = c.prototype;
                            var f = new a(),
                                g = c.apply(f, d.concat(w.call(arguments)));
                            return Object(g) === g ? g : f;
                        }
                        return c.apply(b, d.concat(w.call(arguments)));
                    };
                return e;
            }),
        (s.flexbox = function () {
            return J("flexWrap");
        }),
        (s.canvas = function () {
            var a = b.createElement("canvas");
            return !!a.getContext && !!a.getContext("2d");
        }),
        (s.canvastext = function () {
            return !!e.canvas && !!F(b.createElement("canvas").getContext("2d").fillText, "function");
        }),
        (s.webgl = function () {
            return !!a.WebGLRenderingContext;
        }),
        (s.touch = function () {
            var c;
            return (
                "ontouchstart" in a || (a.DocumentTouch && b instanceof DocumentTouch)
                    ? (c = !0)
                    : y(["@media (", n.join("touch-enabled),("), h, ")", "{#modernizr{top:9px;position:absolute}}"].join(""), function (a) {
                          c = a.offsetTop === 9;
                      }),
                c
            );
        }),
        (s.geolocation = function () {
            return "geolocation" in navigator;
        }),
        (s.postmessage = function () {
            return !!a.postMessage;
        }),
        (s.websqldatabase = function () {
            return !!a.openDatabase;
        }),
        (s.indexedDB = function () {
            return !!J("indexedDB", a);
        }),
        (s.hashchange = function () {
            return A("hashchange", a) && (b.documentMode === c || b.documentMode > 7);
        }),
        (s.history = function () {
            return !!a.history && !!history.pushState;
        }),
        (s.draganddrop = function () {
            var a = b.createElement("div");
            return "draggable" in a || ("ondragstart" in a && "ondrop" in a);
        }),
        (s.websockets = function () {
            return "WebSocket" in a || "MozWebSocket" in a;
        }),
        (s.rgba = function () {
            return D("background-color:rgba(150,255,150,.5)"), G(j.backgroundColor, "rgba");
        }),
        (s.hsla = function () {
            return D("background-color:hsla(120,40%,100%,.5)"), G(j.backgroundColor, "rgba") || G(j.backgroundColor, "hsla");
        }),
        (s.multiplebgs = function () {
            return D("background:url(https://),url(https://),red url(https://)"), /(url\s*\(.*?){3}/.test(j.background);
        }),
        (s.backgroundsize = function () {
            return J("backgroundSize");
        }),
        (s.borderimage = function () {
            return J("borderImage");
        }),
        (s.borderradius = function () {
            return J("borderRadius");
        }),
        (s.boxshadow = function () {
            return J("boxShadow");
        }),
        (s.textshadow = function () {
            return b.createElement("div").style.textShadow === "";
        }),
        (s.opacity = function () {
            return E("opacity:.55"), /^0.55$/.test(j.opacity);
        }),
        (s.cssanimations = function () {
            return J("animationName");
        }),
        (s.csscolumns = function () {
            return J("columnCount");
        }),
        (s.cssgradients = function () {
            var a = "background-image:",
                b = "gradient(linear,left top,right bottom,from(#9f9),to(white));",
                c = "linear-gradient(left top,#9f9, white);";
            return D((a + "-webkit- ".split(" ").join(b + a) + n.join(c + a)).slice(0, -a.length)), G(j.backgroundImage, "gradient");
        }),
        (s.cssreflections = function () {
            return J("boxReflect");
        }),
        (s.csstransforms = function () {
            return !!J("transform");
        }),
        (s.csstransforms3d = function () {
            var a = !!J("perspective");
            return (
                a &&
                    "webkitPerspective" in g.style &&
                    y("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}", function (b, c) {
                        a = b.offsetLeft === 9 && b.offsetHeight === 3;
                    }),
                a
            );
        }),
        (s.csstransitions = function () {
            return J("transition");
        }),
        (s.fontface = function () {
            var a;
            return (
                y('@font-face {font-family:"font";src:url("https://")}', function (c, d) {
                    var e = b.getElementById("smodernizr"),
                        f = e.sheet || e.styleSheet,
                        g = f ? (f.cssRules && f.cssRules[0] ? f.cssRules[0].cssText : f.cssText || "") : "";
                    a = /src/i.test(g) && g.indexOf(d.split(" ")[0]) === 0;
                }),
                a
            );
        }),
        (s.generatedcontent = function () {
            var a;
            return (
                y(["#", h, "{font:0/0 a}#", h, ':after{content:"', l, '";visibility:hidden;font:3px/1 a}'].join(""), function (b) {
                    a = b.offsetHeight >= 3;
                }),
                a
            );
        }),
        (s.video = function () {
            var a = b.createElement("video"),
                c = !1;
            try {
                if ((c = !!a.canPlayType))
                    (c = new Boolean(c)),
                        (c.ogg = a.canPlayType('video/ogg; codecs="theora"').replace(/^no$/, "")),
                        (c.h264 = a.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/, "")),
                        (c.webm = a.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/, ""));
            } catch (d) {}
            return c;
        }),
        (s.audio = function () {
            var a = b.createElement("audio"),
                c = !1;
            try {
                if ((c = !!a.canPlayType))
                    (c = new Boolean(c)),
                        (c.ogg = a.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, "")),
                        (c.mp3 = a.canPlayType("audio/mpeg;").replace(/^no$/, "")),
                        (c.wav = a.canPlayType('audio/wav; codecs="1"').replace(/^no$/, "")),
                        (c.m4a = (a.canPlayType("audio/x-m4a;") || a.canPlayType("audio/aac;")).replace(/^no$/, ""));
            } catch (d) {}
            return c;
        }),
        (s.localstorage = function () {
            try {
                return localStorage.setItem(h, h), localStorage.removeItem(h), !0;
            } catch (a) {
                return !1;
            }
        }),
        (s.sessionstorage = function () {
            try {
                return sessionStorage.setItem(h, h), sessionStorage.removeItem(h), !0;
            } catch (a) {
                return !1;
            }
        }),
        (s.webworkers = function () {
            return !!a.Worker;
        }),
        (s.applicationcache = function () {
            return !!a.applicationCache;
        }),
        (s.svg = function () {
            return !!b.createElementNS && !!b.createElementNS(r.svg, "svg").createSVGRect;
        }),
        (s.inlinesvg = function () {
            var a = b.createElement("div");
            return (a.innerHTML = "<svg/>"), (a.firstChild && a.firstChild.namespaceURI) == r.svg;
        }),
        (s.smil = function () {
            return !!b.createElementNS && /SVGAnimate/.test(m.call(b.createElementNS(r.svg, "animate")));
        }),
        (s.svgclippaths = function () {
            return !!b.createElementNS && /SVGClipPath/.test(m.call(b.createElementNS(r.svg, "clipPath")));
        });
    for (var L in s) C(s, L) && ((x = L.toLowerCase()), (e[x] = s[L]()), v.push((e[x] ? "" : "no-") + x));
    return (
        e.input || K(),
        (e.addTest = function (a, b) {
            if (typeof a == "object") for (var d in a) C(a, d) && e.addTest(d, a[d]);
            else {
                a = a.toLowerCase();
                if (e[a] !== c) return e;
                (b = typeof b == "function" ? b() : b), typeof f != "undefined" && f && (g.className += " " + (b ? "" : "no-") + a), (e[a] = b);
            }
            return e;
        }),
        D(""),
        (i = k = null),
        (function (a, b) {
            function l(a, b) {
                var c = a.createElement("p"),
                    d = a.getElementsByTagName("head")[0] || a.documentElement;
                return (c.innerHTML = "x<style>" + b + "</style>"), d.insertBefore(c.lastChild, d.firstChild);
            }
            function m() {
                var a = s.elements;
                return typeof a == "string" ? a.split(" ") : a;
            }
            function n(a) {
                var b = j[a[h]];
                return b || ((b = {}), i++, (a[h] = i), (j[i] = b)), b;
            }
            function o(a, c, d) {
                c || (c = b);
                if (k) return c.createElement(a);
                d || (d = n(c));
                var g;
                return d.cache[a] ? (g = d.cache[a].cloneNode()) : f.test(a) ? (g = (d.cache[a] = d.createElem(a)).cloneNode()) : (g = d.createElem(a)), g.canHaveChildren && !e.test(a) && !g.tagUrn ? d.frag.appendChild(g) : g;
            }
            function p(a, c) {
                a || (a = b);
                if (k) return a.createDocumentFragment();
                c = c || n(a);
                var d = c.frag.cloneNode(),
                    e = 0,
                    f = m(),
                    g = f.length;
                for (; e < g; e++) d.createElement(f[e]);
                return d;
            }
            function q(a, b) {
                b.cache || ((b.cache = {}), (b.createElem = a.createElement), (b.createFrag = a.createDocumentFragment), (b.frag = b.createFrag())),
                    (a.createElement = function (c) {
                        return s.shivMethods ? o(c, a, b) : b.createElem(c);
                    }),
                    (a.createDocumentFragment = Function(
                        "h,f",
                        "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" +
                            m()
                                .join()
                                .replace(/[\w\-]+/g, function (a) {
                                    return b.createElem(a), b.frag.createElement(a), 'c("' + a + '")';
                                }) +
                            ");return n}"
                    )(s, b.frag));
            }
            function r(a) {
                a || (a = b);
                var c = n(a);
                return (
                    s.shivCSS && !g && !c.hasCSS && (c.hasCSS = !!l(a, "article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")), k || q(a, c), a
                );
            }
            var c = "3.7.0",
                d = a.html5 || {},
                e = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,
                f = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,
                g,
                h = "_html5shiv",
                i = 0,
                j = {},
                k;
            (function () {
                try {
                    var a = b.createElement("a");
                    (a.innerHTML = "<xyz></xyz>"),
                        (g = "hidden" in a),
                        (k =
                            a.childNodes.length == 1 ||
                            (function () {
                                b.createElement("a");
                                var a = b.createDocumentFragment();
                                return typeof a.cloneNode == "undefined" || typeof a.createDocumentFragment == "undefined" || typeof a.createElement == "undefined";
                            })());
                } catch (c) {
                    (g = !0), (k = !0);
                }
            })();
            var s = {
                elements: d.elements || "abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",
                version: c,
                shivCSS: d.shivCSS !== !1,
                supportsUnknownElements: k,
                shivMethods: d.shivMethods !== !1,
                type: "default",
                shivDocument: r,
                createElement: o,
                createDocumentFragment: p,
            };
            (a.html5 = s), r(b);
        })(this, b),
        (e._version = d),
        (e._prefixes = n),
        (e._domPrefixes = q),
        (e._cssomPrefixes = p),
        (e.mq = z),
        (e.hasEvent = A),
        (e.testProp = function (a) {
            return H([a]);
        }),
        (e.testAllProps = J),
        (e.testStyles = y),
        (e.prefixed = function (a, b, c) {
            return b ? J(a, b, c) : J(a, "pfx");
        }),
        (g.className = g.className.replace(/(^|\s)no-js(\s|$)/, "$1$2") + (f ? " js " + v.join(" ") : "")),
        e
    );
})(this, this.document)),
    (function (a, b, c) {
        function d(a) {
            return "[object Function]" == o.call(a);
        }
        function e(a) {
            return "string" == typeof a;
        }
        function f() {}
        function g(a) {
            return !a || "loaded" == a || "complete" == a || "uninitialized" == a;
        }
        function h() {
            var a = p.shift();
            (q = 1),
                a
                    ? a.t
                        ? m(function () {
                              ("c" == a.t ? B.injectCss : B.injectJs)(a.s, 0, a.a, a.x, a.e, 1);
                          }, 0)
                        : (a(), h())
                    : (q = 0);
        }
        function i(a, c, d, e, f, i, j) {
            function k(b) {
                if (!o && g(l.readyState) && ((u.r = o = 1), !q && h(), (l.onload = l.onreadystatechange = null), b)) {
                    "img" != a &&
                        m(function () {
                            t.removeChild(l);
                        }, 50);
                    for (var d in y[c]) y[c].hasOwnProperty(d) && y[c][d].onload();
                }
            }
            var j = j || B.errorTimeout,
                l = b.createElement(a),
                o = 0,
                r = 0,
                u = { t: d, s: c, e: f, a: i, x: j };
            1 === y[c] && ((r = 1), (y[c] = [])),
                "object" == a ? (l.data = c) : ((l.src = c), (l.type = a)),
                (l.width = l.height = "0"),
                (l.onerror = l.onload = l.onreadystatechange = function () {
                    k.call(this, r);
                }),
                p.splice(e, 0, u),
                "img" != a && (r || 2 === y[c] ? (t.insertBefore(l, s ? null : n), m(k, j)) : y[c].push(l));
        }
        function j(a, b, c, d, f) {
            return (q = 0), (b = b || "j"), e(a) ? i("c" == b ? v : u, a, b, this.i++, c, d, f) : (p.splice(this.i++, 0, a), 1 == p.length && h()), this;
        }
        function k() {
            var a = B;
            return (a.loader = { load: j, i: 0 }), a;
        }
        var l = b.documentElement,
            m = a.setTimeout,
            n = b.getElementsByTagName("script")[0],
            o = {}.toString,
            p = [],
            q = 0,
            r = "MozAppearance" in l.style,
            s = r && !!b.createRange().compareNode,
            t = s ? l : n.parentNode,
            l = a.opera && "[object Opera]" == o.call(a.opera),
            l = !!b.attachEvent && !l,
            u = r ? "object" : l ? "script" : "img",
            v = l ? "script" : u,
            w =
                Array.isArray ||
                function (a) {
                    return "[object Array]" == o.call(a);
                },
            x = [],
            y = {},
            z = {
                timeout: function (a, b) {
                    return b.length && (a.timeout = b[0]), a;
                },
            },
            A,
            B;
        (B = function (a) {
            function b(a) {
                var a = a.split("!"),
                    b = x.length,
                    c = a.pop(),
                    d = a.length,
                    c = { url: c, origUrl: c, prefixes: a },
                    e,
                    f,
                    g;
                for (f = 0; f < d; f++) (g = a[f].split("=")), (e = z[g.shift()]) && (c = e(c, g));
                for (f = 0; f < b; f++) c = x[f](c);
                return c;
            }
            function g(a, e, f, g, h) {
                var i = b(a),
                    j = i.autoCallback;
                i.url.split(".").pop().split("?").shift(),
                    i.bypass ||
                        (e && (e = d(e) ? e : e[a] || e[g] || e[a.split("/").pop().split("?")[0]]),
                        i.instead
                            ? i.instead(a, e, f, g, h)
                            : (y[i.url] ? (i.noexec = !0) : (y[i.url] = 1),
                              f.load(i.url, i.forceCSS || (!i.forceJS && "css" == i.url.split(".").pop().split("?").shift()) ? "c" : c, i.noexec, i.attrs, i.timeout),
                              (d(e) || d(j)) &&
                                  f.load(function () {
                                      k(), e && e(i.origUrl, h, g), j && j(i.origUrl, h, g), (y[i.url] = 2);
                                  })));
            }
            function h(a, b) {
                function c(a, c) {
                    if (a) {
                        if (e(a))
                            c ||
                                (j = function () {
                                    var a = [].slice.call(arguments);
                                    k.apply(this, a), l();
                                }),
                                g(a, j, b, 0, h);
                        else if (Object(a) === a)
                            for (n in ((m = (function () {
                                var b = 0,
                                    c;
                                for (c in a) a.hasOwnProperty(c) && b++;
                                return b;
                            })()),
                            a))
                                a.hasOwnProperty(n) &&
                                    (!c &&
                                        !--m &&
                                        (d(j)
                                            ? (j = function () {
                                                  var a = [].slice.call(arguments);
                                                  k.apply(this, a), l();
                                              })
                                            : (j[n] = (function (a) {
                                                  return function () {
                                                      var b = [].slice.call(arguments);
                                                      a && a.apply(this, b), l();
                                                  };
                                              })(k[n]))),
                                    g(a[n], j, b, n, h));
                    } else !c && l();
                }
                var h = !!a.test,
                    i = a.load || a.both,
                    j = a.callback || f,
                    k = j,
                    l = a.complete || f,
                    m,
                    n;
                c(h ? a.yep : a.nope, !!i), i && c(i);
            }
            var i,
                j,
                l = this.yepnope.loader;
            if (e(a)) g(a, 0, l, 0);
            else if (w(a)) for (i = 0; i < a.length; i++) (j = a[i]), e(j) ? g(j, 0, l, 0) : w(j) ? B(j) : Object(j) === j && h(j, l);
            else Object(a) === a && h(a, l);
        }),
            (B.addPrefix = function (a, b) {
                z[a] = b;
            }),
            (B.addFilter = function (a) {
                x.push(a);
            }),
            (B.errorTimeout = 1e4),
            null == b.readyState &&
                b.addEventListener &&
                ((b.readyState = "loading"),
                b.addEventListener(
                    "DOMContentLoaded",
                    (A = function () {
                        b.removeEventListener("DOMContentLoaded", A, 0), (b.readyState = "complete");
                    }),
                    0
                )),
            (a.yepnope = k()),
            (a.yepnope.executeStack = h),
            (a.yepnope.injectJs = function (a, c, d, e, i, j) {
                var k = b.createElement("script"),
                    l,
                    o,
                    e = e || B.errorTimeout;
                k.src = a;
                for (o in d) k.setAttribute(o, d[o]);
                (c = j ? h : c || f),
                    (k.onreadystatechange = k.onload = function () {
                        !l && g(k.readyState) && ((l = 1), c(), (k.onload = k.onreadystatechange = null));
                    }),
                    m(function () {
                        l || ((l = 1), c(1));
                    }, e),
                    i ? k.onload() : n.parentNode.insertBefore(k, n);
            }),
            (a.yepnope.injectCss = function (a, c, d, e, g, i) {
                var e = b.createElement("link"),
                    j,
                    c = i ? h : c || f;
                (e.href = a), (e.rel = "stylesheet"), (e.type = "text/css");
                for (j in d) e.setAttribute(j, d[j]);
                g || (n.parentNode.insertBefore(e, n), m(c, 0));
            });
    })(this, document),
    (Modernizr.load = function () {
        yepnope.apply(window, [].slice.call(arguments, 0));
    });

/*-------------------------------------------------------------
  2. jQuery v3.4.1
---------------------------------------------------------------*/
/*! jQuery v3.4.1 | (c) JS Foundation and other contributors | jquery.org/license */
!(function (e, t) {
    "use strict";
    "object" == typeof module && "object" == typeof module.exports
        ? (module.exports = e.document
              ? t(e, !0)
              : function (e) {
                    if (!e.document) throw new Error("jQuery requires a window with a document");
                    return t(e);
                })
        : t(e);
})("undefined" != typeof window ? window : this, function (C, e) {
    "use strict";
    var t = [],
        E = C.document,
        r = Object.getPrototypeOf,
        s = t.slice,
        g = t.concat,
        u = t.push,
        i = t.indexOf,
        n = {},
        o = n.toString,
        v = n.hasOwnProperty,
        a = v.toString,
        l = a.call(Object),
        y = {},
        m = function (e) {
            return "function" == typeof e && "number" != typeof e.nodeType;
        },
        x = function (e) {
            return null != e && e === e.window;
        },
        c = { type: !0, src: !0, nonce: !0, noModule: !0 };
    function b(e, t, n) {
        var r,
            i,
            o = (n = n || E).createElement("script");
        if (((o.text = e), t)) for (r in c) (i = t[r] || (t.getAttribute && t.getAttribute(r))) && o.setAttribute(r, i);
        n.head.appendChild(o).parentNode.removeChild(o);
    }
    function w(e) {
        return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? n[o.call(e)] || "object" : typeof e;
    }
    var f = "3.4.1",
        k = function (e, t) {
            return new k.fn.init(e, t);
        },
        p = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
    function d(e) {
        var t = !!e && "length" in e && e.length,
            n = w(e);
        return !m(e) && !x(e) && ("array" === n || 0 === t || ("number" == typeof t && 0 < t && t - 1 in e));
    }
    (k.fn = k.prototype = {
        jquery: f,
        constructor: k,
        length: 0,
        toArray: function () {
            return s.call(this);
        },
        get: function (e) {
            return null == e ? s.call(this) : e < 0 ? this[e + this.length] : this[e];
        },
        pushStack: function (e) {
            var t = k.merge(this.constructor(), e);
            return (t.prevObject = this), t;
        },
        each: function (e) {
            return k.each(this, e);
        },
        map: function (n) {
            return this.pushStack(
                k.map(this, function (e, t) {
                    return n.call(e, t, e);
                })
            );
        },
        slice: function () {
            return this.pushStack(s.apply(this, arguments));
        },
        first: function () {
            return this.eq(0);
        },
        last: function () {
            return this.eq(-1);
        },
        eq: function (e) {
            var t = this.length,
                n = +e + (e < 0 ? t : 0);
            return this.pushStack(0 <= n && n < t ? [this[n]] : []);
        },
        end: function () {
            return this.prevObject || this.constructor();
        },
        push: u,
        sort: t.sort,
        splice: t.splice,
    }),
        (k.extend = k.fn.extend = function () {
            var e,
                t,
                n,
                r,
                i,
                o,
                a = arguments[0] || {},
                s = 1,
                u = arguments.length,
                l = !1;
            for ("boolean" == typeof a && ((l = a), (a = arguments[s] || {}), s++), "object" == typeof a || m(a) || (a = {}), s === u && ((a = this), s--); s < u; s++)
                if (null != (e = arguments[s]))
                    for (t in e)
                        (r = e[t]),
                            "__proto__" !== t &&
                                a !== r &&
                                (l && r && (k.isPlainObject(r) || (i = Array.isArray(r)))
                                    ? ((n = a[t]), (o = i && !Array.isArray(n) ? [] : i || k.isPlainObject(n) ? n : {}), (i = !1), (a[t] = k.extend(l, o, r)))
                                    : void 0 !== r && (a[t] = r));
            return a;
        }),
        k.extend({
            expando: "jQuery" + (f + Math.random()).replace(/\D/g, ""),
            isReady: !0,
            error: function (e) {
                throw new Error(e);
            },
            noop: function () {},
            isPlainObject: function (e) {
                var t, n;
                return !(!e || "[object Object]" !== o.call(e)) && (!(t = r(e)) || ("function" == typeof (n = v.call(t, "constructor") && t.constructor) && a.call(n) === l));
            },
            isEmptyObject: function (e) {
                var t;
                for (t in e) return !1;
                return !0;
            },
            globalEval: function (e, t) {
                b(e, { nonce: t && t.nonce });
            },
            each: function (e, t) {
                var n,
                    r = 0;
                if (d(e)) {
                    for (n = e.length; r < n; r++) if (!1 === t.call(e[r], r, e[r])) break;
                } else for (r in e) if (!1 === t.call(e[r], r, e[r])) break;
                return e;
            },
            trim: function (e) {
                return null == e ? "" : (e + "").replace(p, "");
            },
            makeArray: function (e, t) {
                var n = t || [];
                return null != e && (d(Object(e)) ? k.merge(n, "string" == typeof e ? [e] : e) : u.call(n, e)), n;
            },
            inArray: function (e, t, n) {
                return null == t ? -1 : i.call(t, e, n);
            },
            merge: function (e, t) {
                for (var n = +t.length, r = 0, i = e.length; r < n; r++) e[i++] = t[r];
                return (e.length = i), e;
            },
            grep: function (e, t, n) {
                for (var r = [], i = 0, o = e.length, a = !n; i < o; i++) !t(e[i], i) !== a && r.push(e[i]);
                return r;
            },
            map: function (e, t, n) {
                var r,
                    i,
                    o = 0,
                    a = [];
                if (d(e)) for (r = e.length; o < r; o++) null != (i = t(e[o], o, n)) && a.push(i);
                else for (o in e) null != (i = t(e[o], o, n)) && a.push(i);
                return g.apply([], a);
            },
            guid: 1,
            support: y,
        }),
        "function" == typeof Symbol && (k.fn[Symbol.iterator] = t[Symbol.iterator]),
        k.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (e, t) {
            n["[object " + t + "]"] = t.toLowerCase();
        });
    var h = (function (n) {
        var e,
            d,
            b,
            o,
            i,
            h,
            f,
            g,
            w,
            u,
            l,
            T,
            C,
            a,
            E,
            v,
            s,
            c,
            y,
            k = "sizzle" + 1 * new Date(),
            m = n.document,
            S = 0,
            r = 0,
            p = ue(),
            x = ue(),
            N = ue(),
            A = ue(),
            D = function (e, t) {
                return e === t && (l = !0), 0;
            },
            j = {}.hasOwnProperty,
            t = [],
            q = t.pop,
            L = t.push,
            H = t.push,
            O = t.slice,
            P = function (e, t) {
                for (var n = 0, r = e.length; n < r; n++) if (e[n] === t) return n;
                return -1;
            },
            R = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            M = "[\\x20\\t\\r\\n\\f]",
            I = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
            W = "\\[" + M + "*(" + I + ")(?:" + M + "*([*^$|!~]?=)" + M + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + I + "))|)" + M + "*\\]",
            $ = ":(" + I + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + W + ")*)|.*)\\)|)",
            F = new RegExp(M + "+", "g"),
            B = new RegExp("^" + M + "+|((?:^|[^\\\\])(?:\\\\.)*)" + M + "+$", "g"),
            _ = new RegExp("^" + M + "*," + M + "*"),
            z = new RegExp("^" + M + "*([>+~]|" + M + ")" + M + "*"),
            U = new RegExp(M + "|>"),
            X = new RegExp($),
            V = new RegExp("^" + I + "$"),
            G = {
                ID: new RegExp("^#(" + I + ")"),
                CLASS: new RegExp("^\\.(" + I + ")"),
                TAG: new RegExp("^(" + I + "|[*])"),
                ATTR: new RegExp("^" + W),
                PSEUDO: new RegExp("^" + $),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + M + "*(even|odd|(([+-]|)(\\d*)n|)" + M + "*(?:([+-]|)" + M + "*(\\d+)|))" + M + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + R + ")$", "i"),
                needsContext: new RegExp("^" + M + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + M + "*((?:-\\d)?\\d*)" + M + "*\\)|)(?=[^-]|$)", "i"),
            },
            Y = /HTML$/i,
            Q = /^(?:input|select|textarea|button)$/i,
            J = /^h\d$/i,
            K = /^[^{]+\{\s*\[native \w/,
            Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            ee = /[+~]/,
            te = new RegExp("\\\\([\\da-f]{1,6}" + M + "?|(" + M + ")|.)", "ig"),
            ne = function (e, t, n) {
                var r = "0x" + t - 65536;
                return r != r || n ? t : r < 0 ? String.fromCharCode(r + 65536) : String.fromCharCode((r >> 10) | 55296, (1023 & r) | 56320);
            },
            re = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
            ie = function (e, t) {
                return t ? ("\0" === e ? "\ufffd" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " ") : "\\" + e;
            },
            oe = function () {
                T();
            },
            ae = be(
                function (e) {
                    return !0 === e.disabled && "fieldset" === e.nodeName.toLowerCase();
                },
                { dir: "parentNode", next: "legend" }
            );
        try {
            H.apply((t = O.call(m.childNodes)), m.childNodes), t[m.childNodes.length].nodeType;
        } catch (e) {
            H = {
                apply: t.length
                    ? function (e, t) {
                          L.apply(e, O.call(t));
                      }
                    : function (e, t) {
                          var n = e.length,
                              r = 0;
                          while ((e[n++] = t[r++]));
                          e.length = n - 1;
                      },
            };
        }
        function se(t, e, n, r) {
            var i,
                o,
                a,
                s,
                u,
                l,
                c,
                f = e && e.ownerDocument,
                p = e ? e.nodeType : 9;
            if (((n = n || []), "string" != typeof t || !t || (1 !== p && 9 !== p && 11 !== p))) return n;
            if (!r && ((e ? e.ownerDocument || e : m) !== C && T(e), (e = e || C), E)) {
                if (11 !== p && (u = Z.exec(t)))
                    if ((i = u[1])) {
                        if (9 === p) {
                            if (!(a = e.getElementById(i))) return n;
                            if (a.id === i) return n.push(a), n;
                        } else if (f && (a = f.getElementById(i)) && y(e, a) && a.id === i) return n.push(a), n;
                    } else {
                        if (u[2]) return H.apply(n, e.getElementsByTagName(t)), n;
                        if ((i = u[3]) && d.getElementsByClassName && e.getElementsByClassName) return H.apply(n, e.getElementsByClassName(i)), n;
                    }
                if (d.qsa && !A[t + " "] && (!v || !v.test(t)) && (1 !== p || "object" !== e.nodeName.toLowerCase())) {
                    if (((c = t), (f = e), 1 === p && U.test(t))) {
                        (s = e.getAttribute("id")) ? (s = s.replace(re, ie)) : e.setAttribute("id", (s = k)), (o = (l = h(t)).length);
                        while (o--) l[o] = "#" + s + " " + xe(l[o]);
                        (c = l.join(",")), (f = (ee.test(t) && ye(e.parentNode)) || e);
                    }
                    try {
                        return H.apply(n, f.querySelectorAll(c)), n;
                    } catch (e) {
                        A(t, !0);
                    } finally {
                        s === k && e.removeAttribute("id");
                    }
                }
            }
            return g(t.replace(B, "$1"), e, n, r);
        }
        function ue() {
            var r = [];
            return function e(t, n) {
                return r.push(t + " ") > b.cacheLength && delete e[r.shift()], (e[t + " "] = n);
            };
        }
        function le(e) {
            return (e[k] = !0), e;
        }
        function ce(e) {
            var t = C.createElement("fieldset");
            try {
                return !!e(t);
            } catch (e) {
                return !1;
            } finally {
                t.parentNode && t.parentNode.removeChild(t), (t = null);
            }
        }
        function fe(e, t) {
            var n = e.split("|"),
                r = n.length;
            while (r--) b.attrHandle[n[r]] = t;
        }
        function pe(e, t) {
            var n = t && e,
                r = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
            if (r) return r;
            if (n) while ((n = n.nextSibling)) if (n === t) return -1;
            return e ? 1 : -1;
        }
        function de(t) {
            return function (e) {
                return "input" === e.nodeName.toLowerCase() && e.type === t;
            };
        }
        function he(n) {
            return function (e) {
                var t = e.nodeName.toLowerCase();
                return ("input" === t || "button" === t) && e.type === n;
            };
        }
        function ge(t) {
            return function (e) {
                return "form" in e
                    ? e.parentNode && !1 === e.disabled
                        ? "label" in e
                            ? "label" in e.parentNode
                                ? e.parentNode.disabled === t
                                : e.disabled === t
                            : e.isDisabled === t || (e.isDisabled !== !t && ae(e) === t)
                        : e.disabled === t
                    : "label" in e && e.disabled === t;
            };
        }
        function ve(a) {
            return le(function (o) {
                return (
                    (o = +o),
                    le(function (e, t) {
                        var n,
                            r = a([], e.length, o),
                            i = r.length;
                        while (i--) e[(n = r[i])] && (e[n] = !(t[n] = e[n]));
                    })
                );
            });
        }
        function ye(e) {
            return e && "undefined" != typeof e.getElementsByTagName && e;
        }
        for (e in ((d = se.support = {}),
        (i = se.isXML = function (e) {
            var t = e.namespaceURI,
                n = (e.ownerDocument || e).documentElement;
            return !Y.test(t || (n && n.nodeName) || "HTML");
        }),
        (T = se.setDocument = function (e) {
            var t,
                n,
                r = e ? e.ownerDocument || e : m;
            return (
                r !== C &&
                    9 === r.nodeType &&
                    r.documentElement &&
                    ((a = (C = r).documentElement),
                    (E = !i(C)),
                    m !== C && (n = C.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", oe, !1) : n.attachEvent && n.attachEvent("onunload", oe)),
                    (d.attributes = ce(function (e) {
                        return (e.className = "i"), !e.getAttribute("className");
                    })),
                    (d.getElementsByTagName = ce(function (e) {
                        return e.appendChild(C.createComment("")), !e.getElementsByTagName("*").length;
                    })),
                    (d.getElementsByClassName = K.test(C.getElementsByClassName)),
                    (d.getById = ce(function (e) {
                        return (a.appendChild(e).id = k), !C.getElementsByName || !C.getElementsByName(k).length;
                    })),
                    d.getById
                        ? ((b.filter.ID = function (e) {
                              var t = e.replace(te, ne);
                              return function (e) {
                                  return e.getAttribute("id") === t;
                              };
                          }),
                          (b.find.ID = function (e, t) {
                              if ("undefined" != typeof t.getElementById && E) {
                                  var n = t.getElementById(e);
                                  return n ? [n] : [];
                              }
                          }))
                        : ((b.filter.ID = function (e) {
                              var n = e.replace(te, ne);
                              return function (e) {
                                  var t = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id");
                                  return t && t.value === n;
                              };
                          }),
                          (b.find.ID = function (e, t) {
                              if ("undefined" != typeof t.getElementById && E) {
                                  var n,
                                      r,
                                      i,
                                      o = t.getElementById(e);
                                  if (o) {
                                      if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
                                      (i = t.getElementsByName(e)), (r = 0);
                                      while ((o = i[r++])) if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
                                  }
                                  return [];
                              }
                          })),
                    (b.find.TAG = d.getElementsByTagName
                        ? function (e, t) {
                              return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : d.qsa ? t.querySelectorAll(e) : void 0;
                          }
                        : function (e, t) {
                              var n,
                                  r = [],
                                  i = 0,
                                  o = t.getElementsByTagName(e);
                              if ("*" === e) {
                                  while ((n = o[i++])) 1 === n.nodeType && r.push(n);
                                  return r;
                              }
                              return o;
                          }),
                    (b.find.CLASS =
                        d.getElementsByClassName &&
                        function (e, t) {
                            if ("undefined" != typeof t.getElementsByClassName && E) return t.getElementsByClassName(e);
                        }),
                    (s = []),
                    (v = []),
                    (d.qsa = K.test(C.querySelectorAll)) &&
                        (ce(function (e) {
                            (a.appendChild(e).innerHTML = "<a id='" + k + "'></a><select id='" + k + "-\r\\' msallowcapture=''><option selected=''></option></select>"),
                                e.querySelectorAll("[msallowcapture^='']").length && v.push("[*^$]=" + M + "*(?:''|\"\")"),
                                e.querySelectorAll("[selected]").length || v.push("\\[" + M + "*(?:value|" + R + ")"),
                                e.querySelectorAll("[id~=" + k + "-]").length || v.push("~="),
                                e.querySelectorAll(":checked").length || v.push(":checked"),
                                e.querySelectorAll("a#" + k + "+*").length || v.push(".#.+[+~]");
                        }),
                        ce(function (e) {
                            e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                            var t = C.createElement("input");
                            t.setAttribute("type", "hidden"),
                                e.appendChild(t).setAttribute("name", "D"),
                                e.querySelectorAll("[name=d]").length && v.push("name" + M + "*[*^$|!~]?="),
                                2 !== e.querySelectorAll(":enabled").length && v.push(":enabled", ":disabled"),
                                (a.appendChild(e).disabled = !0),
                                2 !== e.querySelectorAll(":disabled").length && v.push(":enabled", ":disabled"),
                                e.querySelectorAll("*,:x"),
                                v.push(",.*:");
                        })),
                    (d.matchesSelector = K.test((c = a.matches || a.webkitMatchesSelector || a.mozMatchesSelector || a.oMatchesSelector || a.msMatchesSelector))) &&
                        ce(function (e) {
                            (d.disconnectedMatch = c.call(e, "*")), c.call(e, "[s!='']:x"), s.push("!=", $);
                        }),
                    (v = v.length && new RegExp(v.join("|"))),
                    (s = s.length && new RegExp(s.join("|"))),
                    (t = K.test(a.compareDocumentPosition)),
                    (y =
                        t || K.test(a.contains)
                            ? function (e, t) {
                                  var n = 9 === e.nodeType ? e.documentElement : e,
                                      r = t && t.parentNode;
                                  return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)));
                              }
                            : function (e, t) {
                                  if (t) while ((t = t.parentNode)) if (t === e) return !0;
                                  return !1;
                              }),
                    (D = t
                        ? function (e, t) {
                              if (e === t) return (l = !0), 0;
                              var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                              return (
                                  n ||
                                  (1 & (n = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || (!d.sortDetached && t.compareDocumentPosition(e) === n)
                                      ? e === C || (e.ownerDocument === m && y(m, e))
                                          ? -1
                                          : t === C || (t.ownerDocument === m && y(m, t))
                                          ? 1
                                          : u
                                          ? P(u, e) - P(u, t)
                                          : 0
                                      : 4 & n
                                      ? -1
                                      : 1)
                              );
                          }
                        : function (e, t) {
                              if (e === t) return (l = !0), 0;
                              var n,
                                  r = 0,
                                  i = e.parentNode,
                                  o = t.parentNode,
                                  a = [e],
                                  s = [t];
                              if (!i || !o) return e === C ? -1 : t === C ? 1 : i ? -1 : o ? 1 : u ? P(u, e) - P(u, t) : 0;
                              if (i === o) return pe(e, t);
                              n = e;
                              while ((n = n.parentNode)) a.unshift(n);
                              n = t;
                              while ((n = n.parentNode)) s.unshift(n);
                              while (a[r] === s[r]) r++;
                              return r ? pe(a[r], s[r]) : a[r] === m ? -1 : s[r] === m ? 1 : 0;
                          })),
                C
            );
        }),
        (se.matches = function (e, t) {
            return se(e, null, null, t);
        }),
        (se.matchesSelector = function (e, t) {
            if (((e.ownerDocument || e) !== C && T(e), d.matchesSelector && E && !A[t + " "] && (!s || !s.test(t)) && (!v || !v.test(t))))
                try {
                    var n = c.call(e, t);
                    if (n || d.disconnectedMatch || (e.document && 11 !== e.document.nodeType)) return n;
                } catch (e) {
                    A(t, !0);
                }
            return 0 < se(t, C, null, [e]).length;
        }),
        (se.contains = function (e, t) {
            return (e.ownerDocument || e) !== C && T(e), y(e, t);
        }),
        (se.attr = function (e, t) {
            (e.ownerDocument || e) !== C && T(e);
            var n = b.attrHandle[t.toLowerCase()],
                r = n && j.call(b.attrHandle, t.toLowerCase()) ? n(e, t, !E) : void 0;
            return void 0 !== r ? r : d.attributes || !E ? e.getAttribute(t) : (r = e.getAttributeNode(t)) && r.specified ? r.value : null;
        }),
        (se.escape = function (e) {
            return (e + "").replace(re, ie);
        }),
        (se.error = function (e) {
            throw new Error("Syntax error, unrecognized expression: " + e);
        }),
        (se.uniqueSort = function (e) {
            var t,
                n = [],
                r = 0,
                i = 0;
            if (((l = !d.detectDuplicates), (u = !d.sortStable && e.slice(0)), e.sort(D), l)) {
                while ((t = e[i++])) t === e[i] && (r = n.push(i));
                while (r--) e.splice(n[r], 1);
            }
            return (u = null), e;
        }),
        (o = se.getText = function (e) {
            var t,
                n = "",
                r = 0,
                i = e.nodeType;
            if (i) {
                if (1 === i || 9 === i || 11 === i) {
                    if ("string" == typeof e.textContent) return e.textContent;
                    for (e = e.firstChild; e; e = e.nextSibling) n += o(e);
                } else if (3 === i || 4 === i) return e.nodeValue;
            } else while ((t = e[r++])) n += o(t);
            return n;
        }),
        ((b = se.selectors = {
            cacheLength: 50,
            createPseudo: le,
            match: G,
            attrHandle: {},
            find: {},
            relative: { ">": { dir: "parentNode", first: !0 }, " ": { dir: "parentNode" }, "+": { dir: "previousSibling", first: !0 }, "~": { dir: "previousSibling" } },
            preFilter: {
                ATTR: function (e) {
                    return (e[1] = e[1].replace(te, ne)), (e[3] = (e[3] || e[4] || e[5] || "").replace(te, ne)), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4);
                },
                CHILD: function (e) {
                    return (
                        (e[1] = e[1].toLowerCase()),
                        "nth" === e[1].slice(0, 3) ? (e[3] || se.error(e[0]), (e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3]))), (e[5] = +(e[7] + e[8] || "odd" === e[3]))) : e[3] && se.error(e[0]),
                        e
                    );
                },
                PSEUDO: function (e) {
                    var t,
                        n = !e[6] && e[2];
                    return G.CHILD.test(e[0])
                        ? null
                        : (e[3] ? (e[2] = e[4] || e[5] || "") : n && X.test(n) && (t = h(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && ((e[0] = e[0].slice(0, t)), (e[2] = n.slice(0, t))), e.slice(0, 3));
                },
            },
            filter: {
                TAG: function (e) {
                    var t = e.replace(te, ne).toLowerCase();
                    return "*" === e
                        ? function () {
                              return !0;
                          }
                        : function (e) {
                              return e.nodeName && e.nodeName.toLowerCase() === t;
                          };
                },
                CLASS: function (e) {
                    var t = p[e + " "];
                    return (
                        t ||
                        ((t = new RegExp("(^|" + M + ")" + e + "(" + M + "|$)")) &&
                            p(e, function (e) {
                                return t.test(("string" == typeof e.className && e.className) || ("undefined" != typeof e.getAttribute && e.getAttribute("class")) || "");
                            }))
                    );
                },
                ATTR: function (n, r, i) {
                    return function (e) {
                        var t = se.attr(e, n);
                        return null == t
                            ? "!=" === r
                            : !r ||
                                  ((t += ""),
                                  "=" === r
                                      ? t === i
                                      : "!=" === r
                                      ? t !== i
                                      : "^=" === r
                                      ? i && 0 === t.indexOf(i)
                                      : "*=" === r
                                      ? i && -1 < t.indexOf(i)
                                      : "$=" === r
                                      ? i && t.slice(-i.length) === i
                                      : "~=" === r
                                      ? -1 < (" " + t.replace(F, " ") + " ").indexOf(i)
                                      : "|=" === r && (t === i || t.slice(0, i.length + 1) === i + "-"));
                    };
                },
                CHILD: function (h, e, t, g, v) {
                    var y = "nth" !== h.slice(0, 3),
                        m = "last" !== h.slice(-4),
                        x = "of-type" === e;
                    return 1 === g && 0 === v
                        ? function (e) {
                              return !!e.parentNode;
                          }
                        : function (e, t, n) {
                              var r,
                                  i,
                                  o,
                                  a,
                                  s,
                                  u,
                                  l = y !== m ? "nextSibling" : "previousSibling",
                                  c = e.parentNode,
                                  f = x && e.nodeName.toLowerCase(),
                                  p = !n && !x,
                                  d = !1;
                              if (c) {
                                  if (y) {
                                      while (l) {
                                          a = e;
                                          while ((a = a[l])) if (x ? a.nodeName.toLowerCase() === f : 1 === a.nodeType) return !1;
                                          u = l = "only" === h && !u && "nextSibling";
                                      }
                                      return !0;
                                  }
                                  if (((u = [m ? c.firstChild : c.lastChild]), m && p)) {
                                      (d = (s = (r = (i = (o = (a = c)[k] || (a[k] = {}))[a.uniqueID] || (o[a.uniqueID] = {}))[h] || [])[0] === S && r[1]) && r[2]), (a = s && c.childNodes[s]);
                                      while ((a = (++s && a && a[l]) || (d = s = 0) || u.pop()))
                                          if (1 === a.nodeType && ++d && a === e) {
                                              i[h] = [S, s, d];
                                              break;
                                          }
                                  } else if ((p && (d = s = (r = (i = (o = (a = e)[k] || (a[k] = {}))[a.uniqueID] || (o[a.uniqueID] = {}))[h] || [])[0] === S && r[1]), !1 === d))
                                      while ((a = (++s && a && a[l]) || (d = s = 0) || u.pop()))
                                          if ((x ? a.nodeName.toLowerCase() === f : 1 === a.nodeType) && ++d && (p && ((i = (o = a[k] || (a[k] = {}))[a.uniqueID] || (o[a.uniqueID] = {}))[h] = [S, d]), a === e)) break;
                                  return (d -= v) === g || (d % g == 0 && 0 <= d / g);
                              }
                          };
                },
                PSEUDO: function (e, o) {
                    var t,
                        a = b.pseudos[e] || b.setFilters[e.toLowerCase()] || se.error("unsupported pseudo: " + e);
                    return a[k]
                        ? a(o)
                        : 1 < a.length
                        ? ((t = [e, e, "", o]),
                          b.setFilters.hasOwnProperty(e.toLowerCase())
                              ? le(function (e, t) {
                                    var n,
                                        r = a(e, o),
                                        i = r.length;
                                    while (i--) e[(n = P(e, r[i]))] = !(t[n] = r[i]);
                                })
                              : function (e) {
                                    return a(e, 0, t);
                                })
                        : a;
                },
            },
            pseudos: {
                not: le(function (e) {
                    var r = [],
                        i = [],
                        s = f(e.replace(B, "$1"));
                    return s[k]
                        ? le(function (e, t, n, r) {
                              var i,
                                  o = s(e, null, r, []),
                                  a = e.length;
                              while (a--) (i = o[a]) && (e[a] = !(t[a] = i));
                          })
                        : function (e, t, n) {
                              return (r[0] = e), s(r, null, n, i), (r[0] = null), !i.pop();
                          };
                }),
                has: le(function (t) {
                    return function (e) {
                        return 0 < se(t, e).length;
                    };
                }),
                contains: le(function (t) {
                    return (
                        (t = t.replace(te, ne)),
                        function (e) {
                            return -1 < (e.textContent || o(e)).indexOf(t);
                        }
                    );
                }),
                lang: le(function (n) {
                    return (
                        V.test(n || "") || se.error("unsupported lang: " + n),
                        (n = n.replace(te, ne).toLowerCase()),
                        function (e) {
                            var t;
                            do {
                                if ((t = E ? e.lang : e.getAttribute("xml:lang") || e.getAttribute("lang"))) return (t = t.toLowerCase()) === n || 0 === t.indexOf(n + "-");
                            } while ((e = e.parentNode) && 1 === e.nodeType);
                            return !1;
                        }
                    );
                }),
                target: function (e) {
                    var t = n.location && n.location.hash;
                    return t && t.slice(1) === e.id;
                },
                root: function (e) {
                    return e === a;
                },
                focus: function (e) {
                    return e === C.activeElement && (!C.hasFocus || C.hasFocus()) && !!(e.type || e.href || ~e.tabIndex);
                },
                enabled: ge(!1),
                disabled: ge(!0),
                checked: function (e) {
                    var t = e.nodeName.toLowerCase();
                    return ("input" === t && !!e.checked) || ("option" === t && !!e.selected);
                },
                selected: function (e) {
                    return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected;
                },
                empty: function (e) {
                    for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return !1;
                    return !0;
                },
                parent: function (e) {
                    return !b.pseudos.empty(e);
                },
                header: function (e) {
                    return J.test(e.nodeName);
                },
                input: function (e) {
                    return Q.test(e.nodeName);
                },
                button: function (e) {
                    var t = e.nodeName.toLowerCase();
                    return ("input" === t && "button" === e.type) || "button" === t;
                },
                text: function (e) {
                    var t;
                    return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase());
                },
                first: ve(function () {
                    return [0];
                }),
                last: ve(function (e, t) {
                    return [t - 1];
                }),
                eq: ve(function (e, t, n) {
                    return [n < 0 ? n + t : n];
                }),
                even: ve(function (e, t) {
                    for (var n = 0; n < t; n += 2) e.push(n);
                    return e;
                }),
                odd: ve(function (e, t) {
                    for (var n = 1; n < t; n += 2) e.push(n);
                    return e;
                }),
                lt: ve(function (e, t, n) {
                    for (var r = n < 0 ? n + t : t < n ? t : n; 0 <= --r; ) e.push(r);
                    return e;
                }),
                gt: ve(function (e, t, n) {
                    for (var r = n < 0 ? n + t : n; ++r < t; ) e.push(r);
                    return e;
                }),
            },
        }).pseudos.nth = b.pseudos.eq),
        { radio: !0, checkbox: !0, file: !0, password: !0, image: !0 }))
            b.pseudos[e] = de(e);
        for (e in { submit: !0, reset: !0 }) b.pseudos[e] = he(e);
        function me() {}
        function xe(e) {
            for (var t = 0, n = e.length, r = ""; t < n; t++) r += e[t].value;
            return r;
        }
        function be(s, e, t) {
            var u = e.dir,
                l = e.next,
                c = l || u,
                f = t && "parentNode" === c,
                p = r++;
            return e.first
                ? function (e, t, n) {
                      while ((e = e[u])) if (1 === e.nodeType || f) return s(e, t, n);
                      return !1;
                  }
                : function (e, t, n) {
                      var r,
                          i,
                          o,
                          a = [S, p];
                      if (n) {
                          while ((e = e[u])) if ((1 === e.nodeType || f) && s(e, t, n)) return !0;
                      } else
                          while ((e = e[u]))
                              if (1 === e.nodeType || f)
                                  if (((i = (o = e[k] || (e[k] = {}))[e.uniqueID] || (o[e.uniqueID] = {})), l && l === e.nodeName.toLowerCase())) e = e[u] || e;
                                  else {
                                      if ((r = i[c]) && r[0] === S && r[1] === p) return (a[2] = r[2]);
                                      if (((i[c] = a)[2] = s(e, t, n))) return !0;
                                  }
                      return !1;
                  };
        }
        function we(i) {
            return 1 < i.length
                ? function (e, t, n) {
                      var r = i.length;
                      while (r--) if (!i[r](e, t, n)) return !1;
                      return !0;
                  }
                : i[0];
        }
        function Te(e, t, n, r, i) {
            for (var o, a = [], s = 0, u = e.length, l = null != t; s < u; s++) (o = e[s]) && ((n && !n(o, r, i)) || (a.push(o), l && t.push(s)));
            return a;
        }
        function Ce(d, h, g, v, y, e) {
            return (
                v && !v[k] && (v = Ce(v)),
                y && !y[k] && (y = Ce(y, e)),
                le(function (e, t, n, r) {
                    var i,
                        o,
                        a,
                        s = [],
                        u = [],
                        l = t.length,
                        c =
                            e ||
                            (function (e, t, n) {
                                for (var r = 0, i = t.length; r < i; r++) se(e, t[r], n);
                                return n;
                            })(h || "*", n.nodeType ? [n] : n, []),
                        f = !d || (!e && h) ? c : Te(c, s, d, n, r),
                        p = g ? (y || (e ? d : l || v) ? [] : t) : f;
                    if ((g && g(f, p, n, r), v)) {
                        (i = Te(p, u)), v(i, [], n, r), (o = i.length);
                        while (o--) (a = i[o]) && (p[u[o]] = !(f[u[o]] = a));
                    }
                    if (e) {
                        if (y || d) {
                            if (y) {
                                (i = []), (o = p.length);
                                while (o--) (a = p[o]) && i.push((f[o] = a));
                                y(null, (p = []), i, r);
                            }
                            o = p.length;
                            while (o--) (a = p[o]) && -1 < (i = y ? P(e, a) : s[o]) && (e[i] = !(t[i] = a));
                        }
                    } else (p = Te(p === t ? p.splice(l, p.length) : p)), y ? y(null, t, p, r) : H.apply(t, p);
                })
            );
        }
        function Ee(e) {
            for (
                var i,
                    t,
                    n,
                    r = e.length,
                    o = b.relative[e[0].type],
                    a = o || b.relative[" "],
                    s = o ? 1 : 0,
                    u = be(
                        function (e) {
                            return e === i;
                        },
                        a,
                        !0
                    ),
                    l = be(
                        function (e) {
                            return -1 < P(i, e);
                        },
                        a,
                        !0
                    ),
                    c = [
                        function (e, t, n) {
                            var r = (!o && (n || t !== w)) || ((i = t).nodeType ? u(e, t, n) : l(e, t, n));
                            return (i = null), r;
                        },
                    ];
                s < r;
                s++
            )
                if ((t = b.relative[e[s].type])) c = [be(we(c), t)];
                else {
                    if ((t = b.filter[e[s].type].apply(null, e[s].matches))[k]) {
                        for (n = ++s; n < r; n++) if (b.relative[e[n].type]) break;
                        return Ce(1 < s && we(c), 1 < s && xe(e.slice(0, s - 1).concat({ value: " " === e[s - 2].type ? "*" : "" })).replace(B, "$1"), t, s < n && Ee(e.slice(s, n)), n < r && Ee((e = e.slice(n))), n < r && xe(e));
                    }
                    c.push(t);
                }
            return we(c);
        }
        return (
            (me.prototype = b.filters = b.pseudos),
            (b.setFilters = new me()),
            (h = se.tokenize = function (e, t) {
                var n,
                    r,
                    i,
                    o,
                    a,
                    s,
                    u,
                    l = x[e + " "];
                if (l) return t ? 0 : l.slice(0);
                (a = e), (s = []), (u = b.preFilter);
                while (a) {
                    for (o in ((n && !(r = _.exec(a))) || (r && (a = a.slice(r[0].length) || a), s.push((i = []))),
                    (n = !1),
                    (r = z.exec(a)) && ((n = r.shift()), i.push({ value: n, type: r[0].replace(B, " ") }), (a = a.slice(n.length))),
                    b.filter))
                        !(r = G[o].exec(a)) || (u[o] && !(r = u[o](r))) || ((n = r.shift()), i.push({ value: n, type: o, matches: r }), (a = a.slice(n.length)));
                    if (!n) break;
                }
                return t ? a.length : a ? se.error(e) : x(e, s).slice(0);
            }),
            (f = se.compile = function (e, t) {
                var n,
                    v,
                    y,
                    m,
                    x,
                    r,
                    i = [],
                    o = [],
                    a = N[e + " "];
                if (!a) {
                    t || (t = h(e)), (n = t.length);
                    while (n--) (a = Ee(t[n]))[k] ? i.push(a) : o.push(a);
                    (a = N(
                        e,
                        ((v = o),
                        (m = 0 < (y = i).length),
                        (x = 0 < v.length),
                        (r = function (e, t, n, r, i) {
                            var o,
                                a,
                                s,
                                u = 0,
                                l = "0",
                                c = e && [],
                                f = [],
                                p = w,
                                d = e || (x && b.find.TAG("*", i)),
                                h = (S += null == p ? 1 : Math.random() || 0.1),
                                g = d.length;
                            for (i && (w = t === C || t || i); l !== g && null != (o = d[l]); l++) {
                                if (x && o) {
                                    (a = 0), t || o.ownerDocument === C || (T(o), (n = !E));
                                    while ((s = v[a++]))
                                        if (s(o, t || C, n)) {
                                            r.push(o);
                                            break;
                                        }
                                    i && (S = h);
                                }
                                m && ((o = !s && o) && u--, e && c.push(o));
                            }
                            if (((u += l), m && l !== u)) {
                                a = 0;
                                while ((s = y[a++])) s(c, f, t, n);
                                if (e) {
                                    if (0 < u) while (l--) c[l] || f[l] || (f[l] = q.call(r));
                                    f = Te(f);
                                }
                                H.apply(r, f), i && !e && 0 < f.length && 1 < u + y.length && se.uniqueSort(r);
                            }
                            return i && ((S = h), (w = p)), c;
                        }),
                        m ? le(r) : r)
                    )).selector = e;
                }
                return a;
            }),
            (g = se.select = function (e, t, n, r) {
                var i,
                    o,
                    a,
                    s,
                    u,
                    l = "function" == typeof e && e,
                    c = !r && h((e = l.selector || e));
                if (((n = n || []), 1 === c.length)) {
                    if (2 < (o = c[0] = c[0].slice(0)).length && "ID" === (a = o[0]).type && 9 === t.nodeType && E && b.relative[o[1].type]) {
                        if (!(t = (b.find.ID(a.matches[0].replace(te, ne), t) || [])[0])) return n;
                        l && (t = t.parentNode), (e = e.slice(o.shift().value.length));
                    }
                    i = G.needsContext.test(e) ? 0 : o.length;
                    while (i--) {
                        if (((a = o[i]), b.relative[(s = a.type)])) break;
                        if ((u = b.find[s]) && (r = u(a.matches[0].replace(te, ne), (ee.test(o[0].type) && ye(t.parentNode)) || t))) {
                            if ((o.splice(i, 1), !(e = r.length && xe(o)))) return H.apply(n, r), n;
                            break;
                        }
                    }
                }
                return (l || f(e, c))(r, t, !E, n, !t || (ee.test(e) && ye(t.parentNode)) || t), n;
            }),
            (d.sortStable = k.split("").sort(D).join("") === k),
            (d.detectDuplicates = !!l),
            T(),
            (d.sortDetached = ce(function (e) {
                return 1 & e.compareDocumentPosition(C.createElement("fieldset"));
            })),
            ce(function (e) {
                return (e.innerHTML = "<a href='#'></a>"), "#" === e.firstChild.getAttribute("href");
            }) ||
                fe("type|href|height|width", function (e, t, n) {
                    if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2);
                }),
            (d.attributes &&
                ce(function (e) {
                    return (e.innerHTML = "<input/>"), e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value");
                })) ||
                fe("value", function (e, t, n) {
                    if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue;
                }),
            ce(function (e) {
                return null == e.getAttribute("disabled");
            }) ||
                fe(R, function (e, t, n) {
                    var r;
                    if (!n) return !0 === e[t] ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null;
                }),
            se
        );
    })(C);
    (k.find = h), (k.expr = h.selectors), (k.expr[":"] = k.expr.pseudos), (k.uniqueSort = k.unique = h.uniqueSort), (k.text = h.getText), (k.isXMLDoc = h.isXML), (k.contains = h.contains), (k.escapeSelector = h.escape);
    var T = function (e, t, n) {
            var r = [],
                i = void 0 !== n;
            while ((e = e[t]) && 9 !== e.nodeType)
                if (1 === e.nodeType) {
                    if (i && k(e).is(n)) break;
                    r.push(e);
                }
            return r;
        },
        S = function (e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n;
        },
        N = k.expr.match.needsContext;
    function A(e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase();
    }
    var D = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
    function j(e, n, r) {
        return m(n)
            ? k.grep(e, function (e, t) {
                  return !!n.call(e, t, e) !== r;
              })
            : n.nodeType
            ? k.grep(e, function (e) {
                  return (e === n) !== r;
              })
            : "string" != typeof n
            ? k.grep(e, function (e) {
                  return -1 < i.call(n, e) !== r;
              })
            : k.filter(n, e, r);
    }
    (k.filter = function (e, t, n) {
        var r = t[0];
        return (
            n && (e = ":not(" + e + ")"),
            1 === t.length && 1 === r.nodeType
                ? k.find.matchesSelector(r, e)
                    ? [r]
                    : []
                : k.find.matches(
                      e,
                      k.grep(t, function (e) {
                          return 1 === e.nodeType;
                      })
                  )
        );
    }),
        k.fn.extend({
            find: function (e) {
                var t,
                    n,
                    r = this.length,
                    i = this;
                if ("string" != typeof e)
                    return this.pushStack(
                        k(e).filter(function () {
                            for (t = 0; t < r; t++) if (k.contains(i[t], this)) return !0;
                        })
                    );
                for (n = this.pushStack([]), t = 0; t < r; t++) k.find(e, i[t], n);
                return 1 < r ? k.uniqueSort(n) : n;
            },
            filter: function (e) {
                return this.pushStack(j(this, e || [], !1));
            },
            not: function (e) {
                return this.pushStack(j(this, e || [], !0));
            },
            is: function (e) {
                return !!j(this, "string" == typeof e && N.test(e) ? k(e) : e || [], !1).length;
            },
        });
    var q,
        L = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
    ((k.fn.init = function (e, t, n) {
        var r, i;
        if (!e) return this;
        if (((n = n || q), "string" == typeof e)) {
            if (!(r = "<" === e[0] && ">" === e[e.length - 1] && 3 <= e.length ? [null, e, null] : L.exec(e)) || (!r[1] && t)) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
            if (r[1]) {
                if (((t = t instanceof k ? t[0] : t), k.merge(this, k.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : E, !0)), D.test(r[1]) && k.isPlainObject(t))) for (r in t) m(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
                return this;
            }
            return (i = E.getElementById(r[2])) && ((this[0] = i), (this.length = 1)), this;
        }
        return e.nodeType ? ((this[0] = e), (this.length = 1), this) : m(e) ? (void 0 !== n.ready ? n.ready(e) : e(k)) : k.makeArray(e, this);
    }).prototype = k.fn),
        (q = k(E));
    var H = /^(?:parents|prev(?:Until|All))/,
        O = { children: !0, contents: !0, next: !0, prev: !0 };
    function P(e, t) {
        while ((e = e[t]) && 1 !== e.nodeType);
        return e;
    }
    k.fn.extend({
        has: function (e) {
            var t = k(e, this),
                n = t.length;
            return this.filter(function () {
                for (var e = 0; e < n; e++) if (k.contains(this, t[e])) return !0;
            });
        },
        closest: function (e, t) {
            var n,
                r = 0,
                i = this.length,
                o = [],
                a = "string" != typeof e && k(e);
            if (!N.test(e))
                for (; r < i; r++)
                    for (n = this[r]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (a ? -1 < a.index(n) : 1 === n.nodeType && k.find.matchesSelector(n, e))) {
                            o.push(n);
                            break;
                        }
            return this.pushStack(1 < o.length ? k.uniqueSort(o) : o);
        },
        index: function (e) {
            return e ? ("string" == typeof e ? i.call(k(e), this[0]) : i.call(this, e.jquery ? e[0] : e)) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1;
        },
        add: function (e, t) {
            return this.pushStack(k.uniqueSort(k.merge(this.get(), k(e, t))));
        },
        addBack: function (e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e));
        },
    }),
        k.each(
            {
                parent: function (e) {
                    var t = e.parentNode;
                    return t && 11 !== t.nodeType ? t : null;
                },
                parents: function (e) {
                    return T(e, "parentNode");
                },
                parentsUntil: function (e, t, n) {
                    return T(e, "parentNode", n);
                },
                next: function (e) {
                    return P(e, "nextSibling");
                },
                prev: function (e) {
                    return P(e, "previousSibling");
                },
                nextAll: function (e) {
                    return T(e, "nextSibling");
                },
                prevAll: function (e) {
                    return T(e, "previousSibling");
                },
                nextUntil: function (e, t, n) {
                    return T(e, "nextSibling", n);
                },
                prevUntil: function (e, t, n) {
                    return T(e, "previousSibling", n);
                },
                siblings: function (e) {
                    return S((e.parentNode || {}).firstChild, e);
                },
                children: function (e) {
                    return S(e.firstChild);
                },
                contents: function (e) {
                    return "undefined" != typeof e.contentDocument ? e.contentDocument : (A(e, "template") && (e = e.content || e), k.merge([], e.childNodes));
                },
            },
            function (r, i) {
                k.fn[r] = function (e, t) {
                    var n = k.map(this, i, e);
                    return "Until" !== r.slice(-5) && (t = e), t && "string" == typeof t && (n = k.filter(t, n)), 1 < this.length && (O[r] || k.uniqueSort(n), H.test(r) && n.reverse()), this.pushStack(n);
                };
            }
        );
    var R = /[^\x20\t\r\n\f]+/g;
    function M(e) {
        return e;
    }
    function I(e) {
        throw e;
    }
    function W(e, t, n, r) {
        var i;
        try {
            e && m((i = e.promise)) ? i.call(e).done(t).fail(n) : e && m((i = e.then)) ? i.call(e, t, n) : t.apply(void 0, [e].slice(r));
        } catch (e) {
            n.apply(void 0, [e]);
        }
    }
    (k.Callbacks = function (r) {
        var e, n;
        r =
            "string" == typeof r
                ? ((e = r),
                  (n = {}),
                  k.each(e.match(R) || [], function (e, t) {
                      n[t] = !0;
                  }),
                  n)
                : k.extend({}, r);
        var i,
            t,
            o,
            a,
            s = [],
            u = [],
            l = -1,
            c = function () {
                for (a = a || r.once, o = i = !0; u.length; l = -1) {
                    t = u.shift();
                    while (++l < s.length) !1 === s[l].apply(t[0], t[1]) && r.stopOnFalse && ((l = s.length), (t = !1));
                }
                r.memory || (t = !1), (i = !1), a && (s = t ? [] : "");
            },
            f = {
                add: function () {
                    return (
                        s &&
                            (t && !i && ((l = s.length - 1), u.push(t)),
                            (function n(e) {
                                k.each(e, function (e, t) {
                                    m(t) ? (r.unique && f.has(t)) || s.push(t) : t && t.length && "string" !== w(t) && n(t);
                                });
                            })(arguments),
                            t && !i && c()),
                        this
                    );
                },
                remove: function () {
                    return (
                        k.each(arguments, function (e, t) {
                            var n;
                            while (-1 < (n = k.inArray(t, s, n))) s.splice(n, 1), n <= l && l--;
                        }),
                        this
                    );
                },
                has: function (e) {
                    return e ? -1 < k.inArray(e, s) : 0 < s.length;
                },
                empty: function () {
                    return s && (s = []), this;
                },
                disable: function () {
                    return (a = u = []), (s = t = ""), this;
                },
                disabled: function () {
                    return !s;
                },
                lock: function () {
                    return (a = u = []), t || i || (s = t = ""), this;
                },
                locked: function () {
                    return !!a;
                },
                fireWith: function (e, t) {
                    return a || ((t = [e, (t = t || []).slice ? t.slice() : t]), u.push(t), i || c()), this;
                },
                fire: function () {
                    return f.fireWith(this, arguments), this;
                },
                fired: function () {
                    return !!o;
                },
            };
        return f;
    }),
        k.extend({
            Deferred: function (e) {
                var o = [
                        ["notify", "progress", k.Callbacks("memory"), k.Callbacks("memory"), 2],
                        ["resolve", "done", k.Callbacks("once memory"), k.Callbacks("once memory"), 0, "resolved"],
                        ["reject", "fail", k.Callbacks("once memory"), k.Callbacks("once memory"), 1, "rejected"],
                    ],
                    i = "pending",
                    a = {
                        state: function () {
                            return i;
                        },
                        always: function () {
                            return s.done(arguments).fail(arguments), this;
                        },
                        catch: function (e) {
                            return a.then(null, e);
                        },
                        pipe: function () {
                            var i = arguments;
                            return k
                                .Deferred(function (r) {
                                    k.each(o, function (e, t) {
                                        var n = m(i[t[4]]) && i[t[4]];
                                        s[t[1]](function () {
                                            var e = n && n.apply(this, arguments);
                                            e && m(e.promise) ? e.promise().progress(r.notify).done(r.resolve).fail(r.reject) : r[t[0] + "With"](this, n ? [e] : arguments);
                                        });
                                    }),
                                        (i = null);
                                })
                                .promise();
                        },
                        then: function (t, n, r) {
                            var u = 0;
                            function l(i, o, a, s) {
                                return function () {
                                    var n = this,
                                        r = arguments,
                                        e = function () {
                                            var e, t;
                                            if (!(i < u)) {
                                                if ((e = a.apply(n, r)) === o.promise()) throw new TypeError("Thenable self-resolution");
                                                (t = e && ("object" == typeof e || "function" == typeof e) && e.then),
                                                    m(t)
                                                        ? s
                                                            ? t.call(e, l(u, o, M, s), l(u, o, I, s))
                                                            : (u++, t.call(e, l(u, o, M, s), l(u, o, I, s), l(u, o, M, o.notifyWith)))
                                                        : (a !== M && ((n = void 0), (r = [e])), (s || o.resolveWith)(n, r));
                                            }
                                        },
                                        t = s
                                            ? e
                                            : function () {
                                                  try {
                                                      e();
                                                  } catch (e) {
                                                      k.Deferred.exceptionHook && k.Deferred.exceptionHook(e, t.stackTrace), u <= i + 1 && (a !== I && ((n = void 0), (r = [e])), o.rejectWith(n, r));
                                                  }
                                              };
                                    i ? t() : (k.Deferred.getStackHook && (t.stackTrace = k.Deferred.getStackHook()), C.setTimeout(t));
                                };
                            }
                            return k
                                .Deferred(function (e) {
                                    o[0][3].add(l(0, e, m(r) ? r : M, e.notifyWith)), o[1][3].add(l(0, e, m(t) ? t : M)), o[2][3].add(l(0, e, m(n) ? n : I));
                                })
                                .promise();
                        },
                        promise: function (e) {
                            return null != e ? k.extend(e, a) : a;
                        },
                    },
                    s = {};
                return (
                    k.each(o, function (e, t) {
                        var n = t[2],
                            r = t[5];
                        (a[t[1]] = n.add),
                            r &&
                                n.add(
                                    function () {
                                        i = r;
                                    },
                                    o[3 - e][2].disable,
                                    o[3 - e][3].disable,
                                    o[0][2].lock,
                                    o[0][3].lock
                                ),
                            n.add(t[3].fire),
                            (s[t[0]] = function () {
                                return s[t[0] + "With"](this === s ? void 0 : this, arguments), this;
                            }),
                            (s[t[0] + "With"] = n.fireWith);
                    }),
                    a.promise(s),
                    e && e.call(s, s),
                    s
                );
            },
            when: function (e) {
                var n = arguments.length,
                    t = n,
                    r = Array(t),
                    i = s.call(arguments),
                    o = k.Deferred(),
                    a = function (t) {
                        return function (e) {
                            (r[t] = this), (i[t] = 1 < arguments.length ? s.call(arguments) : e), --n || o.resolveWith(r, i);
                        };
                    };
                if (n <= 1 && (W(e, o.done(a(t)).resolve, o.reject, !n), "pending" === o.state() || m(i[t] && i[t].then))) return o.then();
                while (t--) W(i[t], a(t), o.reject);
                return o.promise();
            },
        });
    var $ = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    (k.Deferred.exceptionHook = function (e, t) {
        C.console && C.console.warn && e && $.test(e.name) && C.console.warn("jQuery.Deferred exception: " + e.message, e.stack, t);
    }),
        (k.readyException = function (e) {
            C.setTimeout(function () {
                throw e;
            });
        });
    var F = k.Deferred();
    function B() {
        E.removeEventListener("DOMContentLoaded", B), C.removeEventListener("load", B), k.ready();
    }
    (k.fn.ready = function (e) {
        return (
            F.then(e)["catch"](function (e) {
                k.readyException(e);
            }),
            this
        );
    }),
        k.extend({
            isReady: !1,
            readyWait: 1,
            ready: function (e) {
                (!0 === e ? --k.readyWait : k.isReady) || ((k.isReady = !0) !== e && 0 < --k.readyWait) || F.resolveWith(E, [k]);
            },
        }),
        (k.ready.then = F.then),
        "complete" === E.readyState || ("loading" !== E.readyState && !E.documentElement.doScroll) ? C.setTimeout(k.ready) : (E.addEventListener("DOMContentLoaded", B), C.addEventListener("load", B));
    var _ = function (e, t, n, r, i, o, a) {
            var s = 0,
                u = e.length,
                l = null == n;
            if ("object" === w(n)) for (s in ((i = !0), n)) _(e, t, s, n[s], !0, o, a);
            else if (
                void 0 !== r &&
                ((i = !0),
                m(r) || (a = !0),
                l &&
                    (a
                        ? (t.call(e, r), (t = null))
                        : ((l = t),
                          (t = function (e, t, n) {
                              return l.call(k(e), n);
                          }))),
                t)
            )
                for (; s < u; s++) t(e[s], n, a ? r : r.call(e[s], s, t(e[s], n)));
            return i ? e : l ? t.call(e) : u ? t(e[0], n) : o;
        },
        z = /^-ms-/,
        U = /-([a-z])/g;
    function X(e, t) {
        return t.toUpperCase();
    }
    function V(e) {
        return e.replace(z, "ms-").replace(U, X);
    }
    var G = function (e) {
        return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType;
    };
    function Y() {
        this.expando = k.expando + Y.uid++;
    }
    (Y.uid = 1),
        (Y.prototype = {
            cache: function (e) {
                var t = e[this.expando];
                return t || ((t = {}), G(e) && (e.nodeType ? (e[this.expando] = t) : Object.defineProperty(e, this.expando, { value: t, configurable: !0 }))), t;
            },
            set: function (e, t, n) {
                var r,
                    i = this.cache(e);
                if ("string" == typeof t) i[V(t)] = n;
                else for (r in t) i[V(r)] = t[r];
                return i;
            },
            get: function (e, t) {
                return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][V(t)];
            },
            access: function (e, t, n) {
                return void 0 === t || (t && "string" == typeof t && void 0 === n) ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t);
            },
            remove: function (e, t) {
                var n,
                    r = e[this.expando];
                if (void 0 !== r) {
                    if (void 0 !== t) {
                        n = (t = Array.isArray(t) ? t.map(V) : (t = V(t)) in r ? [t] : t.match(R) || []).length;
                        while (n--) delete r[t[n]];
                    }
                    (void 0 === t || k.isEmptyObject(r)) && (e.nodeType ? (e[this.expando] = void 0) : delete e[this.expando]);
                }
            },
            hasData: function (e) {
                var t = e[this.expando];
                return void 0 !== t && !k.isEmptyObject(t);
            },
        });
    var Q = new Y(),
        J = new Y(),
        K = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        Z = /[A-Z]/g;
    function ee(e, t, n) {
        var r, i;
        if (void 0 === n && 1 === e.nodeType)
            if (((r = "data-" + t.replace(Z, "-$&").toLowerCase()), "string" == typeof (n = e.getAttribute(r)))) {
                try {
                    n = "true" === (i = n) || ("false" !== i && ("null" === i ? null : i === +i + "" ? +i : K.test(i) ? JSON.parse(i) : i));
                } catch (e) {}
                J.set(e, t, n);
            } else n = void 0;
        return n;
    }
    k.extend({
        hasData: function (e) {
            return J.hasData(e) || Q.hasData(e);
        },
        data: function (e, t, n) {
            return J.access(e, t, n);
        },
        removeData: function (e, t) {
            J.remove(e, t);
        },
        _data: function (e, t, n) {
            return Q.access(e, t, n);
        },
        _removeData: function (e, t) {
            Q.remove(e, t);
        },
    }),
        k.fn.extend({
            data: function (n, e) {
                var t,
                    r,
                    i,
                    o = this[0],
                    a = o && o.attributes;
                if (void 0 === n) {
                    if (this.length && ((i = J.get(o)), 1 === o.nodeType && !Q.get(o, "hasDataAttrs"))) {
                        t = a.length;
                        while (t--) a[t] && 0 === (r = a[t].name).indexOf("data-") && ((r = V(r.slice(5))), ee(o, r, i[r]));
                        Q.set(o, "hasDataAttrs", !0);
                    }
                    return i;
                }
                return "object" == typeof n
                    ? this.each(function () {
                          J.set(this, n);
                      })
                    : _(
                          this,
                          function (e) {
                              var t;
                              if (o && void 0 === e) return void 0 !== (t = J.get(o, n)) ? t : void 0 !== (t = ee(o, n)) ? t : void 0;
                              this.each(function () {
                                  J.set(this, n, e);
                              });
                          },
                          null,
                          e,
                          1 < arguments.length,
                          null,
                          !0
                      );
            },
            removeData: function (e) {
                return this.each(function () {
                    J.remove(this, e);
                });
            },
        }),
        k.extend({
            queue: function (e, t, n) {
                var r;
                if (e) return (t = (t || "fx") + "queue"), (r = Q.get(e, t)), n && (!r || Array.isArray(n) ? (r = Q.access(e, t, k.makeArray(n))) : r.push(n)), r || [];
            },
            dequeue: function (e, t) {
                t = t || "fx";
                var n = k.queue(e, t),
                    r = n.length,
                    i = n.shift(),
                    o = k._queueHooks(e, t);
                "inprogress" === i && ((i = n.shift()), r--),
                    i &&
                        ("fx" === t && n.unshift("inprogress"),
                        delete o.stop,
                        i.call(
                            e,
                            function () {
                                k.dequeue(e, t);
                            },
                            o
                        )),
                    !r && o && o.empty.fire();
            },
            _queueHooks: function (e, t) {
                var n = t + "queueHooks";
                return (
                    Q.get(e, n) ||
                    Q.access(e, n, {
                        empty: k.Callbacks("once memory").add(function () {
                            Q.remove(e, [t + "queue", n]);
                        }),
                    })
                );
            },
        }),
        k.fn.extend({
            queue: function (t, n) {
                var e = 2;
                return (
                    "string" != typeof t && ((n = t), (t = "fx"), e--),
                    arguments.length < e
                        ? k.queue(this[0], t)
                        : void 0 === n
                        ? this
                        : this.each(function () {
                              var e = k.queue(this, t, n);
                              k._queueHooks(this, t), "fx" === t && "inprogress" !== e[0] && k.dequeue(this, t);
                          })
                );
            },
            dequeue: function (e) {
                return this.each(function () {
                    k.dequeue(this, e);
                });
            },
            clearQueue: function (e) {
                return this.queue(e || "fx", []);
            },
            promise: function (e, t) {
                var n,
                    r = 1,
                    i = k.Deferred(),
                    o = this,
                    a = this.length,
                    s = function () {
                        --r || i.resolveWith(o, [o]);
                    };
                "string" != typeof e && ((t = e), (e = void 0)), (e = e || "fx");
                while (a--) (n = Q.get(o[a], e + "queueHooks")) && n.empty && (r++, n.empty.add(s));
                return s(), i.promise(t);
            },
        });
    var te = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        ne = new RegExp("^(?:([+-])=|)(" + te + ")([a-z%]*)$", "i"),
        re = ["Top", "Right", "Bottom", "Left"],
        ie = E.documentElement,
        oe = function (e) {
            return k.contains(e.ownerDocument, e);
        },
        ae = { composed: !0 };
    ie.getRootNode &&
        (oe = function (e) {
            return k.contains(e.ownerDocument, e) || e.getRootNode(ae) === e.ownerDocument;
        });
    var se = function (e, t) {
            return "none" === (e = t || e).style.display || ("" === e.style.display && oe(e) && "none" === k.css(e, "display"));
        },
        ue = function (e, t, n, r) {
            var i,
                o,
                a = {};
            for (o in t) (a[o] = e.style[o]), (e.style[o] = t[o]);
            for (o in ((i = n.apply(e, r || [])), t)) e.style[o] = a[o];
            return i;
        };
    function le(e, t, n, r) {
        var i,
            o,
            a = 20,
            s = r
                ? function () {
                      return r.cur();
                  }
                : function () {
                      return k.css(e, t, "");
                  },
            u = s(),
            l = (n && n[3]) || (k.cssNumber[t] ? "" : "px"),
            c = e.nodeType && (k.cssNumber[t] || ("px" !== l && +u)) && ne.exec(k.css(e, t));
        if (c && c[3] !== l) {
            (u /= 2), (l = l || c[3]), (c = +u || 1);
            while (a--) k.style(e, t, c + l), (1 - o) * (1 - (o = s() / u || 0.5)) <= 0 && (a = 0), (c /= o);
            (c *= 2), k.style(e, t, c + l), (n = n || []);
        }
        return n && ((c = +c || +u || 0), (i = n[1] ? c + (n[1] + 1) * n[2] : +n[2]), r && ((r.unit = l), (r.start = c), (r.end = i))), i;
    }
    var ce = {};
    function fe(e, t) {
        for (var n, r, i, o, a, s, u, l = [], c = 0, f = e.length; c < f; c++)
            (r = e[c]).style &&
                ((n = r.style.display),
                t
                    ? ("none" === n && ((l[c] = Q.get(r, "display") || null), l[c] || (r.style.display = "")),
                      "" === r.style.display &&
                          se(r) &&
                          (l[c] =
                              ((u = a = o = void 0),
                              (a = (i = r).ownerDocument),
                              (s = i.nodeName),
                              (u = ce[s]) || ((o = a.body.appendChild(a.createElement(s))), (u = k.css(o, "display")), o.parentNode.removeChild(o), "none" === u && (u = "block"), (ce[s] = u)))))
                    : "none" !== n && ((l[c] = "none"), Q.set(r, "display", n)));
        for (c = 0; c < f; c++) null != l[c] && (e[c].style.display = l[c]);
        return e;
    }
    k.fn.extend({
        show: function () {
            return fe(this, !0);
        },
        hide: function () {
            return fe(this);
        },
        toggle: function (e) {
            return "boolean" == typeof e
                ? e
                    ? this.show()
                    : this.hide()
                : this.each(function () {
                      se(this) ? k(this).show() : k(this).hide();
                  });
        },
    });
    var pe = /^(?:checkbox|radio)$/i,
        de = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        he = /^$|^module$|\/(?:java|ecma)script/i,
        ge = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""],
        };
    function ve(e, t) {
        var n;
        return (n = "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName(t || "*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll(t || "*") : []), void 0 === t || (t && A(e, t)) ? k.merge([e], n) : n;
    }
    function ye(e, t) {
        for (var n = 0, r = e.length; n < r; n++) Q.set(e[n], "globalEval", !t || Q.get(t[n], "globalEval"));
    }
    (ge.optgroup = ge.option), (ge.tbody = ge.tfoot = ge.colgroup = ge.caption = ge.thead), (ge.th = ge.td);
    var me,
        xe,
        be = /<|&#?\w+;/;
    function we(e, t, n, r, i) {
        for (var o, a, s, u, l, c, f = t.createDocumentFragment(), p = [], d = 0, h = e.length; d < h; d++)
            if ((o = e[d]) || 0 === o)
                if ("object" === w(o)) k.merge(p, o.nodeType ? [o] : o);
                else if (be.test(o)) {
                    (a = a || f.appendChild(t.createElement("div"))), (s = (de.exec(o) || ["", ""])[1].toLowerCase()), (u = ge[s] || ge._default), (a.innerHTML = u[1] + k.htmlPrefilter(o) + u[2]), (c = u[0]);
                    while (c--) a = a.lastChild;
                    k.merge(p, a.childNodes), ((a = f.firstChild).textContent = "");
                } else p.push(t.createTextNode(o));
        (f.textContent = ""), (d = 0);
        while ((o = p[d++]))
            if (r && -1 < k.inArray(o, r)) i && i.push(o);
            else if (((l = oe(o)), (a = ve(f.appendChild(o), "script")), l && ye(a), n)) {
                c = 0;
                while ((o = a[c++])) he.test(o.type || "") && n.push(o);
            }
        return f;
    }
    (me = E.createDocumentFragment().appendChild(E.createElement("div"))),
        (xe = E.createElement("input")).setAttribute("type", "radio"),
        xe.setAttribute("checked", "checked"),
        xe.setAttribute("name", "t"),
        me.appendChild(xe),
        (y.checkClone = me.cloneNode(!0).cloneNode(!0).lastChild.checked),
        (me.innerHTML = "<textarea>x</textarea>"),
        (y.noCloneChecked = !!me.cloneNode(!0).lastChild.defaultValue);
    var Te = /^key/,
        Ce = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
        Ee = /^([^.]*)(?:\.(.+)|)/;
    function ke() {
        return !0;
    }
    function Se() {
        return !1;
    }
    function Ne(e, t) {
        return (
            (e ===
                (function () {
                    try {
                        return E.activeElement;
                    } catch (e) {}
                })()) ==
            ("focus" === t)
        );
    }
    function Ae(e, t, n, r, i, o) {
        var a, s;
        if ("object" == typeof t) {
            for (s in ("string" != typeof n && ((r = r || n), (n = void 0)), t)) Ae(e, s, n, r, t[s], o);
            return e;
        }
        if ((null == r && null == i ? ((i = n), (r = n = void 0)) : null == i && ("string" == typeof n ? ((i = r), (r = void 0)) : ((i = r), (r = n), (n = void 0))), !1 === i)) i = Se;
        else if (!i) return e;
        return (
            1 === o &&
                ((a = i),
                ((i = function (e) {
                    return k().off(e), a.apply(this, arguments);
                }).guid = a.guid || (a.guid = k.guid++))),
            e.each(function () {
                k.event.add(this, t, i, r, n);
            })
        );
    }
    function De(e, i, o) {
        o
            ? (Q.set(e, i, !1),
              k.event.add(e, i, {
                  namespace: !1,
                  handler: function (e) {
                      var t,
                          n,
                          r = Q.get(this, i);
                      if (1 & e.isTrigger && this[i]) {
                          if (r.length) (k.event.special[i] || {}).delegateType && e.stopPropagation();
                          else if (((r = s.call(arguments)), Q.set(this, i, r), (t = o(this, i)), this[i](), r !== (n = Q.get(this, i)) || t ? Q.set(this, i, !1) : (n = {}), r !== n))
                              return e.stopImmediatePropagation(), e.preventDefault(), n.value;
                      } else r.length && (Q.set(this, i, { value: k.event.trigger(k.extend(r[0], k.Event.prototype), r.slice(1), this) }), e.stopImmediatePropagation());
                  },
              }))
            : void 0 === Q.get(e, i) && k.event.add(e, i, ke);
    }
    (k.event = {
        global: {},
        add: function (t, e, n, r, i) {
            var o,
                a,
                s,
                u,
                l,
                c,
                f,
                p,
                d,
                h,
                g,
                v = Q.get(t);
            if (v) {
                n.handler && ((n = (o = n).handler), (i = o.selector)),
                    i && k.find.matchesSelector(ie, i),
                    n.guid || (n.guid = k.guid++),
                    (u = v.events) || (u = v.events = {}),
                    (a = v.handle) ||
                        (a = v.handle = function (e) {
                            return "undefined" != typeof k && k.event.triggered !== e.type ? k.event.dispatch.apply(t, arguments) : void 0;
                        }),
                    (l = (e = (e || "").match(R) || [""]).length);
                while (l--)
                    (d = g = (s = Ee.exec(e[l]) || [])[1]),
                        (h = (s[2] || "").split(".").sort()),
                        d &&
                            ((f = k.event.special[d] || {}),
                            (d = (i ? f.delegateType : f.bindType) || d),
                            (f = k.event.special[d] || {}),
                            (c = k.extend({ type: d, origType: g, data: r, handler: n, guid: n.guid, selector: i, needsContext: i && k.expr.match.needsContext.test(i), namespace: h.join(".") }, o)),
                            (p = u[d]) || (((p = u[d] = []).delegateCount = 0), (f.setup && !1 !== f.setup.call(t, r, h, a)) || (t.addEventListener && t.addEventListener(d, a))),
                            f.add && (f.add.call(t, c), c.handler.guid || (c.handler.guid = n.guid)),
                            i ? p.splice(p.delegateCount++, 0, c) : p.push(c),
                            (k.event.global[d] = !0));
            }
        },
        remove: function (e, t, n, r, i) {
            var o,
                a,
                s,
                u,
                l,
                c,
                f,
                p,
                d,
                h,
                g,
                v = Q.hasData(e) && Q.get(e);
            if (v && (u = v.events)) {
                l = (t = (t || "").match(R) || [""]).length;
                while (l--)
                    if (((d = g = (s = Ee.exec(t[l]) || [])[1]), (h = (s[2] || "").split(".").sort()), d)) {
                        (f = k.event.special[d] || {}), (p = u[(d = (r ? f.delegateType : f.bindType) || d)] || []), (s = s[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)")), (a = o = p.length);
                        while (o--)
                            (c = p[o]),
                                (!i && g !== c.origType) ||
                                    (n && n.guid !== c.guid) ||
                                    (s && !s.test(c.namespace)) ||
                                    (r && r !== c.selector && ("**" !== r || !c.selector)) ||
                                    (p.splice(o, 1), c.selector && p.delegateCount--, f.remove && f.remove.call(e, c));
                        a && !p.length && ((f.teardown && !1 !== f.teardown.call(e, h, v.handle)) || k.removeEvent(e, d, v.handle), delete u[d]);
                    } else for (d in u) k.event.remove(e, d + t[l], n, r, !0);
                k.isEmptyObject(u) && Q.remove(e, "handle events");
            }
        },
        dispatch: function (e) {
            var t,
                n,
                r,
                i,
                o,
                a,
                s = k.event.fix(e),
                u = new Array(arguments.length),
                l = (Q.get(this, "events") || {})[s.type] || [],
                c = k.event.special[s.type] || {};
            for (u[0] = s, t = 1; t < arguments.length; t++) u[t] = arguments[t];
            if (((s.delegateTarget = this), !c.preDispatch || !1 !== c.preDispatch.call(this, s))) {
                (a = k.event.handlers.call(this, s, l)), (t = 0);
                while ((i = a[t++]) && !s.isPropagationStopped()) {
                    (s.currentTarget = i.elem), (n = 0);
                    while ((o = i.handlers[n++]) && !s.isImmediatePropagationStopped())
                        (s.rnamespace && !1 !== o.namespace && !s.rnamespace.test(o.namespace)) ||
                            ((s.handleObj = o), (s.data = o.data), void 0 !== (r = ((k.event.special[o.origType] || {}).handle || o.handler).apply(i.elem, u)) && !1 === (s.result = r) && (s.preventDefault(), s.stopPropagation()));
                }
                return c.postDispatch && c.postDispatch.call(this, s), s.result;
            }
        },
        handlers: function (e, t) {
            var n,
                r,
                i,
                o,
                a,
                s = [],
                u = t.delegateCount,
                l = e.target;
            if (u && l.nodeType && !("click" === e.type && 1 <= e.button))
                for (; l !== this; l = l.parentNode || this)
                    if (1 === l.nodeType && ("click" !== e.type || !0 !== l.disabled)) {
                        for (o = [], a = {}, n = 0; n < u; n++) void 0 === a[(i = (r = t[n]).selector + " ")] && (a[i] = r.needsContext ? -1 < k(i, this).index(l) : k.find(i, this, null, [l]).length), a[i] && o.push(r);
                        o.length && s.push({ elem: l, handlers: o });
                    }
            return (l = this), u < t.length && s.push({ elem: l, handlers: t.slice(u) }), s;
        },
        addProp: function (t, e) {
            Object.defineProperty(k.Event.prototype, t, {
                enumerable: !0,
                configurable: !0,
                get: m(e)
                    ? function () {
                          if (this.originalEvent) return e(this.originalEvent);
                      }
                    : function () {
                          if (this.originalEvent) return this.originalEvent[t];
                      },
                set: function (e) {
                    Object.defineProperty(this, t, { enumerable: !0, configurable: !0, writable: !0, value: e });
                },
            });
        },
        fix: function (e) {
            return e[k.expando] ? e : new k.Event(e);
        },
        special: {
            load: { noBubble: !0 },
            click: {
                setup: function (e) {
                    var t = this || e;
                    return pe.test(t.type) && t.click && A(t, "input") && De(t, "click", ke), !1;
                },
                trigger: function (e) {
                    var t = this || e;
                    return pe.test(t.type) && t.click && A(t, "input") && De(t, "click"), !0;
                },
                _default: function (e) {
                    var t = e.target;
                    return (pe.test(t.type) && t.click && A(t, "input") && Q.get(t, "click")) || A(t, "a");
                },
            },
            beforeunload: {
                postDispatch: function (e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result);
                },
            },
        },
    }),
        (k.removeEvent = function (e, t, n) {
            e.removeEventListener && e.removeEventListener(t, n);
        }),
        (k.Event = function (e, t) {
            if (!(this instanceof k.Event)) return new k.Event(e, t);
            e && e.type
                ? ((this.originalEvent = e),
                  (this.type = e.type),
                  (this.isDefaultPrevented = e.defaultPrevented || (void 0 === e.defaultPrevented && !1 === e.returnValue) ? ke : Se),
                  (this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target),
                  (this.currentTarget = e.currentTarget),
                  (this.relatedTarget = e.relatedTarget))
                : (this.type = e),
                t && k.extend(this, t),
                (this.timeStamp = (e && e.timeStamp) || Date.now()),
                (this[k.expando] = !0);
        }),
        (k.Event.prototype = {
            constructor: k.Event,
            isDefaultPrevented: Se,
            isPropagationStopped: Se,
            isImmediatePropagationStopped: Se,
            isSimulated: !1,
            preventDefault: function () {
                var e = this.originalEvent;
                (this.isDefaultPrevented = ke), e && !this.isSimulated && e.preventDefault();
            },
            stopPropagation: function () {
                var e = this.originalEvent;
                (this.isPropagationStopped = ke), e && !this.isSimulated && e.stopPropagation();
            },
            stopImmediatePropagation: function () {
                var e = this.originalEvent;
                (this.isImmediatePropagationStopped = ke), e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation();
            },
        }),
        k.each(
            {
                altKey: !0,
                bubbles: !0,
                cancelable: !0,
                changedTouches: !0,
                ctrlKey: !0,
                detail: !0,
                eventPhase: !0,
                metaKey: !0,
                pageX: !0,
                pageY: !0,
                shiftKey: !0,
                view: !0,
                char: !0,
                code: !0,
                charCode: !0,
                key: !0,
                keyCode: !0,
                button: !0,
                buttons: !0,
                clientX: !0,
                clientY: !0,
                offsetX: !0,
                offsetY: !0,
                pointerId: !0,
                pointerType: !0,
                screenX: !0,
                screenY: !0,
                targetTouches: !0,
                toElement: !0,
                touches: !0,
                which: function (e) {
                    var t = e.button;
                    return null == e.which && Te.test(e.type) ? (null != e.charCode ? e.charCode : e.keyCode) : !e.which && void 0 !== t && Ce.test(e.type) ? (1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0) : e.which;
                },
            },
            k.event.addProp
        ),
        k.each({ focus: "focusin", blur: "focusout" }, function (e, t) {
            k.event.special[e] = {
                setup: function () {
                    return De(this, e, Ne), !1;
                },
                trigger: function () {
                    return De(this, e), !0;
                },
                delegateType: t,
            };
        }),
        k.each({ mouseenter: "mouseover", mouseleave: "mouseout", pointerenter: "pointerover", pointerleave: "pointerout" }, function (e, i) {
            k.event.special[e] = {
                delegateType: i,
                bindType: i,
                handle: function (e) {
                    var t,
                        n = e.relatedTarget,
                        r = e.handleObj;
                    return (n && (n === this || k.contains(this, n))) || ((e.type = r.origType), (t = r.handler.apply(this, arguments)), (e.type = i)), t;
                },
            };
        }),
        k.fn.extend({
            on: function (e, t, n, r) {
                return Ae(this, e, t, n, r);
            },
            one: function (e, t, n, r) {
                return Ae(this, e, t, n, r, 1);
            },
            off: function (e, t, n) {
                var r, i;
                if (e && e.preventDefault && e.handleObj) return (r = e.handleObj), k(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
                if ("object" == typeof e) {
                    for (i in e) this.off(i, t, e[i]);
                    return this;
                }
                return (
                    (!1 !== t && "function" != typeof t) || ((n = t), (t = void 0)),
                    !1 === n && (n = Se),
                    this.each(function () {
                        k.event.remove(this, e, n, t);
                    })
                );
            },
        });
    var je = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
        qe = /<script|<style|<link/i,
        Le = /checked\s*(?:[^=]|=\s*.checked.)/i,
        He = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
    function Oe(e, t) {
        return (A(e, "table") && A(11 !== t.nodeType ? t : t.firstChild, "tr") && k(e).children("tbody")[0]) || e;
    }
    function Pe(e) {
        return (e.type = (null !== e.getAttribute("type")) + "/" + e.type), e;
    }
    function Re(e) {
        return "true/" === (e.type || "").slice(0, 5) ? (e.type = e.type.slice(5)) : e.removeAttribute("type"), e;
    }
    function Me(e, t) {
        var n, r, i, o, a, s, u, l;
        if (1 === t.nodeType) {
            if (Q.hasData(e) && ((o = Q.access(e)), (a = Q.set(t, o)), (l = o.events))) for (i in (delete a.handle, (a.events = {}), l)) for (n = 0, r = l[i].length; n < r; n++) k.event.add(t, i, l[i][n]);
            J.hasData(e) && ((s = J.access(e)), (u = k.extend({}, s)), J.set(t, u));
        }
    }
    function Ie(n, r, i, o) {
        r = g.apply([], r);
        var e,
            t,
            a,
            s,
            u,
            l,
            c = 0,
            f = n.length,
            p = f - 1,
            d = r[0],
            h = m(d);
        if (h || (1 < f && "string" == typeof d && !y.checkClone && Le.test(d)))
            return n.each(function (e) {
                var t = n.eq(e);
                h && (r[0] = d.call(this, e, t.html())), Ie(t, r, i, o);
            });
        if (f && ((t = (e = we(r, n[0].ownerDocument, !1, n, o)).firstChild), 1 === e.childNodes.length && (e = t), t || o)) {
            for (s = (a = k.map(ve(e, "script"), Pe)).length; c < f; c++) (u = e), c !== p && ((u = k.clone(u, !0, !0)), s && k.merge(a, ve(u, "script"))), i.call(n[c], u, c);
            if (s)
                for (l = a[a.length - 1].ownerDocument, k.map(a, Re), c = 0; c < s; c++)
                    (u = a[c]),
                        he.test(u.type || "") &&
                            !Q.access(u, "globalEval") &&
                            k.contains(l, u) &&
                            (u.src && "module" !== (u.type || "").toLowerCase() ? k._evalUrl && !u.noModule && k._evalUrl(u.src, { nonce: u.nonce || u.getAttribute("nonce") }) : b(u.textContent.replace(He, ""), u, l));
        }
        return n;
    }
    function We(e, t, n) {
        for (var r, i = t ? k.filter(t, e) : e, o = 0; null != (r = i[o]); o++) n || 1 !== r.nodeType || k.cleanData(ve(r)), r.parentNode && (n && oe(r) && ye(ve(r, "script")), r.parentNode.removeChild(r));
        return e;
    }
    k.extend({
        htmlPrefilter: function (e) {
            return e.replace(je, "<$1></$2>");
        },
        clone: function (e, t, n) {
            var r,
                i,
                o,
                a,
                s,
                u,
                l,
                c = e.cloneNode(!0),
                f = oe(e);
            if (!(y.noCloneChecked || (1 !== e.nodeType && 11 !== e.nodeType) || k.isXMLDoc(e)))
                for (a = ve(c), r = 0, i = (o = ve(e)).length; r < i; r++)
                    (s = o[r]), (u = a[r]), void 0, "input" === (l = u.nodeName.toLowerCase()) && pe.test(s.type) ? (u.checked = s.checked) : ("input" !== l && "textarea" !== l) || (u.defaultValue = s.defaultValue);
            if (t)
                if (n) for (o = o || ve(e), a = a || ve(c), r = 0, i = o.length; r < i; r++) Me(o[r], a[r]);
                else Me(e, c);
            return 0 < (a = ve(c, "script")).length && ye(a, !f && ve(e, "script")), c;
        },
        cleanData: function (e) {
            for (var t, n, r, i = k.event.special, o = 0; void 0 !== (n = e[o]); o++)
                if (G(n)) {
                    if ((t = n[Q.expando])) {
                        if (t.events) for (r in t.events) i[r] ? k.event.remove(n, r) : k.removeEvent(n, r, t.handle);
                        n[Q.expando] = void 0;
                    }
                    n[J.expando] && (n[J.expando] = void 0);
                }
        },
    }),
        k.fn.extend({
            detach: function (e) {
                return We(this, e, !0);
            },
            remove: function (e) {
                return We(this, e);
            },
            text: function (e) {
                return _(
                    this,
                    function (e) {
                        return void 0 === e
                            ? k.text(this)
                            : this.empty().each(function () {
                                  (1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType) || (this.textContent = e);
                              });
                    },
                    null,
                    e,
                    arguments.length
                );
            },
            append: function () {
                return Ie(this, arguments, function (e) {
                    (1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType) || Oe(this, e).appendChild(e);
                });
            },
            prepend: function () {
                return Ie(this, arguments, function (e) {
                    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                        var t = Oe(this, e);
                        t.insertBefore(e, t.firstChild);
                    }
                });
            },
            before: function () {
                return Ie(this, arguments, function (e) {
                    this.parentNode && this.parentNode.insertBefore(e, this);
                });
            },
            after: function () {
                return Ie(this, arguments, function (e) {
                    this.parentNode && this.parentNode.insertBefore(e, this.nextSibling);
                });
            },
            empty: function () {
                for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (k.cleanData(ve(e, !1)), (e.textContent = ""));
                return this;
            },
            clone: function (e, t) {
                return (
                    (e = null != e && e),
                    (t = null == t ? e : t),
                    this.map(function () {
                        return k.clone(this, e, t);
                    })
                );
            },
            html: function (e) {
                return _(
                    this,
                    function (e) {
                        var t = this[0] || {},
                            n = 0,
                            r = this.length;
                        if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                        if ("string" == typeof e && !qe.test(e) && !ge[(de.exec(e) || ["", ""])[1].toLowerCase()]) {
                            e = k.htmlPrefilter(e);
                            try {
                                for (; n < r; n++) 1 === (t = this[n] || {}).nodeType && (k.cleanData(ve(t, !1)), (t.innerHTML = e));
                                t = 0;
                            } catch (e) {}
                        }
                        t && this.empty().append(e);
                    },
                    null,
                    e,
                    arguments.length
                );
            },
            replaceWith: function () {
                var n = [];
                return Ie(
                    this,
                    arguments,
                    function (e) {
                        var t = this.parentNode;
                        k.inArray(this, n) < 0 && (k.cleanData(ve(this)), t && t.replaceChild(e, this));
                    },
                    n
                );
            },
        }),
        k.each({ appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith" }, function (e, a) {
            k.fn[e] = function (e) {
                for (var t, n = [], r = k(e), i = r.length - 1, o = 0; o <= i; o++) (t = o === i ? this : this.clone(!0)), k(r[o])[a](t), u.apply(n, t.get());
                return this.pushStack(n);
            };
        });
    var $e = new RegExp("^(" + te + ")(?!px)[a-z%]+$", "i"),
        Fe = function (e) {
            var t = e.ownerDocument.defaultView;
            return (t && t.opener) || (t = C), t.getComputedStyle(e);
        },
        Be = new RegExp(re.join("|"), "i");
    function _e(e, t, n) {
        var r,
            i,
            o,
            a,
            s = e.style;
        return (
            (n = n || Fe(e)) &&
                ("" !== (a = n.getPropertyValue(t) || n[t]) || oe(e) || (a = k.style(e, t)),
                !y.pixelBoxStyles() && $e.test(a) && Be.test(t) && ((r = s.width), (i = s.minWidth), (o = s.maxWidth), (s.minWidth = s.maxWidth = s.width = a), (a = n.width), (s.width = r), (s.minWidth = i), (s.maxWidth = o))),
            void 0 !== a ? a + "" : a
        );
    }
    function ze(e, t) {
        return {
            get: function () {
                if (!e()) return (this.get = t).apply(this, arguments);
                delete this.get;
            },
        };
    }
    !(function () {
        function e() {
            if (u) {
                (s.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0"),
                    (u.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%"),
                    ie.appendChild(s).appendChild(u);
                var e = C.getComputedStyle(u);
                (n = "1%" !== e.top),
                    (a = 12 === t(e.marginLeft)),
                    (u.style.right = "60%"),
                    (o = 36 === t(e.right)),
                    (r = 36 === t(e.width)),
                    (u.style.position = "absolute"),
                    (i = 12 === t(u.offsetWidth / 3)),
                    ie.removeChild(s),
                    (u = null);
            }
        }
        function t(e) {
            return Math.round(parseFloat(e));
        }
        var n,
            r,
            i,
            o,
            a,
            s = E.createElement("div"),
            u = E.createElement("div");
        u.style &&
            ((u.style.backgroundClip = "content-box"),
            (u.cloneNode(!0).style.backgroundClip = ""),
            (y.clearCloneStyle = "content-box" === u.style.backgroundClip),
            k.extend(y, {
                boxSizingReliable: function () {
                    return e(), r;
                },
                pixelBoxStyles: function () {
                    return e(), o;
                },
                pixelPosition: function () {
                    return e(), n;
                },
                reliableMarginLeft: function () {
                    return e(), a;
                },
                scrollboxSize: function () {
                    return e(), i;
                },
            }));
    })();
    var Ue = ["Webkit", "Moz", "ms"],
        Xe = E.createElement("div").style,
        Ve = {};
    function Ge(e) {
        var t = k.cssProps[e] || Ve[e];
        return (
            t ||
            (e in Xe
                ? e
                : (Ve[e] =
                      (function (e) {
                          var t = e[0].toUpperCase() + e.slice(1),
                              n = Ue.length;
                          while (n--) if ((e = Ue[n] + t) in Xe) return e;
                      })(e) || e))
        );
    }
    var Ye = /^(none|table(?!-c[ea]).+)/,
        Qe = /^--/,
        Je = { position: "absolute", visibility: "hidden", display: "block" },
        Ke = { letterSpacing: "0", fontWeight: "400" };
    function Ze(e, t, n) {
        var r = ne.exec(t);
        return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t;
    }
    function et(e, t, n, r, i, o) {
        var a = "width" === t ? 1 : 0,
            s = 0,
            u = 0;
        if (n === (r ? "border" : "content")) return 0;
        for (; a < 4; a += 2)
            "margin" === n && (u += k.css(e, n + re[a], !0, i)),
                r
                    ? ("content" === n && (u -= k.css(e, "padding" + re[a], !0, i)), "margin" !== n && (u -= k.css(e, "border" + re[a] + "Width", !0, i)))
                    : ((u += k.css(e, "padding" + re[a], !0, i)), "padding" !== n ? (u += k.css(e, "border" + re[a] + "Width", !0, i)) : (s += k.css(e, "border" + re[a] + "Width", !0, i)));
        return !r && 0 <= o && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - u - s - 0.5)) || 0), u;
    }
    function tt(e, t, n) {
        var r = Fe(e),
            i = (!y.boxSizingReliable() || n) && "border-box" === k.css(e, "boxSizing", !1, r),
            o = i,
            a = _e(e, t, r),
            s = "offset" + t[0].toUpperCase() + t.slice(1);
        if ($e.test(a)) {
            if (!n) return a;
            a = "auto";
        }
        return (
            ((!y.boxSizingReliable() && i) || "auto" === a || (!parseFloat(a) && "inline" === k.css(e, "display", !1, r))) && e.getClientRects().length && ((i = "border-box" === k.css(e, "boxSizing", !1, r)), (o = s in e) && (a = e[s])),
            (a = parseFloat(a) || 0) + et(e, t, n || (i ? "border" : "content"), o, r, a) + "px"
        );
    }
    function nt(e, t, n, r, i) {
        return new nt.prototype.init(e, t, n, r, i);
    }
    k.extend({
        cssHooks: {
            opacity: {
                get: function (e, t) {
                    if (t) {
                        var n = _e(e, "opacity");
                        return "" === n ? "1" : n;
                    }
                },
            },
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0,
        },
        cssProps: {},
        style: function (e, t, n, r) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var i,
                    o,
                    a,
                    s = V(t),
                    u = Qe.test(t),
                    l = e.style;
                if ((u || (t = Ge(s)), (a = k.cssHooks[t] || k.cssHooks[s]), void 0 === n)) return a && "get" in a && void 0 !== (i = a.get(e, !1, r)) ? i : l[t];
                "string" === (o = typeof n) && (i = ne.exec(n)) && i[1] && ((n = le(e, t, i)), (o = "number")),
                    null != n &&
                        n == n &&
                        ("number" !== o || u || (n += (i && i[3]) || (k.cssNumber[s] ? "" : "px")),
                        y.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"),
                        (a && "set" in a && void 0 === (n = a.set(e, n, r))) || (u ? l.setProperty(t, n) : (l[t] = n)));
            }
        },
        css: function (e, t, n, r) {
            var i,
                o,
                a,
                s = V(t);
            return (
                Qe.test(t) || (t = Ge(s)),
                (a = k.cssHooks[t] || k.cssHooks[s]) && "get" in a && (i = a.get(e, !0, n)),
                void 0 === i && (i = _e(e, t, r)),
                "normal" === i && t in Ke && (i = Ke[t]),
                "" === n || n ? ((o = parseFloat(i)), !0 === n || isFinite(o) ? o || 0 : i) : i
            );
        },
    }),
        k.each(["height", "width"], function (e, u) {
            k.cssHooks[u] = {
                get: function (e, t, n) {
                    if (t)
                        return !Ye.test(k.css(e, "display")) || (e.getClientRects().length && e.getBoundingClientRect().width)
                            ? tt(e, u, n)
                            : ue(e, Je, function () {
                                  return tt(e, u, n);
                              });
                },
                set: function (e, t, n) {
                    var r,
                        i = Fe(e),
                        o = !y.scrollboxSize() && "absolute" === i.position,
                        a = (o || n) && "border-box" === k.css(e, "boxSizing", !1, i),
                        s = n ? et(e, u, n, a, i) : 0;
                    return (
                        a && o && (s -= Math.ceil(e["offset" + u[0].toUpperCase() + u.slice(1)] - parseFloat(i[u]) - et(e, u, "border", !1, i) - 0.5)),
                        s && (r = ne.exec(t)) && "px" !== (r[3] || "px") && ((e.style[u] = t), (t = k.css(e, u))),
                        Ze(0, t, s)
                    );
                },
            };
        }),
        (k.cssHooks.marginLeft = ze(y.reliableMarginLeft, function (e, t) {
            if (t)
                return (
                    (parseFloat(_e(e, "marginLeft")) ||
                        e.getBoundingClientRect().left -
                            ue(e, { marginLeft: 0 }, function () {
                                return e.getBoundingClientRect().left;
                            })) + "px"
                );
        })),
        k.each({ margin: "", padding: "", border: "Width" }, function (i, o) {
            (k.cssHooks[i + o] = {
                expand: function (e) {
                    for (var t = 0, n = {}, r = "string" == typeof e ? e.split(" ") : [e]; t < 4; t++) n[i + re[t] + o] = r[t] || r[t - 2] || r[0];
                    return n;
                },
            }),
                "margin" !== i && (k.cssHooks[i + o].set = Ze);
        }),
        k.fn.extend({
            css: function (e, t) {
                return _(
                    this,
                    function (e, t, n) {
                        var r,
                            i,
                            o = {},
                            a = 0;
                        if (Array.isArray(t)) {
                            for (r = Fe(e), i = t.length; a < i; a++) o[t[a]] = k.css(e, t[a], !1, r);
                            return o;
                        }
                        return void 0 !== n ? k.style(e, t, n) : k.css(e, t);
                    },
                    e,
                    t,
                    1 < arguments.length
                );
            },
        }),
        (((k.Tween = nt).prototype = {
            constructor: nt,
            init: function (e, t, n, r, i, o) {
                (this.elem = e), (this.prop = n), (this.easing = i || k.easing._default), (this.options = t), (this.start = this.now = this.cur()), (this.end = r), (this.unit = o || (k.cssNumber[n] ? "" : "px"));
            },
            cur: function () {
                var e = nt.propHooks[this.prop];
                return e && e.get ? e.get(this) : nt.propHooks._default.get(this);
            },
            run: function (e) {
                var t,
                    n = nt.propHooks[this.prop];
                return (
                    this.options.duration ? (this.pos = t = k.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration)) : (this.pos = t = e),
                    (this.now = (this.end - this.start) * t + this.start),
                    this.options.step && this.options.step.call(this.elem, this.now, this),
                    n && n.set ? n.set(this) : nt.propHooks._default.set(this),
                    this
                );
            },
        }).init.prototype = nt.prototype),
        ((nt.propHooks = {
            _default: {
                get: function (e) {
                    var t;
                    return 1 !== e.elem.nodeType || (null != e.elem[e.prop] && null == e.elem.style[e.prop]) ? e.elem[e.prop] : (t = k.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0;
                },
                set: function (e) {
                    k.fx.step[e.prop] ? k.fx.step[e.prop](e) : 1 !== e.elem.nodeType || (!k.cssHooks[e.prop] && null == e.elem.style[Ge(e.prop)]) ? (e.elem[e.prop] = e.now) : k.style(e.elem, e.prop, e.now + e.unit);
                },
            },
        }).scrollTop = nt.propHooks.scrollLeft = {
            set: function (e) {
                e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now);
            },
        }),
        (k.easing = {
            linear: function (e) {
                return e;
            },
            swing: function (e) {
                return 0.5 - Math.cos(e * Math.PI) / 2;
            },
            _default: "swing",
        }),
        (k.fx = nt.prototype.init),
        (k.fx.step = {});
    var rt,
        it,
        ot,
        at,
        st = /^(?:toggle|show|hide)$/,
        ut = /queueHooks$/;
    function lt() {
        it && (!1 === E.hidden && C.requestAnimationFrame ? C.requestAnimationFrame(lt) : C.setTimeout(lt, k.fx.interval), k.fx.tick());
    }
    function ct() {
        return (
            C.setTimeout(function () {
                rt = void 0;
            }),
            (rt = Date.now())
        );
    }
    function ft(e, t) {
        var n,
            r = 0,
            i = { height: e };
        for (t = t ? 1 : 0; r < 4; r += 2 - t) i["margin" + (n = re[r])] = i["padding" + n] = e;
        return t && (i.opacity = i.width = e), i;
    }
    function pt(e, t, n) {
        for (var r, i = (dt.tweeners[t] || []).concat(dt.tweeners["*"]), o = 0, a = i.length; o < a; o++) if ((r = i[o].call(n, t, e))) return r;
    }
    function dt(o, e, t) {
        var n,
            a,
            r = 0,
            i = dt.prefilters.length,
            s = k.Deferred().always(function () {
                delete u.elem;
            }),
            u = function () {
                if (a) return !1;
                for (var e = rt || ct(), t = Math.max(0, l.startTime + l.duration - e), n = 1 - (t / l.duration || 0), r = 0, i = l.tweens.length; r < i; r++) l.tweens[r].run(n);
                return s.notifyWith(o, [l, n, t]), n < 1 && i ? t : (i || s.notifyWith(o, [l, 1, 0]), s.resolveWith(o, [l]), !1);
            },
            l = s.promise({
                elem: o,
                props: k.extend({}, e),
                opts: k.extend(!0, { specialEasing: {}, easing: k.easing._default }, t),
                originalProperties: e,
                originalOptions: t,
                startTime: rt || ct(),
                duration: t.duration,
                tweens: [],
                createTween: function (e, t) {
                    var n = k.Tween(o, l.opts, e, t, l.opts.specialEasing[e] || l.opts.easing);
                    return l.tweens.push(n), n;
                },
                stop: function (e) {
                    var t = 0,
                        n = e ? l.tweens.length : 0;
                    if (a) return this;
                    for (a = !0; t < n; t++) l.tweens[t].run(1);
                    return e ? (s.notifyWith(o, [l, 1, 0]), s.resolveWith(o, [l, e])) : s.rejectWith(o, [l, e]), this;
                },
            }),
            c = l.props;
        for (
            !(function (e, t) {
                var n, r, i, o, a;
                for (n in e)
                    if (((i = t[(r = V(n))]), (o = e[n]), Array.isArray(o) && ((i = o[1]), (o = e[n] = o[0])), n !== r && ((e[r] = o), delete e[n]), (a = k.cssHooks[r]) && ("expand" in a)))
                        for (n in ((o = a.expand(o)), delete e[r], o)) (n in e) || ((e[n] = o[n]), (t[n] = i));
                    else t[r] = i;
            })(c, l.opts.specialEasing);
            r < i;
            r++
        )
            if ((n = dt.prefilters[r].call(l, o, c, l.opts))) return m(n.stop) && (k._queueHooks(l.elem, l.opts.queue).stop = n.stop.bind(n)), n;
        return (
            k.map(c, pt, l),
            m(l.opts.start) && l.opts.start.call(o, l),
            l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always),
            k.fx.timer(k.extend(u, { elem: o, anim: l, queue: l.opts.queue })),
            l
        );
    }
    (k.Animation = k.extend(dt, {
        tweeners: {
            "*": [
                function (e, t) {
                    var n = this.createTween(e, t);
                    return le(n.elem, e, ne.exec(t), n), n;
                },
            ],
        },
        tweener: function (e, t) {
            m(e) ? ((t = e), (e = ["*"])) : (e = e.match(R));
            for (var n, r = 0, i = e.length; r < i; r++) (n = e[r]), (dt.tweeners[n] = dt.tweeners[n] || []), dt.tweeners[n].unshift(t);
        },
        prefilters: [
            function (e, t, n) {
                var r,
                    i,
                    o,
                    a,
                    s,
                    u,
                    l,
                    c,
                    f = "width" in t || "height" in t,
                    p = this,
                    d = {},
                    h = e.style,
                    g = e.nodeType && se(e),
                    v = Q.get(e, "fxshow");
                for (r in (n.queue ||
                    (null == (a = k._queueHooks(e, "fx")).unqueued &&
                        ((a.unqueued = 0),
                        (s = a.empty.fire),
                        (a.empty.fire = function () {
                            a.unqueued || s();
                        })),
                    a.unqueued++,
                    p.always(function () {
                        p.always(function () {
                            a.unqueued--, k.queue(e, "fx").length || a.empty.fire();
                        });
                    })),
                t))
                    if (((i = t[r]), st.test(i))) {
                        if ((delete t[r], (o = o || "toggle" === i), i === (g ? "hide" : "show"))) {
                            if ("show" !== i || !v || void 0 === v[r]) continue;
                            g = !0;
                        }
                        d[r] = (v && v[r]) || k.style(e, r);
                    }
                if ((u = !k.isEmptyObject(t)) || !k.isEmptyObject(d))
                    for (r in (f &&
                        1 === e.nodeType &&
                        ((n.overflow = [h.overflow, h.overflowX, h.overflowY]),
                        null == (l = v && v.display) && (l = Q.get(e, "display")),
                        "none" === (c = k.css(e, "display")) && (l ? (c = l) : (fe([e], !0), (l = e.style.display || l), (c = k.css(e, "display")), fe([e]))),
                        ("inline" === c || ("inline-block" === c && null != l)) &&
                            "none" === k.css(e, "float") &&
                            (u ||
                                (p.done(function () {
                                    h.display = l;
                                }),
                                null == l && ((c = h.display), (l = "none" === c ? "" : c))),
                            (h.display = "inline-block"))),
                    n.overflow &&
                        ((h.overflow = "hidden"),
                        p.always(function () {
                            (h.overflow = n.overflow[0]), (h.overflowX = n.overflow[1]), (h.overflowY = n.overflow[2]);
                        })),
                    (u = !1),
                    d))
                        u ||
                            (v ? "hidden" in v && (g = v.hidden) : (v = Q.access(e, "fxshow", { display: l })),
                            o && (v.hidden = !g),
                            g && fe([e], !0),
                            p.done(function () {
                                for (r in (g || fe([e]), Q.remove(e, "fxshow"), d)) k.style(e, r, d[r]);
                            })),
                            (u = pt(g ? v[r] : 0, r, p)),
                            r in v || ((v[r] = u.start), g && ((u.end = u.start), (u.start = 0)));
            },
        ],
        prefilter: function (e, t) {
            t ? dt.prefilters.unshift(e) : dt.prefilters.push(e);
        },
    })),
        (k.speed = function (e, t, n) {
            var r = e && "object" == typeof e ? k.extend({}, e) : { complete: n || (!n && t) || (m(e) && e), duration: e, easing: (n && t) || (t && !m(t) && t) };
            return (
                k.fx.off ? (r.duration = 0) : "number" != typeof r.duration && (r.duration in k.fx.speeds ? (r.duration = k.fx.speeds[r.duration]) : (r.duration = k.fx.speeds._default)),
                (null != r.queue && !0 !== r.queue) || (r.queue = "fx"),
                (r.old = r.complete),
                (r.complete = function () {
                    m(r.old) && r.old.call(this), r.queue && k.dequeue(this, r.queue);
                }),
                r
            );
        }),
        k.fn.extend({
            fadeTo: function (e, t, n, r) {
                return this.filter(se).css("opacity", 0).show().end().animate({ opacity: t }, e, n, r);
            },
            animate: function (t, e, n, r) {
                var i = k.isEmptyObject(t),
                    o = k.speed(e, n, r),
                    a = function () {
                        var e = dt(this, k.extend({}, t), o);
                        (i || Q.get(this, "finish")) && e.stop(!0);
                    };
                return (a.finish = a), i || !1 === o.queue ? this.each(a) : this.queue(o.queue, a);
            },
            stop: function (i, e, o) {
                var a = function (e) {
                    var t = e.stop;
                    delete e.stop, t(o);
                };
                return (
                    "string" != typeof i && ((o = e), (e = i), (i = void 0)),
                    e && !1 !== i && this.queue(i || "fx", []),
                    this.each(function () {
                        var e = !0,
                            t = null != i && i + "queueHooks",
                            n = k.timers,
                            r = Q.get(this);
                        if (t) r[t] && r[t].stop && a(r[t]);
                        else for (t in r) r[t] && r[t].stop && ut.test(t) && a(r[t]);
                        for (t = n.length; t--; ) n[t].elem !== this || (null != i && n[t].queue !== i) || (n[t].anim.stop(o), (e = !1), n.splice(t, 1));
                        (!e && o) || k.dequeue(this, i);
                    })
                );
            },
            finish: function (a) {
                return (
                    !1 !== a && (a = a || "fx"),
                    this.each(function () {
                        var e,
                            t = Q.get(this),
                            n = t[a + "queue"],
                            r = t[a + "queueHooks"],
                            i = k.timers,
                            o = n ? n.length : 0;
                        for (t.finish = !0, k.queue(this, a, []), r && r.stop && r.stop.call(this, !0), e = i.length; e--; ) i[e].elem === this && i[e].queue === a && (i[e].anim.stop(!0), i.splice(e, 1));
                        for (e = 0; e < o; e++) n[e] && n[e].finish && n[e].finish.call(this);
                        delete t.finish;
                    })
                );
            },
        }),
        k.each(["toggle", "show", "hide"], function (e, r) {
            var i = k.fn[r];
            k.fn[r] = function (e, t, n) {
                return null == e || "boolean" == typeof e ? i.apply(this, arguments) : this.animate(ft(r, !0), e, t, n);
            };
        }),
        k.each({ slideDown: ft("show"), slideUp: ft("hide"), slideToggle: ft("toggle"), fadeIn: { opacity: "show" }, fadeOut: { opacity: "hide" }, fadeToggle: { opacity: "toggle" } }, function (e, r) {
            k.fn[e] = function (e, t, n) {
                return this.animate(r, e, t, n);
            };
        }),
        (k.timers = []),
        (k.fx.tick = function () {
            var e,
                t = 0,
                n = k.timers;
            for (rt = Date.now(); t < n.length; t++) (e = n[t])() || n[t] !== e || n.splice(t--, 1);
            n.length || k.fx.stop(), (rt = void 0);
        }),
        (k.fx.timer = function (e) {
            k.timers.push(e), k.fx.start();
        }),
        (k.fx.interval = 13),
        (k.fx.start = function () {
            it || ((it = !0), lt());
        }),
        (k.fx.stop = function () {
            it = null;
        }),
        (k.fx.speeds = { slow: 600, fast: 200, _default: 400 }),
        (k.fn.delay = function (r, e) {
            return (
                (r = (k.fx && k.fx.speeds[r]) || r),
                (e = e || "fx"),
                this.queue(e, function (e, t) {
                    var n = C.setTimeout(e, r);
                    t.stop = function () {
                        C.clearTimeout(n);
                    };
                })
            );
        }),
        (ot = E.createElement("input")),
        (at = E.createElement("select").appendChild(E.createElement("option"))),
        (ot.type = "checkbox"),
        (y.checkOn = "" !== ot.value),
        (y.optSelected = at.selected),
        ((ot = E.createElement("input")).value = "t"),
        (ot.type = "radio"),
        (y.radioValue = "t" === ot.value);
    var ht,
        gt = k.expr.attrHandle;
    k.fn.extend({
        attr: function (e, t) {
            return _(this, k.attr, e, t, 1 < arguments.length);
        },
        removeAttr: function (e) {
            return this.each(function () {
                k.removeAttr(this, e);
            });
        },
    }),
        k.extend({
            attr: function (e, t, n) {
                var r,
                    i,
                    o = e.nodeType;
                if (3 !== o && 8 !== o && 2 !== o)
                    return "undefined" == typeof e.getAttribute
                        ? k.prop(e, t, n)
                        : ((1 === o && k.isXMLDoc(e)) || (i = k.attrHooks[t.toLowerCase()] || (k.expr.match.bool.test(t) ? ht : void 0)),
                          void 0 !== n
                              ? null === n
                                  ? void k.removeAttr(e, t)
                                  : i && "set" in i && void 0 !== (r = i.set(e, n, t))
                                  ? r
                                  : (e.setAttribute(t, n + ""), n)
                              : i && "get" in i && null !== (r = i.get(e, t))
                              ? r
                              : null == (r = k.find.attr(e, t))
                              ? void 0
                              : r);
            },
            attrHooks: {
                type: {
                    set: function (e, t) {
                        if (!y.radioValue && "radio" === t && A(e, "input")) {
                            var n = e.value;
                            return e.setAttribute("type", t), n && (e.value = n), t;
                        }
                    },
                },
            },
            removeAttr: function (e, t) {
                var n,
                    r = 0,
                    i = t && t.match(R);
                if (i && 1 === e.nodeType) while ((n = i[r++])) e.removeAttribute(n);
            },
        }),
        (ht = {
            set: function (e, t, n) {
                return !1 === t ? k.removeAttr(e, n) : e.setAttribute(n, n), n;
            },
        }),
        k.each(k.expr.match.bool.source.match(/\w+/g), function (e, t) {
            var a = gt[t] || k.find.attr;
            gt[t] = function (e, t, n) {
                var r,
                    i,
                    o = t.toLowerCase();
                return n || ((i = gt[o]), (gt[o] = r), (r = null != a(e, t, n) ? o : null), (gt[o] = i)), r;
            };
        });
    var vt = /^(?:input|select|textarea|button)$/i,
        yt = /^(?:a|area)$/i;
    function mt(e) {
        return (e.match(R) || []).join(" ");
    }
    function xt(e) {
        return (e.getAttribute && e.getAttribute("class")) || "";
    }
    function bt(e) {
        return Array.isArray(e) ? e : ("string" == typeof e && e.match(R)) || [];
    }
    k.fn.extend({
        prop: function (e, t) {
            return _(this, k.prop, e, t, 1 < arguments.length);
        },
        removeProp: function (e) {
            return this.each(function () {
                delete this[k.propFix[e] || e];
            });
        },
    }),
        k.extend({
            prop: function (e, t, n) {
                var r,
                    i,
                    o = e.nodeType;
                if (3 !== o && 8 !== o && 2 !== o)
                    return (
                        (1 === o && k.isXMLDoc(e)) || ((t = k.propFix[t] || t), (i = k.propHooks[t])),
                        void 0 !== n ? (i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : (e[t] = n)) : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t]
                    );
            },
            propHooks: {
                tabIndex: {
                    get: function (e) {
                        var t = k.find.attr(e, "tabindex");
                        return t ? parseInt(t, 10) : vt.test(e.nodeName) || (yt.test(e.nodeName) && e.href) ? 0 : -1;
                    },
                },
            },
            propFix: { for: "htmlFor", class: "className" },
        }),
        y.optSelected ||
            (k.propHooks.selected = {
                get: function (e) {
                    var t = e.parentNode;
                    return t && t.parentNode && t.parentNode.selectedIndex, null;
                },
                set: function (e) {
                    var t = e.parentNode;
                    t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex);
                },
            }),
        k.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
            k.propFix[this.toLowerCase()] = this;
        }),
        k.fn.extend({
            addClass: function (t) {
                var e,
                    n,
                    r,
                    i,
                    o,
                    a,
                    s,
                    u = 0;
                if (m(t))
                    return this.each(function (e) {
                        k(this).addClass(t.call(this, e, xt(this)));
                    });
                if ((e = bt(t)).length)
                    while ((n = this[u++]))
                        if (((i = xt(n)), (r = 1 === n.nodeType && " " + mt(i) + " "))) {
                            a = 0;
                            while ((o = e[a++])) r.indexOf(" " + o + " ") < 0 && (r += o + " ");
                            i !== (s = mt(r)) && n.setAttribute("class", s);
                        }
                return this;
            },
            removeClass: function (t) {
                var e,
                    n,
                    r,
                    i,
                    o,
                    a,
                    s,
                    u = 0;
                if (m(t))
                    return this.each(function (e) {
                        k(this).removeClass(t.call(this, e, xt(this)));
                    });
                if (!arguments.length) return this.attr("class", "");
                if ((e = bt(t)).length)
                    while ((n = this[u++]))
                        if (((i = xt(n)), (r = 1 === n.nodeType && " " + mt(i) + " "))) {
                            a = 0;
                            while ((o = e[a++])) while (-1 < r.indexOf(" " + o + " ")) r = r.replace(" " + o + " ", " ");
                            i !== (s = mt(r)) && n.setAttribute("class", s);
                        }
                return this;
            },
            toggleClass: function (i, t) {
                var o = typeof i,
                    a = "string" === o || Array.isArray(i);
                return "boolean" == typeof t && a
                    ? t
                        ? this.addClass(i)
                        : this.removeClass(i)
                    : m(i)
                    ? this.each(function (e) {
                          k(this).toggleClass(i.call(this, e, xt(this), t), t);
                      })
                    : this.each(function () {
                          var e, t, n, r;
                          if (a) {
                              (t = 0), (n = k(this)), (r = bt(i));
                              while ((e = r[t++])) n.hasClass(e) ? n.removeClass(e) : n.addClass(e);
                          } else (void 0 !== i && "boolean" !== o) || ((e = xt(this)) && Q.set(this, "__className__", e), this.setAttribute && this.setAttribute("class", e || !1 === i ? "" : Q.get(this, "__className__") || ""));
                      });
            },
            hasClass: function (e) {
                var t,
                    n,
                    r = 0;
                t = " " + e + " ";
                while ((n = this[r++])) if (1 === n.nodeType && -1 < (" " + mt(xt(n)) + " ").indexOf(t)) return !0;
                return !1;
            },
        });
    var wt = /\r/g;
    k.fn.extend({
        val: function (n) {
            var r,
                e,
                i,
                t = this[0];
            return arguments.length
                ? ((i = m(n)),
                  this.each(function (e) {
                      var t;
                      1 === this.nodeType &&
                          (null == (t = i ? n.call(this, e, k(this).val()) : n)
                              ? (t = "")
                              : "number" == typeof t
                              ? (t += "")
                              : Array.isArray(t) &&
                                (t = k.map(t, function (e) {
                                    return null == e ? "" : e + "";
                                })),
                          ((r = k.valHooks[this.type] || k.valHooks[this.nodeName.toLowerCase()]) && "set" in r && void 0 !== r.set(this, t, "value")) || (this.value = t));
                  }))
                : t
                ? (r = k.valHooks[t.type] || k.valHooks[t.nodeName.toLowerCase()]) && "get" in r && void 0 !== (e = r.get(t, "value"))
                    ? e
                    : "string" == typeof (e = t.value)
                    ? e.replace(wt, "")
                    : null == e
                    ? ""
                    : e
                : void 0;
        },
    }),
        k.extend({
            valHooks: {
                option: {
                    get: function (e) {
                        var t = k.find.attr(e, "value");
                        return null != t ? t : mt(k.text(e));
                    },
                },
                select: {
                    get: function (e) {
                        var t,
                            n,
                            r,
                            i = e.options,
                            o = e.selectedIndex,
                            a = "select-one" === e.type,
                            s = a ? null : [],
                            u = a ? o + 1 : i.length;
                        for (r = o < 0 ? u : a ? o : 0; r < u; r++)
                            if (((n = i[r]).selected || r === o) && !n.disabled && (!n.parentNode.disabled || !A(n.parentNode, "optgroup"))) {
                                if (((t = k(n).val()), a)) return t;
                                s.push(t);
                            }
                        return s;
                    },
                    set: function (e, t) {
                        var n,
                            r,
                            i = e.options,
                            o = k.makeArray(t),
                            a = i.length;
                        while (a--) ((r = i[a]).selected = -1 < k.inArray(k.valHooks.option.get(r), o)) && (n = !0);
                        return n || (e.selectedIndex = -1), o;
                    },
                },
            },
        }),
        k.each(["radio", "checkbox"], function () {
            (k.valHooks[this] = {
                set: function (e, t) {
                    if (Array.isArray(t)) return (e.checked = -1 < k.inArray(k(e).val(), t));
                },
            }),
                y.checkOn ||
                    (k.valHooks[this].get = function (e) {
                        return null === e.getAttribute("value") ? "on" : e.value;
                    });
        }),
        (y.focusin = "onfocusin" in C);
    var Tt = /^(?:focusinfocus|focusoutblur)$/,
        Ct = function (e) {
            e.stopPropagation();
        };
    k.extend(k.event, {
        trigger: function (e, t, n, r) {
            var i,
                o,
                a,
                s,
                u,
                l,
                c,
                f,
                p = [n || E],
                d = v.call(e, "type") ? e.type : e,
                h = v.call(e, "namespace") ? e.namespace.split(".") : [];
            if (
                ((o = f = a = n = n || E),
                3 !== n.nodeType &&
                    8 !== n.nodeType &&
                    !Tt.test(d + k.event.triggered) &&
                    (-1 < d.indexOf(".") && ((d = (h = d.split(".")).shift()), h.sort()),
                    (u = d.indexOf(":") < 0 && "on" + d),
                    ((e = e[k.expando] ? e : new k.Event(d, "object" == typeof e && e)).isTrigger = r ? 2 : 3),
                    (e.namespace = h.join(".")),
                    (e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)") : null),
                    (e.result = void 0),
                    e.target || (e.target = n),
                    (t = null == t ? [e] : k.makeArray(t, [e])),
                    (c = k.event.special[d] || {}),
                    r || !c.trigger || !1 !== c.trigger.apply(n, t)))
            ) {
                if (!r && !c.noBubble && !x(n)) {
                    for (s = c.delegateType || d, Tt.test(s + d) || (o = o.parentNode); o; o = o.parentNode) p.push(o), (a = o);
                    a === (n.ownerDocument || E) && p.push(a.defaultView || a.parentWindow || C);
                }
                i = 0;
                while ((o = p[i++]) && !e.isPropagationStopped())
                    (f = o),
                        (e.type = 1 < i ? s : c.bindType || d),
                        (l = (Q.get(o, "events") || {})[e.type] && Q.get(o, "handle")) && l.apply(o, t),
                        (l = u && o[u]) && l.apply && G(o) && ((e.result = l.apply(o, t)), !1 === e.result && e.preventDefault());
                return (
                    (e.type = d),
                    r ||
                        e.isDefaultPrevented() ||
                        (c._default && !1 !== c._default.apply(p.pop(), t)) ||
                        !G(n) ||
                        (u &&
                            m(n[d]) &&
                            !x(n) &&
                            ((a = n[u]) && (n[u] = null),
                            (k.event.triggered = d),
                            e.isPropagationStopped() && f.addEventListener(d, Ct),
                            n[d](),
                            e.isPropagationStopped() && f.removeEventListener(d, Ct),
                            (k.event.triggered = void 0),
                            a && (n[u] = a))),
                    e.result
                );
            }
        },
        simulate: function (e, t, n) {
            var r = k.extend(new k.Event(), n, { type: e, isSimulated: !0 });
            k.event.trigger(r, null, t);
        },
    }),
        k.fn.extend({
            trigger: function (e, t) {
                return this.each(function () {
                    k.event.trigger(e, t, this);
                });
            },
            triggerHandler: function (e, t) {
                var n = this[0];
                if (n) return k.event.trigger(e, t, n, !0);
            },
        }),
        y.focusin ||
            k.each({ focus: "focusin", blur: "focusout" }, function (n, r) {
                var i = function (e) {
                    k.event.simulate(r, e.target, k.event.fix(e));
                };
                k.event.special[r] = {
                    setup: function () {
                        var e = this.ownerDocument || this,
                            t = Q.access(e, r);
                        t || e.addEventListener(n, i, !0), Q.access(e, r, (t || 0) + 1);
                    },
                    teardown: function () {
                        var e = this.ownerDocument || this,
                            t = Q.access(e, r) - 1;
                        t ? Q.access(e, r, t) : (e.removeEventListener(n, i, !0), Q.remove(e, r));
                    },
                };
            });
    var Et = C.location,
        kt = Date.now(),
        St = /\?/;
    k.parseXML = function (e) {
        var t;
        if (!e || "string" != typeof e) return null;
        try {
            t = new C.DOMParser().parseFromString(e, "text/xml");
        } catch (e) {
            t = void 0;
        }
        return (t && !t.getElementsByTagName("parsererror").length) || k.error("Invalid XML: " + e), t;
    };
    var Nt = /\[\]$/,
        At = /\r?\n/g,
        Dt = /^(?:submit|button|image|reset|file)$/i,
        jt = /^(?:input|select|textarea|keygen)/i;
    function qt(n, e, r, i) {
        var t;
        if (Array.isArray(e))
            k.each(e, function (e, t) {
                r || Nt.test(n) ? i(n, t) : qt(n + "[" + ("object" == typeof t && null != t ? e : "") + "]", t, r, i);
            });
        else if (r || "object" !== w(e)) i(n, e);
        else for (t in e) qt(n + "[" + t + "]", e[t], r, i);
    }
    (k.param = function (e, t) {
        var n,
            r = [],
            i = function (e, t) {
                var n = m(t) ? t() : t;
                r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n);
            };
        if (null == e) return "";
        if (Array.isArray(e) || (e.jquery && !k.isPlainObject(e)))
            k.each(e, function () {
                i(this.name, this.value);
            });
        else for (n in e) qt(n, e[n], t, i);
        return r.join("&");
    }),
        k.fn.extend({
            serialize: function () {
                return k.param(this.serializeArray());
            },
            serializeArray: function () {
                return this.map(function () {
                    var e = k.prop(this, "elements");
                    return e ? k.makeArray(e) : this;
                })
                    .filter(function () {
                        var e = this.type;
                        return this.name && !k(this).is(":disabled") && jt.test(this.nodeName) && !Dt.test(e) && (this.checked || !pe.test(e));
                    })
                    .map(function (e, t) {
                        var n = k(this).val();
                        return null == n
                            ? null
                            : Array.isArray(n)
                            ? k.map(n, function (e) {
                                  return { name: t.name, value: e.replace(At, "\r\n") };
                              })
                            : { name: t.name, value: n.replace(At, "\r\n") };
                    })
                    .get();
            },
        });
    var Lt = /%20/g,
        Ht = /#.*$/,
        Ot = /([?&])_=[^&]*/,
        Pt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        Rt = /^(?:GET|HEAD)$/,
        Mt = /^\/\//,
        It = {},
        Wt = {},
        $t = "*/".concat("*"),
        Ft = E.createElement("a");
    function Bt(o) {
        return function (e, t) {
            "string" != typeof e && ((t = e), (e = "*"));
            var n,
                r = 0,
                i = e.toLowerCase().match(R) || [];
            if (m(t)) while ((n = i[r++])) "+" === n[0] ? ((n = n.slice(1) || "*"), (o[n] = o[n] || []).unshift(t)) : (o[n] = o[n] || []).push(t);
        };
    }
    function _t(t, i, o, a) {
        var s = {},
            u = t === Wt;
        function l(e) {
            var r;
            return (
                (s[e] = !0),
                k.each(t[e] || [], function (e, t) {
                    var n = t(i, o, a);
                    return "string" != typeof n || u || s[n] ? (u ? !(r = n) : void 0) : (i.dataTypes.unshift(n), l(n), !1);
                }),
                r
            );
        }
        return l(i.dataTypes[0]) || (!s["*"] && l("*"));
    }
    function zt(e, t) {
        var n,
            r,
            i = k.ajaxSettings.flatOptions || {};
        for (n in t) void 0 !== t[n] && ((i[n] ? e : r || (r = {}))[n] = t[n]);
        return r && k.extend(!0, e, r), e;
    }
    (Ft.href = Et.href),
        k.extend({
            active: 0,
            lastModified: {},
            etag: {},
            ajaxSettings: {
                url: Et.href,
                type: "GET",
                isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Et.protocol),
                global: !0,
                processData: !0,
                async: !0,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: { "*": $t, text: "text/plain", html: "text/html", xml: "application/xml, text/xml", json: "application/json, text/javascript" },
                contents: { xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/ },
                responseFields: { xml: "responseXML", text: "responseText", json: "responseJSON" },
                converters: { "* text": String, "text html": !0, "text json": JSON.parse, "text xml": k.parseXML },
                flatOptions: { url: !0, context: !0 },
            },
            ajaxSetup: function (e, t) {
                return t ? zt(zt(e, k.ajaxSettings), t) : zt(k.ajaxSettings, e);
            },
            ajaxPrefilter: Bt(It),
            ajaxTransport: Bt(Wt),
            ajax: function (e, t) {
                "object" == typeof e && ((t = e), (e = void 0)), (t = t || {});
                var c,
                    f,
                    p,
                    n,
                    d,
                    r,
                    h,
                    g,
                    i,
                    o,
                    v = k.ajaxSetup({}, t),
                    y = v.context || v,
                    m = v.context && (y.nodeType || y.jquery) ? k(y) : k.event,
                    x = k.Deferred(),
                    b = k.Callbacks("once memory"),
                    w = v.statusCode || {},
                    a = {},
                    s = {},
                    u = "canceled",
                    T = {
                        readyState: 0,
                        getResponseHeader: function (e) {
                            var t;
                            if (h) {
                                if (!n) {
                                    n = {};
                                    while ((t = Pt.exec(p))) n[t[1].toLowerCase() + " "] = (n[t[1].toLowerCase() + " "] || []).concat(t[2]);
                                }
                                t = n[e.toLowerCase() + " "];
                            }
                            return null == t ? null : t.join(", ");
                        },
                        getAllResponseHeaders: function () {
                            return h ? p : null;
                        },
                        setRequestHeader: function (e, t) {
                            return null == h && ((e = s[e.toLowerCase()] = s[e.toLowerCase()] || e), (a[e] = t)), this;
                        },
                        overrideMimeType: function (e) {
                            return null == h && (v.mimeType = e), this;
                        },
                        statusCode: function (e) {
                            var t;
                            if (e)
                                if (h) T.always(e[T.status]);
                                else for (t in e) w[t] = [w[t], e[t]];
                            return this;
                        },
                        abort: function (e) {
                            var t = e || u;
                            return c && c.abort(t), l(0, t), this;
                        },
                    };
                if (
                    (x.promise(T),
                    (v.url = ((e || v.url || Et.href) + "").replace(Mt, Et.protocol + "//")),
                    (v.type = t.method || t.type || v.method || v.type),
                    (v.dataTypes = (v.dataType || "*").toLowerCase().match(R) || [""]),
                    null == v.crossDomain)
                ) {
                    r = E.createElement("a");
                    try {
                        (r.href = v.url), (r.href = r.href), (v.crossDomain = Ft.protocol + "//" + Ft.host != r.protocol + "//" + r.host);
                    } catch (e) {
                        v.crossDomain = !0;
                    }
                }
                if ((v.data && v.processData && "string" != typeof v.data && (v.data = k.param(v.data, v.traditional)), _t(It, v, t, T), h)) return T;
                for (i in ((g = k.event && v.global) && 0 == k.active++ && k.event.trigger("ajaxStart"),
                (v.type = v.type.toUpperCase()),
                (v.hasContent = !Rt.test(v.type)),
                (f = v.url.replace(Ht, "")),
                v.hasContent
                    ? v.data && v.processData && 0 === (v.contentType || "").indexOf("application/x-www-form-urlencoded") && (v.data = v.data.replace(Lt, "+"))
                    : ((o = v.url.slice(f.length)),
                      v.data && (v.processData || "string" == typeof v.data) && ((f += (St.test(f) ? "&" : "?") + v.data), delete v.data),
                      !1 === v.cache && ((f = f.replace(Ot, "$1")), (o = (St.test(f) ? "&" : "?") + "_=" + kt++ + o)),
                      (v.url = f + o)),
                v.ifModified && (k.lastModified[f] && T.setRequestHeader("If-Modified-Since", k.lastModified[f]), k.etag[f] && T.setRequestHeader("If-None-Match", k.etag[f])),
                ((v.data && v.hasContent && !1 !== v.contentType) || t.contentType) && T.setRequestHeader("Content-Type", v.contentType),
                T.setRequestHeader("Accept", v.dataTypes[0] && v.accepts[v.dataTypes[0]] ? v.accepts[v.dataTypes[0]] + ("*" !== v.dataTypes[0] ? ", " + $t + "; q=0.01" : "") : v.accepts["*"]),
                v.headers))
                    T.setRequestHeader(i, v.headers[i]);
                if (v.beforeSend && (!1 === v.beforeSend.call(y, T, v) || h)) return T.abort();
                if (((u = "abort"), b.add(v.complete), T.done(v.success), T.fail(v.error), (c = _t(Wt, v, t, T)))) {
                    if (((T.readyState = 1), g && m.trigger("ajaxSend", [T, v]), h)) return T;
                    v.async &&
                        0 < v.timeout &&
                        (d = C.setTimeout(function () {
                            T.abort("timeout");
                        }, v.timeout));
                    try {
                        (h = !1), c.send(a, l);
                    } catch (e) {
                        if (h) throw e;
                        l(-1, e);
                    }
                } else l(-1, "No Transport");
                function l(e, t, n, r) {
                    var i,
                        o,
                        a,
                        s,
                        u,
                        l = t;
                    h ||
                        ((h = !0),
                        d && C.clearTimeout(d),
                        (c = void 0),
                        (p = r || ""),
                        (T.readyState = 0 < e ? 4 : 0),
                        (i = (200 <= e && e < 300) || 304 === e),
                        n &&
                            (s = (function (e, t, n) {
                                var r,
                                    i,
                                    o,
                                    a,
                                    s = e.contents,
                                    u = e.dataTypes;
                                while ("*" === u[0]) u.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
                                if (r)
                                    for (i in s)
                                        if (s[i] && s[i].test(r)) {
                                            u.unshift(i);
                                            break;
                                        }
                                if (u[0] in n) o = u[0];
                                else {
                                    for (i in n) {
                                        if (!u[0] || e.converters[i + " " + u[0]]) {
                                            o = i;
                                            break;
                                        }
                                        a || (a = i);
                                    }
                                    o = o || a;
                                }
                                if (o) return o !== u[0] && u.unshift(o), n[o];
                            })(v, T, n)),
                        (s = (function (e, t, n, r) {
                            var i,
                                o,
                                a,
                                s,
                                u,
                                l = {},
                                c = e.dataTypes.slice();
                            if (c[1]) for (a in e.converters) l[a.toLowerCase()] = e.converters[a];
                            o = c.shift();
                            while (o)
                                if ((e.responseFields[o] && (n[e.responseFields[o]] = t), !u && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), (u = o), (o = c.shift())))
                                    if ("*" === o) o = u;
                                    else if ("*" !== u && u !== o) {
                                        if (!(a = l[u + " " + o] || l["* " + o]))
                                            for (i in l)
                                                if ((s = i.split(" "))[1] === o && (a = l[u + " " + s[0]] || l["* " + s[0]])) {
                                                    !0 === a ? (a = l[i]) : !0 !== l[i] && ((o = s[0]), c.unshift(s[1]));
                                                    break;
                                                }
                                        if (!0 !== a)
                                            if (a && e["throws"]) t = a(t);
                                            else
                                                try {
                                                    t = a(t);
                                                } catch (e) {
                                                    return { state: "parsererror", error: a ? e : "No conversion from " + u + " to " + o };
                                                }
                                    }
                            return { state: "success", data: t };
                        })(v, s, T, i)),
                        i
                            ? (v.ifModified && ((u = T.getResponseHeader("Last-Modified")) && (k.lastModified[f] = u), (u = T.getResponseHeader("etag")) && (k.etag[f] = u)),
                              204 === e || "HEAD" === v.type ? (l = "nocontent") : 304 === e ? (l = "notmodified") : ((l = s.state), (o = s.data), (i = !(a = s.error))))
                            : ((a = l), (!e && l) || ((l = "error"), e < 0 && (e = 0))),
                        (T.status = e),
                        (T.statusText = (t || l) + ""),
                        i ? x.resolveWith(y, [o, l, T]) : x.rejectWith(y, [T, l, a]),
                        T.statusCode(w),
                        (w = void 0),
                        g && m.trigger(i ? "ajaxSuccess" : "ajaxError", [T, v, i ? o : a]),
                        b.fireWith(y, [T, l]),
                        g && (m.trigger("ajaxComplete", [T, v]), --k.active || k.event.trigger("ajaxStop")));
                }
                return T;
            },
            getJSON: function (e, t, n) {
                return k.get(e, t, n, "json");
            },
            getScript: function (e, t) {
                return k.get(e, void 0, t, "script");
            },
        }),
        k.each(["get", "post"], function (e, i) {
            k[i] = function (e, t, n, r) {
                return m(t) && ((r = r || n), (n = t), (t = void 0)), k.ajax(k.extend({ url: e, type: i, dataType: r, data: t, success: n }, k.isPlainObject(e) && e));
            };
        }),
        (k._evalUrl = function (e, t) {
            return k.ajax({
                url: e,
                type: "GET",
                dataType: "script",
                cache: !0,
                async: !1,
                global: !1,
                converters: { "text script": function () {} },
                dataFilter: function (e) {
                    k.globalEval(e, t);
                },
            });
        }),
        k.fn.extend({
            wrapAll: function (e) {
                var t;
                return (
                    this[0] &&
                        (m(e) && (e = e.call(this[0])),
                        (t = k(e, this[0].ownerDocument).eq(0).clone(!0)),
                        this[0].parentNode && t.insertBefore(this[0]),
                        t
                            .map(function () {
                                var e = this;
                                while (e.firstElementChild) e = e.firstElementChild;
                                return e;
                            })
                            .append(this)),
                    this
                );
            },
            wrapInner: function (n) {
                return m(n)
                    ? this.each(function (e) {
                          k(this).wrapInner(n.call(this, e));
                      })
                    : this.each(function () {
                          var e = k(this),
                              t = e.contents();
                          t.length ? t.wrapAll(n) : e.append(n);
                      });
            },
            wrap: function (t) {
                var n = m(t);
                return this.each(function (e) {
                    k(this).wrapAll(n ? t.call(this, e) : t);
                });
            },
            unwrap: function (e) {
                return (
                    this.parent(e)
                        .not("body")
                        .each(function () {
                            k(this).replaceWith(this.childNodes);
                        }),
                    this
                );
            },
        }),
        (k.expr.pseudos.hidden = function (e) {
            return !k.expr.pseudos.visible(e);
        }),
        (k.expr.pseudos.visible = function (e) {
            return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
        }),
        (k.ajaxSettings.xhr = function () {
            try {
                return new C.XMLHttpRequest();
            } catch (e) {}
        });
    var Ut = { 0: 200, 1223: 204 },
        Xt = k.ajaxSettings.xhr();
    (y.cors = !!Xt && "withCredentials" in Xt),
        (y.ajax = Xt = !!Xt),
        k.ajaxTransport(function (i) {
            var o, a;
            if (y.cors || (Xt && !i.crossDomain))
                return {
                    send: function (e, t) {
                        var n,
                            r = i.xhr();
                        if ((r.open(i.type, i.url, i.async, i.username, i.password), i.xhrFields)) for (n in i.xhrFields) r[n] = i.xhrFields[n];
                        for (n in (i.mimeType && r.overrideMimeType && r.overrideMimeType(i.mimeType), i.crossDomain || e["X-Requested-With"] || (e["X-Requested-With"] = "XMLHttpRequest"), e)) r.setRequestHeader(n, e[n]);
                        (o = function (e) {
                            return function () {
                                o &&
                                    ((o = a = r.onload = r.onerror = r.onabort = r.ontimeout = r.onreadystatechange = null),
                                    "abort" === e
                                        ? r.abort()
                                        : "error" === e
                                        ? "number" != typeof r.status
                                            ? t(0, "error")
                                            : t(r.status, r.statusText)
                                        : t(Ut[r.status] || r.status, r.statusText, "text" !== (r.responseType || "text") || "string" != typeof r.responseText ? { binary: r.response } : { text: r.responseText }, r.getAllResponseHeaders()));
                            };
                        }),
                            (r.onload = o()),
                            (a = r.onerror = r.ontimeout = o("error")),
                            void 0 !== r.onabort
                                ? (r.onabort = a)
                                : (r.onreadystatechange = function () {
                                      4 === r.readyState &&
                                          C.setTimeout(function () {
                                              o && a();
                                          });
                                  }),
                            (o = o("abort"));
                        try {
                            r.send((i.hasContent && i.data) || null);
                        } catch (e) {
                            if (o) throw e;
                        }
                    },
                    abort: function () {
                        o && o();
                    },
                };
        }),
        k.ajaxPrefilter(function (e) {
            e.crossDomain && (e.contents.script = !1);
        }),
        k.ajaxSetup({
            accepts: { script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript" },
            contents: { script: /\b(?:java|ecma)script\b/ },
            converters: {
                "text script": function (e) {
                    return k.globalEval(e), e;
                },
            },
        }),
        k.ajaxPrefilter("script", function (e) {
            void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET");
        }),
        k.ajaxTransport("script", function (n) {
            var r, i;
            if (n.crossDomain || n.scriptAttrs)
                return {
                    send: function (e, t) {
                        (r = k("<script>")
                            .attr(n.scriptAttrs || {})
                            .prop({ charset: n.scriptCharset, src: n.url })
                            .on(
                                "load error",
                                (i = function (e) {
                                    r.remove(), (i = null), e && t("error" === e.type ? 404 : 200, e.type);
                                })
                            )),
                            E.head.appendChild(r[0]);
                    },
                    abort: function () {
                        i && i();
                    },
                };
        });
    var Vt,
        Gt = [],
        Yt = /(=)\?(?=&|$)|\?\?/;
    k.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function () {
            var e = Gt.pop() || k.expando + "_" + kt++;
            return (this[e] = !0), e;
        },
    }),
        k.ajaxPrefilter("json jsonp", function (e, t, n) {
            var r,
                i,
                o,
                a = !1 !== e.jsonp && (Yt.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && Yt.test(e.data) && "data");
            if (a || "jsonp" === e.dataTypes[0])
                return (
                    (r = e.jsonpCallback = m(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback),
                    a ? (e[a] = e[a].replace(Yt, "$1" + r)) : !1 !== e.jsonp && (e.url += (St.test(e.url) ? "&" : "?") + e.jsonp + "=" + r),
                    (e.converters["script json"] = function () {
                        return o || k.error(r + " was not called"), o[0];
                    }),
                    (e.dataTypes[0] = "json"),
                    (i = C[r]),
                    (C[r] = function () {
                        o = arguments;
                    }),
                    n.always(function () {
                        void 0 === i ? k(C).removeProp(r) : (C[r] = i), e[r] && ((e.jsonpCallback = t.jsonpCallback), Gt.push(r)), o && m(i) && i(o[0]), (o = i = void 0);
                    }),
                    "script"
                );
        }),
        (y.createHTMLDocument = (((Vt = E.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>"), 2 === Vt.childNodes.length)),
        (k.parseHTML = function (e, t, n) {
            return "string" != typeof e
                ? []
                : ("boolean" == typeof t && ((n = t), (t = !1)),
                  t || (y.createHTMLDocument ? (((r = (t = E.implementation.createHTMLDocument("")).createElement("base")).href = E.location.href), t.head.appendChild(r)) : (t = E)),
                  (o = !n && []),
                  (i = D.exec(e)) ? [t.createElement(i[1])] : ((i = we([e], t, o)), o && o.length && k(o).remove(), k.merge([], i.childNodes)));
            var r, i, o;
        }),
        (k.fn.load = function (e, t, n) {
            var r,
                i,
                o,
                a = this,
                s = e.indexOf(" ");
            return (
                -1 < s && ((r = mt(e.slice(s))), (e = e.slice(0, s))),
                m(t) ? ((n = t), (t = void 0)) : t && "object" == typeof t && (i = "POST"),
                0 < a.length &&
                    k
                        .ajax({ url: e, type: i || "GET", dataType: "html", data: t })
                        .done(function (e) {
                            (o = arguments), a.html(r ? k("<div>").append(k.parseHTML(e)).find(r) : e);
                        })
                        .always(
                            n &&
                                function (e, t) {
                                    a.each(function () {
                                        n.apply(this, o || [e.responseText, t, e]);
                                    });
                                }
                        ),
                this
            );
        }),
        k.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, t) {
            k.fn[t] = function (e) {
                return this.on(t, e);
            };
        }),
        (k.expr.pseudos.animated = function (t) {
            return k.grep(k.timers, function (e) {
                return t === e.elem;
            }).length;
        }),
        (k.offset = {
            setOffset: function (e, t, n) {
                var r,
                    i,
                    o,
                    a,
                    s,
                    u,
                    l = k.css(e, "position"),
                    c = k(e),
                    f = {};
                "static" === l && (e.style.position = "relative"),
                    (s = c.offset()),
                    (o = k.css(e, "top")),
                    (u = k.css(e, "left")),
                    ("absolute" === l || "fixed" === l) && -1 < (o + u).indexOf("auto") ? ((a = (r = c.position()).top), (i = r.left)) : ((a = parseFloat(o) || 0), (i = parseFloat(u) || 0)),
                    m(t) && (t = t.call(e, n, k.extend({}, s))),
                    null != t.top && (f.top = t.top - s.top + a),
                    null != t.left && (f.left = t.left - s.left + i),
                    "using" in t ? t.using.call(e, f) : c.css(f);
            },
        }),
        k.fn.extend({
            offset: function (t) {
                if (arguments.length)
                    return void 0 === t
                        ? this
                        : this.each(function (e) {
                              k.offset.setOffset(this, t, e);
                          });
                var e,
                    n,
                    r = this[0];
                return r ? (r.getClientRects().length ? ((e = r.getBoundingClientRect()), (n = r.ownerDocument.defaultView), { top: e.top + n.pageYOffset, left: e.left + n.pageXOffset }) : { top: 0, left: 0 }) : void 0;
            },
            position: function () {
                if (this[0]) {
                    var e,
                        t,
                        n,
                        r = this[0],
                        i = { top: 0, left: 0 };
                    if ("fixed" === k.css(r, "position")) t = r.getBoundingClientRect();
                    else {
                        (t = this.offset()), (n = r.ownerDocument), (e = r.offsetParent || n.documentElement);
                        while (e && (e === n.body || e === n.documentElement) && "static" === k.css(e, "position")) e = e.parentNode;
                        e && e !== r && 1 === e.nodeType && (((i = k(e).offset()).top += k.css(e, "borderTopWidth", !0)), (i.left += k.css(e, "borderLeftWidth", !0)));
                    }
                    return { top: t.top - i.top - k.css(r, "marginTop", !0), left: t.left - i.left - k.css(r, "marginLeft", !0) };
                }
            },
            offsetParent: function () {
                return this.map(function () {
                    var e = this.offsetParent;
                    while (e && "static" === k.css(e, "position")) e = e.offsetParent;
                    return e || ie;
                });
            },
        }),
        k.each({ scrollLeft: "pageXOffset", scrollTop: "pageYOffset" }, function (t, i) {
            var o = "pageYOffset" === i;
            k.fn[t] = function (e) {
                return _(
                    this,
                    function (e, t, n) {
                        var r;
                        if ((x(e) ? (r = e) : 9 === e.nodeType && (r = e.defaultView), void 0 === n)) return r ? r[i] : e[t];
                        r ? r.scrollTo(o ? r.pageXOffset : n, o ? n : r.pageYOffset) : (e[t] = n);
                    },
                    t,
                    e,
                    arguments.length
                );
            };
        }),
        k.each(["top", "left"], function (e, n) {
            k.cssHooks[n] = ze(y.pixelPosition, function (e, t) {
                if (t) return (t = _e(e, n)), $e.test(t) ? k(e).position()[n] + "px" : t;
            });
        }),
        k.each({ Height: "height", Width: "width" }, function (a, s) {
            k.each({ padding: "inner" + a, content: s, "": "outer" + a }, function (r, o) {
                k.fn[o] = function (e, t) {
                    var n = arguments.length && (r || "boolean" != typeof e),
                        i = r || (!0 === e || !0 === t ? "margin" : "border");
                    return _(
                        this,
                        function (e, t, n) {
                            var r;
                            return x(e)
                                ? 0 === o.indexOf("outer")
                                    ? e["inner" + a]
                                    : e.document.documentElement["client" + a]
                                : 9 === e.nodeType
                                ? ((r = e.documentElement), Math.max(e.body["scroll" + a], r["scroll" + a], e.body["offset" + a], r["offset" + a], r["client" + a]))
                                : void 0 === n
                                ? k.css(e, t, i)
                                : k.style(e, t, n, i);
                        },
                        s,
                        n ? e : void 0,
                        n
                    );
                };
            });
        }),
        k.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function (e, n) {
            k.fn[n] = function (e, t) {
                return 0 < arguments.length ? this.on(n, null, e, t) : this.trigger(n);
            };
        }),
        k.fn.extend({
            hover: function (e, t) {
                return this.mouseenter(e).mouseleave(t || e);
            },
        }),
        k.fn.extend({
            bind: function (e, t, n) {
                return this.on(e, null, t, n);
            },
            unbind: function (e, t) {
                return this.off(e, null, t);
            },
            delegate: function (e, t, n, r) {
                return this.on(t, e, n, r);
            },
            undelegate: function (e, t, n) {
                return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n);
            },
        }),
        (k.proxy = function (e, t) {
            var n, r, i;
            if (("string" == typeof t && ((n = e[t]), (t = e), (e = n)), m(e)))
                return (
                    (r = s.call(arguments, 2)),
                    ((i = function () {
                        return e.apply(t || this, r.concat(s.call(arguments)));
                    }).guid = e.guid = e.guid || k.guid++),
                    i
                );
        }),
        (k.holdReady = function (e) {
            e ? k.readyWait++ : k.ready(!0);
        }),
        (k.isArray = Array.isArray),
        (k.parseJSON = JSON.parse),
        (k.nodeName = A),
        (k.isFunction = m),
        (k.isWindow = x),
        (k.camelCase = V),
        (k.type = w),
        (k.now = Date.now),
        (k.isNumeric = function (e) {
            var t = k.type(e);
            return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e));
        }),
        "function" == typeof define &&
            define.amd &&
            define("jquery", [], function () {
                return k;
            });
    var Qt = C.jQuery,
        Jt = C.$;
    return (
        (k.noConflict = function (e) {
            return C.$ === k && (C.$ = Jt), e && C.jQuery === k && (C.jQuery = Qt), k;
        }),
        e || (C.jQuery = C.$ = k),
        k
    );
});

/*-------------------------------------------------------------
  3. Popper Bootstrap
---------------------------------------------------------------*/
/*
 Copyright (C) Federico Zivolo 2018
 Distributed under the MIT License (license terms are at http://opensource.org/licenses/MIT).
 */ (function (e, t) {
    "object" == typeof exports && "undefined" != typeof module ? (module.exports = t()) : "function" == typeof define && define.amd ? define(t) : (e.Popper = t());
})(this, function () {
    "use strict";
    function e(e) {
        return e && "[object Function]" === {}.toString.call(e);
    }
    function t(e, t) {
        if (1 !== e.nodeType) return [];
        var o = getComputedStyle(e, null);
        return t ? o[t] : o;
    }
    function o(e) {
        return "HTML" === e.nodeName ? e : e.parentNode || e.host;
    }
    function n(e) {
        if (!e) return document.body;
        switch (e.nodeName) {
            case "HTML":
            case "BODY":
                return e.ownerDocument.body;
            case "#document":
                return e.body;
        }
        var i = t(e),
            r = i.overflow,
            p = i.overflowX,
            s = i.overflowY;
        return /(auto|scroll|overlay)/.test(r + s + p) ? e : n(o(e));
    }
    function r(e) {
        return 11 === e ? re : 10 === e ? pe : re || pe;
    }
    function p(e) {
        if (!e) return document.documentElement;
        for (var o = r(10) ? document.body : null, n = e.offsetParent; n === o && e.nextElementSibling; ) n = (e = e.nextElementSibling).offsetParent;
        var i = n && n.nodeName;
        return i && "BODY" !== i && "HTML" !== i ? (-1 !== ["TD", "TABLE"].indexOf(n.nodeName) && "static" === t(n, "position") ? p(n) : n) : e ? e.ownerDocument.documentElement : document.documentElement;
    }
    function s(e) {
        var t = e.nodeName;
        return "BODY" !== t && ("HTML" === t || p(e.firstElementChild) === e);
    }
    function d(e) {
        return null === e.parentNode ? e : d(e.parentNode);
    }
    function a(e, t) {
        if (!e || !e.nodeType || !t || !t.nodeType) return document.documentElement;
        var o = e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING,
            n = o ? e : t,
            i = o ? t : e,
            r = document.createRange();
        r.setStart(n, 0), r.setEnd(i, 0);
        var l = r.commonAncestorContainer;
        if ((e !== l && t !== l) || n.contains(i)) return s(l) ? l : p(l);
        var f = d(e);
        return f.host ? a(f.host, t) : a(e, d(t).host);
    }
    function l(e) {
        var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "top",
            o = "top" === t ? "scrollTop" : "scrollLeft",
            n = e.nodeName;
        if ("BODY" === n || "HTML" === n) {
            var i = e.ownerDocument.documentElement,
                r = e.ownerDocument.scrollingElement || i;
            return r[o];
        }
        return e[o];
    }
    function f(e, t) {
        var o = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
            n = l(t, "top"),
            i = l(t, "left"),
            r = o ? -1 : 1;
        return (e.top += n * r), (e.bottom += n * r), (e.left += i * r), (e.right += i * r), e;
    }
    function m(e, t) {
        var o = "x" === t ? "Left" : "Top",
            n = "Left" == o ? "Right" : "Bottom";
        return parseFloat(e["border" + o + "Width"], 10) + parseFloat(e["border" + n + "Width"], 10);
    }
    function h(e, t, o, n) {
        return $(t["offset" + e], t["scroll" + e], o["client" + e], o["offset" + e], o["scroll" + e], r(10) ? o["offset" + e] + n["margin" + ("Height" === e ? "Top" : "Left")] + n["margin" + ("Height" === e ? "Bottom" : "Right")] : 0);
    }
    function c() {
        var e = document.body,
            t = document.documentElement,
            o = r(10) && getComputedStyle(t);
        return { height: h("Height", e, t, o), width: h("Width", e, t, o) };
    }
    function g(e) {
        return le({}, e, { right: e.left + e.width, bottom: e.top + e.height });
    }
    function u(e) {
        var o = {};
        try {
            if (r(10)) {
                o = e.getBoundingClientRect();
                var n = l(e, "top"),
                    i = l(e, "left");
                (o.top += n), (o.left += i), (o.bottom += n), (o.right += i);
            } else o = e.getBoundingClientRect();
        } catch (t) {}
        var p = { left: o.left, top: o.top, width: o.right - o.left, height: o.bottom - o.top },
            s = "HTML" === e.nodeName ? c() : {},
            d = s.width || e.clientWidth || p.right - p.left,
            a = s.height || e.clientHeight || p.bottom - p.top,
            f = e.offsetWidth - d,
            h = e.offsetHeight - a;
        if (f || h) {
            var u = t(e);
            (f -= m(u, "x")), (h -= m(u, "y")), (p.width -= f), (p.height -= h);
        }
        return g(p);
    }
    function b(e, o) {
        var i = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
            p = r(10),
            s = "HTML" === o.nodeName,
            d = u(e),
            a = u(o),
            l = n(e),
            m = t(o),
            h = parseFloat(m.borderTopWidth, 10),
            c = parseFloat(m.borderLeftWidth, 10);
        i && "HTML" === o.nodeName && ((a.top = $(a.top, 0)), (a.left = $(a.left, 0)));
        var b = g({ top: d.top - a.top - h, left: d.left - a.left - c, width: d.width, height: d.height });
        if (((b.marginTop = 0), (b.marginLeft = 0), !p && s)) {
            var y = parseFloat(m.marginTop, 10),
                w = parseFloat(m.marginLeft, 10);
            (b.top -= h - y), (b.bottom -= h - y), (b.left -= c - w), (b.right -= c - w), (b.marginTop = y), (b.marginLeft = w);
        }
        return (p && !i ? o.contains(l) : o === l && "BODY" !== l.nodeName) && (b = f(b, o)), b;
    }
    function y(e) {
        var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
            o = e.ownerDocument.documentElement,
            n = b(e, o),
            i = $(o.clientWidth, window.innerWidth || 0),
            r = $(o.clientHeight, window.innerHeight || 0),
            p = t ? 0 : l(o),
            s = t ? 0 : l(o, "left"),
            d = { top: p - n.top + n.marginTop, left: s - n.left + n.marginLeft, width: i, height: r };
        return g(d);
    }
    function w(e) {
        var n = e.nodeName;
        return "BODY" === n || "HTML" === n ? !1 : "fixed" === t(e, "position") || w(o(e));
    }
    function E(e) {
        if (!e || !e.parentElement || r()) return document.documentElement;
        for (var o = e.parentElement; o && "none" === t(o, "transform"); ) o = o.parentElement;
        return o || document.documentElement;
    }
    function v(e, t, i, r) {
        var p = 4 < arguments.length && void 0 !== arguments[4] && arguments[4],
            s = { top: 0, left: 0 },
            d = p ? E(e) : a(e, t);
        if ("viewport" === r) s = y(d, p);
        else {
            var l;
            "scrollParent" === r ? ((l = n(o(t))), "BODY" === l.nodeName && (l = e.ownerDocument.documentElement)) : "window" === r ? (l = e.ownerDocument.documentElement) : (l = r);
            var f = b(l, d, p);
            if ("HTML" === l.nodeName && !w(d)) {
                var m = c(),
                    h = m.height,
                    g = m.width;
                (s.top += f.top - f.marginTop), (s.bottom = h + f.top), (s.left += f.left - f.marginLeft), (s.right = g + f.left);
            } else s = f;
        }
        return (s.left += i), (s.top += i), (s.right -= i), (s.bottom -= i), s;
    }
    function x(e) {
        var t = e.width,
            o = e.height;
        return t * o;
    }
    function O(e, t, o, n, i) {
        var r = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : 0;
        if (-1 === e.indexOf("auto")) return e;
        var p = v(o, n, r, i),
            s = { top: { width: p.width, height: t.top - p.top }, right: { width: p.right - t.right, height: p.height }, bottom: { width: p.width, height: p.bottom - t.bottom }, left: { width: t.left - p.left, height: p.height } },
            d = Object.keys(s)
                .map(function (e) {
                    return le({ key: e }, s[e], { area: x(s[e]) });
                })
                .sort(function (e, t) {
                    return t.area - e.area;
                }),
            a = d.filter(function (e) {
                var t = e.width,
                    n = e.height;
                return t >= o.clientWidth && n >= o.clientHeight;
            }),
            l = 0 < a.length ? a[0].key : d[0].key,
            f = e.split("-")[1];
        return l + (f ? "-" + f : "");
    }
    function L(e, t, o) {
        var n = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null,
            i = n ? E(t) : a(t, o);
        return b(o, i, n);
    }
    function S(e) {
        var t = getComputedStyle(e),
            o = parseFloat(t.marginTop) + parseFloat(t.marginBottom),
            n = parseFloat(t.marginLeft) + parseFloat(t.marginRight),
            i = { width: e.offsetWidth + n, height: e.offsetHeight + o };
        return i;
    }
    function T(e) {
        var t = { left: "right", right: "left", bottom: "top", top: "bottom" };
        return e.replace(/left|right|bottom|top/g, function (e) {
            return t[e];
        });
    }
    function C(e, t, o) {
        o = o.split("-")[0];
        var n = S(e),
            i = { width: n.width, height: n.height },
            r = -1 !== ["right", "left"].indexOf(o),
            p = r ? "top" : "left",
            s = r ? "left" : "top",
            d = r ? "height" : "width",
            a = r ? "width" : "height";
        return (i[p] = t[p] + t[d] / 2 - n[d] / 2), (i[s] = o === s ? t[s] - n[a] : t[T(s)]), i;
    }
    function D(e, t) {
        return Array.prototype.find ? e.find(t) : e.filter(t)[0];
    }
    function N(e, t, o) {
        if (Array.prototype.findIndex)
            return e.findIndex(function (e) {
                return e[t] === o;
            });
        var n = D(e, function (e) {
            return e[t] === o;
        });
        return e.indexOf(n);
    }
    function P(t, o, n) {
        var i = void 0 === n ? t : t.slice(0, N(t, "name", n));
        return (
            i.forEach(function (t) {
                t["function"] && console.warn("`modifier.function` is deprecated, use `modifier.fn`!");
                var n = t["function"] || t.fn;
                t.enabled && e(n) && ((o.offsets.popper = g(o.offsets.popper)), (o.offsets.reference = g(o.offsets.reference)), (o = n(o, t)));
            }),
            o
        );
    }
    function k() {
        if (!this.state.isDestroyed) {
            var e = { instance: this, styles: {}, arrowStyles: {}, attributes: {}, flipped: !1, offsets: {} };
            (e.offsets.reference = L(this.state, this.popper, this.reference, this.options.positionFixed)),
                (e.placement = O(this.options.placement, e.offsets.reference, this.popper, this.reference, this.options.modifiers.flip.boundariesElement, this.options.modifiers.flip.padding)),
                (e.originalPlacement = e.placement),
                (e.positionFixed = this.options.positionFixed),
                (e.offsets.popper = C(this.popper, e.offsets.reference, e.placement)),
                (e.offsets.popper.position = this.options.positionFixed ? "fixed" : "absolute"),
                (e = P(this.modifiers, e)),
                this.state.isCreated ? this.options.onUpdate(e) : ((this.state.isCreated = !0), this.options.onCreate(e));
        }
    }
    function W(e, t) {
        return e.some(function (e) {
            var o = e.name,
                n = e.enabled;
            return n && o === t;
        });
    }
    function B(e) {
        for (var t = [!1, "ms", "Webkit", "Moz", "O"], o = e.charAt(0).toUpperCase() + e.slice(1), n = 0; n < t.length; n++) {
            var i = t[n],
                r = i ? "" + i + o : e;
            if ("undefined" != typeof document.body.style[r]) return r;
        }
        return null;
    }
    function H() {
        return (
            (this.state.isDestroyed = !0),
            W(this.modifiers, "applyStyle") &&
                (this.popper.removeAttribute("x-placement"),
                (this.popper.style.position = ""),
                (this.popper.style.top = ""),
                (this.popper.style.left = ""),
                (this.popper.style.right = ""),
                (this.popper.style.bottom = ""),
                (this.popper.style.willChange = ""),
                (this.popper.style[B("transform")] = "")),
            this.disableEventListeners(),
            this.options.removeOnDestroy && this.popper.parentNode.removeChild(this.popper),
            this
        );
    }
    function A(e) {
        var t = e.ownerDocument;
        return t ? t.defaultView : window;
    }
    function M(e, t, o, i) {
        var r = "BODY" === e.nodeName,
            p = r ? e.ownerDocument.defaultView : e;
        p.addEventListener(t, o, { passive: !0 }), r || M(n(p.parentNode), t, o, i), i.push(p);
    }
    function I(e, t, o, i) {
        (o.updateBound = i), A(e).addEventListener("resize", o.updateBound, { passive: !0 });
        var r = n(e);
        return M(r, "scroll", o.updateBound, o.scrollParents), (o.scrollElement = r), (o.eventsEnabled = !0), o;
    }
    function F() {
        this.state.eventsEnabled || (this.state = I(this.reference, this.options, this.state, this.scheduleUpdate));
    }
    function R(e, t) {
        return (
            A(e).removeEventListener("resize", t.updateBound),
            t.scrollParents.forEach(function (e) {
                e.removeEventListener("scroll", t.updateBound);
            }),
            (t.updateBound = null),
            (t.scrollParents = []),
            (t.scrollElement = null),
            (t.eventsEnabled = !1),
            t
        );
    }
    function U() {
        this.state.eventsEnabled && (cancelAnimationFrame(this.scheduleUpdate), (this.state = R(this.reference, this.state)));
    }
    function Y(e) {
        return "" !== e && !isNaN(parseFloat(e)) && isFinite(e);
    }
    function j(e, t) {
        Object.keys(t).forEach(function (o) {
            var n = "";
            -1 !== ["width", "height", "top", "right", "bottom", "left"].indexOf(o) && Y(t[o]) && (n = "px"), (e.style[o] = t[o] + n);
        });
    }
    function K(e, t) {
        Object.keys(t).forEach(function (o) {
            var n = t[o];
            !1 === n ? e.removeAttribute(o) : e.setAttribute(o, t[o]);
        });
    }
    function q(e, t, o) {
        var n = D(e, function (e) {
                var o = e.name;
                return o === t;
            }),
            i =
                !!n &&
                e.some(function (e) {
                    return e.name === o && e.enabled && e.order < n.order;
                });
        if (!i) {
            var r = "`" + t + "`";
            console.warn("`" + o + "`" + " modifier is required by " + r + " modifier in order to work, be sure to include it before " + r + "!");
        }
        return i;
    }
    function G(e) {
        return "end" === e ? "start" : "start" === e ? "end" : e;
    }
    function z(e) {
        var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
            o = me.indexOf(e),
            n = me.slice(o + 1).concat(me.slice(0, o));
        return t ? n.reverse() : n;
    }
    function V(e, t, o, n) {
        var i = e.match(/((?:\-|\+)?\d*\.?\d*)(.*)/),
            r = +i[1],
            p = i[2];
        if (!r) return e;
        if (0 === p.indexOf("%")) {
            var s;
            switch (p) {
                case "%p":
                    s = o;
                    break;
                case "%":
                case "%r":
                default:
                    s = n;
            }
            var d = g(s);
            return (d[t] / 100) * r;
        }
        if ("vh" === p || "vw" === p) {
            var a;
            return (a = "vh" === p ? $(document.documentElement.clientHeight, window.innerHeight || 0) : $(document.documentElement.clientWidth, window.innerWidth || 0)), (a / 100) * r;
        }
        return r;
    }
    function _(e, t, o, n) {
        var i = [0, 0],
            r = -1 !== ["right", "left"].indexOf(n),
            p = e.split(/(\+|\-)/).map(function (e) {
                return e.trim();
            }),
            s = p.indexOf(
                D(p, function (e) {
                    return -1 !== e.search(/,|\s/);
                })
            );
        p[s] && -1 === p[s].indexOf(",") && console.warn("Offsets separated by white space(s) are deprecated, use a comma (,) instead.");
        var d = /\s*,\s*|\s+/,
            a = -1 === s ? [p] : [p.slice(0, s).concat([p[s].split(d)[0]]), [p[s].split(d)[1]].concat(p.slice(s + 1))];
        return (
            (a = a.map(function (e, n) {
                var i = (1 === n ? !r : r) ? "height" : "width",
                    p = !1;
                return e
                    .reduce(function (e, t) {
                        return "" === e[e.length - 1] && -1 !== ["+", "-"].indexOf(t) ? ((e[e.length - 1] = t), (p = !0), e) : p ? ((e[e.length - 1] += t), (p = !1), e) : e.concat(t);
                    }, [])
                    .map(function (e) {
                        return V(e, i, t, o);
                    });
            })),
            a.forEach(function (e, t) {
                e.forEach(function (o, n) {
                    Y(o) && (i[t] += o * ("-" === e[n - 1] ? -1 : 1));
                });
            }),
            i
        );
    }
    function X(e, t) {
        var o,
            n = t.offset,
            i = e.placement,
            r = e.offsets,
            p = r.popper,
            s = r.reference,
            d = i.split("-")[0];
        return (
            (o = Y(+n) ? [+n, 0] : _(n, p, s, d)),
            "left" === d ? ((p.top += o[0]), (p.left -= o[1])) : "right" === d ? ((p.top += o[0]), (p.left += o[1])) : "top" === d ? ((p.left += o[0]), (p.top -= o[1])) : "bottom" === d && ((p.left += o[0]), (p.top += o[1])),
            (e.popper = p),
            e
        );
    }
    for (var J = Math.min, Q = Math.round, Z = Math.floor, $ = Math.max, ee = "undefined" != typeof window && "undefined" != typeof document, te = ["Edge", "Trident", "Firefox"], oe = 0, ne = 0; ne < te.length; ne += 1)
        if (ee && 0 <= navigator.userAgent.indexOf(te[ne])) {
            oe = 1;
            break;
        }
    var i = ee && window.Promise,
        ie = i
            ? function (e) {
                  var t = !1;
                  return function () {
                      t ||
                          ((t = !0),
                          window.Promise.resolve().then(function () {
                              (t = !1), e();
                          }));
                  };
              }
            : function (e) {
                  var t = !1;
                  return function () {
                      t ||
                          ((t = !0),
                          setTimeout(function () {
                              (t = !1), e();
                          }, oe));
                  };
              },
        re = ee && !!(window.MSInputMethodContext && document.documentMode),
        pe = ee && /MSIE 10/.test(navigator.userAgent),
        se = function (e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        },
        de = (function () {
            function e(e, t) {
                for (var o, n = 0; n < t.length; n++) (o = t[n]), (o.enumerable = o.enumerable || !1), (o.configurable = !0), "value" in o && (o.writable = !0), Object.defineProperty(e, o.key, o);
            }
            return function (t, o, n) {
                return o && e(t.prototype, o), n && e(t, n), t;
            };
        })(),
        ae = function (e, t, o) {
            return t in e ? Object.defineProperty(e, t, { value: o, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = o), e;
        },
        le =
            Object.assign ||
            function (e) {
                for (var t, o = 1; o < arguments.length; o++) for (var n in ((t = arguments[o]), t)) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e;
            },
        fe = ["auto-start", "auto", "auto-end", "top-start", "top", "top-end", "right-start", "right", "right-end", "bottom-end", "bottom", "bottom-start", "left-end", "left", "left-start"],
        me = fe.slice(3),
        he = { FLIP: "flip", CLOCKWISE: "clockwise", COUNTERCLOCKWISE: "counterclockwise" },
        ce = (function () {
            function t(o, n) {
                var i = this,
                    r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
                se(this, t),
                    (this.scheduleUpdate = function () {
                        return requestAnimationFrame(i.update);
                    }),
                    (this.update = ie(this.update.bind(this))),
                    (this.options = le({}, t.Defaults, r)),
                    (this.state = { isDestroyed: !1, isCreated: !1, scrollParents: [] }),
                    (this.reference = o && o.jquery ? o[0] : o),
                    (this.popper = n && n.jquery ? n[0] : n),
                    (this.options.modifiers = {}),
                    Object.keys(le({}, t.Defaults.modifiers, r.modifiers)).forEach(function (e) {
                        i.options.modifiers[e] = le({}, t.Defaults.modifiers[e] || {}, r.modifiers ? r.modifiers[e] : {});
                    }),
                    (this.modifiers = Object.keys(this.options.modifiers)
                        .map(function (e) {
                            return le({ name: e }, i.options.modifiers[e]);
                        })
                        .sort(function (e, t) {
                            return e.order - t.order;
                        })),
                    this.modifiers.forEach(function (t) {
                        t.enabled && e(t.onLoad) && t.onLoad(i.reference, i.popper, i.options, t, i.state);
                    }),
                    this.update();
                var p = this.options.eventsEnabled;
                p && this.enableEventListeners(), (this.state.eventsEnabled = p);
            }
            return (
                de(t, [
                    {
                        key: "update",
                        value: function () {
                            return k.call(this);
                        },
                    },
                    {
                        key: "destroy",
                        value: function () {
                            return H.call(this);
                        },
                    },
                    {
                        key: "enableEventListeners",
                        value: function () {
                            return F.call(this);
                        },
                    },
                    {
                        key: "disableEventListeners",
                        value: function () {
                            return U.call(this);
                        },
                    },
                ]),
                t
            );
        })();
    return (
        (ce.Utils = ("undefined" == typeof window ? global : window).PopperUtils),
        (ce.placements = fe),
        (ce.Defaults = {
            placement: "bottom",
            positionFixed: !1,
            eventsEnabled: !0,
            removeOnDestroy: !1,
            onCreate: function () {},
            onUpdate: function () {},
            modifiers: {
                shift: {
                    order: 100,
                    enabled: !0,
                    fn: function (e) {
                        var t = e.placement,
                            o = t.split("-")[0],
                            n = t.split("-")[1];
                        if (n) {
                            var i = e.offsets,
                                r = i.reference,
                                p = i.popper,
                                s = -1 !== ["bottom", "top"].indexOf(o),
                                d = s ? "left" : "top",
                                a = s ? "width" : "height",
                                l = { start: ae({}, d, r[d]), end: ae({}, d, r[d] + r[a] - p[a]) };
                            e.offsets.popper = le({}, p, l[n]);
                        }
                        return e;
                    },
                },
                offset: { order: 200, enabled: !0, fn: X, offset: 0 },
                preventOverflow: {
                    order: 300,
                    enabled: !0,
                    fn: function (e, t) {
                        var o = t.boundariesElement || p(e.instance.popper);
                        e.instance.reference === o && (o = p(o));
                        var n = B("transform"),
                            i = e.instance.popper.style,
                            r = i.top,
                            s = i.left,
                            d = i[n];
                        (i.top = ""), (i.left = ""), (i[n] = "");
                        var a = v(e.instance.popper, e.instance.reference, t.padding, o, e.positionFixed);
                        (i.top = r), (i.left = s), (i[n] = d), (t.boundaries = a);
                        var l = t.priority,
                            f = e.offsets.popper,
                            m = {
                                primary: function (e) {
                                    var o = f[e];
                                    return f[e] < a[e] && !t.escapeWithReference && (o = $(f[e], a[e])), ae({}, e, o);
                                },
                                secondary: function (e) {
                                    var o = "right" === e ? "left" : "top",
                                        n = f[o];
                                    return f[e] > a[e] && !t.escapeWithReference && (n = J(f[o], a[e] - ("right" === e ? f.width : f.height))), ae({}, o, n);
                                },
                            };
                        return (
                            l.forEach(function (e) {
                                var t = -1 === ["left", "top"].indexOf(e) ? "secondary" : "primary";
                                f = le({}, f, m[t](e));
                            }),
                            (e.offsets.popper = f),
                            e
                        );
                    },
                    priority: ["left", "right", "top", "bottom"],
                    padding: 5,
                    boundariesElement: "scrollParent",
                },
                keepTogether: {
                    order: 400,
                    enabled: !0,
                    fn: function (e) {
                        var t = e.offsets,
                            o = t.popper,
                            n = t.reference,
                            i = e.placement.split("-")[0],
                            r = Z,
                            p = -1 !== ["top", "bottom"].indexOf(i),
                            s = p ? "right" : "bottom",
                            d = p ? "left" : "top",
                            a = p ? "width" : "height";
                        return o[s] < r(n[d]) && (e.offsets.popper[d] = r(n[d]) - o[a]), o[d] > r(n[s]) && (e.offsets.popper[d] = r(n[s])), e;
                    },
                },
                arrow: {
                    order: 500,
                    enabled: !0,
                    fn: function (e, o) {
                        var n;
                        if (!q(e.instance.modifiers, "arrow", "keepTogether")) return e;
                        var i = o.element;
                        if ("string" == typeof i) {
                            if (((i = e.instance.popper.querySelector(i)), !i)) return e;
                        } else if (!e.instance.popper.contains(i)) return console.warn("WARNING: `arrow.element` must be child of its popper element!"), e;
                        var r = e.placement.split("-")[0],
                            p = e.offsets,
                            s = p.popper,
                            d = p.reference,
                            a = -1 !== ["left", "right"].indexOf(r),
                            l = a ? "height" : "width",
                            f = a ? "Top" : "Left",
                            m = f.toLowerCase(),
                            h = a ? "left" : "top",
                            c = a ? "bottom" : "right",
                            u = S(i)[l];
                        d[c] - u < s[m] && (e.offsets.popper[m] -= s[m] - (d[c] - u)), d[m] + u > s[c] && (e.offsets.popper[m] += d[m] + u - s[c]), (e.offsets.popper = g(e.offsets.popper));
                        var b = d[m] + d[l] / 2 - u / 2,
                            y = t(e.instance.popper),
                            w = parseFloat(y["margin" + f], 10),
                            E = parseFloat(y["border" + f + "Width"], 10),
                            v = b - e.offsets.popper[m] - w - E;
                        return (v = $(J(s[l] - u, v), 0)), (e.arrowElement = i), (e.offsets.arrow = ((n = {}), ae(n, m, Q(v)), ae(n, h, ""), n)), e;
                    },
                    element: "[x-arrow]",
                },
                flip: {
                    order: 600,
                    enabled: !0,
                    fn: function (e, t) {
                        if (W(e.instance.modifiers, "inner")) return e;
                        if (e.flipped && e.placement === e.originalPlacement) return e;
                        var o = v(e.instance.popper, e.instance.reference, t.padding, t.boundariesElement, e.positionFixed),
                            n = e.placement.split("-")[0],
                            i = T(n),
                            r = e.placement.split("-")[1] || "",
                            p = [];
                        switch (t.behavior) {
                            case he.FLIP:
                                p = [n, i];
                                break;
                            case he.CLOCKWISE:
                                p = z(n);
                                break;
                            case he.COUNTERCLOCKWISE:
                                p = z(n, !0);
                                break;
                            default:
                                p = t.behavior;
                        }
                        return (
                            p.forEach(function (s, d) {
                                if (n !== s || p.length === d + 1) return e;
                                (n = e.placement.split("-")[0]), (i = T(n));
                                var a = e.offsets.popper,
                                    l = e.offsets.reference,
                                    f = Z,
                                    m = ("left" === n && f(a.right) > f(l.left)) || ("right" === n && f(a.left) < f(l.right)) || ("top" === n && f(a.bottom) > f(l.top)) || ("bottom" === n && f(a.top) < f(l.bottom)),
                                    h = f(a.left) < f(o.left),
                                    c = f(a.right) > f(o.right),
                                    g = f(a.top) < f(o.top),
                                    u = f(a.bottom) > f(o.bottom),
                                    b = ("left" === n && h) || ("right" === n && c) || ("top" === n && g) || ("bottom" === n && u),
                                    y = -1 !== ["top", "bottom"].indexOf(n),
                                    w = !!t.flipVariations && ((y && "start" === r && h) || (y && "end" === r && c) || (!y && "start" === r && g) || (!y && "end" === r && u));
                                (m || b || w) &&
                                    ((e.flipped = !0),
                                    (m || b) && (n = p[d + 1]),
                                    w && (r = G(r)),
                                    (e.placement = n + (r ? "-" + r : "")),
                                    (e.offsets.popper = le({}, e.offsets.popper, C(e.instance.popper, e.offsets.reference, e.placement))),
                                    (e = P(e.instance.modifiers, e, "flip")));
                            }),
                            e
                        );
                    },
                    behavior: "flip",
                    padding: 5,
                    boundariesElement: "viewport",
                },
                inner: {
                    order: 700,
                    enabled: !1,
                    fn: function (e) {
                        var t = e.placement,
                            o = t.split("-")[0],
                            n = e.offsets,
                            i = n.popper,
                            r = n.reference,
                            p = -1 !== ["left", "right"].indexOf(o),
                            s = -1 === ["top", "left"].indexOf(o);
                        return (i[p ? "left" : "top"] = r[o] - (s ? i[p ? "width" : "height"] : 0)), (e.placement = T(t)), (e.offsets.popper = g(i)), e;
                    },
                },
                hide: {
                    order: 800,
                    enabled: !0,
                    fn: function (e) {
                        if (!q(e.instance.modifiers, "hide", "preventOverflow")) return e;
                        var t = e.offsets.reference,
                            o = D(e.instance.modifiers, function (e) {
                                return "preventOverflow" === e.name;
                            }).boundaries;
                        if (t.bottom < o.top || t.left > o.right || t.top > o.bottom || t.right < o.left) {
                            if (!0 === e.hide) return e;
                            (e.hide = !0), (e.attributes["x-out-of-boundaries"] = "");
                        } else {
                            if (!1 === e.hide) return e;
                            (e.hide = !1), (e.attributes["x-out-of-boundaries"] = !1);
                        }
                        return e;
                    },
                },
                computeStyle: {
                    order: 850,
                    enabled: !0,
                    fn: function (e, t) {
                        var o = t.x,
                            n = t.y,
                            i = e.offsets.popper,
                            r = D(e.instance.modifiers, function (e) {
                                return "applyStyle" === e.name;
                            }).gpuAcceleration;
                        void 0 !== r && console.warn("WARNING: `gpuAcceleration` option moved to `computeStyle` modifier and will not be supported in future versions of Popper.js!");
                        var s,
                            d,
                            a = void 0 === r ? t.gpuAcceleration : r,
                            l = p(e.instance.popper),
                            f = u(l),
                            m = { position: i.position },
                            h = { left: Z(i.left), top: Q(i.top), bottom: Q(i.bottom), right: Z(i.right) },
                            c = "bottom" === o ? "top" : "bottom",
                            g = "right" === n ? "left" : "right",
                            b = B("transform");
                        if (((d = "bottom" == c ? -f.height + h.bottom : h.top), (s = "right" == g ? -f.width + h.right : h.left), a && b))
                            (m[b] = "translate3d(" + s + "px, " + d + "px, 0)"), (m[c] = 0), (m[g] = 0), (m.willChange = "transform");
                        else {
                            var y = "bottom" == c ? -1 : 1,
                                w = "right" == g ? -1 : 1;
                            (m[c] = d * y), (m[g] = s * w), (m.willChange = c + ", " + g);
                        }
                        var E = { "x-placement": e.placement };
                        return (e.attributes = le({}, E, e.attributes)), (e.styles = le({}, m, e.styles)), (e.arrowStyles = le({}, e.offsets.arrow, e.arrowStyles)), e;
                    },
                    gpuAcceleration: !0,
                    x: "bottom",
                    y: "right",
                },
                applyStyle: {
                    order: 900,
                    enabled: !0,
                    fn: function (e) {
                        return j(e.instance.popper, e.styles), K(e.instance.popper, e.attributes), e.arrowElement && Object.keys(e.arrowStyles).length && j(e.arrowElement, e.arrowStyles), e;
                    },
                    onLoad: function (e, t, o, n, i) {
                        var r = L(i, t, e, o.positionFixed),
                            p = O(o.placement, r, t, e, o.modifiers.flip.boundariesElement, o.modifiers.flip.padding);
                        return t.setAttribute("x-placement", p), j(t, { position: o.positionFixed ? "fixed" : "absolute" }), o;
                    },
                    gpuAcceleration: void 0,
                },
            },
        }),
        ce
    );
});
//# sourceMappingURL=popper.min.js.map

/*-------------------------------------------------------------
  4. Bootstrap v4.3.1
---------------------------------------------------------------*/
/*!
 * Bootstrap v4.3.1 (https://getbootstrap.com/)
 * Copyright 2011-2019 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
!(function (t, e) {
    "object" == typeof exports && "undefined" != typeof module
        ? e(exports, require("jquery"), require("popper.js"))
        : "function" == typeof define && define.amd
        ? define(["exports", "jquery", "popper.js"], e)
        : e(((t = t || self).bootstrap = {}), t.jQuery, t.Popper);
})(this, function (t, g, u) {
    "use strict";
    function i(t, e) {
        for (var n = 0; n < e.length; n++) {
            var i = e[n];
            (i.enumerable = i.enumerable || !1), (i.configurable = !0), "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i);
        }
    }
    function s(t, e, n) {
        return e && i(t.prototype, e), n && i(t, n), t;
    }
    function l(o) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {},
                e = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols &&
                (e = e.concat(
                    Object.getOwnPropertySymbols(r).filter(function (t) {
                        return Object.getOwnPropertyDescriptor(r, t).enumerable;
                    })
                )),
                e.forEach(function (t) {
                    var e, n, i;
                    (e = o), (i = r[(n = t)]), n in e ? Object.defineProperty(e, n, { value: i, enumerable: !0, configurable: !0, writable: !0 }) : (e[n] = i);
                });
        }
        return o;
    }
    (g = g && g.hasOwnProperty("default") ? g.default : g), (u = u && u.hasOwnProperty("default") ? u.default : u);
    var e = "transitionend";
    function n(t) {
        var e = this,
            n = !1;
        return (
            g(this).one(_.TRANSITION_END, function () {
                n = !0;
            }),
            setTimeout(function () {
                n || _.triggerTransitionEnd(e);
            }, t),
            this
        );
    }
    var _ = {
        TRANSITION_END: "bsTransitionEnd",
        getUID: function (t) {
            for (; (t += ~~(1e6 * Math.random())), document.getElementById(t); );
            return t;
        },
        getSelectorFromElement: function (t) {
            var e = t.getAttribute("data-target");
            if (!e || "#" === e) {
                var n = t.getAttribute("href");
                e = n && "#" !== n ? n.trim() : "";
            }
            try {
                return document.querySelector(e) ? e : null;
            } catch (t) {
                return null;
            }
        },
        getTransitionDurationFromElement: function (t) {
            if (!t) return 0;
            var e = g(t).css("transition-duration"),
                n = g(t).css("transition-delay"),
                i = parseFloat(e),
                o = parseFloat(n);
            return i || o ? ((e = e.split(",")[0]), (n = n.split(",")[0]), 1e3 * (parseFloat(e) + parseFloat(n))) : 0;
        },
        reflow: function (t) {
            return t.offsetHeight;
        },
        triggerTransitionEnd: function (t) {
            g(t).trigger(e);
        },
        supportsTransitionEnd: function () {
            return Boolean(e);
        },
        isElement: function (t) {
            return (t[0] || t).nodeType;
        },
        typeCheckConfig: function (t, e, n) {
            for (var i in n)
                if (Object.prototype.hasOwnProperty.call(n, i)) {
                    var o = n[i],
                        r = e[i],
                        s =
                            r && _.isElement(r)
                                ? "element"
                                : ((a = r),
                                  {}.toString
                                      .call(a)
                                      .match(/\s([a-z]+)/i)[1]
                                      .toLowerCase());
                    if (!new RegExp(o).test(s)) throw new Error(t.toUpperCase() + ': Option "' + i + '" provided type "' + s + '" but expected type "' + o + '".');
                }
            var a;
        },
        findShadowRoot: function (t) {
            if (!document.documentElement.attachShadow) return null;
            if ("function" != typeof t.getRootNode) return t instanceof ShadowRoot ? t : t.parentNode ? _.findShadowRoot(t.parentNode) : null;
            var e = t.getRootNode();
            return e instanceof ShadowRoot ? e : null;
        },
    };
    (g.fn.emulateTransitionEnd = n),
        (g.event.special[_.TRANSITION_END] = {
            bindType: e,
            delegateType: e,
            handle: function (t) {
                if (g(t.target).is(this)) return t.handleObj.handler.apply(this, arguments);
            },
        });
    var o = "alert",
        r = "bs.alert",
        a = "." + r,
        c = g.fn[o],
        h = { CLOSE: "close" + a, CLOSED: "closed" + a, CLICK_DATA_API: "click" + a + ".data-api" },
        f = "alert",
        d = "fade",
        m = "show",
        p = (function () {
            function i(t) {
                this._element = t;
            }
            var t = i.prototype;
            return (
                (t.close = function (t) {
                    var e = this._element;
                    t && (e = this._getRootElement(t)), this._triggerCloseEvent(e).isDefaultPrevented() || this._removeElement(e);
                }),
                (t.dispose = function () {
                    g.removeData(this._element, r), (this._element = null);
                }),
                (t._getRootElement = function (t) {
                    var e = _.getSelectorFromElement(t),
                        n = !1;
                    return e && (n = document.querySelector(e)), n || (n = g(t).closest("." + f)[0]), n;
                }),
                (t._triggerCloseEvent = function (t) {
                    var e = g.Event(h.CLOSE);
                    return g(t).trigger(e), e;
                }),
                (t._removeElement = function (e) {
                    var n = this;
                    if ((g(e).removeClass(m), g(e).hasClass(d))) {
                        var t = _.getTransitionDurationFromElement(e);
                        g(e)
                            .one(_.TRANSITION_END, function (t) {
                                return n._destroyElement(e, t);
                            })
                            .emulateTransitionEnd(t);
                    } else this._destroyElement(e);
                }),
                (t._destroyElement = function (t) {
                    g(t).detach().trigger(h.CLOSED).remove();
                }),
                (i._jQueryInterface = function (n) {
                    return this.each(function () {
                        var t = g(this),
                            e = t.data(r);
                        e || ((e = new i(this)), t.data(r, e)), "close" === n && e[n](this);
                    });
                }),
                (i._handleDismiss = function (e) {
                    return function (t) {
                        t && t.preventDefault(), e.close(this);
                    };
                }),
                s(i, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                ]),
                i
            );
        })();
    g(document).on(h.CLICK_DATA_API, '[data-dismiss="alert"]', p._handleDismiss(new p())),
        (g.fn[o] = p._jQueryInterface),
        (g.fn[o].Constructor = p),
        (g.fn[o].noConflict = function () {
            return (g.fn[o] = c), p._jQueryInterface;
        });
    var v = "button",
        y = "bs.button",
        E = "." + y,
        C = ".data-api",
        T = g.fn[v],
        S = "active",
        b = "btn",
        I = "focus",
        D = '[data-toggle^="button"]',
        w = '[data-toggle="buttons"]',
        A = 'input:not([type="hidden"])',
        N = ".active",
        O = ".btn",
        k = { CLICK_DATA_API: "click" + E + C, FOCUS_BLUR_DATA_API: "focus" + E + C + " blur" + E + C },
        P = (function () {
            function n(t) {
                this._element = t;
            }
            var t = n.prototype;
            return (
                (t.toggle = function () {
                    var t = !0,
                        e = !0,
                        n = g(this._element).closest(w)[0];
                    if (n) {
                        var i = this._element.querySelector(A);
                        if (i) {
                            if ("radio" === i.type)
                                if (i.checked && this._element.classList.contains(S)) t = !1;
                                else {
                                    var o = n.querySelector(N);
                                    o && g(o).removeClass(S);
                                }
                            if (t) {
                                if (i.hasAttribute("disabled") || n.hasAttribute("disabled") || i.classList.contains("disabled") || n.classList.contains("disabled")) return;
                                (i.checked = !this._element.classList.contains(S)), g(i).trigger("change");
                            }
                            i.focus(), (e = !1);
                        }
                    }
                    e && this._element.setAttribute("aria-pressed", !this._element.classList.contains(S)), t && g(this._element).toggleClass(S);
                }),
                (t.dispose = function () {
                    g.removeData(this._element, y), (this._element = null);
                }),
                (n._jQueryInterface = function (e) {
                    return this.each(function () {
                        var t = g(this).data(y);
                        t || ((t = new n(this)), g(this).data(y, t)), "toggle" === e && t[e]();
                    });
                }),
                s(n, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                ]),
                n
            );
        })();
    g(document)
        .on(k.CLICK_DATA_API, D, function (t) {
            t.preventDefault();
            var e = t.target;
            g(e).hasClass(b) || (e = g(e).closest(O)), P._jQueryInterface.call(g(e), "toggle");
        })
        .on(k.FOCUS_BLUR_DATA_API, D, function (t) {
            var e = g(t.target).closest(O)[0];
            g(e).toggleClass(I, /^focus(in)?$/.test(t.type));
        }),
        (g.fn[v] = P._jQueryInterface),
        (g.fn[v].Constructor = P),
        (g.fn[v].noConflict = function () {
            return (g.fn[v] = T), P._jQueryInterface;
        });
    var L = "carousel",
        j = "bs.carousel",
        H = "." + j,
        R = ".data-api",
        x = g.fn[L],
        F = { interval: 5e3, keyboard: !0, slide: !1, pause: "hover", wrap: !0, touch: !0 },
        U = { interval: "(number|boolean)", keyboard: "boolean", slide: "(boolean|string)", pause: "(string|boolean)", wrap: "boolean", touch: "boolean" },
        W = "next",
        q = "prev",
        M = "left",
        K = "right",
        Q = {
            SLIDE: "slide" + H,
            SLID: "slid" + H,
            KEYDOWN: "keydown" + H,
            MOUSEENTER: "mouseenter" + H,
            MOUSELEAVE: "mouseleave" + H,
            TOUCHSTART: "touchstart" + H,
            TOUCHMOVE: "touchmove" + H,
            TOUCHEND: "touchend" + H,
            POINTERDOWN: "pointerdown" + H,
            POINTERUP: "pointerup" + H,
            DRAG_START: "dragstart" + H,
            LOAD_DATA_API: "load" + H + R,
            CLICK_DATA_API: "click" + H + R,
        },
        B = "carousel",
        V = "active",
        Y = "slide",
        z = "carousel-item-right",
        X = "carousel-item-left",
        $ = "carousel-item-next",
        G = "carousel-item-prev",
        J = "pointer-event",
        Z = ".active",
        tt = ".active.carousel-item",
        et = ".carousel-item",
        nt = ".carousel-item img",
        it = ".carousel-item-next, .carousel-item-prev",
        ot = ".carousel-indicators",
        rt = "[data-slide], [data-slide-to]",
        st = '[data-ride="carousel"]',
        at = { TOUCH: "touch", PEN: "pen" },
        lt = (function () {
            function r(t, e) {
                (this._items = null),
                    (this._interval = null),
                    (this._activeElement = null),
                    (this._isPaused = !1),
                    (this._isSliding = !1),
                    (this.touchTimeout = null),
                    (this.touchStartX = 0),
                    (this.touchDeltaX = 0),
                    (this._config = this._getConfig(e)),
                    (this._element = t),
                    (this._indicatorsElement = this._element.querySelector(ot)),
                    (this._touchSupported = "ontouchstart" in document.documentElement || 0 < navigator.maxTouchPoints),
                    (this._pointerEvent = Boolean(window.PointerEvent || window.MSPointerEvent)),
                    this._addEventListeners();
            }
            var t = r.prototype;
            return (
                (t.next = function () {
                    this._isSliding || this._slide(W);
                }),
                (t.nextWhenVisible = function () {
                    !document.hidden && g(this._element).is(":visible") && "hidden" !== g(this._element).css("visibility") && this.next();
                }),
                (t.prev = function () {
                    this._isSliding || this._slide(q);
                }),
                (t.pause = function (t) {
                    t || (this._isPaused = !0), this._element.querySelector(it) && (_.triggerTransitionEnd(this._element), this.cycle(!0)), clearInterval(this._interval), (this._interval = null);
                }),
                (t.cycle = function (t) {
                    t || (this._isPaused = !1),
                        this._interval && (clearInterval(this._interval), (this._interval = null)),
                        this._config.interval && !this._isPaused && (this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval));
                }),
                (t.to = function (t) {
                    var e = this;
                    this._activeElement = this._element.querySelector(tt);
                    var n = this._getItemIndex(this._activeElement);
                    if (!(t > this._items.length - 1 || t < 0))
                        if (this._isSliding)
                            g(this._element).one(Q.SLID, function () {
                                return e.to(t);
                            });
                        else {
                            if (n === t) return this.pause(), void this.cycle();
                            var i = n < t ? W : q;
                            this._slide(i, this._items[t]);
                        }
                }),
                (t.dispose = function () {
                    g(this._element).off(H),
                        g.removeData(this._element, j),
                        (this._items = null),
                        (this._config = null),
                        (this._element = null),
                        (this._interval = null),
                        (this._isPaused = null),
                        (this._isSliding = null),
                        (this._activeElement = null),
                        (this._indicatorsElement = null);
                }),
                (t._getConfig = function (t) {
                    return (t = l({}, F, t)), _.typeCheckConfig(L, t, U), t;
                }),
                (t._handleSwipe = function () {
                    var t = Math.abs(this.touchDeltaX);
                    if (!(t <= 40)) {
                        var e = t / this.touchDeltaX;
                        0 < e && this.prev(), e < 0 && this.next();
                    }
                }),
                (t._addEventListeners = function () {
                    var e = this;
                    this._config.keyboard &&
                        g(this._element).on(Q.KEYDOWN, function (t) {
                            return e._keydown(t);
                        }),
                        "hover" === this._config.pause &&
                            g(this._element)
                                .on(Q.MOUSEENTER, function (t) {
                                    return e.pause(t);
                                })
                                .on(Q.MOUSELEAVE, function (t) {
                                    return e.cycle(t);
                                }),
                        this._config.touch && this._addTouchEventListeners();
                }),
                (t._addTouchEventListeners = function () {
                    var n = this;
                    if (this._touchSupported) {
                        var e = function (t) {
                                n._pointerEvent && at[t.originalEvent.pointerType.toUpperCase()] ? (n.touchStartX = t.originalEvent.clientX) : n._pointerEvent || (n.touchStartX = t.originalEvent.touches[0].clientX);
                            },
                            i = function (t) {
                                n._pointerEvent && at[t.originalEvent.pointerType.toUpperCase()] && (n.touchDeltaX = t.originalEvent.clientX - n.touchStartX),
                                    n._handleSwipe(),
                                    "hover" === n._config.pause &&
                                        (n.pause(),
                                        n.touchTimeout && clearTimeout(n.touchTimeout),
                                        (n.touchTimeout = setTimeout(function (t) {
                                            return n.cycle(t);
                                        }, 500 + n._config.interval)));
                            };
                        g(this._element.querySelectorAll(nt)).on(Q.DRAG_START, function (t) {
                            return t.preventDefault();
                        }),
                            this._pointerEvent
                                ? (g(this._element).on(Q.POINTERDOWN, function (t) {
                                      return e(t);
                                  }),
                                  g(this._element).on(Q.POINTERUP, function (t) {
                                      return i(t);
                                  }),
                                  this._element.classList.add(J))
                                : (g(this._element).on(Q.TOUCHSTART, function (t) {
                                      return e(t);
                                  }),
                                  g(this._element).on(Q.TOUCHMOVE, function (t) {
                                      var e;
                                      (e = t).originalEvent.touches && 1 < e.originalEvent.touches.length ? (n.touchDeltaX = 0) : (n.touchDeltaX = e.originalEvent.touches[0].clientX - n.touchStartX);
                                  }),
                                  g(this._element).on(Q.TOUCHEND, function (t) {
                                      return i(t);
                                  }));
                    }
                }),
                (t._keydown = function (t) {
                    if (!/input|textarea/i.test(t.target.tagName))
                        switch (t.which) {
                            case 37:
                                t.preventDefault(), this.prev();
                                break;
                            case 39:
                                t.preventDefault(), this.next();
                        }
                }),
                (t._getItemIndex = function (t) {
                    return (this._items = t && t.parentNode ? [].slice.call(t.parentNode.querySelectorAll(et)) : []), this._items.indexOf(t);
                }),
                (t._getItemByDirection = function (t, e) {
                    var n = t === W,
                        i = t === q,
                        o = this._getItemIndex(e),
                        r = this._items.length - 1;
                    if (((i && 0 === o) || (n && o === r)) && !this._config.wrap) return e;
                    var s = (o + (t === q ? -1 : 1)) % this._items.length;
                    return -1 === s ? this._items[this._items.length - 1] : this._items[s];
                }),
                (t._triggerSlideEvent = function (t, e) {
                    var n = this._getItemIndex(t),
                        i = this._getItemIndex(this._element.querySelector(tt)),
                        o = g.Event(Q.SLIDE, { relatedTarget: t, direction: e, from: i, to: n });
                    return g(this._element).trigger(o), o;
                }),
                (t._setActiveIndicatorElement = function (t) {
                    if (this._indicatorsElement) {
                        var e = [].slice.call(this._indicatorsElement.querySelectorAll(Z));
                        g(e).removeClass(V);
                        var n = this._indicatorsElement.children[this._getItemIndex(t)];
                        n && g(n).addClass(V);
                    }
                }),
                (t._slide = function (t, e) {
                    var n,
                        i,
                        o,
                        r = this,
                        s = this._element.querySelector(tt),
                        a = this._getItemIndex(s),
                        l = e || (s && this._getItemByDirection(t, s)),
                        c = this._getItemIndex(l),
                        h = Boolean(this._interval);
                    if (((o = t === W ? ((n = X), (i = $), M) : ((n = z), (i = G), K)), l && g(l).hasClass(V))) this._isSliding = !1;
                    else if (!this._triggerSlideEvent(l, o).isDefaultPrevented() && s && l) {
                        (this._isSliding = !0), h && this.pause(), this._setActiveIndicatorElement(l);
                        var u = g.Event(Q.SLID, { relatedTarget: l, direction: o, from: a, to: c });
                        if (g(this._element).hasClass(Y)) {
                            g(l).addClass(i), _.reflow(l), g(s).addClass(n), g(l).addClass(n);
                            var f = parseInt(l.getAttribute("data-interval"), 10);
                            this._config.interval = f ? ((this._config.defaultInterval = this._config.defaultInterval || this._config.interval), f) : this._config.defaultInterval || this._config.interval;
                            var d = _.getTransitionDurationFromElement(s);
                            g(s)
                                .one(_.TRANSITION_END, function () {
                                    g(l)
                                        .removeClass(n + " " + i)
                                        .addClass(V),
                                        g(s).removeClass(V + " " + i + " " + n),
                                        (r._isSliding = !1),
                                        setTimeout(function () {
                                            return g(r._element).trigger(u);
                                        }, 0);
                                })
                                .emulateTransitionEnd(d);
                        } else g(s).removeClass(V), g(l).addClass(V), (this._isSliding = !1), g(this._element).trigger(u);
                        h && this.cycle();
                    }
                }),
                (r._jQueryInterface = function (i) {
                    return this.each(function () {
                        var t = g(this).data(j),
                            e = l({}, F, g(this).data());
                        "object" == typeof i && (e = l({}, e, i));
                        var n = "string" == typeof i ? i : e.slide;
                        if ((t || ((t = new r(this, e)), g(this).data(j, t)), "number" == typeof i)) t.to(i);
                        else if ("string" == typeof n) {
                            if ("undefined" == typeof t[n]) throw new TypeError('No method named "' + n + '"');
                            t[n]();
                        } else e.interval && e.ride && (t.pause(), t.cycle());
                    });
                }),
                (r._dataApiClickHandler = function (t) {
                    var e = _.getSelectorFromElement(this);
                    if (e) {
                        var n = g(e)[0];
                        if (n && g(n).hasClass(B)) {
                            var i = l({}, g(n).data(), g(this).data()),
                                o = this.getAttribute("data-slide-to");
                            o && (i.interval = !1), r._jQueryInterface.call(g(n), i), o && g(n).data(j).to(o), t.preventDefault();
                        }
                    }
                }),
                s(r, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return F;
                        },
                    },
                ]),
                r
            );
        })();
    g(document).on(Q.CLICK_DATA_API, rt, lt._dataApiClickHandler),
        g(window).on(Q.LOAD_DATA_API, function () {
            for (var t = [].slice.call(document.querySelectorAll(st)), e = 0, n = t.length; e < n; e++) {
                var i = g(t[e]);
                lt._jQueryInterface.call(i, i.data());
            }
        }),
        (g.fn[L] = lt._jQueryInterface),
        (g.fn[L].Constructor = lt),
        (g.fn[L].noConflict = function () {
            return (g.fn[L] = x), lt._jQueryInterface;
        });
    var ct = "collapse",
        ht = "bs.collapse",
        ut = "." + ht,
        ft = g.fn[ct],
        dt = { toggle: !0, parent: "" },
        gt = { toggle: "boolean", parent: "(string|element)" },
        _t = { SHOW: "show" + ut, SHOWN: "shown" + ut, HIDE: "hide" + ut, HIDDEN: "hidden" + ut, CLICK_DATA_API: "click" + ut + ".data-api" },
        mt = "show",
        pt = "collapse",
        vt = "collapsing",
        yt = "collapsed",
        Et = "width",
        Ct = "height",
        Tt = ".show, .collapsing",
        St = '[data-toggle="collapse"]',
        bt = (function () {
            function a(e, t) {
                (this._isTransitioning = !1),
                    (this._element = e),
                    (this._config = this._getConfig(t)),
                    (this._triggerArray = [].slice.call(document.querySelectorAll('[data-toggle="collapse"][href="#' + e.id + '"],[data-toggle="collapse"][data-target="#' + e.id + '"]')));
                for (var n = [].slice.call(document.querySelectorAll(St)), i = 0, o = n.length; i < o; i++) {
                    var r = n[i],
                        s = _.getSelectorFromElement(r),
                        a = [].slice.call(document.querySelectorAll(s)).filter(function (t) {
                            return t === e;
                        });
                    null !== s && 0 < a.length && ((this._selector = s), this._triggerArray.push(r));
                }
                (this._parent = this._config.parent ? this._getParent() : null), this._config.parent || this._addAriaAndCollapsedClass(this._element, this._triggerArray), this._config.toggle && this.toggle();
            }
            var t = a.prototype;
            return (
                (t.toggle = function () {
                    g(this._element).hasClass(mt) ? this.hide() : this.show();
                }),
                (t.show = function () {
                    var t,
                        e,
                        n = this;
                    if (
                        !this._isTransitioning &&
                        !g(this._element).hasClass(mt) &&
                        (this._parent &&
                            0 ===
                                (t = [].slice.call(this._parent.querySelectorAll(Tt)).filter(function (t) {
                                    return "string" == typeof n._config.parent ? t.getAttribute("data-parent") === n._config.parent : t.classList.contains(pt);
                                })).length &&
                            (t = null),
                        !(t && (e = g(t).not(this._selector).data(ht)) && e._isTransitioning))
                    ) {
                        var i = g.Event(_t.SHOW);
                        if ((g(this._element).trigger(i), !i.isDefaultPrevented())) {
                            t && (a._jQueryInterface.call(g(t).not(this._selector), "hide"), e || g(t).data(ht, null));
                            var o = this._getDimension();
                            g(this._element).removeClass(pt).addClass(vt), (this._element.style[o] = 0), this._triggerArray.length && g(this._triggerArray).removeClass(yt).attr("aria-expanded", !0), this.setTransitioning(!0);
                            var r = "scroll" + (o[0].toUpperCase() + o.slice(1)),
                                s = _.getTransitionDurationFromElement(this._element);
                            g(this._element)
                                .one(_.TRANSITION_END, function () {
                                    g(n._element).removeClass(vt).addClass(pt).addClass(mt), (n._element.style[o] = ""), n.setTransitioning(!1), g(n._element).trigger(_t.SHOWN);
                                })
                                .emulateTransitionEnd(s),
                                (this._element.style[o] = this._element[r] + "px");
                        }
                    }
                }),
                (t.hide = function () {
                    var t = this;
                    if (!this._isTransitioning && g(this._element).hasClass(mt)) {
                        var e = g.Event(_t.HIDE);
                        if ((g(this._element).trigger(e), !e.isDefaultPrevented())) {
                            var n = this._getDimension();
                            (this._element.style[n] = this._element.getBoundingClientRect()[n] + "px"), _.reflow(this._element), g(this._element).addClass(vt).removeClass(pt).removeClass(mt);
                            var i = this._triggerArray.length;
                            if (0 < i)
                                for (var o = 0; o < i; o++) {
                                    var r = this._triggerArray[o],
                                        s = _.getSelectorFromElement(r);
                                    if (null !== s) g([].slice.call(document.querySelectorAll(s))).hasClass(mt) || g(r).addClass(yt).attr("aria-expanded", !1);
                                }
                            this.setTransitioning(!0);
                            this._element.style[n] = "";
                            var a = _.getTransitionDurationFromElement(this._element);
                            g(this._element)
                                .one(_.TRANSITION_END, function () {
                                    t.setTransitioning(!1), g(t._element).removeClass(vt).addClass(pt).trigger(_t.HIDDEN);
                                })
                                .emulateTransitionEnd(a);
                        }
                    }
                }),
                (t.setTransitioning = function (t) {
                    this._isTransitioning = t;
                }),
                (t.dispose = function () {
                    g.removeData(this._element, ht), (this._config = null), (this._parent = null), (this._element = null), (this._triggerArray = null), (this._isTransitioning = null);
                }),
                (t._getConfig = function (t) {
                    return ((t = l({}, dt, t)).toggle = Boolean(t.toggle)), _.typeCheckConfig(ct, t, gt), t;
                }),
                (t._getDimension = function () {
                    return g(this._element).hasClass(Et) ? Et : Ct;
                }),
                (t._getParent = function () {
                    var t,
                        n = this;
                    _.isElement(this._config.parent) ? ((t = this._config.parent), "undefined" != typeof this._config.parent.jquery && (t = this._config.parent[0])) : (t = document.querySelector(this._config.parent));
                    var e = '[data-toggle="collapse"][data-parent="' + this._config.parent + '"]',
                        i = [].slice.call(t.querySelectorAll(e));
                    return (
                        g(i).each(function (t, e) {
                            n._addAriaAndCollapsedClass(a._getTargetFromElement(e), [e]);
                        }),
                        t
                    );
                }),
                (t._addAriaAndCollapsedClass = function (t, e) {
                    var n = g(t).hasClass(mt);
                    e.length && g(e).toggleClass(yt, !n).attr("aria-expanded", n);
                }),
                (a._getTargetFromElement = function (t) {
                    var e = _.getSelectorFromElement(t);
                    return e ? document.querySelector(e) : null;
                }),
                (a._jQueryInterface = function (i) {
                    return this.each(function () {
                        var t = g(this),
                            e = t.data(ht),
                            n = l({}, dt, t.data(), "object" == typeof i && i ? i : {});
                        if ((!e && n.toggle && /show|hide/.test(i) && (n.toggle = !1), e || ((e = new a(this, n)), t.data(ht, e)), "string" == typeof i)) {
                            if ("undefined" == typeof e[i]) throw new TypeError('No method named "' + i + '"');
                            e[i]();
                        }
                    });
                }),
                s(a, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return dt;
                        },
                    },
                ]),
                a
            );
        })();
    g(document).on(_t.CLICK_DATA_API, St, function (t) {
        "A" === t.currentTarget.tagName && t.preventDefault();
        var n = g(this),
            e = _.getSelectorFromElement(this),
            i = [].slice.call(document.querySelectorAll(e));
        g(i).each(function () {
            var t = g(this),
                e = t.data(ht) ? "toggle" : n.data();
            bt._jQueryInterface.call(t, e);
        });
    }),
        (g.fn[ct] = bt._jQueryInterface),
        (g.fn[ct].Constructor = bt),
        (g.fn[ct].noConflict = function () {
            return (g.fn[ct] = ft), bt._jQueryInterface;
        });
    var It = "dropdown",
        Dt = "bs.dropdown",
        wt = "." + Dt,
        At = ".data-api",
        Nt = g.fn[It],
        Ot = new RegExp("38|40|27"),
        kt = { HIDE: "hide" + wt, HIDDEN: "hidden" + wt, SHOW: "show" + wt, SHOWN: "shown" + wt, CLICK: "click" + wt, CLICK_DATA_API: "click" + wt + At, KEYDOWN_DATA_API: "keydown" + wt + At, KEYUP_DATA_API: "keyup" + wt + At },
        Pt = "disabled",
        Lt = "show",
        jt = "dropup",
        Ht = "dropright",
        Rt = "dropleft",
        xt = "dropdown-menu-right",
        Ft = "position-static",
        Ut = '[data-toggle="dropdown"]',
        Wt = ".dropdown form",
        qt = ".dropdown-menu",
        Mt = ".navbar-nav",
        Kt = ".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)",
        Qt = "top-start",
        Bt = "top-end",
        Vt = "bottom-start",
        Yt = "bottom-end",
        zt = "right-start",
        Xt = "left-start",
        $t = { offset: 0, flip: !0, boundary: "scrollParent", reference: "toggle", display: "dynamic" },
        Gt = { offset: "(number|string|function)", flip: "boolean", boundary: "(string|element)", reference: "(string|element)", display: "string" },
        Jt = (function () {
            function c(t, e) {
                (this._element = t), (this._popper = null), (this._config = this._getConfig(e)), (this._menu = this._getMenuElement()), (this._inNavbar = this._detectNavbar()), this._addEventListeners();
            }
            var t = c.prototype;
            return (
                (t.toggle = function () {
                    if (!this._element.disabled && !g(this._element).hasClass(Pt)) {
                        var t = c._getParentFromElement(this._element),
                            e = g(this._menu).hasClass(Lt);
                        if ((c._clearMenus(), !e)) {
                            var n = { relatedTarget: this._element },
                                i = g.Event(kt.SHOW, n);
                            if ((g(t).trigger(i), !i.isDefaultPrevented())) {
                                if (!this._inNavbar) {
                                    if ("undefined" == typeof u) throw new TypeError("Bootstrap's dropdowns require Popper.js (https://popper.js.org/)");
                                    var o = this._element;
                                    "parent" === this._config.reference
                                        ? (o = t)
                                        : _.isElement(this._config.reference) && ((o = this._config.reference), "undefined" != typeof this._config.reference.jquery && (o = this._config.reference[0])),
                                        "scrollParent" !== this._config.boundary && g(t).addClass(Ft),
                                        (this._popper = new u(o, this._menu, this._getPopperConfig()));
                                }
                                "ontouchstart" in document.documentElement && 0 === g(t).closest(Mt).length && g(document.body).children().on("mouseover", null, g.noop),
                                    this._element.focus(),
                                    this._element.setAttribute("aria-expanded", !0),
                                    g(this._menu).toggleClass(Lt),
                                    g(t).toggleClass(Lt).trigger(g.Event(kt.SHOWN, n));
                            }
                        }
                    }
                }),
                (t.show = function () {
                    if (!(this._element.disabled || g(this._element).hasClass(Pt) || g(this._menu).hasClass(Lt))) {
                        var t = { relatedTarget: this._element },
                            e = g.Event(kt.SHOW, t),
                            n = c._getParentFromElement(this._element);
                        g(n).trigger(e), e.isDefaultPrevented() || (g(this._menu).toggleClass(Lt), g(n).toggleClass(Lt).trigger(g.Event(kt.SHOWN, t)));
                    }
                }),
                (t.hide = function () {
                    if (!this._element.disabled && !g(this._element).hasClass(Pt) && g(this._menu).hasClass(Lt)) {
                        var t = { relatedTarget: this._element },
                            e = g.Event(kt.HIDE, t),
                            n = c._getParentFromElement(this._element);
                        g(n).trigger(e), e.isDefaultPrevented() || (g(this._menu).toggleClass(Lt), g(n).toggleClass(Lt).trigger(g.Event(kt.HIDDEN, t)));
                    }
                }),
                (t.dispose = function () {
                    g.removeData(this._element, Dt), g(this._element).off(wt), (this._element = null), (this._menu = null) !== this._popper && (this._popper.destroy(), (this._popper = null));
                }),
                (t.update = function () {
                    (this._inNavbar = this._detectNavbar()), null !== this._popper && this._popper.scheduleUpdate();
                }),
                (t._addEventListeners = function () {
                    var e = this;
                    g(this._element).on(kt.CLICK, function (t) {
                        t.preventDefault(), t.stopPropagation(), e.toggle();
                    });
                }),
                (t._getConfig = function (t) {
                    return (t = l({}, this.constructor.Default, g(this._element).data(), t)), _.typeCheckConfig(It, t, this.constructor.DefaultType), t;
                }),
                (t._getMenuElement = function () {
                    if (!this._menu) {
                        var t = c._getParentFromElement(this._element);
                        t && (this._menu = t.querySelector(qt));
                    }
                    return this._menu;
                }),
                (t._getPlacement = function () {
                    var t = g(this._element.parentNode),
                        e = Vt;
                    return t.hasClass(jt) ? ((e = Qt), g(this._menu).hasClass(xt) && (e = Bt)) : t.hasClass(Ht) ? (e = zt) : t.hasClass(Rt) ? (e = Xt) : g(this._menu).hasClass(xt) && (e = Yt), e;
                }),
                (t._detectNavbar = function () {
                    return 0 < g(this._element).closest(".navbar").length;
                }),
                (t._getOffset = function () {
                    var e = this,
                        t = {};
                    return (
                        "function" == typeof this._config.offset
                            ? (t.fn = function (t) {
                                  return (t.offsets = l({}, t.offsets, e._config.offset(t.offsets, e._element) || {})), t;
                              })
                            : (t.offset = this._config.offset),
                        t
                    );
                }),
                (t._getPopperConfig = function () {
                    var t = { placement: this._getPlacement(), modifiers: { offset: this._getOffset(), flip: { enabled: this._config.flip }, preventOverflow: { boundariesElement: this._config.boundary } } };
                    return "static" === this._config.display && (t.modifiers.applyStyle = { enabled: !1 }), t;
                }),
                (c._jQueryInterface = function (e) {
                    return this.each(function () {
                        var t = g(this).data(Dt);
                        if ((t || ((t = new c(this, "object" == typeof e ? e : null)), g(this).data(Dt, t)), "string" == typeof e)) {
                            if ("undefined" == typeof t[e]) throw new TypeError('No method named "' + e + '"');
                            t[e]();
                        }
                    });
                }),
                (c._clearMenus = function (t) {
                    if (!t || (3 !== t.which && ("keyup" !== t.type || 9 === t.which)))
                        for (var e = [].slice.call(document.querySelectorAll(Ut)), n = 0, i = e.length; n < i; n++) {
                            var o = c._getParentFromElement(e[n]),
                                r = g(e[n]).data(Dt),
                                s = { relatedTarget: e[n] };
                            if ((t && "click" === t.type && (s.clickEvent = t), r)) {
                                var a = r._menu;
                                if (g(o).hasClass(Lt) && !(t && (("click" === t.type && /input|textarea/i.test(t.target.tagName)) || ("keyup" === t.type && 9 === t.which)) && g.contains(o, t.target))) {
                                    var l = g.Event(kt.HIDE, s);
                                    g(o).trigger(l),
                                        l.isDefaultPrevented() ||
                                            ("ontouchstart" in document.documentElement && g(document.body).children().off("mouseover", null, g.noop),
                                            e[n].setAttribute("aria-expanded", "false"),
                                            g(a).removeClass(Lt),
                                            g(o).removeClass(Lt).trigger(g.Event(kt.HIDDEN, s)));
                                }
                            }
                        }
                }),
                (c._getParentFromElement = function (t) {
                    var e,
                        n = _.getSelectorFromElement(t);
                    return n && (e = document.querySelector(n)), e || t.parentNode;
                }),
                (c._dataApiKeydownHandler = function (t) {
                    if (
                        (/input|textarea/i.test(t.target.tagName) ? !(32 === t.which || (27 !== t.which && ((40 !== t.which && 38 !== t.which) || g(t.target).closest(qt).length))) : Ot.test(t.which)) &&
                        (t.preventDefault(), t.stopPropagation(), !this.disabled && !g(this).hasClass(Pt))
                    ) {
                        var e = c._getParentFromElement(this),
                            n = g(e).hasClass(Lt);
                        if (n && (!n || (27 !== t.which && 32 !== t.which))) {
                            var i = [].slice.call(e.querySelectorAll(Kt));
                            if (0 !== i.length) {
                                var o = i.indexOf(t.target);
                                38 === t.which && 0 < o && o--, 40 === t.which && o < i.length - 1 && o++, o < 0 && (o = 0), i[o].focus();
                            }
                        } else {
                            if (27 === t.which) {
                                var r = e.querySelector(Ut);
                                g(r).trigger("focus");
                            }
                            g(this).trigger("click");
                        }
                    }
                }),
                s(c, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return $t;
                        },
                    },
                    {
                        key: "DefaultType",
                        get: function () {
                            return Gt;
                        },
                    },
                ]),
                c
            );
        })();
    g(document)
        .on(kt.KEYDOWN_DATA_API, Ut, Jt._dataApiKeydownHandler)
        .on(kt.KEYDOWN_DATA_API, qt, Jt._dataApiKeydownHandler)
        .on(kt.CLICK_DATA_API + " " + kt.KEYUP_DATA_API, Jt._clearMenus)
        .on(kt.CLICK_DATA_API, Ut, function (t) {
            t.preventDefault(), t.stopPropagation(), Jt._jQueryInterface.call(g(this), "toggle");
        })
        .on(kt.CLICK_DATA_API, Wt, function (t) {
            t.stopPropagation();
        }),
        (g.fn[It] = Jt._jQueryInterface),
        (g.fn[It].Constructor = Jt),
        (g.fn[It].noConflict = function () {
            return (g.fn[It] = Nt), Jt._jQueryInterface;
        });
    var Zt = "modal",
        te = "bs.modal",
        ee = "." + te,
        ne = g.fn[Zt],
        ie = { backdrop: !0, keyboard: !0, focus: !0, show: !0 },
        oe = { backdrop: "(boolean|string)", keyboard: "boolean", focus: "boolean", show: "boolean" },
        re = {
            HIDE: "hide" + ee,
            HIDDEN: "hidden" + ee,
            SHOW: "show" + ee,
            SHOWN: "shown" + ee,
            FOCUSIN: "focusin" + ee,
            RESIZE: "resize" + ee,
            CLICK_DISMISS: "click.dismiss" + ee,
            KEYDOWN_DISMISS: "keydown.dismiss" + ee,
            MOUSEUP_DISMISS: "mouseup.dismiss" + ee,
            MOUSEDOWN_DISMISS: "mousedown.dismiss" + ee,
            CLICK_DATA_API: "click" + ee + ".data-api",
        },
        se = "modal-dialog-scrollable",
        ae = "modal-scrollbar-measure",
        le = "modal-backdrop",
        ce = "modal-open",
        he = "fade",
        ue = "show",
        fe = ".modal-dialog",
        de = ".modal-body",
        ge = '[data-toggle="modal"]',
        _e = '[data-dismiss="modal"]',
        me = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
        pe = ".sticky-top",
        ve = (function () {
            function o(t, e) {
                (this._config = this._getConfig(e)),
                    (this._element = t),
                    (this._dialog = t.querySelector(fe)),
                    (this._backdrop = null),
                    (this._isShown = !1),
                    (this._isBodyOverflowing = !1),
                    (this._ignoreBackdropClick = !1),
                    (this._isTransitioning = !1),
                    (this._scrollbarWidth = 0);
            }
            var t = o.prototype;
            return (
                (t.toggle = function (t) {
                    return this._isShown ? this.hide() : this.show(t);
                }),
                (t.show = function (t) {
                    var e = this;
                    if (!this._isShown && !this._isTransitioning) {
                        g(this._element).hasClass(he) && (this._isTransitioning = !0);
                        var n = g.Event(re.SHOW, { relatedTarget: t });
                        g(this._element).trigger(n),
                            this._isShown ||
                                n.isDefaultPrevented() ||
                                ((this._isShown = !0),
                                this._checkScrollbar(),
                                this._setScrollbar(),
                                this._adjustDialog(),
                                this._setEscapeEvent(),
                                this._setResizeEvent(),
                                g(this._element).on(re.CLICK_DISMISS, _e, function (t) {
                                    return e.hide(t);
                                }),
                                g(this._dialog).on(re.MOUSEDOWN_DISMISS, function () {
                                    g(e._element).one(re.MOUSEUP_DISMISS, function (t) {
                                        g(t.target).is(e._element) && (e._ignoreBackdropClick = !0);
                                    });
                                }),
                                this._showBackdrop(function () {
                                    return e._showElement(t);
                                }));
                    }
                }),
                (t.hide = function (t) {
                    var e = this;
                    if ((t && t.preventDefault(), this._isShown && !this._isTransitioning)) {
                        var n = g.Event(re.HIDE);
                        if ((g(this._element).trigger(n), this._isShown && !n.isDefaultPrevented())) {
                            this._isShown = !1;
                            var i = g(this._element).hasClass(he);
                            if (
                                (i && (this._isTransitioning = !0),
                                this._setEscapeEvent(),
                                this._setResizeEvent(),
                                g(document).off(re.FOCUSIN),
                                g(this._element).removeClass(ue),
                                g(this._element).off(re.CLICK_DISMISS),
                                g(this._dialog).off(re.MOUSEDOWN_DISMISS),
                                i)
                            ) {
                                var o = _.getTransitionDurationFromElement(this._element);
                                g(this._element)
                                    .one(_.TRANSITION_END, function (t) {
                                        return e._hideModal(t);
                                    })
                                    .emulateTransitionEnd(o);
                            } else this._hideModal();
                        }
                    }
                }),
                (t.dispose = function () {
                    [window, this._element, this._dialog].forEach(function (t) {
                        return g(t).off(ee);
                    }),
                        g(document).off(re.FOCUSIN),
                        g.removeData(this._element, te),
                        (this._config = null),
                        (this._element = null),
                        (this._dialog = null),
                        (this._backdrop = null),
                        (this._isShown = null),
                        (this._isBodyOverflowing = null),
                        (this._ignoreBackdropClick = null),
                        (this._isTransitioning = null),
                        (this._scrollbarWidth = null);
                }),
                (t.handleUpdate = function () {
                    this._adjustDialog();
                }),
                (t._getConfig = function (t) {
                    return (t = l({}, ie, t)), _.typeCheckConfig(Zt, t, oe), t;
                }),
                (t._showElement = function (t) {
                    var e = this,
                        n = g(this._element).hasClass(he);
                    (this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE) || document.body.appendChild(this._element),
                        (this._element.style.display = "block"),
                        this._element.removeAttribute("aria-hidden"),
                        this._element.setAttribute("aria-modal", !0),
                        g(this._dialog).hasClass(se) ? (this._dialog.querySelector(de).scrollTop = 0) : (this._element.scrollTop = 0),
                        n && _.reflow(this._element),
                        g(this._element).addClass(ue),
                        this._config.focus && this._enforceFocus();
                    var i = g.Event(re.SHOWN, { relatedTarget: t }),
                        o = function () {
                            e._config.focus && e._element.focus(), (e._isTransitioning = !1), g(e._element).trigger(i);
                        };
                    if (n) {
                        var r = _.getTransitionDurationFromElement(this._dialog);
                        g(this._dialog).one(_.TRANSITION_END, o).emulateTransitionEnd(r);
                    } else o();
                }),
                (t._enforceFocus = function () {
                    var e = this;
                    g(document)
                        .off(re.FOCUSIN)
                        .on(re.FOCUSIN, function (t) {
                            document !== t.target && e._element !== t.target && 0 === g(e._element).has(t.target).length && e._element.focus();
                        });
                }),
                (t._setEscapeEvent = function () {
                    var e = this;
                    this._isShown && this._config.keyboard
                        ? g(this._element).on(re.KEYDOWN_DISMISS, function (t) {
                              27 === t.which && (t.preventDefault(), e.hide());
                          })
                        : this._isShown || g(this._element).off(re.KEYDOWN_DISMISS);
                }),
                (t._setResizeEvent = function () {
                    var e = this;
                    this._isShown
                        ? g(window).on(re.RESIZE, function (t) {
                              return e.handleUpdate(t);
                          })
                        : g(window).off(re.RESIZE);
                }),
                (t._hideModal = function () {
                    var t = this;
                    (this._element.style.display = "none"),
                        this._element.setAttribute("aria-hidden", !0),
                        this._element.removeAttribute("aria-modal"),
                        (this._isTransitioning = !1),
                        this._showBackdrop(function () {
                            g(document.body).removeClass(ce), t._resetAdjustments(), t._resetScrollbar(), g(t._element).trigger(re.HIDDEN);
                        });
                }),
                (t._removeBackdrop = function () {
                    this._backdrop && (g(this._backdrop).remove(), (this._backdrop = null));
                }),
                (t._showBackdrop = function (t) {
                    var e = this,
                        n = g(this._element).hasClass(he) ? he : "";
                    if (this._isShown && this._config.backdrop) {
                        if (
                            ((this._backdrop = document.createElement("div")),
                            (this._backdrop.className = le),
                            n && this._backdrop.classList.add(n),
                            g(this._backdrop).appendTo(document.body),
                            g(this._element).on(re.CLICK_DISMISS, function (t) {
                                e._ignoreBackdropClick ? (e._ignoreBackdropClick = !1) : t.target === t.currentTarget && ("static" === e._config.backdrop ? e._element.focus() : e.hide());
                            }),
                            n && _.reflow(this._backdrop),
                            g(this._backdrop).addClass(ue),
                            !t)
                        )
                            return;
                        if (!n) return void t();
                        var i = _.getTransitionDurationFromElement(this._backdrop);
                        g(this._backdrop).one(_.TRANSITION_END, t).emulateTransitionEnd(i);
                    } else if (!this._isShown && this._backdrop) {
                        g(this._backdrop).removeClass(ue);
                        var o = function () {
                            e._removeBackdrop(), t && t();
                        };
                        if (g(this._element).hasClass(he)) {
                            var r = _.getTransitionDurationFromElement(this._backdrop);
                            g(this._backdrop).one(_.TRANSITION_END, o).emulateTransitionEnd(r);
                        } else o();
                    } else t && t();
                }),
                (t._adjustDialog = function () {
                    var t = this._element.scrollHeight > document.documentElement.clientHeight;
                    !this._isBodyOverflowing && t && (this._element.style.paddingLeft = this._scrollbarWidth + "px"), this._isBodyOverflowing && !t && (this._element.style.paddingRight = this._scrollbarWidth + "px");
                }),
                (t._resetAdjustments = function () {
                    (this._element.style.paddingLeft = ""), (this._element.style.paddingRight = "");
                }),
                (t._checkScrollbar = function () {
                    var t = document.body.getBoundingClientRect();
                    (this._isBodyOverflowing = t.left + t.right < window.innerWidth), (this._scrollbarWidth = this._getScrollbarWidth());
                }),
                (t._setScrollbar = function () {
                    var o = this;
                    if (this._isBodyOverflowing) {
                        var t = [].slice.call(document.querySelectorAll(me)),
                            e = [].slice.call(document.querySelectorAll(pe));
                        g(t).each(function (t, e) {
                            var n = e.style.paddingRight,
                                i = g(e).css("padding-right");
                            g(e)
                                .data("padding-right", n)
                                .css("padding-right", parseFloat(i) + o._scrollbarWidth + "px");
                        }),
                            g(e).each(function (t, e) {
                                var n = e.style.marginRight,
                                    i = g(e).css("margin-right");
                                g(e)
                                    .data("margin-right", n)
                                    .css("margin-right", parseFloat(i) - o._scrollbarWidth + "px");
                            });
                        var n = document.body.style.paddingRight,
                            i = g(document.body).css("padding-right");
                        g(document.body)
                            .data("padding-right", n)
                            .css("padding-right", parseFloat(i) + this._scrollbarWidth + "px");
                    }
                    g(document.body).addClass(ce);
                }),
                (t._resetScrollbar = function () {
                    var t = [].slice.call(document.querySelectorAll(me));
                    g(t).each(function (t, e) {
                        var n = g(e).data("padding-right");
                        g(e).removeData("padding-right"), (e.style.paddingRight = n || "");
                    });
                    var e = [].slice.call(document.querySelectorAll("" + pe));
                    g(e).each(function (t, e) {
                        var n = g(e).data("margin-right");
                        "undefined" != typeof n && g(e).css("margin-right", n).removeData("margin-right");
                    });
                    var n = g(document.body).data("padding-right");
                    g(document.body).removeData("padding-right"), (document.body.style.paddingRight = n || "");
                }),
                (t._getScrollbarWidth = function () {
                    var t = document.createElement("div");
                    (t.className = ae), document.body.appendChild(t);
                    var e = t.getBoundingClientRect().width - t.clientWidth;
                    return document.body.removeChild(t), e;
                }),
                (o._jQueryInterface = function (n, i) {
                    return this.each(function () {
                        var t = g(this).data(te),
                            e = l({}, ie, g(this).data(), "object" == typeof n && n ? n : {});
                        if ((t || ((t = new o(this, e)), g(this).data(te, t)), "string" == typeof n)) {
                            if ("undefined" == typeof t[n]) throw new TypeError('No method named "' + n + '"');
                            t[n](i);
                        } else e.show && t.show(i);
                    });
                }),
                s(o, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return ie;
                        },
                    },
                ]),
                o
            );
        })();
    g(document).on(re.CLICK_DATA_API, ge, function (t) {
        var e,
            n = this,
            i = _.getSelectorFromElement(this);
        i && (e = document.querySelector(i));
        var o = g(e).data(te) ? "toggle" : l({}, g(e).data(), g(this).data());
        ("A" !== this.tagName && "AREA" !== this.tagName) || t.preventDefault();
        var r = g(e).one(re.SHOW, function (t) {
            t.isDefaultPrevented() ||
                r.one(re.HIDDEN, function () {
                    g(n).is(":visible") && n.focus();
                });
        });
        ve._jQueryInterface.call(g(e), o, this);
    }),
        (g.fn[Zt] = ve._jQueryInterface),
        (g.fn[Zt].Constructor = ve),
        (g.fn[Zt].noConflict = function () {
            return (g.fn[Zt] = ne), ve._jQueryInterface;
        });
    var ye = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"],
        Ee = {
            "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
            a: ["target", "href", "title", "rel"],
            area: [],
            b: [],
            br: [],
            col: [],
            code: [],
            div: [],
            em: [],
            hr: [],
            h1: [],
            h2: [],
            h3: [],
            h4: [],
            h5: [],
            h6: [],
            i: [],
            img: ["src", "alt", "title", "width", "height"],
            li: [],
            ol: [],
            p: [],
            pre: [],
            s: [],
            small: [],
            span: [],
            sub: [],
            sup: [],
            strong: [],
            u: [],
            ul: [],
        },
        Ce = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi,
        Te = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;
    function Se(t, s, e) {
        if (0 === t.length) return t;
        if (e && "function" == typeof e) return e(t);
        for (
            var n = new window.DOMParser().parseFromString(t, "text/html"),
                a = Object.keys(s),
                l = [].slice.call(n.body.querySelectorAll("*")),
                i = function (t, e) {
                    var n = l[t],
                        i = n.nodeName.toLowerCase();
                    if (-1 === a.indexOf(n.nodeName.toLowerCase())) return n.parentNode.removeChild(n), "continue";
                    var o = [].slice.call(n.attributes),
                        r = [].concat(s["*"] || [], s[i] || []);
                    o.forEach(function (t) {
                        (function (t, e) {
                            var n = t.nodeName.toLowerCase();
                            if (-1 !== e.indexOf(n)) return -1 === ye.indexOf(n) || Boolean(t.nodeValue.match(Ce) || t.nodeValue.match(Te));
                            for (
                                var i = e.filter(function (t) {
                                        return t instanceof RegExp;
                                    }),
                                    o = 0,
                                    r = i.length;
                                o < r;
                                o++
                            )
                                if (n.match(i[o])) return !0;
                            return !1;
                        })(t, r) || n.removeAttribute(t.nodeName);
                    });
                },
                o = 0,
                r = l.length;
            o < r;
            o++
        )
            i(o);
        return n.body.innerHTML;
    }
    var be = "tooltip",
        Ie = "bs.tooltip",
        De = "." + Ie,
        we = g.fn[be],
        Ae = "bs-tooltip",
        Ne = new RegExp("(^|\\s)" + Ae + "\\S+", "g"),
        Oe = ["sanitize", "whiteList", "sanitizeFn"],
        ke = {
            animation: "boolean",
            template: "string",
            title: "(string|element|function)",
            trigger: "string",
            delay: "(number|object)",
            html: "boolean",
            selector: "(string|boolean)",
            placement: "(string|function)",
            offset: "(number|string|function)",
            container: "(string|element|boolean)",
            fallbackPlacement: "(string|array)",
            boundary: "(string|element)",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            whiteList: "object",
        },
        Pe = { AUTO: "auto", TOP: "top", RIGHT: "right", BOTTOM: "bottom", LEFT: "left" },
        Le = {
            animation: !0,
            template: '<div class="tooltip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            selector: !1,
            placement: "top",
            offset: 0,
            container: !1,
            fallbackPlacement: "flip",
            boundary: "scrollParent",
            sanitize: !0,
            sanitizeFn: null,
            whiteList: Ee,
        },
        je = "show",
        He = "out",
        Re = {
            HIDE: "hide" + De,
            HIDDEN: "hidden" + De,
            SHOW: "show" + De,
            SHOWN: "shown" + De,
            INSERTED: "inserted" + De,
            CLICK: "click" + De,
            FOCUSIN: "focusin" + De,
            FOCUSOUT: "focusout" + De,
            MOUSEENTER: "mouseenter" + De,
            MOUSELEAVE: "mouseleave" + De,
        },
        xe = "fade",
        Fe = "show",
        Ue = ".tooltip-inner",
        We = ".arrow",
        qe = "hover",
        Me = "focus",
        Ke = "click",
        Qe = "manual",
        Be = (function () {
            function i(t, e) {
                if ("undefined" == typeof u) throw new TypeError("Bootstrap's tooltips require Popper.js (https://popper.js.org/)");
                (this._isEnabled = !0), (this._timeout = 0), (this._hoverState = ""), (this._activeTrigger = {}), (this._popper = null), (this.element = t), (this.config = this._getConfig(e)), (this.tip = null), this._setListeners();
            }
            var t = i.prototype;
            return (
                (t.enable = function () {
                    this._isEnabled = !0;
                }),
                (t.disable = function () {
                    this._isEnabled = !1;
                }),
                (t.toggleEnabled = function () {
                    this._isEnabled = !this._isEnabled;
                }),
                (t.toggle = function (t) {
                    if (this._isEnabled)
                        if (t) {
                            var e = this.constructor.DATA_KEY,
                                n = g(t.currentTarget).data(e);
                            n || ((n = new this.constructor(t.currentTarget, this._getDelegateConfig())), g(t.currentTarget).data(e, n)),
                                (n._activeTrigger.click = !n._activeTrigger.click),
                                n._isWithActiveTrigger() ? n._enter(null, n) : n._leave(null, n);
                        } else {
                            if (g(this.getTipElement()).hasClass(Fe)) return void this._leave(null, this);
                            this._enter(null, this);
                        }
                }),
                (t.dispose = function () {
                    clearTimeout(this._timeout),
                        g.removeData(this.element, this.constructor.DATA_KEY),
                        g(this.element).off(this.constructor.EVENT_KEY),
                        g(this.element).closest(".modal").off("hide.bs.modal"),
                        this.tip && g(this.tip).remove(),
                        (this._isEnabled = null),
                        (this._timeout = null),
                        (this._hoverState = null),
                        (this._activeTrigger = null) !== this._popper && this._popper.destroy(),
                        (this._popper = null),
                        (this.element = null),
                        (this.config = null),
                        (this.tip = null);
                }),
                (t.show = function () {
                    var e = this;
                    if ("none" === g(this.element).css("display")) throw new Error("Please use show on visible elements");
                    var t = g.Event(this.constructor.Event.SHOW);
                    if (this.isWithContent() && this._isEnabled) {
                        g(this.element).trigger(t);
                        var n = _.findShadowRoot(this.element),
                            i = g.contains(null !== n ? n : this.element.ownerDocument.documentElement, this.element);
                        if (t.isDefaultPrevented() || !i) return;
                        var o = this.getTipElement(),
                            r = _.getUID(this.constructor.NAME);
                        o.setAttribute("id", r), this.element.setAttribute("aria-describedby", r), this.setContent(), this.config.animation && g(o).addClass(xe);
                        var s = "function" == typeof this.config.placement ? this.config.placement.call(this, o, this.element) : this.config.placement,
                            a = this._getAttachment(s);
                        this.addAttachmentClass(a);
                        var l = this._getContainer();
                        g(o).data(this.constructor.DATA_KEY, this),
                            g.contains(this.element.ownerDocument.documentElement, this.tip) || g(o).appendTo(l),
                            g(this.element).trigger(this.constructor.Event.INSERTED),
                            (this._popper = new u(this.element, o, {
                                placement: a,
                                modifiers: { offset: this._getOffset(), flip: { behavior: this.config.fallbackPlacement }, arrow: { element: We }, preventOverflow: { boundariesElement: this.config.boundary } },
                                onCreate: function (t) {
                                    t.originalPlacement !== t.placement && e._handlePopperPlacementChange(t);
                                },
                                onUpdate: function (t) {
                                    return e._handlePopperPlacementChange(t);
                                },
                            })),
                            g(o).addClass(Fe),
                            "ontouchstart" in document.documentElement && g(document.body).children().on("mouseover", null, g.noop);
                        var c = function () {
                            e.config.animation && e._fixTransition();
                            var t = e._hoverState;
                            (e._hoverState = null), g(e.element).trigger(e.constructor.Event.SHOWN), t === He && e._leave(null, e);
                        };
                        if (g(this.tip).hasClass(xe)) {
                            var h = _.getTransitionDurationFromElement(this.tip);
                            g(this.tip).one(_.TRANSITION_END, c).emulateTransitionEnd(h);
                        } else c();
                    }
                }),
                (t.hide = function (t) {
                    var e = this,
                        n = this.getTipElement(),
                        i = g.Event(this.constructor.Event.HIDE),
                        o = function () {
                            e._hoverState !== je && n.parentNode && n.parentNode.removeChild(n),
                                e._cleanTipClass(),
                                e.element.removeAttribute("aria-describedby"),
                                g(e.element).trigger(e.constructor.Event.HIDDEN),
                                null !== e._popper && e._popper.destroy(),
                                t && t();
                        };
                    if ((g(this.element).trigger(i), !i.isDefaultPrevented())) {
                        if (
                            (g(n).removeClass(Fe),
                            "ontouchstart" in document.documentElement && g(document.body).children().off("mouseover", null, g.noop),
                            (this._activeTrigger[Ke] = !1),
                            (this._activeTrigger[Me] = !1),
                            (this._activeTrigger[qe] = !1),
                            g(this.tip).hasClass(xe))
                        ) {
                            var r = _.getTransitionDurationFromElement(n);
                            g(n).one(_.TRANSITION_END, o).emulateTransitionEnd(r);
                        } else o();
                        this._hoverState = "";
                    }
                }),
                (t.update = function () {
                    null !== this._popper && this._popper.scheduleUpdate();
                }),
                (t.isWithContent = function () {
                    return Boolean(this.getTitle());
                }),
                (t.addAttachmentClass = function (t) {
                    g(this.getTipElement()).addClass(Ae + "-" + t);
                }),
                (t.getTipElement = function () {
                    return (this.tip = this.tip || g(this.config.template)[0]), this.tip;
                }),
                (t.setContent = function () {
                    var t = this.getTipElement();
                    this.setElementContent(g(t.querySelectorAll(Ue)), this.getTitle()), g(t).removeClass(xe + " " + Fe);
                }),
                (t.setElementContent = function (t, e) {
                    "object" != typeof e || (!e.nodeType && !e.jquery)
                        ? this.config.html
                            ? (this.config.sanitize && (e = Se(e, this.config.whiteList, this.config.sanitizeFn)), t.html(e))
                            : t.text(e)
                        : this.config.html
                        ? g(e).parent().is(t) || t.empty().append(e)
                        : t.text(g(e).text());
                }),
                (t.getTitle = function () {
                    var t = this.element.getAttribute("data-original-title");
                    return t || (t = "function" == typeof this.config.title ? this.config.title.call(this.element) : this.config.title), t;
                }),
                (t._getOffset = function () {
                    var e = this,
                        t = {};
                    return (
                        "function" == typeof this.config.offset
                            ? (t.fn = function (t) {
                                  return (t.offsets = l({}, t.offsets, e.config.offset(t.offsets, e.element) || {})), t;
                              })
                            : (t.offset = this.config.offset),
                        t
                    );
                }),
                (t._getContainer = function () {
                    return !1 === this.config.container ? document.body : _.isElement(this.config.container) ? g(this.config.container) : g(document).find(this.config.container);
                }),
                (t._getAttachment = function (t) {
                    return Pe[t.toUpperCase()];
                }),
                (t._setListeners = function () {
                    var i = this;
                    this.config.trigger.split(" ").forEach(function (t) {
                        if ("click" === t)
                            g(i.element).on(i.constructor.Event.CLICK, i.config.selector, function (t) {
                                return i.toggle(t);
                            });
                        else if (t !== Qe) {
                            var e = t === qe ? i.constructor.Event.MOUSEENTER : i.constructor.Event.FOCUSIN,
                                n = t === qe ? i.constructor.Event.MOUSELEAVE : i.constructor.Event.FOCUSOUT;
                            g(i.element)
                                .on(e, i.config.selector, function (t) {
                                    return i._enter(t);
                                })
                                .on(n, i.config.selector, function (t) {
                                    return i._leave(t);
                                });
                        }
                    }),
                        g(this.element)
                            .closest(".modal")
                            .on("hide.bs.modal", function () {
                                i.element && i.hide();
                            }),
                        this.config.selector ? (this.config = l({}, this.config, { trigger: "manual", selector: "" })) : this._fixTitle();
                }),
                (t._fixTitle = function () {
                    var t = typeof this.element.getAttribute("data-original-title");
                    (this.element.getAttribute("title") || "string" !== t) && (this.element.setAttribute("data-original-title", this.element.getAttribute("title") || ""), this.element.setAttribute("title", ""));
                }),
                (t._enter = function (t, e) {
                    var n = this.constructor.DATA_KEY;
                    (e = e || g(t.currentTarget).data(n)) || ((e = new this.constructor(t.currentTarget, this._getDelegateConfig())), g(t.currentTarget).data(n, e)),
                        t && (e._activeTrigger["focusin" === t.type ? Me : qe] = !0),
                        g(e.getTipElement()).hasClass(Fe) || e._hoverState === je
                            ? (e._hoverState = je)
                            : (clearTimeout(e._timeout),
                              (e._hoverState = je),
                              e.config.delay && e.config.delay.show
                                  ? (e._timeout = setTimeout(function () {
                                        e._hoverState === je && e.show();
                                    }, e.config.delay.show))
                                  : e.show());
                }),
                (t._leave = function (t, e) {
                    var n = this.constructor.DATA_KEY;
                    (e = e || g(t.currentTarget).data(n)) || ((e = new this.constructor(t.currentTarget, this._getDelegateConfig())), g(t.currentTarget).data(n, e)),
                        t && (e._activeTrigger["focusout" === t.type ? Me : qe] = !1),
                        e._isWithActiveTrigger() ||
                            (clearTimeout(e._timeout),
                            (e._hoverState = He),
                            e.config.delay && e.config.delay.hide
                                ? (e._timeout = setTimeout(function () {
                                      e._hoverState === He && e.hide();
                                  }, e.config.delay.hide))
                                : e.hide());
                }),
                (t._isWithActiveTrigger = function () {
                    for (var t in this._activeTrigger) if (this._activeTrigger[t]) return !0;
                    return !1;
                }),
                (t._getConfig = function (t) {
                    var e = g(this.element).data();
                    return (
                        Object.keys(e).forEach(function (t) {
                            -1 !== Oe.indexOf(t) && delete e[t];
                        }),
                        "number" == typeof (t = l({}, this.constructor.Default, e, "object" == typeof t && t ? t : {})).delay && (t.delay = { show: t.delay, hide: t.delay }),
                        "number" == typeof t.title && (t.title = t.title.toString()),
                        "number" == typeof t.content && (t.content = t.content.toString()),
                        _.typeCheckConfig(be, t, this.constructor.DefaultType),
                        t.sanitize && (t.template = Se(t.template, t.whiteList, t.sanitizeFn)),
                        t
                    );
                }),
                (t._getDelegateConfig = function () {
                    var t = {};
                    if (this.config) for (var e in this.config) this.constructor.Default[e] !== this.config[e] && (t[e] = this.config[e]);
                    return t;
                }),
                (t._cleanTipClass = function () {
                    var t = g(this.getTipElement()),
                        e = t.attr("class").match(Ne);
                    null !== e && e.length && t.removeClass(e.join(""));
                }),
                (t._handlePopperPlacementChange = function (t) {
                    var e = t.instance;
                    (this.tip = e.popper), this._cleanTipClass(), this.addAttachmentClass(this._getAttachment(t.placement));
                }),
                (t._fixTransition = function () {
                    var t = this.getTipElement(),
                        e = this.config.animation;
                    null === t.getAttribute("x-placement") && (g(t).removeClass(xe), (this.config.animation = !1), this.hide(), this.show(), (this.config.animation = e));
                }),
                (i._jQueryInterface = function (n) {
                    return this.each(function () {
                        var t = g(this).data(Ie),
                            e = "object" == typeof n && n;
                        if ((t || !/dispose|hide/.test(n)) && (t || ((t = new i(this, e)), g(this).data(Ie, t)), "string" == typeof n)) {
                            if ("undefined" == typeof t[n]) throw new TypeError('No method named "' + n + '"');
                            t[n]();
                        }
                    });
                }),
                s(i, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return Le;
                        },
                    },
                    {
                        key: "NAME",
                        get: function () {
                            return be;
                        },
                    },
                    {
                        key: "DATA_KEY",
                        get: function () {
                            return Ie;
                        },
                    },
                    {
                        key: "Event",
                        get: function () {
                            return Re;
                        },
                    },
                    {
                        key: "EVENT_KEY",
                        get: function () {
                            return De;
                        },
                    },
                    {
                        key: "DefaultType",
                        get: function () {
                            return ke;
                        },
                    },
                ]),
                i
            );
        })();
    (g.fn[be] = Be._jQueryInterface),
        (g.fn[be].Constructor = Be),
        (g.fn[be].noConflict = function () {
            return (g.fn[be] = we), Be._jQueryInterface;
        });
    var Ve = "popover",
        Ye = "bs.popover",
        ze = "." + Ye,
        Xe = g.fn[Ve],
        $e = "bs-popover",
        Ge = new RegExp("(^|\\s)" + $e + "\\S+", "g"),
        Je = l({}, Be.Default, { placement: "right", trigger: "click", content: "", template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>' }),
        Ze = l({}, Be.DefaultType, { content: "(string|element|function)" }),
        tn = "fade",
        en = "show",
        nn = ".popover-header",
        on = ".popover-body",
        rn = {
            HIDE: "hide" + ze,
            HIDDEN: "hidden" + ze,
            SHOW: "show" + ze,
            SHOWN: "shown" + ze,
            INSERTED: "inserted" + ze,
            CLICK: "click" + ze,
            FOCUSIN: "focusin" + ze,
            FOCUSOUT: "focusout" + ze,
            MOUSEENTER: "mouseenter" + ze,
            MOUSELEAVE: "mouseleave" + ze,
        },
        sn = (function (t) {
            var e, n;
            function i() {
                return t.apply(this, arguments) || this;
            }
            (n = t), ((e = i).prototype = Object.create(n.prototype)), ((e.prototype.constructor = e).__proto__ = n);
            var o = i.prototype;
            return (
                (o.isWithContent = function () {
                    return this.getTitle() || this._getContent();
                }),
                (o.addAttachmentClass = function (t) {
                    g(this.getTipElement()).addClass($e + "-" + t);
                }),
                (o.getTipElement = function () {
                    return (this.tip = this.tip || g(this.config.template)[0]), this.tip;
                }),
                (o.setContent = function () {
                    var t = g(this.getTipElement());
                    this.setElementContent(t.find(nn), this.getTitle());
                    var e = this._getContent();
                    "function" == typeof e && (e = e.call(this.element)), this.setElementContent(t.find(on), e), t.removeClass(tn + " " + en);
                }),
                (o._getContent = function () {
                    return this.element.getAttribute("data-content") || this.config.content;
                }),
                (o._cleanTipClass = function () {
                    var t = g(this.getTipElement()),
                        e = t.attr("class").match(Ge);
                    null !== e && 0 < e.length && t.removeClass(e.join(""));
                }),
                (i._jQueryInterface = function (n) {
                    return this.each(function () {
                        var t = g(this).data(Ye),
                            e = "object" == typeof n ? n : null;
                        if ((t || !/dispose|hide/.test(n)) && (t || ((t = new i(this, e)), g(this).data(Ye, t)), "string" == typeof n)) {
                            if ("undefined" == typeof t[n]) throw new TypeError('No method named "' + n + '"');
                            t[n]();
                        }
                    });
                }),
                s(i, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return Je;
                        },
                    },
                    {
                        key: "NAME",
                        get: function () {
                            return Ve;
                        },
                    },
                    {
                        key: "DATA_KEY",
                        get: function () {
                            return Ye;
                        },
                    },
                    {
                        key: "Event",
                        get: function () {
                            return rn;
                        },
                    },
                    {
                        key: "EVENT_KEY",
                        get: function () {
                            return ze;
                        },
                    },
                    {
                        key: "DefaultType",
                        get: function () {
                            return Ze;
                        },
                    },
                ]),
                i
            );
        })(Be);
    (g.fn[Ve] = sn._jQueryInterface),
        (g.fn[Ve].Constructor = sn),
        (g.fn[Ve].noConflict = function () {
            return (g.fn[Ve] = Xe), sn._jQueryInterface;
        });
    var an = "scrollspy",
        ln = "bs.scrollspy",
        cn = "." + ln,
        hn = g.fn[an],
        un = { offset: 10, method: "auto", target: "" },
        fn = { offset: "number", method: "string", target: "(string|element)" },
        dn = { ACTIVATE: "activate" + cn, SCROLL: "scroll" + cn, LOAD_DATA_API: "load" + cn + ".data-api" },
        gn = "dropdown-item",
        _n = "active",
        mn = '[data-spy="scroll"]',
        pn = ".nav, .list-group",
        vn = ".nav-link",
        yn = ".nav-item",
        En = ".list-group-item",
        Cn = ".dropdown",
        Tn = ".dropdown-item",
        Sn = ".dropdown-toggle",
        bn = "offset",
        In = "position",
        Dn = (function () {
            function n(t, e) {
                var n = this;
                (this._element = t),
                    (this._scrollElement = "BODY" === t.tagName ? window : t),
                    (this._config = this._getConfig(e)),
                    (this._selector = this._config.target + " " + vn + "," + this._config.target + " " + En + "," + this._config.target + " " + Tn),
                    (this._offsets = []),
                    (this._targets = []),
                    (this._activeTarget = null),
                    (this._scrollHeight = 0),
                    g(this._scrollElement).on(dn.SCROLL, function (t) {
                        return n._process(t);
                    }),
                    this.refresh(),
                    this._process();
            }
            var t = n.prototype;
            return (
                (t.refresh = function () {
                    var e = this,
                        t = this._scrollElement === this._scrollElement.window ? bn : In,
                        o = "auto" === this._config.method ? t : this._config.method,
                        r = o === In ? this._getScrollTop() : 0;
                    (this._offsets = []),
                        (this._targets = []),
                        (this._scrollHeight = this._getScrollHeight()),
                        [].slice
                            .call(document.querySelectorAll(this._selector))
                            .map(function (t) {
                                var e,
                                    n = _.getSelectorFromElement(t);
                                if ((n && (e = document.querySelector(n)), e)) {
                                    var i = e.getBoundingClientRect();
                                    if (i.width || i.height) return [g(e)[o]().top + r, n];
                                }
                                return null;
                            })
                            .filter(function (t) {
                                return t;
                            })
                            .sort(function (t, e) {
                                return t[0] - e[0];
                            })
                            .forEach(function (t) {
                                e._offsets.push(t[0]), e._targets.push(t[1]);
                            });
                }),
                (t.dispose = function () {
                    g.removeData(this._element, ln),
                        g(this._scrollElement).off(cn),
                        (this._element = null),
                        (this._scrollElement = null),
                        (this._config = null),
                        (this._selector = null),
                        (this._offsets = null),
                        (this._targets = null),
                        (this._activeTarget = null),
                        (this._scrollHeight = null);
                }),
                (t._getConfig = function (t) {
                    if ("string" != typeof (t = l({}, un, "object" == typeof t && t ? t : {})).target) {
                        var e = g(t.target).attr("id");
                        e || ((e = _.getUID(an)), g(t.target).attr("id", e)), (t.target = "#" + e);
                    }
                    return _.typeCheckConfig(an, t, fn), t;
                }),
                (t._getScrollTop = function () {
                    return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop;
                }),
                (t._getScrollHeight = function () {
                    return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
                }),
                (t._getOffsetHeight = function () {
                    return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height;
                }),
                (t._process = function () {
                    var t = this._getScrollTop() + this._config.offset,
                        e = this._getScrollHeight(),
                        n = this._config.offset + e - this._getOffsetHeight();
                    if ((this._scrollHeight !== e && this.refresh(), n <= t)) {
                        var i = this._targets[this._targets.length - 1];
                        this._activeTarget !== i && this._activate(i);
                    } else {
                        if (this._activeTarget && t < this._offsets[0] && 0 < this._offsets[0]) return (this._activeTarget = null), void this._clear();
                        for (var o = this._offsets.length; o--; ) {
                            this._activeTarget !== this._targets[o] && t >= this._offsets[o] && ("undefined" == typeof this._offsets[o + 1] || t < this._offsets[o + 1]) && this._activate(this._targets[o]);
                        }
                    }
                }),
                (t._activate = function (e) {
                    (this._activeTarget = e), this._clear();
                    var t = this._selector.split(",").map(function (t) {
                            return t + '[data-target="' + e + '"],' + t + '[href="' + e + '"]';
                        }),
                        n = g([].slice.call(document.querySelectorAll(t.join(","))));
                    n.hasClass(gn)
                        ? (n.closest(Cn).find(Sn).addClass(_n), n.addClass(_n))
                        : (n.addClass(_n),
                          n
                              .parents(pn)
                              .prev(vn + ", " + En)
                              .addClass(_n),
                          n.parents(pn).prev(yn).children(vn).addClass(_n)),
                        g(this._scrollElement).trigger(dn.ACTIVATE, { relatedTarget: e });
                }),
                (t._clear = function () {
                    [].slice
                        .call(document.querySelectorAll(this._selector))
                        .filter(function (t) {
                            return t.classList.contains(_n);
                        })
                        .forEach(function (t) {
                            return t.classList.remove(_n);
                        });
                }),
                (n._jQueryInterface = function (e) {
                    return this.each(function () {
                        var t = g(this).data(ln);
                        if ((t || ((t = new n(this, "object" == typeof e && e)), g(this).data(ln, t)), "string" == typeof e)) {
                            if ("undefined" == typeof t[e]) throw new TypeError('No method named "' + e + '"');
                            t[e]();
                        }
                    });
                }),
                s(n, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return un;
                        },
                    },
                ]),
                n
            );
        })();
    g(window).on(dn.LOAD_DATA_API, function () {
        for (var t = [].slice.call(document.querySelectorAll(mn)), e = t.length; e--; ) {
            var n = g(t[e]);
            Dn._jQueryInterface.call(n, n.data());
        }
    }),
        (g.fn[an] = Dn._jQueryInterface),
        (g.fn[an].Constructor = Dn),
        (g.fn[an].noConflict = function () {
            return (g.fn[an] = hn), Dn._jQueryInterface;
        });
    var wn = "bs.tab",
        An = "." + wn,
        Nn = g.fn.tab,
        On = { HIDE: "hide" + An, HIDDEN: "hidden" + An, SHOW: "show" + An, SHOWN: "shown" + An, CLICK_DATA_API: "click" + An + ".data-api" },
        kn = "dropdown-menu",
        Pn = "active",
        Ln = "disabled",
        jn = "fade",
        Hn = "show",
        Rn = ".dropdown",
        xn = ".nav, .list-group",
        Fn = ".active",
        Un = "> li > .active",
        Wn = '[data-toggle="tab"], [data-toggle="pill"], [data-toggle="list"]',
        qn = ".dropdown-toggle",
        Mn = "> .dropdown-menu .active",
        Kn = (function () {
            function i(t) {
                this._element = t;
            }
            var t = i.prototype;
            return (
                (t.show = function () {
                    var n = this;
                    if (!((this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && g(this._element).hasClass(Pn)) || g(this._element).hasClass(Ln))) {
                        var t,
                            i,
                            e = g(this._element).closest(xn)[0],
                            o = _.getSelectorFromElement(this._element);
                        if (e) {
                            var r = "UL" === e.nodeName || "OL" === e.nodeName ? Un : Fn;
                            i = (i = g.makeArray(g(e).find(r)))[i.length - 1];
                        }
                        var s = g.Event(On.HIDE, { relatedTarget: this._element }),
                            a = g.Event(On.SHOW, { relatedTarget: i });
                        if ((i && g(i).trigger(s), g(this._element).trigger(a), !a.isDefaultPrevented() && !s.isDefaultPrevented())) {
                            o && (t = document.querySelector(o)), this._activate(this._element, e);
                            var l = function () {
                                var t = g.Event(On.HIDDEN, { relatedTarget: n._element }),
                                    e = g.Event(On.SHOWN, { relatedTarget: i });
                                g(i).trigger(t), g(n._element).trigger(e);
                            };
                            t ? this._activate(t, t.parentNode, l) : l();
                        }
                    }
                }),
                (t.dispose = function () {
                    g.removeData(this._element, wn), (this._element = null);
                }),
                (t._activate = function (t, e, n) {
                    var i = this,
                        o = (!e || ("UL" !== e.nodeName && "OL" !== e.nodeName) ? g(e).children(Fn) : g(e).find(Un))[0],
                        r = n && o && g(o).hasClass(jn),
                        s = function () {
                            return i._transitionComplete(t, o, n);
                        };
                    if (o && r) {
                        var a = _.getTransitionDurationFromElement(o);
                        g(o).removeClass(Hn).one(_.TRANSITION_END, s).emulateTransitionEnd(a);
                    } else s();
                }),
                (t._transitionComplete = function (t, e, n) {
                    if (e) {
                        g(e).removeClass(Pn);
                        var i = g(e.parentNode).find(Mn)[0];
                        i && g(i).removeClass(Pn), "tab" === e.getAttribute("role") && e.setAttribute("aria-selected", !1);
                    }
                    if ((g(t).addClass(Pn), "tab" === t.getAttribute("role") && t.setAttribute("aria-selected", !0), _.reflow(t), t.classList.contains(jn) && t.classList.add(Hn), t.parentNode && g(t.parentNode).hasClass(kn))) {
                        var o = g(t).closest(Rn)[0];
                        if (o) {
                            var r = [].slice.call(o.querySelectorAll(qn));
                            g(r).addClass(Pn);
                        }
                        t.setAttribute("aria-expanded", !0);
                    }
                    n && n();
                }),
                (i._jQueryInterface = function (n) {
                    return this.each(function () {
                        var t = g(this),
                            e = t.data(wn);
                        if ((e || ((e = new i(this)), t.data(wn, e)), "string" == typeof n)) {
                            if ("undefined" == typeof e[n]) throw new TypeError('No method named "' + n + '"');
                            e[n]();
                        }
                    });
                }),
                s(i, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                ]),
                i
            );
        })();
    g(document).on(On.CLICK_DATA_API, Wn, function (t) {
        t.preventDefault(), Kn._jQueryInterface.call(g(this), "show");
    }),
        (g.fn.tab = Kn._jQueryInterface),
        (g.fn.tab.Constructor = Kn),
        (g.fn.tab.noConflict = function () {
            return (g.fn.tab = Nn), Kn._jQueryInterface;
        });
    var Qn = "toast",
        Bn = "bs.toast",
        Vn = "." + Bn,
        Yn = g.fn[Qn],
        zn = { CLICK_DISMISS: "click.dismiss" + Vn, HIDE: "hide" + Vn, HIDDEN: "hidden" + Vn, SHOW: "show" + Vn, SHOWN: "shown" + Vn },
        Xn = "fade",
        $n = "hide",
        Gn = "show",
        Jn = "showing",
        Zn = { animation: "boolean", autohide: "boolean", delay: "number" },
        ti = { animation: !0, autohide: !0, delay: 500 },
        ei = '[data-dismiss="toast"]',
        ni = (function () {
            function i(t, e) {
                (this._element = t), (this._config = this._getConfig(e)), (this._timeout = null), this._setListeners();
            }
            var t = i.prototype;
            return (
                (t.show = function () {
                    var t = this;
                    g(this._element).trigger(zn.SHOW), this._config.animation && this._element.classList.add(Xn);
                    var e = function () {
                        t._element.classList.remove(Jn), t._element.classList.add(Gn), g(t._element).trigger(zn.SHOWN), t._config.autohide && t.hide();
                    };
                    if ((this._element.classList.remove($n), this._element.classList.add(Jn), this._config.animation)) {
                        var n = _.getTransitionDurationFromElement(this._element);
                        g(this._element).one(_.TRANSITION_END, e).emulateTransitionEnd(n);
                    } else e();
                }),
                (t.hide = function (t) {
                    var e = this;
                    this._element.classList.contains(Gn) &&
                        (g(this._element).trigger(zn.HIDE),
                        t
                            ? this._close()
                            : (this._timeout = setTimeout(function () {
                                  e._close();
                              }, this._config.delay)));
                }),
                (t.dispose = function () {
                    clearTimeout(this._timeout),
                        (this._timeout = null),
                        this._element.classList.contains(Gn) && this._element.classList.remove(Gn),
                        g(this._element).off(zn.CLICK_DISMISS),
                        g.removeData(this._element, Bn),
                        (this._element = null),
                        (this._config = null);
                }),
                (t._getConfig = function (t) {
                    return (t = l({}, ti, g(this._element).data(), "object" == typeof t && t ? t : {})), _.typeCheckConfig(Qn, t, this.constructor.DefaultType), t;
                }),
                (t._setListeners = function () {
                    var t = this;
                    g(this._element).on(zn.CLICK_DISMISS, ei, function () {
                        return t.hide(!0);
                    });
                }),
                (t._close = function () {
                    var t = this,
                        e = function () {
                            t._element.classList.add($n), g(t._element).trigger(zn.HIDDEN);
                        };
                    if ((this._element.classList.remove(Gn), this._config.animation)) {
                        var n = _.getTransitionDurationFromElement(this._element);
                        g(this._element).one(_.TRANSITION_END, e).emulateTransitionEnd(n);
                    } else e();
                }),
                (i._jQueryInterface = function (n) {
                    return this.each(function () {
                        var t = g(this),
                            e = t.data(Bn);
                        if ((e || ((e = new i(this, "object" == typeof n && n)), t.data(Bn, e)), "string" == typeof n)) {
                            if ("undefined" == typeof e[n]) throw new TypeError('No method named "' + n + '"');
                            e[n](this);
                        }
                    });
                }),
                s(i, null, [
                    {
                        key: "VERSION",
                        get: function () {
                            return "4.3.1";
                        },
                    },
                    {
                        key: "DefaultType",
                        get: function () {
                            return Zn;
                        },
                    },
                    {
                        key: "Default",
                        get: function () {
                            return ti;
                        },
                    },
                ]),
                i
            );
        })();
    (g.fn[Qn] = ni._jQueryInterface),
        (g.fn[Qn].Constructor = ni),
        (g.fn[Qn].noConflict = function () {
            return (g.fn[Qn] = Yn), ni._jQueryInterface;
        }),
        (function () {
            if ("undefined" == typeof g) throw new TypeError("Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript.");
            var t = g.fn.jquery.split(" ")[0].split(".");
            if ((t[0] < 2 && t[1] < 9) || (1 === t[0] && 9 === t[1] && t[2] < 1) || 4 <= t[0]) throw new Error("Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0");
        })(),
        (t.Util = _),
        (t.Alert = p),
        (t.Button = P),
        (t.Carousel = lt),
        (t.Collapse = bt),
        (t.Dropdown = Jt),
        (t.Modal = ve),
        (t.Popover = sn),
        (t.Scrollspy = Dn),
        (t.Tab = Kn),
        (t.Toast = ni),
        (t.Tooltip = Be),
        Object.defineProperty(t, "__esModule", { value: !0 });
});
//# sourceMappingURL=bootstrap.min.js.map

/*-------------------------------------------------------------
  5. Slick slider jQuery
---------------------------------------------------------------*/
/*
     _ _      _       _
 ___| (_) ___| | __  (_)___
/ __| | |/ __| |/ /  | / __|
\__ \ | | (__|   < _ | \__ \
|___/_|_|\___|_|\_(_)/ |___/
                   |__/

 Version: 1.6.0
  Author: Ken Wheeler
 Website: http://kenwheeler.github.io
    Docs: http://kenwheeler.github.io/slick
    Repo: http://github.com/kenwheeler/slick
  Issues: http://github.com/kenwheeler/slick/issues

 */
!(function (a) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], a) : "undefined" != typeof exports ? (module.exports = a(require("jquery"))) : a(jQuery);
})(function (a) {
    "use strict";
    var b = window.Slick || {};
    (b = (function () {
        function c(c, d) {
            var f,
                e = this;
            (e.defaults = {
                accessibility: !0,
                adaptiveHeight: !1,
                appendArrows: a(c),
                appendDots: a(c),
                arrows: !0,
                asNavFor: null,
                prevArrow: '<button type="button" data-role="none" class="slick-prev" aria-label="Previous" tabindex="0" role="button">Previous</button>',
                nextArrow: '<button type="button" data-role="none" class="slick-next" aria-label="Next" tabindex="0" role="button">Next</button>',
                autoplay: !1,
                autoplaySpeed: 3e3,
                centerMode: !1,
                centerPadding: "50px",
                cssEase: "ease",
                customPaging: function (b, c) {
                    return a('<button type="button" data-role="none" role="button" tabindex="0" />').text(c + 1);
                },
                dots: !1,
                dotsClass: "slick-dots",
                draggable: !0,
                easing: "linear",
                edgeFriction: 0.35,
                fade: !1,
                focusOnSelect: !1,
                infinite: !0,
                initialSlide: 0,
                lazyLoad: "ondemand",
                mobileFirst: !1,
                pauseOnHover: !0,
                pauseOnFocus: !0,
                pauseOnDotsHover: !1,
                respondTo: "window",
                responsive: null,
                rows: 1,
                rtl: !1,
                slide: "",
                slidesPerRow: 1,
                slidesToShow: 1,
                slidesToScroll: 1,
                speed: 500,
                swipe: !0,
                swipeToSlide: !1,
                touchMove: !0,
                touchThreshold: 5,
                useCSS: !0,
                useTransform: !0,
                variableWidth: !1,
                vertical: !1,
                verticalSwiping: !1,
                waitForAnimate: !0,
                zIndex: 1e3,
            }),
                (e.initials = {
                    animating: !1,
                    dragging: !1,
                    autoPlayTimer: null,
                    currentDirection: 0,
                    currentLeft: null,
                    currentSlide: 0,
                    direction: 1,
                    $dots: null,
                    listWidth: null,
                    listHeight: null,
                    loadIndex: 0,
                    $nextArrow: null,
                    $prevArrow: null,
                    slideCount: null,
                    slideWidth: null,
                    $slideTrack: null,
                    $slides: null,
                    sliding: !1,
                    slideOffset: 0,
                    swipeLeft: null,
                    $list: null,
                    touchObject: {},
                    transformsEnabled: !1,
                    unslicked: !1,
                }),
                a.extend(e, e.initials),
                (e.activeBreakpoint = null),
                (e.animType = null),
                (e.animProp = null),
                (e.breakpoints = []),
                (e.breakpointSettings = []),
                (e.cssTransitions = !1),
                (e.focussed = !1),
                (e.interrupted = !1),
                (e.hidden = "hidden"),
                (e.paused = !0),
                (e.positionProp = null),
                (e.respondTo = null),
                (e.rowCount = 1),
                (e.shouldClick = !0),
                (e.$slider = a(c)),
                (e.$slidesCache = null),
                (e.transformType = null),
                (e.transitionType = null),
                (e.visibilityChange = "visibilitychange"),
                (e.windowWidth = 0),
                (e.windowTimer = null),
                (f = a(c).data("slick") || {}),
                (e.options = a.extend({}, e.defaults, d, f)),
                (e.currentSlide = e.options.initialSlide),
                (e.originalSettings = e.options),
                "undefined" != typeof document.mozHidden
                    ? ((e.hidden = "mozHidden"), (e.visibilityChange = "mozvisibilitychange"))
                    : "undefined" != typeof document.webkitHidden && ((e.hidden = "webkitHidden"), (e.visibilityChange = "webkitvisibilitychange")),
                (e.autoPlay = a.proxy(e.autoPlay, e)),
                (e.autoPlayClear = a.proxy(e.autoPlayClear, e)),
                (e.autoPlayIterator = a.proxy(e.autoPlayIterator, e)),
                (e.changeSlide = a.proxy(e.changeSlide, e)),
                (e.clickHandler = a.proxy(e.clickHandler, e)),
                (e.selectHandler = a.proxy(e.selectHandler, e)),
                (e.setPosition = a.proxy(e.setPosition, e)),
                (e.swipeHandler = a.proxy(e.swipeHandler, e)),
                (e.dragHandler = a.proxy(e.dragHandler, e)),
                (e.keyHandler = a.proxy(e.keyHandler, e)),
                (e.instanceUid = b++),
                (e.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/),
                e.registerBreakpoints(),
                e.init(!0);
        }
        var b = 0;
        return c;
    })()),
        (b.prototype.activateADA = function () {
            var a = this;
            a.$slideTrack.find(".slick-active").attr({ "aria-hidden": "false" }).find("a, input, button, select").attr({ tabindex: "0" });
        }),
        (b.prototype.addSlide = b.prototype.slickAdd = function (b, c, d) {
            var e = this;
            if ("boolean" == typeof c) (d = c), (c = null);
            else if (0 > c || c >= e.slideCount) return !1;
            e.unload(),
                "number" == typeof c
                    ? 0 === c && 0 === e.$slides.length
                        ? a(b).appendTo(e.$slideTrack)
                        : d
                        ? a(b).insertBefore(e.$slides.eq(c))
                        : a(b).insertAfter(e.$slides.eq(c))
                    : d === !0
                    ? a(b).prependTo(e.$slideTrack)
                    : a(b).appendTo(e.$slideTrack),
                (e.$slides = e.$slideTrack.children(this.options.slide)),
                e.$slideTrack.children(this.options.slide).detach(),
                e.$slideTrack.append(e.$slides),
                e.$slides.each(function (b, c) {
                    a(c).attr("data-slick-index", b);
                }),
                (e.$slidesCache = e.$slides),
                e.reinit();
        }),
        (b.prototype.animateHeight = function () {
            var a = this;
            if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
                var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
                a.$list.animate({ height: b }, a.options.speed);
            }
        }),
        (b.prototype.animateSlide = function (b, c) {
            var d = {},
                e = this;
            e.animateHeight(),
                e.options.rtl === !0 && e.options.vertical === !1 && (b = -b),
                e.transformsEnabled === !1
                    ? e.options.vertical === !1
                        ? e.$slideTrack.animate({ left: b }, e.options.speed, e.options.easing, c)
                        : e.$slideTrack.animate({ top: b }, e.options.speed, e.options.easing, c)
                    : e.cssTransitions === !1
                    ? (e.options.rtl === !0 && (e.currentLeft = -e.currentLeft),
                      a({ animStart: e.currentLeft }).animate(
                          { animStart: b },
                          {
                              duration: e.options.speed,
                              easing: e.options.easing,
                              step: function (a) {
                                  (a = Math.ceil(a)), e.options.vertical === !1 ? ((d[e.animType] = "translate(" + a + "px, 0px)"), e.$slideTrack.css(d)) : ((d[e.animType] = "translate(0px," + a + "px)"), e.$slideTrack.css(d));
                              },
                              complete: function () {
                                  c && c.call();
                              },
                          }
                      ))
                    : (e.applyTransition(),
                      (b = Math.ceil(b)),
                      e.options.vertical === !1 ? (d[e.animType] = "translate3d(" + b + "px, 0px, 0px)") : (d[e.animType] = "translate3d(0px," + b + "px, 0px)"),
                      e.$slideTrack.css(d),
                      c &&
                          setTimeout(function () {
                              e.disableTransition(), c.call();
                          }, e.options.speed));
        }),
        (b.prototype.getNavTarget = function () {
            var b = this,
                c = b.options.asNavFor;
            return c && null !== c && (c = a(c).not(b.$slider)), c;
        }),
        (b.prototype.asNavFor = function (b) {
            var c = this,
                d = c.getNavTarget();
            null !== d &&
                "object" == typeof d &&
                d.each(function () {
                    var c = a(this).slick("getSlick");
                    c.unslicked || c.slideHandler(b, !0);
                });
        }),
        (b.prototype.applyTransition = function (a) {
            var b = this,
                c = {};
            b.options.fade === !1 ? (c[b.transitionType] = b.transformType + " " + b.options.speed + "ms " + b.options.cssEase) : (c[b.transitionType] = "opacity " + b.options.speed + "ms " + b.options.cssEase),
                b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c);
        }),
        (b.prototype.autoPlay = function () {
            var a = this;
            a.autoPlayClear(), a.slideCount > a.options.slidesToShow && (a.autoPlayTimer = setInterval(a.autoPlayIterator, a.options.autoplaySpeed));
        }),
        (b.prototype.autoPlayClear = function () {
            var a = this;
            a.autoPlayTimer && clearInterval(a.autoPlayTimer);
        }),
        (b.prototype.autoPlayIterator = function () {
            var a = this,
                b = a.currentSlide + a.options.slidesToScroll;
            a.paused ||
                a.interrupted ||
                a.focussed ||
                (a.options.infinite === !1 &&
                    (1 === a.direction && a.currentSlide + 1 === a.slideCount - 1 ? (a.direction = 0) : 0 === a.direction && ((b = a.currentSlide - a.options.slidesToScroll), a.currentSlide - 1 === 0 && (a.direction = 1))),
                a.slideHandler(b));
        }),
        (b.prototype.buildArrows = function () {
            var b = this;
            b.options.arrows === !0 &&
                ((b.$prevArrow = a(b.options.prevArrow).addClass("slick-arrow")),
                (b.$nextArrow = a(b.options.nextArrow).addClass("slick-arrow")),
                b.slideCount > b.options.slidesToShow
                    ? (b.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
                      b.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
                      b.htmlExpr.test(b.options.prevArrow) && b.$prevArrow.prependTo(b.options.appendArrows),
                      b.htmlExpr.test(b.options.nextArrow) && b.$nextArrow.appendTo(b.options.appendArrows),
                      b.options.infinite !== !0 && b.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"))
                    : b.$prevArrow.add(b.$nextArrow).addClass("slick-hidden").attr({ "aria-disabled": "true", tabindex: "-1" }));
        }),
        (b.prototype.buildDots = function () {
            var c,
                d,
                b = this;
            if (b.options.dots === !0 && b.slideCount > b.options.slidesToShow) {
                for (b.$slider.addClass("slick-dotted"), d = a("<ul />").addClass(b.options.dotsClass), c = 0; c <= b.getDotCount(); c += 1) d.append(a("<li />").append(b.options.customPaging.call(this, b, c)));
                (b.$dots = d.appendTo(b.options.appendDots)), b.$dots.find("li").first().addClass("slick-active").attr("aria-hidden", "false");
            }
        }),
        (b.prototype.buildOut = function () {
            var b = this;
            (b.$slides = b.$slider.children(b.options.slide + ":not(.slick-cloned)").addClass("slick-slide")),
                (b.slideCount = b.$slides.length),
                b.$slides.each(function (b, c) {
                    a(c)
                        .attr("data-slick-index", b)
                        .data("originalStyling", a(c).attr("style") || "");
                }),
                b.$slider.addClass("slick-slider"),
                (b.$slideTrack = 0 === b.slideCount ? a('<div class="slick-track"/>').appendTo(b.$slider) : b.$slides.wrapAll('<div class="slick-track"/>').parent()),
                (b.$list = b.$slideTrack.wrap('<div aria-live="polite" class="slick-list"/>').parent()),
                b.$slideTrack.css("opacity", 0),
                (b.options.centerMode === !0 || b.options.swipeToSlide === !0) && (b.options.slidesToScroll = 1),
                a("img[data-lazy]", b.$slider).not("[src]").addClass("slick-loading"),
                b.setupInfinite(),
                b.buildArrows(),
                b.buildDots(),
                b.updateDots(),
                b.setSlideClasses("number" == typeof b.currentSlide ? b.currentSlide : 0),
                b.options.draggable === !0 && b.$list.addClass("draggable");
        }),
        (b.prototype.buildRows = function () {
            var b,
                c,
                d,
                e,
                f,
                g,
                h,
                a = this;
            if (((e = document.createDocumentFragment()), (g = a.$slider.children()), a.options.rows > 1)) {
                for (h = a.options.slidesPerRow * a.options.rows, f = Math.ceil(g.length / h), b = 0; f > b; b++) {
                    var i = document.createElement("div");
                    for (c = 0; c < a.options.rows; c++) {
                        var j = document.createElement("div");
                        for (d = 0; d < a.options.slidesPerRow; d++) {
                            var k = b * h + (c * a.options.slidesPerRow + d);
                            g.get(k) && j.appendChild(g.get(k));
                        }
                        i.appendChild(j);
                    }
                    e.appendChild(i);
                }
                a.$slider.empty().append(e),
                    a.$slider
                        .children()
                        .children()
                        .children()
                        .css({ width: 100 / a.options.slidesPerRow + "%", display: "inline-block" });
            }
        }),
        (b.prototype.checkResponsive = function (b, c) {
            var e,
                f,
                g,
                d = this,
                h = !1,
                i = d.$slider.width(),
                j = window.innerWidth || a(window).width();
            if (("window" === d.respondTo ? (g = j) : "slider" === d.respondTo ? (g = i) : "min" === d.respondTo && (g = Math.min(j, i)), d.options.responsive && d.options.responsive.length && null !== d.options.responsive)) {
                f = null;
                for (e in d.breakpoints) d.breakpoints.hasOwnProperty(e) && (d.originalSettings.mobileFirst === !1 ? g < d.breakpoints[e] && (f = d.breakpoints[e]) : g > d.breakpoints[e] && (f = d.breakpoints[e]));
                null !== f
                    ? null !== d.activeBreakpoint
                        ? (f !== d.activeBreakpoint || c) &&
                          ((d.activeBreakpoint = f),
                          "unslick" === d.breakpointSettings[f] ? d.unslick(f) : ((d.options = a.extend({}, d.originalSettings, d.breakpointSettings[f])), b === !0 && (d.currentSlide = d.options.initialSlide), d.refresh(b)),
                          (h = f))
                        : ((d.activeBreakpoint = f),
                          "unslick" === d.breakpointSettings[f] ? d.unslick(f) : ((d.options = a.extend({}, d.originalSettings, d.breakpointSettings[f])), b === !0 && (d.currentSlide = d.options.initialSlide), d.refresh(b)),
                          (h = f))
                    : null !== d.activeBreakpoint && ((d.activeBreakpoint = null), (d.options = d.originalSettings), b === !0 && (d.currentSlide = d.options.initialSlide), d.refresh(b), (h = f)),
                    b || h === !1 || d.$slider.trigger("breakpoint", [d, h]);
            }
        }),
        (b.prototype.changeSlide = function (b, c) {
            var f,
                g,
                h,
                d = this,
                e = a(b.currentTarget);
            switch ((e.is("a") && b.preventDefault(), e.is("li") || (e = e.closest("li")), (h = d.slideCount % d.options.slidesToScroll !== 0), (f = h ? 0 : (d.slideCount - d.currentSlide) % d.options.slidesToScroll), b.data.message)) {
                case "previous":
                    (g = 0 === f ? d.options.slidesToScroll : d.options.slidesToShow - f), d.slideCount > d.options.slidesToShow && d.slideHandler(d.currentSlide - g, !1, c);
                    break;
                case "next":
                    (g = 0 === f ? d.options.slidesToScroll : f), d.slideCount > d.options.slidesToShow && d.slideHandler(d.currentSlide + g, !1, c);
                    break;
                case "index":
                    var i = 0 === b.data.index ? 0 : b.data.index || e.index() * d.options.slidesToScroll;
                    d.slideHandler(d.checkNavigable(i), !1, c), e.children().trigger("focus");
                    break;
                default:
                    return;
            }
        }),
        (b.prototype.checkNavigable = function (a) {
            var c,
                d,
                b = this;
            if (((c = b.getNavigableIndexes()), (d = 0), a > c[c.length - 1])) a = c[c.length - 1];
            else
                for (var e in c) {
                    if (a < c[e]) {
                        a = d;
                        break;
                    }
                    d = c[e];
                }
            return a;
        }),
        (b.prototype.cleanUpEvents = function () {
            var b = this;
            b.options.dots && null !== b.$dots && a("li", b.$dots).off("click.slick", b.changeSlide).off("mouseenter.slick", a.proxy(b.interrupt, b, !0)).off("mouseleave.slick", a.proxy(b.interrupt, b, !1)),
                b.$slider.off("focus.slick blur.slick"),
                b.options.arrows === !0 && b.slideCount > b.options.slidesToShow && (b.$prevArrow && b.$prevArrow.off("click.slick", b.changeSlide), b.$nextArrow && b.$nextArrow.off("click.slick", b.changeSlide)),
                b.$list.off("touchstart.slick mousedown.slick", b.swipeHandler),
                b.$list.off("touchmove.slick mousemove.slick", b.swipeHandler),
                b.$list.off("touchend.slick mouseup.slick", b.swipeHandler),
                b.$list.off("touchcancel.slick mouseleave.slick", b.swipeHandler),
                b.$list.off("click.slick", b.clickHandler),
                a(document).off(b.visibilityChange, b.visibility),
                b.cleanUpSlideEvents(),
                b.options.accessibility === !0 && b.$list.off("keydown.slick", b.keyHandler),
                b.options.focusOnSelect === !0 && a(b.$slideTrack).children().off("click.slick", b.selectHandler),
                a(window).off("orientationchange.slick.slick-" + b.instanceUid, b.orientationChange),
                a(window).off("resize.slick.slick-" + b.instanceUid, b.resize),
                a("[draggable!=true]", b.$slideTrack).off("dragstart", b.preventDefault),
                a(window).off("load.slick.slick-" + b.instanceUid, b.setPosition),
                a(document).off("ready.slick.slick-" + b.instanceUid, b.setPosition);
        }),
        (b.prototype.cleanUpSlideEvents = function () {
            var b = this;
            b.$list.off("mouseenter.slick", a.proxy(b.interrupt, b, !0)), b.$list.off("mouseleave.slick", a.proxy(b.interrupt, b, !1));
        }),
        (b.prototype.cleanUpRows = function () {
            var b,
                a = this;
            a.options.rows > 1 && ((b = a.$slides.children().children()), b.removeAttr("style"), a.$slider.empty().append(b));
        }),
        (b.prototype.clickHandler = function (a) {
            var b = this;
            b.shouldClick === !1 && (a.stopImmediatePropagation(), a.stopPropagation(), a.preventDefault());
        }),
        (b.prototype.destroy = function (b) {
            var c = this;
            c.autoPlayClear(),
                (c.touchObject = {}),
                c.cleanUpEvents(),
                a(".slick-cloned", c.$slider).detach(),
                c.$dots && c.$dots.remove(),
                c.$prevArrow &&
                    c.$prevArrow.length &&
                    (c.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""), c.htmlExpr.test(c.options.prevArrow) && c.$prevArrow.remove()),
                c.$nextArrow &&
                    c.$nextArrow.length &&
                    (c.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""), c.htmlExpr.test(c.options.nextArrow) && c.$nextArrow.remove()),
                c.$slides &&
                    (c.$slides
                        .removeClass("slick-slide slick-active slick-center slick-visible slick-current")
                        .removeAttr("aria-hidden")
                        .removeAttr("data-slick-index")
                        .each(function () {
                            a(this).attr("style", a(this).data("originalStyling"));
                        }),
                    c.$slideTrack.children(this.options.slide).detach(),
                    c.$slideTrack.detach(),
                    c.$list.detach(),
                    c.$slider.append(c.$slides)),
                c.cleanUpRows(),
                c.$slider.removeClass("slick-slider"),
                c.$slider.removeClass("slick-initialized"),
                c.$slider.removeClass("slick-dotted"),
                (c.unslicked = !0),
                b || c.$slider.trigger("destroy", [c]);
        }),
        (b.prototype.disableTransition = function (a) {
            var b = this,
                c = {};
            (c[b.transitionType] = ""), b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c);
        }),
        (b.prototype.fadeSlide = function (a, b) {
            var c = this;
            c.cssTransitions === !1
                ? (c.$slides.eq(a).css({ zIndex: c.options.zIndex }), c.$slides.eq(a).animate({ opacity: 1 }, c.options.speed, c.options.easing, b))
                : (c.applyTransition(a),
                  c.$slides.eq(a).css({ opacity: 1, zIndex: c.options.zIndex }),
                  b &&
                      setTimeout(function () {
                          c.disableTransition(a), b.call();
                      }, c.options.speed));
        }),
        (b.prototype.fadeSlideOut = function (a) {
            var b = this;
            b.cssTransitions === !1 ? b.$slides.eq(a).animate({ opacity: 0, zIndex: b.options.zIndex - 2 }, b.options.speed, b.options.easing) : (b.applyTransition(a), b.$slides.eq(a).css({ opacity: 0, zIndex: b.options.zIndex - 2 }));
        }),
        (b.prototype.filterSlides = b.prototype.slickFilter = function (a) {
            var b = this;
            null !== a && ((b.$slidesCache = b.$slides), b.unload(), b.$slideTrack.children(this.options.slide).detach(), b.$slidesCache.filter(a).appendTo(b.$slideTrack), b.reinit());
        }),
        (b.prototype.focusHandler = function () {
            var b = this;
            b.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick", "*:not(.slick-arrow)", function (c) {
                c.stopImmediatePropagation();
                var d = a(this);
                setTimeout(function () {
                    b.options.pauseOnFocus && ((b.focussed = d.is(":focus")), b.autoPlay());
                }, 0);
            });
        }),
        (b.prototype.getCurrent = b.prototype.slickCurrentSlide = function () {
            var a = this;
            return a.currentSlide;
        }),
        (b.prototype.getDotCount = function () {
            var a = this,
                b = 0,
                c = 0,
                d = 0;
            if (a.options.infinite === !0) for (; b < a.slideCount; ) ++d, (b = c + a.options.slidesToScroll), (c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow);
            else if (a.options.centerMode === !0) d = a.slideCount;
            else if (a.options.asNavFor) for (; b < a.slideCount; ) ++d, (b = c + a.options.slidesToScroll), (c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow);
            else d = 1 + Math.ceil((a.slideCount - a.options.slidesToShow) / a.options.slidesToScroll);
            return d - 1;
        }),
        (b.prototype.getLeft = function (a) {
            var c,
                d,
                f,
                b = this,
                e = 0;
            return (
                (b.slideOffset = 0),
                (d = b.$slides.first().outerHeight(!0)),
                b.options.infinite === !0
                    ? (b.slideCount > b.options.slidesToShow && ((b.slideOffset = b.slideWidth * b.options.slidesToShow * -1), (e = d * b.options.slidesToShow * -1)),
                      b.slideCount % b.options.slidesToScroll !== 0 &&
                          a + b.options.slidesToScroll > b.slideCount &&
                          b.slideCount > b.options.slidesToShow &&
                          (a > b.slideCount
                              ? ((b.slideOffset = (b.options.slidesToShow - (a - b.slideCount)) * b.slideWidth * -1), (e = (b.options.slidesToShow - (a - b.slideCount)) * d * -1))
                              : ((b.slideOffset = (b.slideCount % b.options.slidesToScroll) * b.slideWidth * -1), (e = (b.slideCount % b.options.slidesToScroll) * d * -1))))
                    : a + b.options.slidesToShow > b.slideCount && ((b.slideOffset = (a + b.options.slidesToShow - b.slideCount) * b.slideWidth), (e = (a + b.options.slidesToShow - b.slideCount) * d)),
                b.slideCount <= b.options.slidesToShow && ((b.slideOffset = 0), (e = 0)),
                b.options.centerMode === !0 && b.options.infinite === !0
                    ? (b.slideOffset += b.slideWidth * Math.floor(b.options.slidesToShow / 2) - b.slideWidth)
                    : b.options.centerMode === !0 && ((b.slideOffset = 0), (b.slideOffset += b.slideWidth * Math.floor(b.options.slidesToShow / 2))),
                (c = b.options.vertical === !1 ? a * b.slideWidth * -1 + b.slideOffset : a * d * -1 + e),
                b.options.variableWidth === !0 &&
                    ((f = b.slideCount <= b.options.slidesToShow || b.options.infinite === !1 ? b.$slideTrack.children(".slick-slide").eq(a) : b.$slideTrack.children(".slick-slide").eq(a + b.options.slidesToShow)),
                    (c = b.options.rtl === !0 ? (f[0] ? -1 * (b.$slideTrack.width() - f[0].offsetLeft - f.width()) : 0) : f[0] ? -1 * f[0].offsetLeft : 0),
                    b.options.centerMode === !0 &&
                        ((f = b.slideCount <= b.options.slidesToShow || b.options.infinite === !1 ? b.$slideTrack.children(".slick-slide").eq(a) : b.$slideTrack.children(".slick-slide").eq(a + b.options.slidesToShow + 1)),
                        (c = b.options.rtl === !0 ? (f[0] ? -1 * (b.$slideTrack.width() - f[0].offsetLeft - f.width()) : 0) : f[0] ? -1 * f[0].offsetLeft : 0),
                        (c += (b.$list.width() - f.outerWidth()) / 2))),
                c
            );
        }),
        (b.prototype.getOption = b.prototype.slickGetOption = function (a) {
            var b = this;
            return b.options[a];
        }),
        (b.prototype.getNavigableIndexes = function () {
            var e,
                a = this,
                b = 0,
                c = 0,
                d = [];
            for (a.options.infinite === !1 ? (e = a.slideCount) : ((b = -1 * a.options.slidesToScroll), (c = -1 * a.options.slidesToScroll), (e = 2 * a.slideCount)); e > b; )
                d.push(b), (b = c + a.options.slidesToScroll), (c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow);
            return d;
        }),
        (b.prototype.getSlick = function () {
            return this;
        }),
        (b.prototype.getSlideCount = function () {
            var c,
                d,
                e,
                b = this;
            return (
                (e = b.options.centerMode === !0 ? b.slideWidth * Math.floor(b.options.slidesToShow / 2) : 0),
                b.options.swipeToSlide === !0
                    ? (b.$slideTrack.find(".slick-slide").each(function (c, f) {
                          return f.offsetLeft - e + a(f).outerWidth() / 2 > -1 * b.swipeLeft ? ((d = f), !1) : void 0;
                      }),
                      (c = Math.abs(a(d).attr("data-slick-index") - b.currentSlide) || 1))
                    : b.options.slidesToScroll
            );
        }),
        (b.prototype.goTo = b.prototype.slickGoTo = function (a, b) {
            var c = this;
            c.changeSlide({ data: { message: "index", index: parseInt(a) } }, b);
        }),
        (b.prototype.init = function (b) {
            var c = this;
            a(c.$slider).hasClass("slick-initialized") ||
                (a(c.$slider).addClass("slick-initialized"), c.buildRows(), c.buildOut(), c.setProps(), c.startLoad(), c.loadSlider(), c.initializeEvents(), c.updateArrows(), c.updateDots(), c.checkResponsive(!0), c.focusHandler()),
                b && c.$slider.trigger("init", [c]),
                c.options.accessibility === !0 && c.initADA(),
                c.options.autoplay && ((c.paused = !1), c.autoPlay());
        }),
        (b.prototype.initADA = function () {
            var b = this;
            b.$slides.add(b.$slideTrack.find(".slick-cloned")).attr({ "aria-hidden": "true", tabindex: "-1" }).find("a, input, button, select").attr({ tabindex: "-1" }),
                b.$slideTrack.attr("role", "listbox"),
                b.$slides.not(b.$slideTrack.find(".slick-cloned")).each(function (c) {
                    a(this).attr({ role: "option", "aria-describedby": "slick-slide" + b.instanceUid + c });
                }),
                null !== b.$dots &&
                    b.$dots
                        .attr("role", "tablist")
                        .find("li")
                        .each(function (c) {
                            a(this).attr({ role: "presentation", "aria-selected": "false", "aria-controls": "navigation" + b.instanceUid + c, id: "slick-slide" + b.instanceUid + c });
                        })
                        .first()
                        .attr("aria-selected", "true")
                        .end()
                        .find("button")
                        .attr("role", "button")
                        .end()
                        .closest("div")
                        .attr("role", "toolbar"),
                b.activateADA();
        }),
        (b.prototype.initArrowEvents = function () {
            var a = this;
            a.options.arrows === !0 &&
                a.slideCount > a.options.slidesToShow &&
                (a.$prevArrow.off("click.slick").on("click.slick", { message: "previous" }, a.changeSlide), a.$nextArrow.off("click.slick").on("click.slick", { message: "next" }, a.changeSlide));
        }),
        (b.prototype.initDotEvents = function () {
            var b = this;
            b.options.dots === !0 && b.slideCount > b.options.slidesToShow && a("li", b.$dots).on("click.slick", { message: "index" }, b.changeSlide),
                b.options.dots === !0 && b.options.pauseOnDotsHover === !0 && a("li", b.$dots).on("mouseenter.slick", a.proxy(b.interrupt, b, !0)).on("mouseleave.slick", a.proxy(b.interrupt, b, !1));
        }),
        (b.prototype.initSlideEvents = function () {
            var b = this;
            b.options.pauseOnHover && (b.$list.on("mouseenter.slick", a.proxy(b.interrupt, b, !0)), b.$list.on("mouseleave.slick", a.proxy(b.interrupt, b, !1)));
        }),
        (b.prototype.initializeEvents = function () {
            var b = this;
            b.initArrowEvents(),
                b.initDotEvents(),
                b.initSlideEvents(),
                b.$list.on("touchstart.slick mousedown.slick", { action: "start" }, b.swipeHandler),
                b.$list.on("touchmove.slick mousemove.slick", { action: "move" }, b.swipeHandler),
                b.$list.on("touchend.slick mouseup.slick", { action: "end" }, b.swipeHandler),
                b.$list.on("touchcancel.slick mouseleave.slick", { action: "end" }, b.swipeHandler),
                b.$list.on("click.slick", b.clickHandler),
                a(document).on(b.visibilityChange, a.proxy(b.visibility, b)),
                b.options.accessibility === !0 && b.$list.on("keydown.slick", b.keyHandler),
                b.options.focusOnSelect === !0 && a(b.$slideTrack).children().on("click.slick", b.selectHandler),
                a(window).on("orientationchange.slick.slick-" + b.instanceUid, a.proxy(b.orientationChange, b)),
                a(window).on("resize.slick.slick-" + b.instanceUid, a.proxy(b.resize, b)),
                a("[draggable!=true]", b.$slideTrack).on("dragstart", b.preventDefault),
                a(window).on("load.slick.slick-" + b.instanceUid, b.setPosition),
                a(document).on("ready.slick.slick-" + b.instanceUid, b.setPosition);
        }),
        (b.prototype.initUI = function () {
            var a = this;
            a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.show(), a.$nextArrow.show()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.show();
        }),
        (b.prototype.keyHandler = function (a) {
            var b = this;
            a.target.tagName.match("TEXTAREA|INPUT|SELECT") ||
                (37 === a.keyCode && b.options.accessibility === !0
                    ? b.changeSlide({ data: { message: b.options.rtl === !0 ? "next" : "previous" } })
                    : 39 === a.keyCode && b.options.accessibility === !0 && b.changeSlide({ data: { message: b.options.rtl === !0 ? "previous" : "next" } }));
        }),
        (b.prototype.lazyLoad = function () {
            function g(c) {
                a("img[data-lazy]", c).each(function () {
                    var c = a(this),
                        d = a(this).attr("data-lazy"),
                        e = document.createElement("img");
                    (e.onload = function () {
                        c.animate({ opacity: 0 }, 100, function () {
                            c.attr("src", d).animate({ opacity: 1 }, 200, function () {
                                c.removeAttr("data-lazy").removeClass("slick-loading");
                            }),
                                b.$slider.trigger("lazyLoaded", [b, c, d]);
                        });
                    }),
                        (e.onerror = function () {
                            c.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), b.$slider.trigger("lazyLoadError", [b, c, d]);
                        }),
                        (e.src = d);
                });
            }
            var c,
                d,
                e,
                f,
                b = this;
            b.options.centerMode === !0
                ? b.options.infinite === !0
                    ? ((e = b.currentSlide + (b.options.slidesToShow / 2 + 1)), (f = e + b.options.slidesToShow + 2))
                    : ((e = Math.max(0, b.currentSlide - (b.options.slidesToShow / 2 + 1))), (f = 2 + (b.options.slidesToShow / 2 + 1) + b.currentSlide))
                : ((e = b.options.infinite ? b.options.slidesToShow + b.currentSlide : b.currentSlide), (f = Math.ceil(e + b.options.slidesToShow)), b.options.fade === !0 && (e > 0 && e--, f <= b.slideCount && f++)),
                (c = b.$slider.find(".slick-slide").slice(e, f)),
                g(c),
                b.slideCount <= b.options.slidesToShow
                    ? ((d = b.$slider.find(".slick-slide")), g(d))
                    : b.currentSlide >= b.slideCount - b.options.slidesToShow
                    ? ((d = b.$slider.find(".slick-cloned").slice(0, b.options.slidesToShow)), g(d))
                    : 0 === b.currentSlide && ((d = b.$slider.find(".slick-cloned").slice(-1 * b.options.slidesToShow)), g(d));
        }),
        (b.prototype.loadSlider = function () {
            var a = this;
            a.setPosition(), a.$slideTrack.css({ opacity: 1 }), a.$slider.removeClass("slick-loading"), a.initUI(), "progressive" === a.options.lazyLoad && a.progressiveLazyLoad();
        }),
        (b.prototype.next = b.prototype.slickNext = function () {
            var a = this;
            a.changeSlide({ data: { message: "next" } });
        }),
        (b.prototype.orientationChange = function () {
            var a = this;
            a.checkResponsive(), a.setPosition();
        }),
        (b.prototype.pause = b.prototype.slickPause = function () {
            var a = this;
            a.autoPlayClear(), (a.paused = !0);
        }),
        (b.prototype.play = b.prototype.slickPlay = function () {
            var a = this;
            a.autoPlay(), (a.options.autoplay = !0), (a.paused = !1), (a.focussed = !1), (a.interrupted = !1);
        }),
        (b.prototype.postSlide = function (a) {
            var b = this;
            b.unslicked || (b.$slider.trigger("afterChange", [b, a]), (b.animating = !1), b.setPosition(), (b.swipeLeft = null), b.options.autoplay && b.autoPlay(), b.options.accessibility === !0 && b.initADA());
        }),
        (b.prototype.prev = b.prototype.slickPrev = function () {
            var a = this;
            a.changeSlide({ data: { message: "previous" } });
        }),
        (b.prototype.preventDefault = function (a) {
            a.preventDefault();
        }),
        (b.prototype.progressiveLazyLoad = function (b) {
            b = b || 1;
            var e,
                f,
                g,
                c = this,
                d = a("img[data-lazy]", c.$slider);
            d.length
                ? ((e = d.first()),
                  (f = e.attr("data-lazy")),
                  (g = document.createElement("img")),
                  (g.onload = function () {
                      e.attr("src", f).removeAttr("data-lazy").removeClass("slick-loading"), c.options.adaptiveHeight === !0 && c.setPosition(), c.$slider.trigger("lazyLoaded", [c, e, f]), c.progressiveLazyLoad();
                  }),
                  (g.onerror = function () {
                      3 > b
                          ? setTimeout(function () {
                                c.progressiveLazyLoad(b + 1);
                            }, 500)
                          : (e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), c.$slider.trigger("lazyLoadError", [c, e, f]), c.progressiveLazyLoad());
                  }),
                  (g.src = f))
                : c.$slider.trigger("allImagesLoaded", [c]);
        }),
        (b.prototype.refresh = function (b) {
            var d,
                e,
                c = this;
            (e = c.slideCount - c.options.slidesToShow),
                !c.options.infinite && c.currentSlide > e && (c.currentSlide = e),
                c.slideCount <= c.options.slidesToShow && (c.currentSlide = 0),
                (d = c.currentSlide),
                c.destroy(!0),
                a.extend(c, c.initials, { currentSlide: d }),
                c.init(),
                b || c.changeSlide({ data: { message: "index", index: d } }, !1);
        }),
        (b.prototype.registerBreakpoints = function () {
            var c,
                d,
                e,
                b = this,
                f = b.options.responsive || null;
            if ("array" === a.type(f) && f.length) {
                b.respondTo = b.options.respondTo || "window";
                for (c in f)
                    if (((e = b.breakpoints.length - 1), (d = f[c].breakpoint), f.hasOwnProperty(c))) {
                        for (; e >= 0; ) b.breakpoints[e] && b.breakpoints[e] === d && b.breakpoints.splice(e, 1), e--;
                        b.breakpoints.push(d), (b.breakpointSettings[d] = f[c].settings);
                    }
                b.breakpoints.sort(function (a, c) {
                    return b.options.mobileFirst ? a - c : c - a;
                });
            }
        }),
        (b.prototype.reinit = function () {
            var b = this;
            (b.$slides = b.$slideTrack.children(b.options.slide).addClass("slick-slide")),
                (b.slideCount = b.$slides.length),
                b.currentSlide >= b.slideCount && 0 !== b.currentSlide && (b.currentSlide = b.currentSlide - b.options.slidesToScroll),
                b.slideCount <= b.options.slidesToShow && (b.currentSlide = 0),
                b.registerBreakpoints(),
                b.setProps(),
                b.setupInfinite(),
                b.buildArrows(),
                b.updateArrows(),
                b.initArrowEvents(),
                b.buildDots(),
                b.updateDots(),
                b.initDotEvents(),
                b.cleanUpSlideEvents(),
                b.initSlideEvents(),
                b.checkResponsive(!1, !0),
                b.options.focusOnSelect === !0 && a(b.$slideTrack).children().on("click.slick", b.selectHandler),
                b.setSlideClasses("number" == typeof b.currentSlide ? b.currentSlide : 0),
                b.setPosition(),
                b.focusHandler(),
                (b.paused = !b.options.autoplay),
                b.autoPlay(),
                b.$slider.trigger("reInit", [b]);
        }),
        (b.prototype.resize = function () {
            var b = this;
            a(window).width() !== b.windowWidth &&
                (clearTimeout(b.windowDelay),
                (b.windowDelay = window.setTimeout(function () {
                    (b.windowWidth = a(window).width()), b.checkResponsive(), b.unslicked || b.setPosition();
                }, 50)));
        }),
        (b.prototype.removeSlide = b.prototype.slickRemove = function (a, b, c) {
            var d = this;
            return (
                "boolean" == typeof a ? ((b = a), (a = b === !0 ? 0 : d.slideCount - 1)) : (a = b === !0 ? --a : a),
                d.slideCount < 1 || 0 > a || a > d.slideCount - 1
                    ? !1
                    : (d.unload(),
                      c === !0 ? d.$slideTrack.children().remove() : d.$slideTrack.children(this.options.slide).eq(a).remove(),
                      (d.$slides = d.$slideTrack.children(this.options.slide)),
                      d.$slideTrack.children(this.options.slide).detach(),
                      d.$slideTrack.append(d.$slides),
                      (d.$slidesCache = d.$slides),
                      void d.reinit())
            );
        }),
        (b.prototype.setCSS = function (a) {
            var d,
                e,
                b = this,
                c = {};
            b.options.rtl === !0 && (a = -a),
                (d = "left" == b.positionProp ? Math.ceil(a) + "px" : "0px"),
                (e = "top" == b.positionProp ? Math.ceil(a) + "px" : "0px"),
                (c[b.positionProp] = a),
                b.transformsEnabled === !1
                    ? b.$slideTrack.css(c)
                    : ((c = {}), b.cssTransitions === !1 ? ((c[b.animType] = "translate(" + d + ", " + e + ")"), b.$slideTrack.css(c)) : ((c[b.animType] = "translate3d(" + d + ", " + e + ", 0px)"), b.$slideTrack.css(c)));
        }),
        (b.prototype.setDimensions = function () {
            var a = this;
            a.options.vertical === !1
                ? a.options.centerMode === !0 && a.$list.css({ padding: "0px " + a.options.centerPadding })
                : (a.$list.height(a.$slides.first().outerHeight(!0) * a.options.slidesToShow), a.options.centerMode === !0 && a.$list.css({ padding: a.options.centerPadding + " 0px" })),
                (a.listWidth = a.$list.width()),
                (a.listHeight = a.$list.height()),
                a.options.vertical === !1 && a.options.variableWidth === !1
                    ? ((a.slideWidth = Math.ceil(a.listWidth / a.options.slidesToShow)), a.$slideTrack.width(Math.ceil(a.slideWidth * a.$slideTrack.children(".slick-slide").length)))
                    : a.options.variableWidth === !0
                    ? a.$slideTrack.width(5e3 * a.slideCount)
                    : ((a.slideWidth = Math.ceil(a.listWidth)), a.$slideTrack.height(Math.ceil(a.$slides.first().outerHeight(!0) * a.$slideTrack.children(".slick-slide").length)));
            var b = a.$slides.first().outerWidth(!0) - a.$slides.first().width();
            a.options.variableWidth === !1 && a.$slideTrack.children(".slick-slide").width(a.slideWidth - b);
        }),
        (b.prototype.setFade = function () {
            var c,
                b = this;
            b.$slides.each(function (d, e) {
                (c = b.slideWidth * d * -1),
                    b.options.rtl === !0 ? a(e).css({ position: "relative", right: c, top: 0, zIndex: b.options.zIndex - 2, opacity: 0 }) : a(e).css({ position: "relative", left: c, top: 0, zIndex: b.options.zIndex - 2, opacity: 0 });
            }),
                b.$slides.eq(b.currentSlide).css({ zIndex: b.options.zIndex - 1, opacity: 1 });
        }),
        (b.prototype.setHeight = function () {
            var a = this;
            if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
                var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
                a.$list.css("height", b);
            }
        }),
        (b.prototype.setOption = b.prototype.slickSetOption = function () {
            var c,
                d,
                e,
                f,
                h,
                b = this,
                g = !1;
            if (
                ("object" === a.type(arguments[0])
                    ? ((e = arguments[0]), (g = arguments[1]), (h = "multiple"))
                    : "string" === a.type(arguments[0]) &&
                      ((e = arguments[0]), (f = arguments[1]), (g = arguments[2]), "responsive" === arguments[0] && "array" === a.type(arguments[1]) ? (h = "responsive") : "undefined" != typeof arguments[1] && (h = "single")),
                "single" === h)
            )
                b.options[e] = f;
            else if ("multiple" === h)
                a.each(e, function (a, c) {
                    b.options[a] = c;
                });
            else if ("responsive" === h)
                for (d in f)
                    if ("array" !== a.type(b.options.responsive)) b.options.responsive = [f[d]];
                    else {
                        for (c = b.options.responsive.length - 1; c >= 0; ) b.options.responsive[c].breakpoint === f[d].breakpoint && b.options.responsive.splice(c, 1), c--;
                        b.options.responsive.push(f[d]);
                    }
            g && (b.unload(), b.reinit());
        }),
        (b.prototype.setPosition = function () {
            var a = this;
            a.setDimensions(), a.setHeight(), a.options.fade === !1 ? a.setCSS(a.getLeft(a.currentSlide)) : a.setFade(), a.$slider.trigger("setPosition", [a]);
        }),
        (b.prototype.setProps = function () {
            var a = this,
                b = document.body.style;
            (a.positionProp = a.options.vertical === !0 ? "top" : "left"),
                "top" === a.positionProp ? a.$slider.addClass("slick-vertical") : a.$slider.removeClass("slick-vertical"),
                (void 0 !== b.WebkitTransition || void 0 !== b.MozTransition || void 0 !== b.msTransition) && a.options.useCSS === !0 && (a.cssTransitions = !0),
                a.options.fade && ("number" == typeof a.options.zIndex ? a.options.zIndex < 3 && (a.options.zIndex = 3) : (a.options.zIndex = a.defaults.zIndex)),
                void 0 !== b.OTransform && ((a.animType = "OTransform"), (a.transformType = "-o-transform"), (a.transitionType = "OTransition"), void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)),
                void 0 !== b.MozTransform && ((a.animType = "MozTransform"), (a.transformType = "-moz-transform"), (a.transitionType = "MozTransition"), void 0 === b.perspectiveProperty && void 0 === b.MozPerspective && (a.animType = !1)),
                void 0 !== b.webkitTransform &&
                    ((a.animType = "webkitTransform"), (a.transformType = "-webkit-transform"), (a.transitionType = "webkitTransition"), void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)),
                void 0 !== b.msTransform && ((a.animType = "msTransform"), (a.transformType = "-ms-transform"), (a.transitionType = "msTransition"), void 0 === b.msTransform && (a.animType = !1)),
                void 0 !== b.transform && a.animType !== !1 && ((a.animType = "transform"), (a.transformType = "transform"), (a.transitionType = "transition")),
                (a.transformsEnabled = a.options.useTransform && null !== a.animType && a.animType !== !1);
        }),
        (b.prototype.setSlideClasses = function (a) {
            var c,
                d,
                e,
                f,
                b = this;
            (d = b.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden", "true")),
                b.$slides.eq(a).addClass("slick-current"),
                b.options.centerMode === !0
                    ? ((c = Math.floor(b.options.slidesToShow / 2)),
                      b.options.infinite === !0 &&
                          (a >= c && a <= b.slideCount - 1 - c
                              ? b.$slides
                                    .slice(a - c, a + c + 1)
                                    .addClass("slick-active")
                                    .attr("aria-hidden", "false")
                              : ((e = b.options.slidesToShow + a),
                                d
                                    .slice(e - c + 1, e + c + 2)
                                    .addClass("slick-active")
                                    .attr("aria-hidden", "false")),
                          0 === a ? d.eq(d.length - 1 - b.options.slidesToShow).addClass("slick-center") : a === b.slideCount - 1 && d.eq(b.options.slidesToShow).addClass("slick-center")),
                      b.$slides.eq(a).addClass("slick-center"))
                    : a >= 0 && a <= b.slideCount - b.options.slidesToShow
                    ? b.$slides
                          .slice(a, a + b.options.slidesToShow)
                          .addClass("slick-active")
                          .attr("aria-hidden", "false")
                    : d.length <= b.options.slidesToShow
                    ? d.addClass("slick-active").attr("aria-hidden", "false")
                    : ((f = b.slideCount % b.options.slidesToShow),
                      (e = b.options.infinite === !0 ? b.options.slidesToShow + a : a),
                      b.options.slidesToShow == b.options.slidesToScroll && b.slideCount - a < b.options.slidesToShow
                          ? d
                                .slice(e - (b.options.slidesToShow - f), e + f)
                                .addClass("slick-active")
                                .attr("aria-hidden", "false")
                          : d
                                .slice(e, e + b.options.slidesToShow)
                                .addClass("slick-active")
                                .attr("aria-hidden", "false")),
                "ondemand" === b.options.lazyLoad && b.lazyLoad();
        }),
        (b.prototype.setupInfinite = function () {
            var c,
                d,
                e,
                b = this;
            if ((b.options.fade === !0 && (b.options.centerMode = !1), b.options.infinite === !0 && b.options.fade === !1 && ((d = null), b.slideCount > b.options.slidesToShow))) {
                for (e = b.options.centerMode === !0 ? b.options.slidesToShow + 1 : b.options.slidesToShow, c = b.slideCount; c > b.slideCount - e; c -= 1)
                    (d = c - 1),
                        a(b.$slides[d])
                            .clone(!0)
                            .attr("id", "")
                            .attr("data-slick-index", d - b.slideCount)
                            .prependTo(b.$slideTrack)
                            .addClass("slick-cloned");
                for (c = 0; e > c; c += 1)
                    (d = c),
                        a(b.$slides[d])
                            .clone(!0)
                            .attr("id", "")
                            .attr("data-slick-index", d + b.slideCount)
                            .appendTo(b.$slideTrack)
                            .addClass("slick-cloned");
                b.$slideTrack
                    .find(".slick-cloned")
                    .find("[id]")
                    .each(function () {
                        a(this).attr("id", "");
                    });
            }
        }),
        (b.prototype.interrupt = function (a) {
            var b = this;
            a || b.autoPlay(), (b.interrupted = a);
        }),
        (b.prototype.selectHandler = function (b) {
            var c = this,
                d = a(b.target).is(".slick-slide") ? a(b.target) : a(b.target).parents(".slick-slide"),
                e = parseInt(d.attr("data-slick-index"));
            return e || (e = 0), c.slideCount <= c.options.slidesToShow ? (c.setSlideClasses(e), void c.asNavFor(e)) : void c.slideHandler(e);
        }),
        (b.prototype.slideHandler = function (a, b, c) {
            var d,
                e,
                f,
                g,
                j,
                h = null,
                i = this;
            return (
                (b = b || !1),
                (i.animating === !0 && i.options.waitForAnimate === !0) || (i.options.fade === !0 && i.currentSlide === a) || i.slideCount <= i.options.slidesToShow
                    ? void 0
                    : (b === !1 && i.asNavFor(a),
                      (d = a),
                      (h = i.getLeft(d)),
                      (g = i.getLeft(i.currentSlide)),
                      (i.currentLeft = null === i.swipeLeft ? g : i.swipeLeft),
                      i.options.infinite === !1 && i.options.centerMode === !1 && (0 > a || a > i.getDotCount() * i.options.slidesToScroll)
                          ? void (
                                i.options.fade === !1 &&
                                ((d = i.currentSlide),
                                c !== !0
                                    ? i.animateSlide(g, function () {
                                          i.postSlide(d);
                                      })
                                    : i.postSlide(d))
                            )
                          : i.options.infinite === !1 && i.options.centerMode === !0 && (0 > a || a > i.slideCount - i.options.slidesToScroll)
                          ? void (
                                i.options.fade === !1 &&
                                ((d = i.currentSlide),
                                c !== !0
                                    ? i.animateSlide(g, function () {
                                          i.postSlide(d);
                                      })
                                    : i.postSlide(d))
                            )
                          : (i.options.autoplay && clearInterval(i.autoPlayTimer),
                            (e =
                                0 > d
                                    ? i.slideCount % i.options.slidesToScroll !== 0
                                        ? i.slideCount - (i.slideCount % i.options.slidesToScroll)
                                        : i.slideCount + d
                                    : d >= i.slideCount
                                    ? i.slideCount % i.options.slidesToScroll !== 0
                                        ? 0
                                        : d - i.slideCount
                                    : d),
                            (i.animating = !0),
                            i.$slider.trigger("beforeChange", [i, i.currentSlide, e]),
                            (f = i.currentSlide),
                            (i.currentSlide = e),
                            i.setSlideClasses(i.currentSlide),
                            i.options.asNavFor && ((j = i.getNavTarget()), (j = j.slick("getSlick")), j.slideCount <= j.options.slidesToShow && j.setSlideClasses(i.currentSlide)),
                            i.updateDots(),
                            i.updateArrows(),
                            i.options.fade === !0
                                ? (c !== !0
                                      ? (i.fadeSlideOut(f),
                                        i.fadeSlide(e, function () {
                                            i.postSlide(e);
                                        }))
                                      : i.postSlide(e),
                                  void i.animateHeight())
                                : void (c !== !0
                                      ? i.animateSlide(h, function () {
                                            i.postSlide(e);
                                        })
                                      : i.postSlide(e))))
            );
        }),
        (b.prototype.startLoad = function () {
            var a = this;
            a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.hide(), a.$nextArrow.hide()),
                a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.hide(),
                a.$slider.addClass("slick-loading");
        }),
        (b.prototype.swipeDirection = function () {
            var a,
                b,
                c,
                d,
                e = this;
            return (
                (a = e.touchObject.startX - e.touchObject.curX),
                (b = e.touchObject.startY - e.touchObject.curY),
                (c = Math.atan2(b, a)),
                (d = Math.round((180 * c) / Math.PI)),
                0 > d && (d = 360 - Math.abs(d)),
                45 >= d && d >= 0
                    ? e.options.rtl === !1
                        ? "left"
                        : "right"
                    : 360 >= d && d >= 315
                    ? e.options.rtl === !1
                        ? "left"
                        : "right"
                    : d >= 135 && 225 >= d
                    ? e.options.rtl === !1
                        ? "right"
                        : "left"
                    : e.options.verticalSwiping === !0
                    ? d >= 35 && 135 >= d
                        ? "down"
                        : "up"
                    : "vertical"
            );
        }),
        (b.prototype.swipeEnd = function (a) {
            var c,
                d,
                b = this;
            if (((b.dragging = !1), (b.interrupted = !1), (b.shouldClick = b.touchObject.swipeLength > 10 ? !1 : !0), void 0 === b.touchObject.curX)) return !1;
            if ((b.touchObject.edgeHit === !0 && b.$slider.trigger("edge", [b, b.swipeDirection()]), b.touchObject.swipeLength >= b.touchObject.minSwipe)) {
                switch ((d = b.swipeDirection())) {
                    case "left":
                    case "down":
                        (c = b.options.swipeToSlide ? b.checkNavigable(b.currentSlide + b.getSlideCount()) : b.currentSlide + b.getSlideCount()), (b.currentDirection = 0);
                        break;
                    case "right":
                    case "up":
                        (c = b.options.swipeToSlide ? b.checkNavigable(b.currentSlide - b.getSlideCount()) : b.currentSlide - b.getSlideCount()), (b.currentDirection = 1);
                }
                "vertical" != d && (b.slideHandler(c), (b.touchObject = {}), b.$slider.trigger("swipe", [b, d]));
            } else b.touchObject.startX !== b.touchObject.curX && (b.slideHandler(b.currentSlide), (b.touchObject = {}));
        }),
        (b.prototype.swipeHandler = function (a) {
            var b = this;
            if (!(b.options.swipe === !1 || ("ontouchend" in document && b.options.swipe === !1) || (b.options.draggable === !1 && -1 !== a.type.indexOf("mouse"))))
                switch (
                    ((b.touchObject.fingerCount = a.originalEvent && void 0 !== a.originalEvent.touches ? a.originalEvent.touches.length : 1),
                    (b.touchObject.minSwipe = b.listWidth / b.options.touchThreshold),
                    b.options.verticalSwiping === !0 && (b.touchObject.minSwipe = b.listHeight / b.options.touchThreshold),
                    a.data.action)
                ) {
                    case "start":
                        b.swipeStart(a);
                        break;
                    case "move":
                        b.swipeMove(a);
                        break;
                    case "end":
                        b.swipeEnd(a);
                }
        }),
        (b.prototype.swipeMove = function (a) {
            var d,
                e,
                f,
                g,
                h,
                b = this;
            return (
                (h = void 0 !== a.originalEvent ? a.originalEvent.touches : null),
                !b.dragging || (h && 1 !== h.length)
                    ? !1
                    : ((d = b.getLeft(b.currentSlide)),
                      (b.touchObject.curX = void 0 !== h ? h[0].pageX : a.clientX),
                      (b.touchObject.curY = void 0 !== h ? h[0].pageY : a.clientY),
                      (b.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(b.touchObject.curX - b.touchObject.startX, 2)))),
                      b.options.verticalSwiping === !0 && (b.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(b.touchObject.curY - b.touchObject.startY, 2)))),
                      (e = b.swipeDirection()),
                      "vertical" !== e
                          ? (void 0 !== a.originalEvent && b.touchObject.swipeLength > 4 && a.preventDefault(),
                            (g = (b.options.rtl === !1 ? 1 : -1) * (b.touchObject.curX > b.touchObject.startX ? 1 : -1)),
                            b.options.verticalSwiping === !0 && (g = b.touchObject.curY > b.touchObject.startY ? 1 : -1),
                            (f = b.touchObject.swipeLength),
                            (b.touchObject.edgeHit = !1),
                            b.options.infinite === !1 &&
                                ((0 === b.currentSlide && "right" === e) || (b.currentSlide >= b.getDotCount() && "left" === e)) &&
                                ((f = b.touchObject.swipeLength * b.options.edgeFriction), (b.touchObject.edgeHit = !0)),
                            b.options.vertical === !1 ? (b.swipeLeft = d + f * g) : (b.swipeLeft = d + f * (b.$list.height() / b.listWidth) * g),
                            b.options.verticalSwiping === !0 && (b.swipeLeft = d + f * g),
                            b.options.fade === !0 || b.options.touchMove === !1 ? !1 : b.animating === !0 ? ((b.swipeLeft = null), !1) : void b.setCSS(b.swipeLeft))
                          : void 0)
            );
        }),
        (b.prototype.swipeStart = function (a) {
            var c,
                b = this;
            return (
                (b.interrupted = !0),
                1 !== b.touchObject.fingerCount || b.slideCount <= b.options.slidesToShow
                    ? ((b.touchObject = {}), !1)
                    : (void 0 !== a.originalEvent && void 0 !== a.originalEvent.touches && (c = a.originalEvent.touches[0]),
                      (b.touchObject.startX = b.touchObject.curX = void 0 !== c ? c.pageX : a.clientX),
                      (b.touchObject.startY = b.touchObject.curY = void 0 !== c ? c.pageY : a.clientY),
                      void (b.dragging = !0))
            );
        }),
        (b.prototype.unfilterSlides = b.prototype.slickUnfilter = function () {
            var a = this;
            null !== a.$slidesCache && (a.unload(), a.$slideTrack.children(this.options.slide).detach(), a.$slidesCache.appendTo(a.$slideTrack), a.reinit());
        }),
        (b.prototype.unload = function () {
            var b = this;
            a(".slick-cloned", b.$slider).remove(),
                b.$dots && b.$dots.remove(),
                b.$prevArrow && b.htmlExpr.test(b.options.prevArrow) && b.$prevArrow.remove(),
                b.$nextArrow && b.htmlExpr.test(b.options.nextArrow) && b.$nextArrow.remove(),
                b.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden", "true").css("width", "");
        }),
        (b.prototype.unslick = function (a) {
            var b = this;
            b.$slider.trigger("unslick", [b, a]), b.destroy();
        }),
        (b.prototype.updateArrows = function () {
            var b,
                a = this;
            (b = Math.floor(a.options.slidesToShow / 2)),
                a.options.arrows === !0 &&
                    a.slideCount > a.options.slidesToShow &&
                    !a.options.infinite &&
                    (a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
                    a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
                    0 === a.currentSlide
                        ? (a.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"), a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"))
                        : a.currentSlide >= a.slideCount - a.options.slidesToShow && a.options.centerMode === !1
                        ? (a.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"), a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"))
                        : a.currentSlide >= a.slideCount - 1 &&
                          a.options.centerMode === !0 &&
                          (a.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"), a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")));
        }),
        (b.prototype.updateDots = function () {
            var a = this;
            null !== a.$dots &&
                (a.$dots.find("li").removeClass("slick-active").attr("aria-hidden", "true"),
                a.$dots
                    .find("li")
                    .eq(Math.floor(a.currentSlide / a.options.slidesToScroll))
                    .addClass("slick-active")
                    .attr("aria-hidden", "false"));
        }),
        (b.prototype.visibility = function () {
            var a = this;
            a.options.autoplay && (document[a.hidden] ? (a.interrupted = !0) : (a.interrupted = !1));
        }),
        (a.fn.slick = function () {
            var f,
                g,
                a = this,
                c = arguments[0],
                d = Array.prototype.slice.call(arguments, 1),
                e = a.length;
            for (f = 0; e > f; f++) if (("object" == typeof c || "undefined" == typeof c ? (a[f].slick = new b(a[f], c)) : (g = a[f].slick[c].apply(a[f].slick, d)), "undefined" != typeof g)) return g;
            return a;
        });
});

/*-------------------------------------------------------------
  6. Isotope jQuery
---------------------------------------------------------------*/
/*!
 * Isotope PACKAGED v3.0.2
 *
 * Licensed GPLv3 for open source use
 * or Isotope Commercial License for commercial use
 *
 * http://isotope.metafizzy.co
 * Copyright 2016 Metafizzy
 */

!(function (t, e) {
    "function" == typeof define && define.amd
        ? define("jquery-bridget/jquery-bridget", ["jquery"], function (i) {
              return e(t, i);
          })
        : "object" == typeof module && module.exports
        ? (module.exports = e(t, require("jquery")))
        : (t.jQueryBridget = e(t, t.jQuery));
})(window, function (t, e) {
    "use strict";
    function i(i, s, a) {
        function u(t, e, n) {
            var o,
                s = "$()." + i + '("' + e + '")';
            return (
                t.each(function (t, u) {
                    var h = a.data(u, i);
                    if (!h) return void r(i + " not initialized. Cannot call methods, i.e. " + s);
                    var d = h[e];
                    if (!d || "_" == e.charAt(0)) return void r(s + " is not a valid method");
                    var l = d.apply(h, n);
                    o = void 0 === o ? l : o;
                }),
                void 0 !== o ? o : t
            );
        }
        function h(t, e) {
            t.each(function (t, n) {
                var o = a.data(n, i);
                o ? (o.option(e), o._init()) : ((o = new s(n, e)), a.data(n, i, o));
            });
        }
        (a = a || e || t.jQuery),
            a &&
                (s.prototype.option ||
                    (s.prototype.option = function (t) {
                        a.isPlainObject(t) && (this.options = a.extend(!0, this.options, t));
                    }),
                (a.fn[i] = function (t) {
                    if ("string" == typeof t) {
                        var e = o.call(arguments, 1);
                        return u(this, t, e);
                    }
                    return h(this, t), this;
                }),
                n(a));
    }
    function n(t) {
        !t || (t && t.bridget) || (t.bridget = i);
    }
    var o = Array.prototype.slice,
        s = t.console,
        r =
            "undefined" == typeof s
                ? function () {}
                : function (t) {
                      s.error(t);
                  };
    return n(e || t.jQuery), i;
}),
    (function (t, e) {
        "function" == typeof define && define.amd ? define("ev-emitter/ev-emitter", e) : "object" == typeof module && module.exports ? (module.exports = e()) : (t.EvEmitter = e());
    })("undefined" != typeof window ? window : this, function () {
        function t() {}
        var e = t.prototype;
        return (
            (e.on = function (t, e) {
                if (t && e) {
                    var i = (this._events = this._events || {}),
                        n = (i[t] = i[t] || []);
                    return n.indexOf(e) == -1 && n.push(e), this;
                }
            }),
            (e.once = function (t, e) {
                if (t && e) {
                    this.on(t, e);
                    var i = (this._onceEvents = this._onceEvents || {}),
                        n = (i[t] = i[t] || {});
                    return (n[e] = !0), this;
                }
            }),
            (e.off = function (t, e) {
                var i = this._events && this._events[t];
                if (i && i.length) {
                    var n = i.indexOf(e);
                    return n != -1 && i.splice(n, 1), this;
                }
            }),
            (e.emitEvent = function (t, e) {
                var i = this._events && this._events[t];
                if (i && i.length) {
                    var n = 0,
                        o = i[n];
                    e = e || [];
                    for (var s = this._onceEvents && this._onceEvents[t]; o; ) {
                        var r = s && s[o];
                        r && (this.off(t, o), delete s[o]), o.apply(this, e), (n += r ? 0 : 1), (o = i[n]);
                    }
                    return this;
                }
            }),
            t
        );
    }),
    (function (t, e) {
        "use strict";
        "function" == typeof define && define.amd
            ? define("get-size/get-size", [], function () {
                  return e();
              })
            : "object" == typeof module && module.exports
            ? (module.exports = e())
            : (t.getSize = e());
    })(window, function () {
        "use strict";
        function t(t) {
            var e = parseFloat(t),
                i = t.indexOf("%") == -1 && !isNaN(e);
            return i && e;
        }
        function e() {}
        function i() {
            for (var t = { width: 0, height: 0, innerWidth: 0, innerHeight: 0, outerWidth: 0, outerHeight: 0 }, e = 0; e < h; e++) {
                var i = u[e];
                t[i] = 0;
            }
            return t;
        }
        function n(t) {
            var e = getComputedStyle(t);
            return e || a("Style returned " + e + ". Are you running this code in a hidden iframe on Firefox? See http://bit.ly/getsizebug1"), e;
        }
        function o() {
            if (!d) {
                d = !0;
                var e = document.createElement("div");
                (e.style.width = "200px"), (e.style.padding = "1px 2px 3px 4px"), (e.style.borderStyle = "solid"), (e.style.borderWidth = "1px 2px 3px 4px"), (e.style.boxSizing = "border-box");
                var i = document.body || document.documentElement;
                i.appendChild(e);
                var o = n(e);
                (s.isBoxSizeOuter = r = 200 == t(o.width)), i.removeChild(e);
            }
        }
        function s(e) {
            if ((o(), "string" == typeof e && (e = document.querySelector(e)), e && "object" == typeof e && e.nodeType)) {
                var s = n(e);
                if ("none" == s.display) return i();
                var a = {};
                (a.width = e.offsetWidth), (a.height = e.offsetHeight);
                for (var d = (a.isBorderBox = "border-box" == s.boxSizing), l = 0; l < h; l++) {
                    var f = u[l],
                        c = s[f],
                        m = parseFloat(c);
                    a[f] = isNaN(m) ? 0 : m;
                }
                var p = a.paddingLeft + a.paddingRight,
                    y = a.paddingTop + a.paddingBottom,
                    g = a.marginLeft + a.marginRight,
                    v = a.marginTop + a.marginBottom,
                    _ = a.borderLeftWidth + a.borderRightWidth,
                    I = a.borderTopWidth + a.borderBottomWidth,
                    z = d && r,
                    x = t(s.width);
                x !== !1 && (a.width = x + (z ? 0 : p + _));
                var S = t(s.height);
                return S !== !1 && (a.height = S + (z ? 0 : y + I)), (a.innerWidth = a.width - (p + _)), (a.innerHeight = a.height - (y + I)), (a.outerWidth = a.width + g), (a.outerHeight = a.height + v), a;
            }
        }
        var r,
            a =
                "undefined" == typeof console
                    ? e
                    : function (t) {
                          console.error(t);
                      },
            u = ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "marginLeft", "marginRight", "marginTop", "marginBottom", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"],
            h = u.length,
            d = !1;
        return s;
    }),
    (function (t, e) {
        "use strict";
        "function" == typeof define && define.amd ? define("desandro-matches-selector/matches-selector", e) : "object" == typeof module && module.exports ? (module.exports = e()) : (t.matchesSelector = e());
    })(window, function () {
        "use strict";
        var t = (function () {
            var t = Element.prototype;
            if (t.matches) return "matches";
            if (t.matchesSelector) return "matchesSelector";
            for (var e = ["webkit", "moz", "ms", "o"], i = 0; i < e.length; i++) {
                var n = e[i],
                    o = n + "MatchesSelector";
                if (t[o]) return o;
            }
        })();
        return function (e, i) {
            return e[t](i);
        };
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define("fizzy-ui-utils/utils", ["desandro-matches-selector/matches-selector"], function (i) {
                  return e(t, i);
              })
            : "object" == typeof module && module.exports
            ? (module.exports = e(t, require("desandro-matches-selector")))
            : (t.fizzyUIUtils = e(t, t.matchesSelector));
    })(window, function (t, e) {
        var i = {};
        (i.extend = function (t, e) {
            for (var i in e) t[i] = e[i];
            return t;
        }),
            (i.modulo = function (t, e) {
                return ((t % e) + e) % e;
            }),
            (i.makeArray = function (t) {
                var e = [];
                if (Array.isArray(t)) e = t;
                else if (t && "number" == typeof t.length) for (var i = 0; i < t.length; i++) e.push(t[i]);
                else e.push(t);
                return e;
            }),
            (i.removeFrom = function (t, e) {
                var i = t.indexOf(e);
                i != -1 && t.splice(i, 1);
            }),
            (i.getParent = function (t, i) {
                for (; t != document.body; ) if (((t = t.parentNode), e(t, i))) return t;
            }),
            (i.getQueryElement = function (t) {
                return "string" == typeof t ? document.querySelector(t) : t;
            }),
            (i.handleEvent = function (t) {
                var e = "on" + t.type;
                this[e] && this[e](t);
            }),
            (i.filterFindElements = function (t, n) {
                t = i.makeArray(t);
                var o = [];
                return (
                    t.forEach(function (t) {
                        if (t instanceof HTMLElement) {
                            if (!n) return void o.push(t);
                            e(t, n) && o.push(t);
                            for (var i = t.querySelectorAll(n), s = 0; s < i.length; s++) o.push(i[s]);
                        }
                    }),
                    o
                );
            }),
            (i.debounceMethod = function (t, e, i) {
                var n = t.prototype[e],
                    o = e + "Timeout";
                t.prototype[e] = function () {
                    var t = this[o];
                    t && clearTimeout(t);
                    var e = arguments,
                        s = this;
                    this[o] = setTimeout(function () {
                        n.apply(s, e), delete s[o];
                    }, i || 100);
                };
            }),
            (i.docReady = function (t) {
                var e = document.readyState;
                "complete" == e || "interactive" == e ? setTimeout(t) : document.addEventListener("DOMContentLoaded", t);
            }),
            (i.toDashed = function (t) {
                return t
                    .replace(/(.)([A-Z])/g, function (t, e, i) {
                        return e + "-" + i;
                    })
                    .toLowerCase();
            });
        var n = t.console;
        return (
            (i.htmlInit = function (e, o) {
                i.docReady(function () {
                    var s = i.toDashed(o),
                        r = "data-" + s,
                        a = document.querySelectorAll("[" + r + "]"),
                        u = document.querySelectorAll(".js-" + s),
                        h = i.makeArray(a).concat(i.makeArray(u)),
                        d = r + "-options",
                        l = t.jQuery;
                    h.forEach(function (t) {
                        var i,
                            s = t.getAttribute(r) || t.getAttribute(d);
                        try {
                            i = s && JSON.parse(s);
                        } catch (a) {
                            return void (n && n.error("Error parsing " + r + " on " + t.className + ": " + a));
                        }
                        var u = new e(t, i);
                        l && l.data(t, o, u);
                    });
                });
            }),
            i
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define("outlayer/item", ["ev-emitter/ev-emitter", "get-size/get-size"], e)
            : "object" == typeof module && module.exports
            ? (module.exports = e(require("ev-emitter"), require("get-size")))
            : ((t.Outlayer = {}), (t.Outlayer.Item = e(t.EvEmitter, t.getSize)));
    })(window, function (t, e) {
        "use strict";
        function i(t) {
            for (var e in t) return !1;
            return (e = null), !0;
        }
        function n(t, e) {
            t && ((this.element = t), (this.layout = e), (this.position = { x: 0, y: 0 }), this._create());
        }
        function o(t) {
            return t.replace(/([A-Z])/g, function (t) {
                return "-" + t.toLowerCase();
            });
        }
        var s = document.documentElement.style,
            r = "string" == typeof s.transition ? "transition" : "WebkitTransition",
            a = "string" == typeof s.transform ? "transform" : "WebkitTransform",
            u = { WebkitTransition: "webkitTransitionEnd", transition: "transitionend" }[r],
            h = { transform: a, transition: r, transitionDuration: r + "Duration", transitionProperty: r + "Property", transitionDelay: r + "Delay" },
            d = (n.prototype = Object.create(t.prototype));
        (d.constructor = n),
            (d._create = function () {
                (this._transn = { ingProperties: {}, clean: {}, onEnd: {} }), this.css({ position: "absolute" });
            }),
            (d.handleEvent = function (t) {
                var e = "on" + t.type;
                this[e] && this[e](t);
            }),
            (d.getSize = function () {
                this.size = e(this.element);
            }),
            (d.css = function (t) {
                var e = this.element.style;
                for (var i in t) {
                    var n = h[i] || i;
                    e[n] = t[i];
                }
            }),
            (d.getPosition = function () {
                var t = getComputedStyle(this.element),
                    e = this.layout._getOption("originLeft"),
                    i = this.layout._getOption("originTop"),
                    n = t[e ? "left" : "right"],
                    o = t[i ? "top" : "bottom"],
                    s = this.layout.size,
                    r = n.indexOf("%") != -1 ? (parseFloat(n) / 100) * s.width : parseInt(n, 10),
                    a = o.indexOf("%") != -1 ? (parseFloat(o) / 100) * s.height : parseInt(o, 10);
                (r = isNaN(r) ? 0 : r), (a = isNaN(a) ? 0 : a), (r -= e ? s.paddingLeft : s.paddingRight), (a -= i ? s.paddingTop : s.paddingBottom), (this.position.x = r), (this.position.y = a);
            }),
            (d.layoutPosition = function () {
                var t = this.layout.size,
                    e = {},
                    i = this.layout._getOption("originLeft"),
                    n = this.layout._getOption("originTop"),
                    o = i ? "paddingLeft" : "paddingRight",
                    s = i ? "left" : "right",
                    r = i ? "right" : "left",
                    a = this.position.x + t[o];
                (e[s] = this.getXValue(a)), (e[r] = "");
                var u = n ? "paddingTop" : "paddingBottom",
                    h = n ? "top" : "bottom",
                    d = n ? "bottom" : "top",
                    l = this.position.y + t[u];
                (e[h] = this.getYValue(l)), (e[d] = ""), this.css(e), this.emitEvent("layout", [this]);
            }),
            (d.getXValue = function (t) {
                var e = this.layout._getOption("horizontal");
                return this.layout.options.percentPosition && !e ? (t / this.layout.size.width) * 100 + "%" : t + "px";
            }),
            (d.getYValue = function (t) {
                var e = this.layout._getOption("horizontal");
                return this.layout.options.percentPosition && e ? (t / this.layout.size.height) * 100 + "%" : t + "px";
            }),
            (d._transitionTo = function (t, e) {
                this.getPosition();
                var i = this.position.x,
                    n = this.position.y,
                    o = parseInt(t, 10),
                    s = parseInt(e, 10),
                    r = o === this.position.x && s === this.position.y;
                if ((this.setPosition(t, e), r && !this.isTransitioning)) return void this.layoutPosition();
                var a = t - i,
                    u = e - n,
                    h = {};
                (h.transform = this.getTranslate(a, u)), this.transition({ to: h, onTransitionEnd: { transform: this.layoutPosition }, isCleaning: !0 });
            }),
            (d.getTranslate = function (t, e) {
                var i = this.layout._getOption("originLeft"),
                    n = this.layout._getOption("originTop");
                return (t = i ? t : -t), (e = n ? e : -e), "translate3d(" + t + "px, " + e + "px, 0)";
            }),
            (d.goTo = function (t, e) {
                this.setPosition(t, e), this.layoutPosition();
            }),
            (d.moveTo = d._transitionTo),
            (d.setPosition = function (t, e) {
                (this.position.x = parseInt(t, 10)), (this.position.y = parseInt(e, 10));
            }),
            (d._nonTransition = function (t) {
                this.css(t.to), t.isCleaning && this._removeStyles(t.to);
                for (var e in t.onTransitionEnd) t.onTransitionEnd[e].call(this);
            }),
            (d.transition = function (t) {
                if (!parseFloat(this.layout.options.transitionDuration)) return void this._nonTransition(t);
                var e = this._transn;
                for (var i in t.onTransitionEnd) e.onEnd[i] = t.onTransitionEnd[i];
                for (i in t.to) (e.ingProperties[i] = !0), t.isCleaning && (e.clean[i] = !0);
                if (t.from) {
                    this.css(t.from);
                    var n = this.element.offsetHeight;
                    n = null;
                }
                this.enableTransition(t.to), this.css(t.to), (this.isTransitioning = !0);
            });
        var l = "opacity," + o(a);
        (d.enableTransition = function () {
            if (!this.isTransitioning) {
                var t = this.layout.options.transitionDuration;
                (t = "number" == typeof t ? t + "ms" : t), this.css({ transitionProperty: l, transitionDuration: t, transitionDelay: this.staggerDelay || 0 }), this.element.addEventListener(u, this, !1);
            }
        }),
            (d.onwebkitTransitionEnd = function (t) {
                this.ontransitionend(t);
            }),
            (d.onotransitionend = function (t) {
                this.ontransitionend(t);
            });
        var f = { "-webkit-transform": "transform" };
        (d.ontransitionend = function (t) {
            if (t.target === this.element) {
                var e = this._transn,
                    n = f[t.propertyName] || t.propertyName;
                if ((delete e.ingProperties[n], i(e.ingProperties) && this.disableTransition(), n in e.clean && ((this.element.style[t.propertyName] = ""), delete e.clean[n]), n in e.onEnd)) {
                    var o = e.onEnd[n];
                    o.call(this), delete e.onEnd[n];
                }
                this.emitEvent("transitionEnd", [this]);
            }
        }),
            (d.disableTransition = function () {
                this.removeTransitionStyles(), this.element.removeEventListener(u, this, !1), (this.isTransitioning = !1);
            }),
            (d._removeStyles = function (t) {
                var e = {};
                for (var i in t) e[i] = "";
                this.css(e);
            });
        var c = { transitionProperty: "", transitionDuration: "", transitionDelay: "" };
        return (
            (d.removeTransitionStyles = function () {
                this.css(c);
            }),
            (d.stagger = function (t) {
                (t = isNaN(t) ? 0 : t), (this.staggerDelay = t + "ms");
            }),
            (d.removeElem = function () {
                this.element.parentNode.removeChild(this.element), this.css({ display: "" }), this.emitEvent("remove", [this]);
            }),
            (d.remove = function () {
                return r && parseFloat(this.layout.options.transitionDuration)
                    ? (this.once("transitionEnd", function () {
                          this.removeElem();
                      }),
                      void this.hide())
                    : void this.removeElem();
            }),
            (d.reveal = function () {
                delete this.isHidden, this.css({ display: "" });
                var t = this.layout.options,
                    e = {},
                    i = this.getHideRevealTransitionEndProperty("visibleStyle");
                (e[i] = this.onRevealTransitionEnd), this.transition({ from: t.hiddenStyle, to: t.visibleStyle, isCleaning: !0, onTransitionEnd: e });
            }),
            (d.onRevealTransitionEnd = function () {
                this.isHidden || this.emitEvent("reveal");
            }),
            (d.getHideRevealTransitionEndProperty = function (t) {
                var e = this.layout.options[t];
                if (e.opacity) return "opacity";
                for (var i in e) return i;
            }),
            (d.hide = function () {
                (this.isHidden = !0), this.css({ display: "" });
                var t = this.layout.options,
                    e = {},
                    i = this.getHideRevealTransitionEndProperty("hiddenStyle");
                (e[i] = this.onHideTransitionEnd), this.transition({ from: t.visibleStyle, to: t.hiddenStyle, isCleaning: !0, onTransitionEnd: e });
            }),
            (d.onHideTransitionEnd = function () {
                this.isHidden && (this.css({ display: "none" }), this.emitEvent("hide"));
            }),
            (d.destroy = function () {
                this.css({ position: "", left: "", right: "", top: "", bottom: "", transition: "", transform: "" });
            }),
            n
        );
    }),
    (function (t, e) {
        "use strict";
        "function" == typeof define && define.amd
            ? define("outlayer/outlayer", ["ev-emitter/ev-emitter", "get-size/get-size", "fizzy-ui-utils/utils", "./item"], function (i, n, o, s) {
                  return e(t, i, n, o, s);
              })
            : "object" == typeof module && module.exports
            ? (module.exports = e(t, require("ev-emitter"), require("get-size"), require("fizzy-ui-utils"), require("./item")))
            : (t.Outlayer = e(t, t.EvEmitter, t.getSize, t.fizzyUIUtils, t.Outlayer.Item));
    })(window, function (t, e, i, n, o) {
        "use strict";
        function s(t, e) {
            var i = n.getQueryElement(t);
            if (!i) return void (u && u.error("Bad element for " + this.constructor.namespace + ": " + (i || t)));
            (this.element = i), h && (this.$element = h(this.element)), (this.options = n.extend({}, this.constructor.defaults)), this.option(e);
            var o = ++l;
            (this.element.outlayerGUID = o), (f[o] = this), this._create();
            var s = this._getOption("initLayout");
            s && this.layout();
        }
        function r(t) {
            function e() {
                t.apply(this, arguments);
            }
            return (e.prototype = Object.create(t.prototype)), (e.prototype.constructor = e), e;
        }
        function a(t) {
            if ("number" == typeof t) return t;
            var e = t.match(/(^\d*\.?\d*)(\w*)/),
                i = e && e[1],
                n = e && e[2];
            if (!i.length) return 0;
            i = parseFloat(i);
            var o = m[n] || 1;
            return i * o;
        }
        var u = t.console,
            h = t.jQuery,
            d = function () {},
            l = 0,
            f = {};
        (s.namespace = "outlayer"),
            (s.Item = o),
            (s.defaults = {
                containerStyle: { position: "relative" },
                initLayout: !0,
                originLeft: !0,
                originTop: !0,
                resize: !0,
                resizeContainer: !0,
                transitionDuration: "0.4s",
                hiddenStyle: { opacity: 0, transform: "scale(0.001)" },
                visibleStyle: { opacity: 1, transform: "scale(1)" },
            });
        var c = s.prototype;
        n.extend(c, e.prototype),
            (c.option = function (t) {
                n.extend(this.options, t);
            }),
            (c._getOption = function (t) {
                var e = this.constructor.compatOptions[t];
                return e && void 0 !== this.options[e] ? this.options[e] : this.options[t];
            }),
            (s.compatOptions = {
                initLayout: "isInitLayout",
                horizontal: "isHorizontal",
                layoutInstant: "isLayoutInstant",
                originLeft: "isOriginLeft",
                originTop: "isOriginTop",
                resize: "isResizeBound",
                resizeContainer: "isResizingContainer",
            }),
            (c._create = function () {
                this.reloadItems(), (this.stamps = []), this.stamp(this.options.stamp), n.extend(this.element.style, this.options.containerStyle);
                var t = this._getOption("resize");
                t && this.bindResize();
            }),
            (c.reloadItems = function () {
                this.items = this._itemize(this.element.children);
            }),
            (c._itemize = function (t) {
                for (var e = this._filterFindItemElements(t), i = this.constructor.Item, n = [], o = 0; o < e.length; o++) {
                    var s = e[o],
                        r = new i(s, this);
                    n.push(r);
                }
                return n;
            }),
            (c._filterFindItemElements = function (t) {
                return n.filterFindElements(t, this.options.itemSelector);
            }),
            (c.getItemElements = function () {
                return this.items.map(function (t) {
                    return t.element;
                });
            }),
            (c.layout = function () {
                this._resetLayout(), this._manageStamps();
                var t = this._getOption("layoutInstant"),
                    e = void 0 !== t ? t : !this._isLayoutInited;
                this.layoutItems(this.items, e), (this._isLayoutInited = !0);
            }),
            (c._init = c.layout),
            (c._resetLayout = function () {
                this.getSize();
            }),
            (c.getSize = function () {
                this.size = i(this.element);
            }),
            (c._getMeasurement = function (t, e) {
                var n,
                    o = this.options[t];
                o ? ("string" == typeof o ? (n = this.element.querySelector(o)) : o instanceof HTMLElement && (n = o), (this[t] = n ? i(n)[e] : o)) : (this[t] = 0);
            }),
            (c.layoutItems = function (t, e) {
                (t = this._getItemsForLayout(t)), this._layoutItems(t, e), this._postLayout();
            }),
            (c._getItemsForLayout = function (t) {
                return t.filter(function (t) {
                    return !t.isIgnored;
                });
            }),
            (c._layoutItems = function (t, e) {
                if ((this._emitCompleteOnItems("layout", t), t && t.length)) {
                    var i = [];
                    t.forEach(function (t) {
                        var n = this._getItemLayoutPosition(t);
                        (n.item = t), (n.isInstant = e || t.isLayoutInstant), i.push(n);
                    }, this),
                        this._processLayoutQueue(i);
                }
            }),
            (c._getItemLayoutPosition = function () {
                return { x: 0, y: 0 };
            }),
            (c._processLayoutQueue = function (t) {
                this.updateStagger(),
                    t.forEach(function (t, e) {
                        this._positionItem(t.item, t.x, t.y, t.isInstant, e);
                    }, this);
            }),
            (c.updateStagger = function () {
                var t = this.options.stagger;
                return null === t || void 0 === t ? void (this.stagger = 0) : ((this.stagger = a(t)), this.stagger);
            }),
            (c._positionItem = function (t, e, i, n, o) {
                n ? t.goTo(e, i) : (t.stagger(o * this.stagger), t.moveTo(e, i));
            }),
            (c._postLayout = function () {
                this.resizeContainer();
            }),
            (c.resizeContainer = function () {
                var t = this._getOption("resizeContainer");
                if (t) {
                    var e = this._getContainerSize();
                    e && (this._setContainerMeasure(e.width, !0), this._setContainerMeasure(e.height, !1));
                }
            }),
            (c._getContainerSize = d),
            (c._setContainerMeasure = function (t, e) {
                if (void 0 !== t) {
                    var i = this.size;
                    i.isBorderBox && (t += e ? i.paddingLeft + i.paddingRight + i.borderLeftWidth + i.borderRightWidth : i.paddingBottom + i.paddingTop + i.borderTopWidth + i.borderBottomWidth),
                        (t = Math.max(t, 0)),
                        (this.element.style[e ? "width" : "height"] = t + "px");
                }
            }),
            (c._emitCompleteOnItems = function (t, e) {
                function i() {
                    o.dispatchEvent(t + "Complete", null, [e]);
                }
                function n() {
                    r++, r == s && i();
                }
                var o = this,
                    s = e.length;
                if (!e || !s) return void i();
                var r = 0;
                e.forEach(function (e) {
                    e.once(t, n);
                });
            }),
            (c.dispatchEvent = function (t, e, i) {
                var n = e ? [e].concat(i) : i;
                if ((this.emitEvent(t, n), h))
                    if (((this.$element = this.$element || h(this.element)), e)) {
                        var o = h.Event(e);
                        (o.type = t), this.$element.trigger(o, i);
                    } else this.$element.trigger(t, i);
            }),
            (c.ignore = function (t) {
                var e = this.getItem(t);
                e && (e.isIgnored = !0);
            }),
            (c.unignore = function (t) {
                var e = this.getItem(t);
                e && delete e.isIgnored;
            }),
            (c.stamp = function (t) {
                (t = this._find(t)), t && ((this.stamps = this.stamps.concat(t)), t.forEach(this.ignore, this));
            }),
            (c.unstamp = function (t) {
                (t = this._find(t)),
                    t &&
                        t.forEach(function (t) {
                            n.removeFrom(this.stamps, t), this.unignore(t);
                        }, this);
            }),
            (c._find = function (t) {
                if (t) return "string" == typeof t && (t = this.element.querySelectorAll(t)), (t = n.makeArray(t));
            }),
            (c._manageStamps = function () {
                this.stamps && this.stamps.length && (this._getBoundingRect(), this.stamps.forEach(this._manageStamp, this));
            }),
            (c._getBoundingRect = function () {
                var t = this.element.getBoundingClientRect(),
                    e = this.size;
                this._boundingRect = {
                    left: t.left + e.paddingLeft + e.borderLeftWidth,
                    top: t.top + e.paddingTop + e.borderTopWidth,
                    right: t.right - (e.paddingRight + e.borderRightWidth),
                    bottom: t.bottom - (e.paddingBottom + e.borderBottomWidth),
                };
            }),
            (c._manageStamp = d),
            (c._getElementOffset = function (t) {
                var e = t.getBoundingClientRect(),
                    n = this._boundingRect,
                    o = i(t),
                    s = { left: e.left - n.left - o.marginLeft, top: e.top - n.top - o.marginTop, right: n.right - e.right - o.marginRight, bottom: n.bottom - e.bottom - o.marginBottom };
                return s;
            }),
            (c.handleEvent = n.handleEvent),
            (c.bindResize = function () {
                t.addEventListener("resize", this), (this.isResizeBound = !0);
            }),
            (c.unbindResize = function () {
                t.removeEventListener("resize", this), (this.isResizeBound = !1);
            }),
            (c.onresize = function () {
                this.resize();
            }),
            n.debounceMethod(s, "onresize", 100),
            (c.resize = function () {
                this.isResizeBound && this.needsResizeLayout() && this.layout();
            }),
            (c.needsResizeLayout = function () {
                var t = i(this.element),
                    e = this.size && t;
                return e && t.innerWidth !== this.size.innerWidth;
            }),
            (c.addItems = function (t) {
                var e = this._itemize(t);
                return e.length && (this.items = this.items.concat(e)), e;
            }),
            (c.appended = function (t) {
                var e = this.addItems(t);
                e.length && (this.layoutItems(e, !0), this.reveal(e));
            }),
            (c.prepended = function (t) {
                var e = this._itemize(t);
                if (e.length) {
                    var i = this.items.slice(0);
                    (this.items = e.concat(i)), this._resetLayout(), this._manageStamps(), this.layoutItems(e, !0), this.reveal(e), this.layoutItems(i);
                }
            }),
            (c.reveal = function (t) {
                if ((this._emitCompleteOnItems("reveal", t), t && t.length)) {
                    var e = this.updateStagger();
                    t.forEach(function (t, i) {
                        t.stagger(i * e), t.reveal();
                    });
                }
            }),
            (c.hide = function (t) {
                if ((this._emitCompleteOnItems("hide", t), t && t.length)) {
                    var e = this.updateStagger();
                    t.forEach(function (t, i) {
                        t.stagger(i * e), t.hide();
                    });
                }
            }),
            (c.revealItemElements = function (t) {
                var e = this.getItems(t);
                this.reveal(e);
            }),
            (c.hideItemElements = function (t) {
                var e = this.getItems(t);
                this.hide(e);
            }),
            (c.getItem = function (t) {
                for (var e = 0; e < this.items.length; e++) {
                    var i = this.items[e];
                    if (i.element == t) return i;
                }
            }),
            (c.getItems = function (t) {
                t = n.makeArray(t);
                var e = [];
                return (
                    t.forEach(function (t) {
                        var i = this.getItem(t);
                        i && e.push(i);
                    }, this),
                    e
                );
            }),
            (c.remove = function (t) {
                var e = this.getItems(t);
                this._emitCompleteOnItems("remove", e),
                    e &&
                        e.length &&
                        e.forEach(function (t) {
                            t.remove(), n.removeFrom(this.items, t);
                        }, this);
            }),
            (c.destroy = function () {
                var t = this.element.style;
                (t.height = ""),
                    (t.position = ""),
                    (t.width = ""),
                    this.items.forEach(function (t) {
                        t.destroy();
                    }),
                    this.unbindResize();
                var e = this.element.outlayerGUID;
                delete f[e], delete this.element.outlayerGUID, h && h.removeData(this.element, this.constructor.namespace);
            }),
            (s.data = function (t) {
                t = n.getQueryElement(t);
                var e = t && t.outlayerGUID;
                return e && f[e];
            }),
            (s.create = function (t, e) {
                var i = r(s);
                return (
                    (i.defaults = n.extend({}, s.defaults)),
                    n.extend(i.defaults, e),
                    (i.compatOptions = n.extend({}, s.compatOptions)),
                    (i.namespace = t),
                    (i.data = s.data),
                    (i.Item = r(o)),
                    n.htmlInit(i, t),
                    h && h.bridget && h.bridget(t, i),
                    i
                );
            });
        var m = { ms: 1, s: 1e3 };
        return (s.Item = o), s;
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define("isotope/js/item", ["outlayer/outlayer"], e)
            : "object" == typeof module && module.exports
            ? (module.exports = e(require("outlayer")))
            : ((t.Isotope = t.Isotope || {}), (t.Isotope.Item = e(t.Outlayer)));
    })(window, function (t) {
        "use strict";
        function e() {
            t.Item.apply(this, arguments);
        }
        var i = (e.prototype = Object.create(t.Item.prototype)),
            n = i._create;
        (i._create = function () {
            (this.id = this.layout.itemGUID++), n.call(this), (this.sortData = {});
        }),
            (i.updateSortData = function () {
                if (!this.isIgnored) {
                    (this.sortData.id = this.id), (this.sortData["original-order"] = this.id), (this.sortData.random = Math.random());
                    var t = this.layout.options.getSortData,
                        e = this.layout._sorters;
                    for (var i in t) {
                        var n = e[i];
                        this.sortData[i] = n(this.element, this);
                    }
                }
            });
        var o = i.destroy;
        return (
            (i.destroy = function () {
                o.apply(this, arguments), this.css({ display: "" });
            }),
            e
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define("isotope/js/layout-mode", ["get-size/get-size", "outlayer/outlayer"], e)
            : "object" == typeof module && module.exports
            ? (module.exports = e(require("get-size"), require("outlayer")))
            : ((t.Isotope = t.Isotope || {}), (t.Isotope.LayoutMode = e(t.getSize, t.Outlayer)));
    })(window, function (t, e) {
        "use strict";
        function i(t) {
            (this.isotope = t), t && ((this.options = t.options[this.namespace]), (this.element = t.element), (this.items = t.filteredItems), (this.size = t.size));
        }
        var n = i.prototype,
            o = ["_resetLayout", "_getItemLayoutPosition", "_manageStamp", "_getContainerSize", "_getElementOffset", "needsResizeLayout", "_getOption"];
        return (
            o.forEach(function (t) {
                n[t] = function () {
                    return e.prototype[t].apply(this.isotope, arguments);
                };
            }),
            (n.needsVerticalResizeLayout = function () {
                var e = t(this.isotope.element),
                    i = this.isotope.size && e;
                return i && e.innerHeight != this.isotope.size.innerHeight;
            }),
            (n._getMeasurement = function () {
                this.isotope._getMeasurement.apply(this, arguments);
            }),
            (n.getColumnWidth = function () {
                this.getSegmentSize("column", "Width");
            }),
            (n.getRowHeight = function () {
                this.getSegmentSize("row", "Height");
            }),
            (n.getSegmentSize = function (t, e) {
                var i = t + e,
                    n = "outer" + e;
                if ((this._getMeasurement(i, n), !this[i])) {
                    var o = this.getFirstItemSize();
                    this[i] = (o && o[n]) || this.isotope.size["inner" + e];
                }
            }),
            (n.getFirstItemSize = function () {
                var e = this.isotope.filteredItems[0];
                return e && e.element && t(e.element);
            }),
            (n.layout = function () {
                this.isotope.layout.apply(this.isotope, arguments);
            }),
            (n.getSize = function () {
                this.isotope.getSize(), (this.size = this.isotope.size);
            }),
            (i.modes = {}),
            (i.create = function (t, e) {
                function o() {
                    i.apply(this, arguments);
                }
                return (o.prototype = Object.create(n)), (o.prototype.constructor = o), e && (o.options = e), (o.prototype.namespace = t), (i.modes[t] = o), o;
            }),
            i
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define("masonry/masonry", ["outlayer/outlayer", "get-size/get-size"], e)
            : "object" == typeof module && module.exports
            ? (module.exports = e(require("outlayer"), require("get-size")))
            : (t.Masonry = e(t.Outlayer, t.getSize));
    })(window, function (t, e) {
        var i = t.create("masonry");
        return (
            (i.compatOptions.fitWidth = "isFitWidth"),
            (i.prototype._resetLayout = function () {
                this.getSize(), this._getMeasurement("columnWidth", "outerWidth"), this._getMeasurement("gutter", "outerWidth"), this.measureColumns(), (this.colYs = []);
                for (var t = 0; t < this.cols; t++) this.colYs.push(0);
                this.maxY = 0;
            }),
            (i.prototype.measureColumns = function () {
                if ((this.getContainerWidth(), !this.columnWidth)) {
                    var t = this.items[0],
                        i = t && t.element;
                    this.columnWidth = (i && e(i).outerWidth) || this.containerWidth;
                }
                var n = (this.columnWidth += this.gutter),
                    o = this.containerWidth + this.gutter,
                    s = o / n,
                    r = n - (o % n),
                    a = r && r < 1 ? "round" : "floor";
                (s = Math[a](s)), (this.cols = Math.max(s, 1));
            }),
            (i.prototype.getContainerWidth = function () {
                var t = this._getOption("fitWidth"),
                    i = t ? this.element.parentNode : this.element,
                    n = e(i);
                this.containerWidth = n && n.innerWidth;
            }),
            (i.prototype._getItemLayoutPosition = function (t) {
                t.getSize();
                var e = t.size.outerWidth % this.columnWidth,
                    i = e && e < 1 ? "round" : "ceil",
                    n = Math[i](t.size.outerWidth / this.columnWidth);
                n = Math.min(n, this.cols);
                for (var o = this._getColGroup(n), s = Math.min.apply(Math, o), r = o.indexOf(s), a = { x: this.columnWidth * r, y: s }, u = s + t.size.outerHeight, h = this.cols + 1 - o.length, d = 0; d < h; d++) this.colYs[r + d] = u;
                return a;
            }),
            (i.prototype._getColGroup = function (t) {
                if (t < 2) return this.colYs;
                for (var e = [], i = this.cols + 1 - t, n = 0; n < i; n++) {
                    var o = this.colYs.slice(n, n + t);
                    e[n] = Math.max.apply(Math, o);
                }
                return e;
            }),
            (i.prototype._manageStamp = function (t) {
                var i = e(t),
                    n = this._getElementOffset(t),
                    o = this._getOption("originLeft"),
                    s = o ? n.left : n.right,
                    r = s + i.outerWidth,
                    a = Math.floor(s / this.columnWidth);
                a = Math.max(0, a);
                var u = Math.floor(r / this.columnWidth);
                (u -= r % this.columnWidth ? 0 : 1), (u = Math.min(this.cols - 1, u));
                for (var h = this._getOption("originTop"), d = (h ? n.top : n.bottom) + i.outerHeight, l = a; l <= u; l++) this.colYs[l] = Math.max(d, this.colYs[l]);
            }),
            (i.prototype._getContainerSize = function () {
                this.maxY = Math.max.apply(Math, this.colYs);
                var t = { height: this.maxY };
                return this._getOption("fitWidth") && (t.width = this._getContainerFitWidth()), t;
            }),
            (i.prototype._getContainerFitWidth = function () {
                for (var t = 0, e = this.cols; --e && 0 === this.colYs[e]; ) t++;
                return (this.cols - t) * this.columnWidth - this.gutter;
            }),
            (i.prototype.needsResizeLayout = function () {
                var t = this.containerWidth;
                return this.getContainerWidth(), t != this.containerWidth;
            }),
            i
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define("isotope/js/layout-modes/masonry", ["../layout-mode", "masonry/masonry"], e)
            : "object" == typeof module && module.exports
            ? (module.exports = e(require("../layout-mode"), require("masonry-layout")))
            : e(t.Isotope.LayoutMode, t.Masonry);
    })(window, function (t, e) {
        "use strict";
        var i = t.create("masonry"),
            n = i.prototype,
            o = { _getElementOffset: !0, layout: !0, _getMeasurement: !0 };
        for (var s in e.prototype) o[s] || (n[s] = e.prototype[s]);
        var r = n.measureColumns;
        n.measureColumns = function () {
            (this.items = this.isotope.filteredItems), r.call(this);
        };
        var a = n._getOption;
        return (
            (n._getOption = function (t) {
                return "fitWidth" == t ? (void 0 !== this.options.isFitWidth ? this.options.isFitWidth : this.options.fitWidth) : a.apply(this.isotope, arguments);
            }),
            i
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd ? define("isotope/js/layout-modes/fit-rows", ["../layout-mode"], e) : "object" == typeof exports ? (module.exports = e(require("../layout-mode"))) : e(t.Isotope.LayoutMode);
    })(window, function (t) {
        "use strict";
        var e = t.create("fitRows"),
            i = e.prototype;
        return (
            (i._resetLayout = function () {
                (this.x = 0), (this.y = 0), (this.maxY = 0), this._getMeasurement("gutter", "outerWidth");
            }),
            (i._getItemLayoutPosition = function (t) {
                t.getSize();
                var e = t.size.outerWidth + this.gutter,
                    i = this.isotope.size.innerWidth + this.gutter;
                0 !== this.x && e + this.x > i && ((this.x = 0), (this.y = this.maxY));
                var n = { x: this.x, y: this.y };
                return (this.maxY = Math.max(this.maxY, this.y + t.size.outerHeight)), (this.x += e), n;
            }),
            (i._getContainerSize = function () {
                return { height: this.maxY };
            }),
            e
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd ? define("isotope/js/layout-modes/vertical", ["../layout-mode"], e) : "object" == typeof module && module.exports ? (module.exports = e(require("../layout-mode"))) : e(t.Isotope.LayoutMode);
    })(window, function (t) {
        "use strict";
        var e = t.create("vertical", { horizontalAlignment: 0 }),
            i = e.prototype;
        return (
            (i._resetLayout = function () {
                this.y = 0;
            }),
            (i._getItemLayoutPosition = function (t) {
                t.getSize();
                var e = (this.isotope.size.innerWidth - t.size.outerWidth) * this.options.horizontalAlignment,
                    i = this.y;
                return (this.y += t.size.outerHeight), { x: e, y: i };
            }),
            (i._getContainerSize = function () {
                return { height: this.y };
            }),
            e
        );
    }),
    (function (t, e) {
        "function" == typeof define && define.amd
            ? define([
                  "outlayer/outlayer",
                  "get-size/get-size",
                  "desandro-matches-selector/matches-selector",
                  "fizzy-ui-utils/utils",
                  "isotope/js/item",
                  "isotope/js/layout-mode",
                  "isotope/js/layout-modes/masonry",
                  "isotope/js/layout-modes/fit-rows",
                  "isotope/js/layout-modes/vertical",
              ], function (i, n, o, s, r, a) {
                  return e(t, i, n, o, s, r, a);
              })
            : "object" == typeof module && module.exports
            ? (module.exports = e(
                  t,
                  require("outlayer"),
                  require("get-size"),
                  require("desandro-matches-selector"),
                  require("fizzy-ui-utils"),
                  require("isotope/js/item"),
                  require("isotope/js/layout-mode"),
                  require("isotope/js/layout-modes/masonry"),
                  require("isotope/js/layout-modes/fit-rows"),
                  require("isotope/js/layout-modes/vertical")
              ))
            : (t.Isotope = e(t, t.Outlayer, t.getSize, t.matchesSelector, t.fizzyUIUtils, t.Isotope.Item, t.Isotope.LayoutMode));
    })(window, function (t, e, i, n, o, s, r) {
        function a(t, e) {
            return function (i, n) {
                for (var o = 0; o < t.length; o++) {
                    var s = t[o],
                        r = i.sortData[s],
                        a = n.sortData[s];
                    if (r > a || r < a) {
                        var u = void 0 !== e[s] ? e[s] : e,
                            h = u ? 1 : -1;
                        return (r > a ? 1 : -1) * h;
                    }
                }
                return 0;
            };
        }
        var u = t.jQuery,
            h = String.prototype.trim
                ? function (t) {
                      return t.trim();
                  }
                : function (t) {
                      return t.replace(/^\s+|\s+$/g, "");
                  },
            d = e.create("isotope", { layoutMode: "masonry", isJQueryFiltering: !0, sortAscending: !0 });
        (d.Item = s), (d.LayoutMode = r);
        var l = d.prototype;
        (l._create = function () {
            (this.itemGUID = 0), (this._sorters = {}), this._getSorters(), e.prototype._create.call(this), (this.modes = {}), (this.filteredItems = this.items), (this.sortHistory = ["original-order"]);
            for (var t in r.modes) this._initLayoutMode(t);
        }),
            (l.reloadItems = function () {
                (this.itemGUID = 0), e.prototype.reloadItems.call(this);
            }),
            (l._itemize = function () {
                for (var t = e.prototype._itemize.apply(this, arguments), i = 0; i < t.length; i++) {
                    var n = t[i];
                    n.id = this.itemGUID++;
                }
                return this._updateItemsSortData(t), t;
            }),
            (l._initLayoutMode = function (t) {
                var e = r.modes[t],
                    i = this.options[t] || {};
                (this.options[t] = e.options ? o.extend(e.options, i) : i), (this.modes[t] = new e(this));
            }),
            (l.layout = function () {
                return !this._isLayoutInited && this._getOption("initLayout") ? void this.arrange() : void this._layout();
            }),
            (l._layout = function () {
                var t = this._getIsInstant();
                this._resetLayout(), this._manageStamps(), this.layoutItems(this.filteredItems, t), (this._isLayoutInited = !0);
            }),
            (l.arrange = function (t) {
                this.option(t), this._getIsInstant();
                var e = this._filter(this.items);
                (this.filteredItems = e.matches), this._bindArrangeComplete(), this._isInstant ? this._noTransition(this._hideReveal, [e]) : this._hideReveal(e), this._sort(), this._layout();
            }),
            (l._init = l.arrange),
            (l._hideReveal = function (t) {
                this.reveal(t.needReveal), this.hide(t.needHide);
            }),
            (l._getIsInstant = function () {
                var t = this._getOption("layoutInstant"),
                    e = void 0 !== t ? t : !this._isLayoutInited;
                return (this._isInstant = e), e;
            }),
            (l._bindArrangeComplete = function () {
                function t() {
                    e && i && n && o.dispatchEvent("arrangeComplete", null, [o.filteredItems]);
                }
                var e,
                    i,
                    n,
                    o = this;
                this.once("layoutComplete", function () {
                    (e = !0), t();
                }),
                    this.once("hideComplete", function () {
                        (i = !0), t();
                    }),
                    this.once("revealComplete", function () {
                        (n = !0), t();
                    });
            }),
            (l._filter = function (t) {
                var e = this.options.filter;
                e = e || "*";
                for (var i = [], n = [], o = [], s = this._getFilterTest(e), r = 0; r < t.length; r++) {
                    var a = t[r];
                    if (!a.isIgnored) {
                        var u = s(a);
                        u && i.push(a), u && a.isHidden ? n.push(a) : u || a.isHidden || o.push(a);
                    }
                }
                return { matches: i, needReveal: n, needHide: o };
            }),
            (l._getFilterTest = function (t) {
                return u && this.options.isJQueryFiltering
                    ? function (e) {
                          return u(e.element).is(t);
                      }
                    : "function" == typeof t
                    ? function (e) {
                          return t(e.element);
                      }
                    : function (e) {
                          return n(e.element, t);
                      };
            }),
            (l.updateSortData = function (t) {
                var e;
                t ? ((t = o.makeArray(t)), (e = this.getItems(t))) : (e = this.items), this._getSorters(), this._updateItemsSortData(e);
            }),
            (l._getSorters = function () {
                var t = this.options.getSortData;
                for (var e in t) {
                    var i = t[e];
                    this._sorters[e] = f(i);
                }
            }),
            (l._updateItemsSortData = function (t) {
                for (var e = t && t.length, i = 0; e && i < e; i++) {
                    var n = t[i];
                    n.updateSortData();
                }
            });
        var f = (function () {
            function t(t) {
                if ("string" != typeof t) return t;
                var i = h(t).split(" "),
                    n = i[0],
                    o = n.match(/^\[(.+)\]$/),
                    s = o && o[1],
                    r = e(s, n),
                    a = d.sortDataParsers[i[1]];
                return (t = a
                    ? function (t) {
                          return t && a(r(t));
                      }
                    : function (t) {
                          return t && r(t);
                      });
            }
            function e(t, e) {
                return t
                    ? function (e) {
                          return e.getAttribute(t);
                      }
                    : function (t) {
                          var i = t.querySelector(e);
                          return i && i.textContent;
                      };
            }
            return t;
        })();
        (d.sortDataParsers = {
            parseInt: function (t) {
                return parseInt(t, 10);
            },
            parseFloat: function (t) {
                return parseFloat(t);
            },
        }),
            (l._sort = function () {
                var t = this.options.sortBy;
                if (t) {
                    var e = [].concat.apply(t, this.sortHistory),
                        i = a(e, this.options.sortAscending);
                    this.filteredItems.sort(i), t != this.sortHistory[0] && this.sortHistory.unshift(t);
                }
            }),
            (l._mode = function () {
                var t = this.options.layoutMode,
                    e = this.modes[t];
                if (!e) throw new Error("No layout mode: " + t);
                return (e.options = this.options[t]), e;
            }),
            (l._resetLayout = function () {
                e.prototype._resetLayout.call(this), this._mode()._resetLayout();
            }),
            (l._getItemLayoutPosition = function (t) {
                return this._mode()._getItemLayoutPosition(t);
            }),
            (l._manageStamp = function (t) {
                this._mode()._manageStamp(t);
            }),
            (l._getContainerSize = function () {
                return this._mode()._getContainerSize();
            }),
            (l.needsResizeLayout = function () {
                return this._mode().needsResizeLayout();
            }),
            (l.appended = function (t) {
                var e = this.addItems(t);
                if (e.length) {
                    var i = this._filterRevealAdded(e);
                    this.filteredItems = this.filteredItems.concat(i);
                }
            }),
            (l.prepended = function (t) {
                var e = this._itemize(t);
                if (e.length) {
                    this._resetLayout(), this._manageStamps();
                    var i = this._filterRevealAdded(e);
                    this.layoutItems(this.filteredItems), (this.filteredItems = i.concat(this.filteredItems)), (this.items = e.concat(this.items));
                }
            }),
            (l._filterRevealAdded = function (t) {
                var e = this._filter(t);
                return this.hide(e.needHide), this.reveal(e.matches), this.layoutItems(e.matches, !0), e.matches;
            }),
            (l.insert = function (t) {
                var e = this.addItems(t);
                if (e.length) {
                    var i,
                        n,
                        o = e.length;
                    for (i = 0; i < o; i++) (n = e[i]), this.element.appendChild(n.element);
                    var s = this._filter(e).matches;
                    for (i = 0; i < o; i++) e[i].isLayoutInstant = !0;
                    for (this.arrange(), i = 0; i < o; i++) delete e[i].isLayoutInstant;
                    this.reveal(s);
                }
            });
        var c = l.remove;
        return (
            (l.remove = function (t) {
                t = o.makeArray(t);
                var e = this.getItems(t);
                c.call(this, t);
                for (var i = e && e.length, n = 0; i && n < i; n++) {
                    var s = e[n];
                    o.removeFrom(this.filteredItems, s);
                }
            }),
            (l.shuffle = function () {
                for (var t = 0; t < this.items.length; t++) {
                    var e = this.items[t];
                    e.sortData.random = Math.random();
                }
                (this.options.sortBy = "random"), this._sort(), this._layout();
            }),
            (l._noTransition = function (t, e) {
                var i = this.options.transitionDuration;
                this.options.transitionDuration = 0;
                var n = t.apply(this, e);
                return (this.options.transitionDuration = i), n;
            }),
            (l.getFilteredItemElements = function () {
                return this.filteredItems.map(function (t) {
                    return t.element;
                });
            }),
            d
        );
    });

/*-------------------------------------------------------------
  7. imagesLoaded jQuery
---------------------------------------------------------------*/
/*!
 * imagesLoaded PACKAGED v4.1.1
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

!(function (t, e) {
    "function" == typeof define && define.amd ? define("ev-emitter/ev-emitter", e) : "object" == typeof module && module.exports ? (module.exports = e()) : (t.EvEmitter = e());
})("undefined" != typeof window ? window : this, function () {
    function t() {}
    var e = t.prototype;
    return (
        (e.on = function (t, e) {
            if (t && e) {
                var i = (this._events = this._events || {}),
                    n = (i[t] = i[t] || []);
                return -1 == n.indexOf(e) && n.push(e), this;
            }
        }),
        (e.once = function (t, e) {
            if (t && e) {
                this.on(t, e);
                var i = (this._onceEvents = this._onceEvents || {}),
                    n = (i[t] = i[t] || {});
                return (n[e] = !0), this;
            }
        }),
        (e.off = function (t, e) {
            var i = this._events && this._events[t];
            if (i && i.length) {
                var n = i.indexOf(e);
                return -1 != n && i.splice(n, 1), this;
            }
        }),
        (e.emitEvent = function (t, e) {
            var i = this._events && this._events[t];
            if (i && i.length) {
                var n = 0,
                    o = i[n];
                e = e || [];
                for (var r = this._onceEvents && this._onceEvents[t]; o; ) {
                    var s = r && r[o];
                    s && (this.off(t, o), delete r[o]), o.apply(this, e), (n += s ? 0 : 1), (o = i[n]);
                }
                return this;
            }
        }),
        t
    );
}),
    (function (t, e) {
        "use strict";
        "function" == typeof define && define.amd
            ? define(["ev-emitter/ev-emitter"], function (i) {
                  return e(t, i);
              })
            : "object" == typeof module && module.exports
            ? (module.exports = e(t, require("ev-emitter")))
            : (t.imagesLoaded = e(t, t.EvEmitter));
    })(window, function (t, e) {
        function i(t, e) {
            for (var i in e) t[i] = e[i];
            return t;
        }
        function n(t) {
            var e = [];
            if (Array.isArray(t)) e = t;
            else if ("number" == typeof t.length) for (var i = 0; i < t.length; i++) e.push(t[i]);
            else e.push(t);
            return e;
        }
        function o(t, e, r) {
            return this instanceof o
                ? ("string" == typeof t && (t = document.querySelectorAll(t)),
                  (this.elements = n(t)),
                  (this.options = i({}, this.options)),
                  "function" == typeof e ? (r = e) : i(this.options, e),
                  r && this.on("always", r),
                  this.getImages(),
                  h && (this.jqDeferred = new h.Deferred()),
                  void setTimeout(
                      function () {
                          this.check();
                      }.bind(this)
                  ))
                : new o(t, e, r);
        }
        function r(t) {
            this.img = t;
        }
        function s(t, e) {
            (this.url = t), (this.element = e), (this.img = new Image());
        }
        var h = t.jQuery,
            a = t.console;
        (o.prototype = Object.create(e.prototype)),
            (o.prototype.options = {}),
            (o.prototype.getImages = function () {
                (this.images = []), this.elements.forEach(this.addElementImages, this);
            }),
            (o.prototype.addElementImages = function (t) {
                "IMG" == t.nodeName && this.addImage(t), this.options.background === !0 && this.addElementBackgroundImages(t);
                var e = t.nodeType;
                if (e && d[e]) {
                    for (var i = t.querySelectorAll("img"), n = 0; n < i.length; n++) {
                        var o = i[n];
                        this.addImage(o);
                    }
                    if ("string" == typeof this.options.background) {
                        var r = t.querySelectorAll(this.options.background);
                        for (n = 0; n < r.length; n++) {
                            var s = r[n];
                            this.addElementBackgroundImages(s);
                        }
                    }
                }
            });
        var d = { 1: !0, 9: !0, 11: !0 };
        return (
            (o.prototype.addElementBackgroundImages = function (t) {
                var e = getComputedStyle(t);
                if (e)
                    for (var i = /url\((['"])?(.*?)\1\)/gi, n = i.exec(e.backgroundImage); null !== n; ) {
                        var o = n && n[2];
                        o && this.addBackground(o, t), (n = i.exec(e.backgroundImage));
                    }
            }),
            (o.prototype.addImage = function (t) {
                var e = new r(t);
                this.images.push(e);
            }),
            (o.prototype.addBackground = function (t, e) {
                var i = new s(t, e);
                this.images.push(i);
            }),
            (o.prototype.check = function () {
                function t(t, i, n) {
                    setTimeout(function () {
                        e.progress(t, i, n);
                    });
                }
                var e = this;
                return (
                    (this.progressedCount = 0),
                    (this.hasAnyBroken = !1),
                    this.images.length
                        ? void this.images.forEach(function (e) {
                              e.once("progress", t), e.check();
                          })
                        : void this.complete()
                );
            }),
            (o.prototype.progress = function (t, e, i) {
                this.progressedCount++,
                    (this.hasAnyBroken = this.hasAnyBroken || !t.isLoaded),
                    this.emitEvent("progress", [this, t, e]),
                    this.jqDeferred && this.jqDeferred.notify && this.jqDeferred.notify(this, t),
                    this.progressedCount == this.images.length && this.complete(),
                    this.options.debug && a && a.log("progress: " + i, t, e);
            }),
            (o.prototype.complete = function () {
                var t = this.hasAnyBroken ? "fail" : "done";
                if (((this.isComplete = !0), this.emitEvent(t, [this]), this.emitEvent("always", [this]), this.jqDeferred)) {
                    var e = this.hasAnyBroken ? "reject" : "resolve";
                    this.jqDeferred[e](this);
                }
            }),
            (r.prototype = Object.create(e.prototype)),
            (r.prototype.check = function () {
                var t = this.getIsImageComplete();
                return t
                    ? void this.confirm(0 !== this.img.naturalWidth, "naturalWidth")
                    : ((this.proxyImage = new Image()),
                      this.proxyImage.addEventListener("load", this),
                      this.proxyImage.addEventListener("error", this),
                      this.img.addEventListener("load", this),
                      this.img.addEventListener("error", this),
                      void (this.proxyImage.src = this.img.src));
            }),
            (r.prototype.getIsImageComplete = function () {
                return this.img.complete && void 0 !== this.img.naturalWidth;
            }),
            (r.prototype.confirm = function (t, e) {
                (this.isLoaded = t), this.emitEvent("progress", [this, this.img, e]);
            }),
            (r.prototype.handleEvent = function (t) {
                var e = "on" + t.type;
                this[e] && this[e](t);
            }),
            (r.prototype.onload = function () {
                this.confirm(!0, "onload"), this.unbindEvents();
            }),
            (r.prototype.onerror = function () {
                this.confirm(!1, "onerror"), this.unbindEvents();
            }),
            (r.prototype.unbindEvents = function () {
                this.proxyImage.removeEventListener("load", this), this.proxyImage.removeEventListener("error", this), this.img.removeEventListener("load", this), this.img.removeEventListener("error", this);
            }),
            (s.prototype = Object.create(r.prototype)),
            (s.prototype.check = function () {
                this.img.addEventListener("load", this), this.img.addEventListener("error", this), (this.img.src = this.url);
                var t = this.getIsImageComplete();
                t && (this.confirm(0 !== this.img.naturalWidth, "naturalWidth"), this.unbindEvents());
            }),
            (s.prototype.unbindEvents = function () {
                this.img.removeEventListener("load", this), this.img.removeEventListener("error", this);
            }),
            (s.prototype.confirm = function (t, e) {
                (this.isLoaded = t), this.emitEvent("progress", [this, this.element, e]);
            }),
            (o.makeJQueryPlugin = function (e) {
                (e = e || t.jQuery),
                    e &&
                        ((h = e),
                        (h.fn.imagesLoaded = function (t, e) {
                            var i = new o(this, t, e);
                            return i.jqDeferred.promise(h(this));
                        }));
            }),
            o.makeJQueryPlugin(),
            o
        );
    });

/*-------------------------------------------------------------
  8. Lightcase - Popup jQuery
---------------------------------------------------------------*/
!(function (t) {
    "use strict";
    var e = {
        cache: {},
        support: {},
        objects: {},
        init: function (e) {
            return this.each(function () {
                t(this)
                    .unbind("click.lightcase")
                    .bind("click.lightcase", function (i) {
                        i.preventDefault(), t(this).lightcase("start", e);
                    });
            });
        },
        start: function (i) {
            (e.origin = lightcase.origin = this),
                (e.settings = lightcase.settings = t.extend(
                    !0,
                    {
                        idPrefix: "lightcase-",
                        classPrefix: "lightcase-",
                        attrPrefix: "lc-",
                        transition: "elastic",
                        transitionOpen: null,
                        transitionClose: null,
                        transitionIn: null,
                        transitionOut: null,
                        cssTransitions: !0,
                        speedIn: 250,
                        speedOut: 250,
                        width: null,
                        height: null,
                        maxWidth: 800,
                        maxHeight: 500,
                        forceWidth: !1,
                        forceHeight: !1,
                        liveResize: !0,
                        fullScreenModeForMobile: !0,
                        mobileMatchExpression: /(iphone|ipod|ipad|android|blackberry|symbian)/,
                        disableShrink: !1,
                        fixedRatio: !0,
                        shrinkFactor: 0.75,
                        overlayOpacity: 0.9,
                        slideshow: !1,
                        slideshowAutoStart: !0,
                        breakBeforeShow: !1,
                        timeout: 5e3,
                        swipe: !0,
                        useKeys: !0,
                        useCategories: !0,
                        useAsCollection: !1,
                        navigateEndless: !0,
                        closeOnOverlayClick: !0,
                        title: null,
                        caption: null,
                        showTitle: !0,
                        showCaption: !0,
                        showSequenceInfo: !0,
                        inline: { width: "auto", height: "auto" },
                        ajax: { width: "auto", height: "auto", type: "get", dataType: "html", data: {} },
                        iframe: { width: 800, height: 500, frameborder: 0 },
                        flash: { width: 400, height: 205, wmode: "transparent" },
                        video: { width: 400, height: 225, poster: "", preload: "auto", controls: !0, autobuffer: !0, autoplay: !0, loop: !1 },
                        attr: "data-rel",
                        href: null,
                        type: null,
                        typeMapping: { image: "jpg,jpeg,gif,png,bmp", flash: "swf", video: "mp4,mov,ogv,ogg,webm", iframe: "html,php", ajax: "json,txt", inline: "#" },
                        errorMessage: function () {
                            return '<p class="' + e.settings.classPrefix + 'error">' + e.settings.labels.errorMessage + "</p>";
                        },
                        labels: { errorMessage: "Source could not be found...", "sequenceInfo.of": " of ", close: "Close", "navigator.prev": "Prev", "navigator.next": "Next", "navigator.play": "Play", "navigator.pause": "Pause" },
                        markup: function () {
                            e.objects.body.append(
                                (e.objects.overlay = t('<div id="' + e.settings.idPrefix + 'overlay"></div>')),
                                (e.objects.loading = t('<div id="' + e.settings.idPrefix + 'loading" class="' + e.settings.classPrefix + 'icon-spin"></div>')),
                                (e.objects.case = t('<div id="' + e.settings.idPrefix + 'case" aria-hidden="true" role="dialog"></div>'))
                            ),
                                e.objects.case.after(
                                    (e.objects.close = t('<a href="#" class="' + e.settings.classPrefix + 'icon-close"><span>' + e.settings.labels.close + "</span></a>")),
                                    (e.objects.nav = t('<div id="' + e.settings.idPrefix + 'nav"></div>'))
                                ),
                                e.objects.nav.append(
                                    (e.objects.prev = t('<a href="#" class="' + e.settings.classPrefix + 'icon-prev"><span>' + e.settings.labels["navigator.prev"] + "</span></a>").hide()),
                                    (e.objects.next = t('<a href="#" class="' + e.settings.classPrefix + 'icon-next"><span>' + e.settings.labels["navigator.next"] + "</span></a>").hide()),
                                    (e.objects.play = t('<a href="#" class="' + e.settings.classPrefix + 'icon-play"><span>' + e.settings.labels["navigator.play"] + "</span></a>").hide()),
                                    (e.objects.pause = t('<a href="#" class="' + e.settings.classPrefix + 'icon-pause"><span>' + e.settings.labels["navigator.pause"] + "</span></a>").hide())
                                ),
                                e.objects.case.append((e.objects.content = t('<div id="' + e.settings.idPrefix + 'content"></div>')), (e.objects.info = t('<div id="' + e.settings.idPrefix + 'info"></div>'))),
                                e.objects.content.append((e.objects.contentInner = t('<div class="' + e.settings.classPrefix + 'contentInner"></div>'))),
                                e.objects.info.append(
                                    (e.objects.sequenceInfo = t('<div id="' + e.settings.idPrefix + 'sequenceInfo"></div>')),
                                    (e.objects.title = t('<h4 id="' + e.settings.idPrefix + 'title"></h4>')),
                                    (e.objects.caption = t('<p id="' + e.settings.idPrefix + 'caption"></p>'))
                                );
                        },
                        onInit: {},
                        onStart: {},
                        onBeforeCalculateDimensions: {},
                        onAfterCalculateDimensions: {},
                        onBeforeShow: {},
                        onFinish: {},
                        onResize: {},
                        onClose: {},
                        onCleanup: {},
                    },
                    i,
                    e.origin.data ? e.origin.data("lc-options") : {}
                )),
                (e.objects.document = t("html")),
                (e.objects.body = t("body")),
                e._callHooks(e.settings.onInit),
                (e.objectData = e._setObjectData(this)),
                e._addElements(),
                e._open(),
                (e.dimensions = e.getViewportDimensions());
        },
        get: function (t) {
            return e.objects[t];
        },
        getObjectData: function () {
            return e.objectData;
        },
        _setObjectData: function (i) {
            var s = t(i),
                n = {
                    this: t(i),
                    title: e.settings.title || s.attr(e._prefixAttributeName("title")) || s.attr("title"),
                    caption: e.settings.caption || s.attr(e._prefixAttributeName("caption")) || s.children("img").attr("alt"),
                    url: e._determineUrl(),
                    requestType: e.settings.ajax.type,
                    requestData: e.settings.ajax.data,
                    requestDataType: e.settings.ajax.dataType,
                    rel: s.attr(e._determineAttributeSelector()),
                    type: e._verifyDataType(e._determineUrl()),
                    isPartOfSequence: e.settings.useAsCollection || e._isPartOfSequence(s.attr(e.settings.attr), ":"),
                    isPartOfSequenceWithSlideshow: e._isPartOfSequence(s.attr(e.settings.attr), ":slideshow"),
                    currentIndex: t(e._determineAttributeSelector()).index(s),
                    sequenceLength: t(e._determineAttributeSelector()).length,
                };
            return (n.sequenceInfo = n.currentIndex + 1 + e.settings.labels["sequenceInfo.of"] + n.sequenceLength), (n.prevIndex = n.currentIndex - 1), (n.nextIndex = n.currentIndex + 1), n;
        },
        _prefixAttributeName: function (t) {
            return "data-" + e.settings.attrPrefix + t;
        },
        _determineLinkTarget: function () {
            return e.settings.href || t(e.origin).attr(e._prefixAttributeName("href")) || t(e.origin).attr("href");
        },
        _determineAttributeSelector: function () {
            var i = t(e.origin),
                s = "";
            if (void 0 !== e.cache.selector) s = e.cache.selector;
            else if (!0 === e.settings.useCategories && i.attr(e._prefixAttributeName("categories"))) {
                var n = i.attr(e._prefixAttributeName("categories")).split(" ");
                t.each(n, function (t, i) {
                    t > 0 && (s += ","), (s += "[" + e._prefixAttributeName("categories") + '~="' + i + '"]');
                });
            } else s = "[" + e.settings.attr + '="' + i.attr(e.settings.attr) + '"]';
            return (e.cache.selector = s), s;
        },
        _determineUrl: function () {
            var i,
                s = e._verifyDataUrl(e._determineLinkTarget()),
                n = 0,
                a = 0,
                o = "";
            return (
                t.each(s, function (t, s) {
                    switch (e._verifyDataType(s.url)) {
                        case "video":
                            var c = document.createElement("video"),
                                r = e._verifyDataType(s.url) + "/" + e._getFileUrlSuffix(s.url);
                            "probably" !== o && o !== c.canPlayType(r) && "" !== c.canPlayType(r) && ((o = c.canPlayType(r)), (i = s.url));
                            break;
                        default:
                            e._devicePixelRatio() >= s.density && s.density >= a && e._matchMedia()("screen and (min-width:" + s.width + "px)").matches && s.width >= n && ((n = s.width), (a = s.density), (i = s.url));
                    }
                }),
                i
            );
        },
        _normalizeUrl: function (t) {
            var e = /^\d+$/,
                i = function (t) {
                    var i = { width: 0, density: 0 };
                    return (
                        t
                            .trim()
                            .split(/\s+/)
                            .forEach(function (t, s) {
                                if (0 === s) return (i.url = t);
                                var n = t.substring(0, t.length - 1),
                                    a = t[t.length - 1],
                                    o = parseInt(n, 10),
                                    c = parseFloat(n);
                                "w" === a && e.test(n) ? (i.width = o) : "h" === a && e.test(n) ? (i.height = o) : "x" !== a || isNaN(c) || (i.density = c);
                            }),
                        i
                    );
                };
            return 0 === t.indexOf("data:") ? [i(t)] : t.split(",").map(i);
        },
        _isPartOfSequence: function (i, s) {
            var n = t("[" + e.settings.attr + '="' + i + '"]');
            return new RegExp(s).test(i) && n.length > 1;
        },
        isSlideshowEnabled: function () {
            return e.objectData.isPartOfSequence && (!0 === e.settings.slideshow || !0 === e.objectData.isPartOfSequenceWithSlideshow);
        },
        _loadContent: function () {
            e.cache.originalObject && e._restoreObject(), e._createObject();
        },
        _createObject: function () {
            var i;
            switch (e.objectData.type) {
                case "image":
                    (i = t(new Image())).attr({ src: e.objectData.url, alt: e.objectData.title });
                    break;
                case "inline":
                    (i = t('<div class="' + e.settings.classPrefix + 'inlineWrap"></div>')).html(e._cloneObject(t(e.objectData.url))),
                        t.each(e.settings.inline, function (t, s) {
                            i.attr(e._prefixAttributeName(t), s);
                        });
                    break;
                case "ajax":
                    (i = t('<div class="' + e.settings.classPrefix + 'inlineWrap"></div>')),
                        t.each(e.settings.ajax, function (t, s) {
                            "data" !== t && i.attr(e._prefixAttributeName(t), s);
                        });
                    break;
                case "flash":
                    (i = t('<embed src="' + e.objectData.url + '" type="application/x-shockwave-flash"></embed>')),
                        t.each(e.settings.flash, function (t, e) {
                            i.attr(t, e);
                        });
                    break;
                case "video":
                    (i = t("<video></video>")).attr("src", e.objectData.url),
                        t.each(e.settings.video, function (t, e) {
                            i.attr(t, e);
                        });
                    break;
                default:
                    (i = t("<iframe></iframe>")).attr({ src: e.objectData.url }),
                        t.each(e.settings.iframe, function (t, e) {
                            i.attr(t, e);
                        });
            }
            e._addObject(i), e._loadObject(i);
        },
        _addObject: function (t) {
            e.objects.contentInner.html(t),
                e._loading("start"),
                e._callHooks(e.settings.onStart),
                !0 === e.settings.showSequenceInfo && e.objectData.isPartOfSequence ? (e.objects.sequenceInfo.html(e.objectData.sequenceInfo), e.objects.sequenceInfo.show()) : (e.objects.sequenceInfo.empty(), e.objects.sequenceInfo.hide()),
                !0 === e.settings.showTitle && void 0 !== e.objectData.title && "" !== e.objectData.title ? (e.objects.title.html(e.objectData.title), e.objects.title.show()) : (e.objects.title.empty(), e.objects.title.hide()),
                !0 === e.settings.showCaption && void 0 !== e.objectData.caption && "" !== e.objectData.caption
                    ? (e.objects.caption.html(e.objectData.caption), e.objects.caption.show())
                    : (e.objects.caption.empty(), e.objects.caption.hide());
        },
        _loadObject: function (i) {
            switch (e.objectData.type) {
                case "inline":
                    t(e.objectData.url) ? e._showContent(i) : e.error();
                    break;
                case "ajax":
                    t.ajax(
                        t.extend({}, e.settings.ajax, {
                            url: e.objectData.url,
                            type: e.objectData.requestType,
                            dataType: e.objectData.requestDataType,
                            data: e.objectData.requestData,
                            success: function (t, s, n) {
                                n.getResponseHeader("X-Ajax-Location")
                                    ? ((e.objectData.url = n.getResponseHeader("X-Ajax-Location")), e._loadObject(i))
                                    : ("json" === e.objectData.requestDataType ? (e.objectData.data = t) : i.html(t), e._showContent(i));
                            },
                            error: function (t, i, s) {
                                e.error();
                            },
                        })
                    );
                    break;
                case "flash":
                    e._showContent(i);
                    break;
                case "video":
                    "function" == typeof i.get(0).canPlayType || 0 === e.objects.case.find("video").length ? e._showContent(i) : e.error();
                    break;
                default:
                    e.objectData.url
                        ? (i.on("load", function () {
                              e._showContent(i);
                          }),
                          i.on("error", function () {
                              e.error();
                          }))
                        : e.error();
            }
        },
        error: function () {
            e.objectData.type = "error";
            var i = t('<div class="' + e.settings.classPrefix + 'inlineWrap"></div>');
            i.html(e.settings.errorMessage), e.objects.contentInner.html(i), e._showContent(e.objects.contentInner);
        },
        _calculateDimensions: function (t) {
            if ((e._cleanupDimensions(), t)) {
                var i = { ratio: 1, objectWidth: t.attr("width") ? t.attr("width") : t.attr(e._prefixAttributeName("width")), objectHeight: t.attr("height") ? t.attr("height") : t.attr(e._prefixAttributeName("height")) };
                if (!e.settings.disableShrink)
                    switch (
                        ((i.maxWidth = parseInt(e.dimensions.windowWidth * e.settings.shrinkFactor)),
                        (i.maxHeight = parseInt(e.dimensions.windowHeight * e.settings.shrinkFactor)),
                        i.maxWidth > e.settings.maxWidth && (i.maxWidth = e.settings.maxWidth),
                        i.maxHeight > e.settings.maxHeight && (i.maxHeight = e.settings.maxHeight),
                        (i.differenceWidthAsPercent = parseInt((100 / i.maxWidth) * i.objectWidth)),
                        (i.differenceHeightAsPercent = parseInt((100 / i.maxHeight) * i.objectHeight)),
                        e.objectData.type)
                    ) {
                        case "image":
                        case "flash":
                        case "video":
                        case "iframe":
                        case "ajax":
                        case "inline":
                            if ("image" === e.objectData.type || !0 === e.settings.fixedRatio) {
                                i.differenceWidthAsPercent > 100 &&
                                    i.differenceWidthAsPercent > i.differenceHeightAsPercent &&
                                    ((i.objectWidth = i.maxWidth), (i.objectHeight = parseInt((i.objectHeight / i.differenceWidthAsPercent) * 100))),
                                    i.differenceHeightAsPercent > 100 &&
                                        i.differenceHeightAsPercent > i.differenceWidthAsPercent &&
                                        ((i.objectWidth = parseInt((i.objectWidth / i.differenceHeightAsPercent) * 100)), (i.objectHeight = i.maxHeight)),
                                    i.differenceHeightAsPercent > 100 &&
                                        i.differenceWidthAsPercent < i.differenceHeightAsPercent &&
                                        ((i.objectWidth = parseInt((i.maxWidth / i.differenceHeightAsPercent) * i.differenceWidthAsPercent)), (i.objectHeight = i.maxHeight));
                                break;
                            }
                        case "error":
                            !isNaN(i.objectWidth) && i.objectWidth > i.maxWidth && (i.objectWidth = i.maxWidth);
                            break;
                        default:
                            (isNaN(i.objectWidth) || i.objectWidth > i.maxWidth) && !e.settings.forceWidth && (i.objectWidth = i.maxWidth),
                                ((isNaN(i.objectHeight) && "auto" !== i.objectHeight) || i.objectHeight > i.maxHeight) && !e.settings.forceHeight && (i.objectHeight = i.maxHeight);
                    }
                if (e.settings.forceWidth) {
                    try {
                        i.objectWidth = e.settings[e.objectData.type].width;
                    } catch (t) {
                        i.objectWidth = e.settings.width || i.objectWidth;
                    }
                    i.maxWidth = null;
                }
                if ((t.attr(e._prefixAttributeName("max-width")) && (i.maxWidth = t.attr(e._prefixAttributeName("max-width"))), e.settings.forceHeight)) {
                    try {
                        i.objectHeight = e.settings[e.objectData.type].height;
                    } catch (t) {
                        i.objectHeight = e.settings.height || i.objectHeight;
                    }
                    i.maxHeight = null;
                }
                t.attr(e._prefixAttributeName("max-height")) && (i.maxHeight = t.attr(e._prefixAttributeName("max-height"))), e._adjustDimensions(t, i);
            }
        },
        _adjustDimensions: function (t, i) {
            t.css({ width: i.objectWidth, height: i.objectHeight, "max-width": i.maxWidth, "max-height": i.maxHeight }),
                e.objects.contentInner.css({ width: t.outerWidth(), height: t.outerHeight(), "max-width": "100%" }),
                e.objects.case.css({ width: e.objects.contentInner.outerWidth(), "max-width": "100%" }),
                e.objects.case.css({ "margin-top": parseInt(-e.objects.case.outerHeight() / 2), "margin-left": parseInt(-e.objects.case.outerWidth() / 2) });
        },
        _loading: function (t) {
            "start" === t ? (e.objects.case.addClass(e.settings.classPrefix + "loading"), e.objects.loading.show()) : "end" === t && (e.objects.case.removeClass(e.settings.classPrefix + "loading"), e.objects.loading.hide());
        },
        getViewportDimensions: function () {
            return { windowWidth: t(window).innerWidth(), windowHeight: t(window).innerHeight() };
        },
        _verifyDataUrl: function (t) {
            return !(!t || void 0 === t || "" === t) && (t.indexOf("#") > -1 && (t = "#" + (t = t.split("#"))[t.length - 1]), e._normalizeUrl(t.toString()));
        },
        _getFileUrlSuffix: function (t) {
            return /(?:\.([^.]+))?$/.exec(t.toLowerCase())[1];
        },
        _verifyDataType: function (t) {
            var i = e.settings.typeMapping;
            if (!t) return !1;
            if (e.settings.type) for (var s in i) if (s === e.settings.type) return e.settings.type;
            for (var s in i)
                if (i.hasOwnProperty(s))
                    for (var n = i[s].split(","), a = 0; a < n.length; a++) {
                        var o = n[a].toLowerCase(),
                            c = new RegExp(".(" + o + ")$", "i"),
                            r = t.toLowerCase().split("?")[0].substr(-5);
                        if (!0 === c.test(r) || ("inline" === s && t.indexOf(o) > -1)) return s;
                    }
            return "iframe";
        },
        _addElements: function () {
            (void 0 !== e.objects.case && t("#" + e.objects.case.attr("id")).length) || e.settings.markup();
        },
        _showContent: function (t) {
            e.objects.document.attr(e._prefixAttributeName("type"), e.objectData.type), (e.cache.object = t), e._callHooks(e.settings.onBeforeShow), e.settings.breakBeforeShow || e.show();
        },
        _startInTransition: function () {
            switch (e.transition.in()) {
                case "scrollTop":
                case "scrollRight":
                case "scrollBottom":
                case "scrollLeft":
                case "scrollHorizontal":
                case "scrollVertical":
                    e.transition.scroll(e.objects.case, "in", e.settings.speedIn), e.transition.fade(e.objects.contentInner, "in", e.settings.speedIn);
                    break;
                case "elastic":
                    e.objects.case.css("opacity") < 1 && (e.transition.zoom(e.objects.case, "in", e.settings.speedIn), e.transition.fade(e.objects.contentInner, "in", e.settings.speedIn));
                case "fade":
                case "fadeInline":
                    e.transition.fade(e.objects.case, "in", e.settings.speedIn), e.transition.fade(e.objects.contentInner, "in", e.settings.speedIn);
                    break;
                default:
                    e.transition.fade(e.objects.case, "in", 0);
            }
            e._loading("end"),
                (e.isBusy = !1),
                e.cache.firstOpened || (e.cache.firstOpened = e.objectData.this),
                e.objects.info.hide(),
                setTimeout(function () {
                    e.transition.fade(e.objects.info, "in", e.settings.speedIn);
                }, e.settings.speedIn),
                e._callHooks(e.settings.onFinish);
        },
        _processContent: function () {
            switch (((e.isBusy = !0), e.transition.fade(e.objects.info, "out", 0), e.settings.transitionOut)) {
                case "scrollTop":
                case "scrollRight":
                case "scrollBottom":
                case "scrollLeft":
                case "scrollVertical":
                case "scrollHorizontal":
                    e.objects.case.is(":hidden")
                        ? (e.transition.fade(e.objects.contentInner, "out", 0),
                          e.transition.fade(e.objects.case, "out", 0, 0, function () {
                              e._loadContent();
                          }))
                        : e.transition.scroll(e.objects.case, "out", e.settings.speedOut, function () {
                              e._loadContent();
                          });
                    break;
                case "fade":
                    e.objects.case.is(":hidden")
                        ? e.transition.fade(e.objects.case, "out", 0, 0, function () {
                              e._loadContent();
                          })
                        : e.transition.fade(e.objects.case, "out", e.settings.speedOut, 0, function () {
                              e._loadContent();
                          });
                    break;
                case "fadeInline":
                case "elastic":
                    e.objects.case.is(":hidden")
                        ? e.transition.fade(e.objects.case, "out", 0, 0, function () {
                              e._loadContent();
                          })
                        : e.transition.fade(e.objects.contentInner, "out", e.settings.speedOut, 0, function () {
                              e._loadContent();
                          });
                    break;
                default:
                    e.transition.fade(e.objects.case, "out", 0, 0, function () {
                        e._loadContent();
                    });
            }
        },
        _handleEvents: function () {
            e._unbindEvents(),
                e.objects.nav.children().not(e.objects.close).hide(),
                e.isSlideshowEnabled() && ((!0 !== e.settings.slideshowAutoStart && !e.isSlideshowStarted) || e.objects.nav.hasClass(e.settings.classPrefix + "paused") ? e._stopTimeout() : e._startTimeout()),
                e.settings.liveResize && e._watchResizeInteraction(),
                e.objects.close.click(function (t) {
                    t.preventDefault(), e.close();
                }),
                !0 === e.settings.closeOnOverlayClick &&
                    e.objects.overlay.css("cursor", "pointer").click(function (t) {
                        t.preventDefault(), e.close();
                    }),
                !0 === e.settings.useKeys && e._addKeyEvents(),
                e.objectData.isPartOfSequence &&
                    (e.objects.nav.attr(e._prefixAttributeName("ispartofsequence"), !0),
                    e.objects.nav.data("items", e._setNavigation()),
                    e.objects.prev.click(function (t) {
                        t.preventDefault(),
                            (!0 !== e.settings.navigateEndless && e.item.isFirst()) || (e.objects.prev.unbind("click"), (e.cache.action = "prev"), e.objects.nav.data("items").prev.click(), e.isSlideshowEnabled() && e._stopTimeout());
                    }),
                    e.objects.next.click(function (t) {
                        t.preventDefault(),
                            (!0 !== e.settings.navigateEndless && e.item.isLast()) || (e.objects.next.unbind("click"), (e.cache.action = "next"), e.objects.nav.data("items").next.click(), e.isSlideshowEnabled() && e._stopTimeout());
                    }),
                    e.isSlideshowEnabled() &&
                        (e.objects.play.click(function (t) {
                            t.preventDefault(), e._startTimeout();
                        }),
                        e.objects.pause.click(function (t) {
                            t.preventDefault(), e._stopTimeout();
                        })),
                    !0 === e.settings.swipe &&
                        (t.isPlainObject(t.event.special.swipeleft) &&
                            e.objects.case.on("swipeleft", function (t) {
                                t.preventDefault(), e.objects.next.click(), e.isSlideshowEnabled() && e._stopTimeout();
                            }),
                        t.isPlainObject(t.event.special.swiperight) &&
                            e.objects.case.on("swiperight", function (t) {
                                t.preventDefault(), e.objects.prev.click(), e.isSlideshowEnabled() && e._stopTimeout();
                            })));
        },
        _addKeyEvents: function () {
            t(document).bind("keyup.lightcase", function (t) {
                if (!e.isBusy)
                    switch (t.keyCode) {
                        case 27:
                            e.objects.close.click();
                            break;
                        case 37:
                            e.objectData.isPartOfSequence && e.objects.prev.click();
                            break;
                        case 39:
                            e.objectData.isPartOfSequence && e.objects.next.click();
                    }
            });
        },
        _startTimeout: function () {
            (e.isSlideshowStarted = !0),
                e.objects.play.hide(),
                e.objects.pause.show(),
                (e.cache.action = "next"),
                e.objects.nav.removeClass(e.settings.classPrefix + "paused"),
                (e.timeout = setTimeout(function () {
                    e.objects.nav.data("items").next.click();
                }, e.settings.timeout));
        },
        _stopTimeout: function () {
            e.objects.play.show(), e.objects.pause.hide(), e.objects.nav.addClass(e.settings.classPrefix + "paused"), clearTimeout(e.timeout);
        },
        _setNavigation: function () {
            var i = t(e.cache.selector || e.settings.attr),
                s = e.objectData.sequenceLength - 1,
                n = { prev: i.eq(e.objectData.prevIndex), next: i.eq(e.objectData.nextIndex) };
            return (
                e.objectData.currentIndex > 0 ? e.objects.prev.show() : (n.prevItem = i.eq(s)),
                e.objectData.nextIndex <= s ? e.objects.next.show() : (n.next = i.eq(0)),
                !0 === e.settings.navigateEndless && (e.objects.prev.show(), e.objects.next.show()),
                n
            );
        },
        item: {
            isFirst: function () {
                return 0 === e.objectData.currentIndex;
            },
            isFirstOpened: function () {
                return e.objectData.this.is(e.cache.firstOpened);
            },
            isLast: function () {
                return e.objectData.currentIndex === e.objectData.sequenceLength - 1;
            },
        },
        _cloneObject: function (t) {
            var i = t.clone(),
                s = t.attr("id");
            return t.is(":hidden") ? (e._cacheObjectData(t), t.attr("id", e.settings.idPrefix + "temp-" + s).empty()) : i.removeAttr("id"), i.show();
        },
        isMobileDevice: function () {
            return !!navigator.userAgent.toLowerCase().match(e.settings.mobileMatchExpression);
        },
        isTransitionSupported: function () {
            var t = e.objects.body.get(0),
                i = !1,
                s = { transition: "", WebkitTransition: "-webkit-", MozTransition: "-moz-", OTransition: "-o-", MsTransition: "-ms-" };
            for (var n in s) s.hasOwnProperty(n) && n in t.style && ((e.support.transition = s[n]), (i = !0));
            return i;
        },
        transition: {
            in: function () {
                return e.settings.transitionOpen && !e.cache.firstOpened ? e.settings.transitionOpen : e.settings.transitionIn;
            },
            fade: function (t, i, s, n, a) {
                var o = "in" === i,
                    c = {},
                    r = t.css("opacity"),
                    l = {},
                    d = n || (o ? 1 : 0);
                (!e.isOpen && o) ||
                    ((c.opacity = r),
                    (l.opacity = d),
                    t.css(e.support.transition + "transition", "none"),
                    t.css(c).show(),
                    e.support.transitions
                        ? ((l[e.support.transition + "transition"] = s + "ms ease"),
                          setTimeout(function () {
                              t.css(l),
                                  setTimeout(function () {
                                      t.css(e.support.transition + "transition", ""), !a || (!e.isOpen && o) || a();
                                  }, s);
                          }, 15))
                        : (t.stop(), t.animate(l, s, a)));
            },
            scroll: function (t, i, s, n) {
                var a = "in" === i,
                    o = a ? e.settings.transitionIn : e.settings.transitionOut,
                    c = "left",
                    r = {},
                    l = a ? 0 : 1,
                    d = a ? "-50%" : "50%",
                    u = {},
                    h = a ? 1 : 0,
                    f = a ? "50%" : "-50%";
                if (e.isOpen || !a) {
                    switch (o) {
                        case "scrollTop":
                            c = "top";
                            break;
                        case "scrollRight":
                            (d = a ? "150%" : "50%"), (f = a ? "50%" : "150%");
                            break;
                        case "scrollBottom":
                            (c = "top"), (d = a ? "150%" : "50%"), (f = a ? "50%" : "150%");
                            break;
                        case "scrollHorizontal":
                            (d = a ? "150%" : "50%"), (f = a ? "50%" : "-50%");
                            break;
                        case "scrollVertical":
                            (c = "top"), (d = a ? "-50%" : "50%"), (f = a ? "50%" : "150%");
                    }
                    if ("prev" === e.cache.action)
                        switch (o) {
                            case "scrollHorizontal":
                                (d = a ? "-50%" : "50%"), (f = a ? "50%" : "150%");
                                break;
                            case "scrollVertical":
                                (d = a ? "150%" : "50%"), (f = a ? "50%" : "-50%");
                        }
                    (r.opacity = l),
                        (r[c] = d),
                        (u.opacity = h),
                        (u[c] = f),
                        t.css(e.support.transition + "transition", "none"),
                        t.css(r).show(),
                        e.support.transitions
                            ? ((u[e.support.transition + "transition"] = s + "ms ease"),
                              setTimeout(function () {
                                  t.css(u),
                                      setTimeout(function () {
                                          t.css(e.support.transition + "transition", ""), !n || (!e.isOpen && a) || n();
                                      }, s);
                              }, 15))
                            : (t.stop(), t.animate(u, s, n));
                }
            },
            zoom: function (t, i, s, n) {
                var a = "in" === i,
                    o = {},
                    c = t.css("opacity"),
                    r = a ? "scale(0.75)" : "scale(1)",
                    l = {},
                    d = a ? 1 : 0,
                    u = a ? "scale(1)" : "scale(0.75)";
                (!e.isOpen && a) ||
                    ((o.opacity = c),
                    (o[e.support.transition + "transform"] = r),
                    (l.opacity = d),
                    t.css(e.support.transition + "transition", "none"),
                    t.css(o).show(),
                    e.support.transitions
                        ? ((l[e.support.transition + "transform"] = u),
                          (l[e.support.transition + "transition"] = s + "ms ease"),
                          setTimeout(function () {
                              t.css(l),
                                  setTimeout(function () {
                                      t.css(e.support.transition + "transform", ""), t.css(e.support.transition + "transition", ""), !n || (!e.isOpen && a) || n();
                                  }, s);
                          }, 15))
                        : (t.stop(), t.animate(l, s, n)));
            },
        },
        _callHooks: function (i) {
            "object" == typeof i &&
                t.each(i, function (t, i) {
                    "function" == typeof i && i.call(e.origin);
                });
        },
        _cacheObjectData: function (i) {
            t.data(i, "cache", { id: i.attr("id"), content: i.html() }), (e.cache.originalObject = i);
        },
        _restoreObject: function () {
            var i = t('[id^="' + e.settings.idPrefix + 'temp-"]');
            i.attr("id", t.data(e.cache.originalObject, "cache").id), i.html(t.data(e.cache.originalObject, "cache").content);
        },
        resize: function (t, i) {
            e.isOpen &&
                (e.isSlideshowEnabled() && e._stopTimeout(),
                "object" == typeof i &&
                    null !== i &&
                    (i.width && e.cache.object.attr(e._prefixAttributeName("width"), i.width),
                    i.maxWidth && e.cache.object.attr(e._prefixAttributeName("max-width"), i.maxWidth),
                    i.height && e.cache.object.attr(e._prefixAttributeName("height"), i.height),
                    i.maxHeight && e.cache.object.attr(e._prefixAttributeName("max-height"), i.maxHeight)),
                (e.dimensions = e.getViewportDimensions()),
                e._calculateDimensions(e.cache.object),
                e._callHooks(e.settings.onResize));
        },
        _watchResizeInteraction: function () {
            t(window).resize(e.resize);
        },
        _unwatchResizeInteraction: function () {
            t(window).off("resize", e.resize);
        },
        _switchToFullScreenMode: function () {
            (e.settings.shrinkFactor = 1), (e.settings.overlayOpacity = 1), t("html").addClass(e.settings.classPrefix + "fullScreenMode");
        },
        _open: function () {
            switch (
                ((e.isOpen = !0),
                (e.support.transitions = !!e.settings.cssTransitions && e.isTransitionSupported()),
                (e.support.mobileDevice = e.isMobileDevice()),
                e.support.mobileDevice && (t("html").addClass(e.settings.classPrefix + "isMobileDevice"), e.settings.fullScreenModeForMobile && e._switchToFullScreenMode()),
                e.settings.transitionIn || (e.settings.transitionIn = e.settings.transition),
                e.settings.transitionOut || (e.settings.transitionOut = e.settings.transition),
                e.transition.in())
            ) {
                case "fade":
                case "fadeInline":
                case "elastic":
                case "scrollTop":
                case "scrollRight":
                case "scrollBottom":
                case "scrollLeft":
                case "scrollVertical":
                case "scrollHorizontal":
                    e.objects.case.is(":hidden") && (e.objects.close.css("opacity", 0), e.objects.overlay.css("opacity", 0), e.objects.case.css("opacity", 0), e.objects.contentInner.css("opacity", 0)),
                        e.transition.fade(e.objects.overlay, "in", e.settings.speedIn, e.settings.overlayOpacity, function () {
                            e.transition.fade(e.objects.close, "in", e.settings.speedIn), e._handleEvents(), e._processContent();
                        });
                    break;
                default:
                    e.transition.fade(e.objects.overlay, "in", 0, e.settings.overlayOpacity, function () {
                        e.transition.fade(e.objects.close, "in", 0), e._handleEvents(), e._processContent();
                    });
            }
            e.objects.document.addClass(e.settings.classPrefix + "open"), e.objects.case.attr("aria-hidden", "false");
        },
        show: function () {
            e._callHooks(e.settings.onBeforeCalculateDimensions), e._calculateDimensions(e.cache.object), e._callHooks(e.settings.onAfterCalculateDimensions), e._startInTransition();
        },
        close: function () {
            switch (
                ((e.isOpen = !1),
                e.isSlideshowEnabled() && (e._stopTimeout(), (e.isSlideshowStarted = !1), e.objects.nav.removeClass(e.settings.classPrefix + "paused")),
                e.objects.loading.hide(),
                e._unbindEvents(),
                e._unwatchResizeInteraction(),
                t("html").removeClass(e.settings.classPrefix + "open"),
                e.objects.case.attr("aria-hidden", "true"),
                e.objects.nav.children().hide(),
                e.objects.close.hide(),
                e._callHooks(e.settings.onClose),
                e.transition.fade(e.objects.info, "out", 0),
                e.settings.transitionClose || e.settings.transitionOut)
            ) {
                case "fade":
                case "fadeInline":
                case "scrollTop":
                case "scrollRight":
                case "scrollBottom":
                case "scrollLeft":
                case "scrollHorizontal":
                case "scrollVertical":
                    e.transition.fade(e.objects.case, "out", e.settings.speedOut, 0, function () {
                        e.transition.fade(e.objects.overlay, "out", e.settings.speedOut, 0, function () {
                            e.cleanup();
                        });
                    });
                    break;
                case "elastic":
                    e.transition.zoom(e.objects.case, "out", e.settings.speedOut, function () {
                        e.transition.fade(e.objects.overlay, "out", e.settings.speedOut, 0, function () {
                            e.cleanup();
                        });
                    });
                    break;
                default:
                    e.cleanup();
            }
        },
        _unbindEvents: function () {
            e.objects.overlay.unbind("click"),
                t(document).unbind("keyup.lightcase"),
                e.objects.case.unbind("swipeleft").unbind("swiperight"),
                e.objects.prev.unbind("click"),
                e.objects.next.unbind("click"),
                e.objects.play.unbind("click"),
                e.objects.pause.unbind("click"),
                e.objects.close.unbind("click");
        },
        _cleanupDimensions: function () {
            var t = e.objects.contentInner.css("opacity");
            e.objects.case.css({ width: "", height: "", top: "", left: "", "margin-top": "", "margin-left": "" }), e.objects.contentInner.removeAttr("style").css("opacity", t), e.objects.contentInner.children().removeAttr("style");
        },
        cleanup: function () {
            e._cleanupDimensions(),
                e.objects.loading.hide(),
                e.objects.overlay.hide(),
                e.objects.case.hide(),
                e.objects.prev.hide(),
                e.objects.next.hide(),
                e.objects.play.hide(),
                e.objects.pause.hide(),
                e.objects.document.removeAttr(e._prefixAttributeName("type")),
                e.objects.nav.removeAttr(e._prefixAttributeName("ispartofsequence")),
                e.objects.contentInner.empty().hide(),
                e.objects.info.children().empty(),
                e.cache.originalObject && e._restoreObject(),
                e._callHooks(e.settings.onCleanup),
                (e.cache = {});
        },
        _matchMedia: function () {
            return window.matchMedia || window.msMatchMedia;
        },
        _devicePixelRatio: function () {
            return window.devicePixelRatio || 1;
        },
        _isPublicMethod: function (t) {
            return "function" == typeof e[t] && "_" !== t.charAt(0);
        },
        _export: function () {
            (window.lightcase = {}),
                t.each(e, function (t) {
                    e._isPublicMethod(t) && (lightcase[t] = e[t]);
                });
        },
    };
    e._export(),
        (t.fn.lightcase = function (i) {
            return e._isPublicMethod(i) ? e[i].apply(this, Array.prototype.slice.call(arguments, 1)) : "object" != typeof i && i ? void t.error("Method " + i + " does not exist on jQuery.lightcase") : e.init.apply(this, arguments);
        });
})(jQuery);

/*-------------------------------------------------------------
  9. CounterUp jQuery
---------------------------------------------------------------*/
/*!
 *
 * jquery.counterup.js
 * https://github.com/bfintal/Counter-Up
 * v1.0
 *
 */
(function ($) {
    "use strict";
    $.fn.counterUp = function (options) {
        var settings = $.extend({ time: 400, delay: 10, offset: 100, beginAt: 0, formatter: false, context: "window", callback: function () {} }, options),
            s;
        return this.each(function () {
            var $this = $(this),
                counter = {
                    time: $(this).data("counterup-time") || settings.time,
                    delay: $(this).data("counterup-delay") || settings.delay,
                    offset: $(this).data("counterup-offset") || settings.offset,
                    beginAt: $(this).data("counterup-beginat") || settings.beginAt,
                    context: $(this).data("counterup-context") || settings.context,
                };
            var counterUpper = function () {
                var nums = [];
                var divisions = counter.time / counter.delay;
                var num = $(this).attr("data-num") ? $(this).attr("data-num") : $this.text();
                var isComma = /[0-9]+,[0-9]+/.test(num);
                num = num.replace(/,/g, "");
                var decimalPlaces = (num.split(".")[1] || []).length;
                if (counter.beginAt > num) counter.beginAt = num;
                var isTime = /[0-9]+:[0-9]+:[0-9]+/.test(num);
                if (isTime) {
                    var times = num.split(":"),
                        m = 1;
                    s = 0;
                    while (times.length > 0) {
                        s += m * parseInt(times.pop(), 10);
                        m *= 60;
                    }
                }
                for (var i = divisions; i >= (counter.beginAt / num) * divisions; i--) {
                    var newNum = parseFloat((num / divisions) * i).toFixed(decimalPlaces);
                    if (isTime) {
                        newNum = parseInt((s / divisions) * i);
                        var hours = parseInt(newNum / 3600) % 24;
                        var minutes = parseInt(newNum / 60) % 60;
                        var seconds = parseInt(newNum % 60, 10);
                        newNum = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
                    }
                    if (isComma) {
                        while (/(\d+)(\d{3})/.test(newNum.toString())) {
                            newNum = newNum.toString().replace(/(\d+)(\d{3})/, "$1" + "," + "$2");
                        }
                    }
                    if (settings.formatter) {
                        newNum = settings.formatter.call(this, newNum);
                    }
                    nums.unshift(newNum);
                }
                $this.data("counterup-nums", nums);
                $this.text(counter.beginAt);
                var f = function () {
                    if (!$this.data("counterup-nums")) {
                        settings.callback.call(this);
                        return;
                    }
                    $this.html($this.data("counterup-nums").shift());
                    if ($this.data("counterup-nums").length) {
                        setTimeout($this.data("counterup-func"), counter.delay);
                    } else {
                        $this.data("counterup-nums", null);
                        $this.data("counterup-func", null);
                        settings.callback.call(this);
                    }
                };
                $this.data("counterup-func", f);
                setTimeout($this.data("counterup-func"), counter.delay);
            };
            $this.waypoint(
                function (direction) {
                    counterUpper();
                    this.destroy();
                },
                { offset: counter.offset + "%", context: counter.context }
            );
        });
    };
})(jQuery);

/*-------------------------------------------------------------
  10. Countdown jQuery
---------------------------------------------------------------*/
/*!
 * The Final Countdown for jQuery v2.2.0 (http://hilios.github.io/jQuery.countdown/)
 * Copyright (c) 2016 Edson Hilios
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
!(function (a) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], a) : a(jQuery);
})(function (a) {
    "use strict";
    function b(a) {
        if (a instanceof Date) return a;
        if (String(a).match(g)) return String(a).match(/^[0-9]*$/) && (a = Number(a)), String(a).match(/\-/) && (a = String(a).replace(/\-/g, "/")), new Date(a);
        throw new Error("Couldn't cast `" + a + "` to a date object.");
    }
    function c(a) {
        var b = a.toString().replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
        return new RegExp(b);
    }
    function d(a) {
        return function (b) {
            var d = b.match(/%(-|!)?[A-Z]{1}(:[^;]+;)?/gi);
            if (d)
                for (var f = 0, g = d.length; f < g; ++f) {
                    var h = d[f].match(/%(-|!)?([a-zA-Z]{1})(:[^;]+;)?/),
                        j = c(h[0]),
                        k = h[1] || "",
                        l = h[3] || "",
                        m = null;
                    (h = h[2]), i.hasOwnProperty(h) && ((m = i[h]), (m = Number(a[m]))), null !== m && ("!" === k && (m = e(l, m)), "" === k && m < 10 && (m = "0" + m.toString()), (b = b.replace(j, m.toString())));
                }
            return (b = b.replace(/%%/, "%"));
        };
    }
    function e(a, b) {
        var c = "s",
            d = "";
        return a && ((a = a.replace(/(:|;|\s)/gi, "").split(/\,/)), 1 === a.length ? (c = a[0]) : ((d = a[0]), (c = a[1]))), Math.abs(b) > 1 ? c : d;
    }
    var f = [],
        g = [],
        h = { precision: 100, elapse: !1, defer: !1 };
    g.push(/^[0-9]*$/.source), g.push(/([0-9]{1,2}\/){2}[0-9]{4}( [0-9]{1,2}(:[0-9]{2}){2})?/.source), g.push(/[0-9]{4}([\/\-][0-9]{1,2}){2}( [0-9]{1,2}(:[0-9]{2}){2})?/.source), (g = new RegExp(g.join("|")));
    var i = { Y: "years", m: "months", n: "daysToMonth", d: "daysToWeek", w: "weeks", W: "weeksToMonth", H: "hours", M: "minutes", S: "seconds", D: "totalDays", I: "totalHours", N: "totalMinutes", T: "totalSeconds" },
        j = function (b, c, d) {
            (this.el = b),
                (this.$el = a(b)),
                (this.interval = null),
                (this.offset = {}),
                (this.options = a.extend({}, h)),
                (this.firstTick = !0),
                (this.instanceNumber = f.length),
                f.push(this),
                this.$el.data("countdown-instance", this.instanceNumber),
                d && ("function" == typeof d ? (this.$el.on("update.countdown", d), this.$el.on("stoped.countdown", d), this.$el.on("finish.countdown", d)) : (this.options = a.extend({}, h, d))),
                this.setFinalDate(c),
                this.options.defer === !1 && this.start();
        };
    a.extend(j.prototype, {
        start: function () {
            null !== this.interval && clearInterval(this.interval);
            var a = this;
            this.update(),
                (this.interval = setInterval(function () {
                    a.update.call(a);
                }, this.options.precision));
        },
        stop: function () {
            clearInterval(this.interval), (this.interval = null), this.dispatchEvent("stoped");
        },
        toggle: function () {
            this.interval ? this.stop() : this.start();
        },
        pause: function () {
            this.stop();
        },
        resume: function () {
            this.start();
        },
        remove: function () {
            this.stop.call(this), (f[this.instanceNumber] = null), delete this.$el.data().countdownInstance;
        },
        setFinalDate: function (a) {
            this.finalDate = b(a);
        },
        update: function () {
            if (0 === this.$el.closest("html").length) return void this.remove();
            var a,
                b = new Date();
            return (
                (a = this.finalDate.getTime() - b.getTime()),
                (a = Math.ceil(a / 1e3)),
                (a = !this.options.elapse && a < 0 ? 0 : Math.abs(a)),
                this.totalSecsLeft === a || this.firstTick
                    ? void (this.firstTick = !1)
                    : ((this.totalSecsLeft = a),
                      (this.elapsed = b >= this.finalDate),
                      (this.offset = {
                          seconds: this.totalSecsLeft % 60,
                          minutes: Math.floor(this.totalSecsLeft / 60) % 60,
                          hours: Math.floor(this.totalSecsLeft / 60 / 60) % 24,
                          days: Math.floor(this.totalSecsLeft / 60 / 60 / 24) % 7,
                          daysToWeek: Math.floor(this.totalSecsLeft / 60 / 60 / 24) % 7,
                          daysToMonth: Math.floor((this.totalSecsLeft / 60 / 60 / 24) % 30.4368),
                          weeks: Math.floor(this.totalSecsLeft / 60 / 60 / 24 / 7),
                          weeksToMonth: Math.floor(this.totalSecsLeft / 60 / 60 / 24 / 7) % 4,
                          months: Math.floor(this.totalSecsLeft / 60 / 60 / 24 / 30.4368),
                          years: Math.abs(this.finalDate.getFullYear() - b.getFullYear()),
                          totalDays: Math.floor(this.totalSecsLeft / 60 / 60 / 24),
                          totalHours: Math.floor(this.totalSecsLeft / 60 / 60),
                          totalMinutes: Math.floor(this.totalSecsLeft / 60),
                          totalSeconds: this.totalSecsLeft,
                      }),
                      void (this.options.elapse || 0 !== this.totalSecsLeft ? this.dispatchEvent("update") : (this.stop(), this.dispatchEvent("finish"))))
            );
        },
        dispatchEvent: function (b) {
            var c = a.Event(b + ".countdown");
            (c.finalDate = this.finalDate), (c.elapsed = this.elapsed), (c.offset = a.extend({}, this.offset)), (c.strftime = d(this.offset)), this.$el.trigger(c);
        },
    }),
        (a.fn.countdown = function () {
            var b = Array.prototype.slice.call(arguments, 0);
            return this.each(function () {
                var c = a(this).data("countdown-instance");
                if (void 0 !== c) {
                    var d = f[c],
                        e = b[0];
                    j.prototype.hasOwnProperty(e)
                        ? d[e].apply(d, b.slice(1))
                        : null === String(e).match(/^[$A-Z_][0-9A-Z_$]*$/i)
                        ? (d.setFinalDate.call(d, e), d.start())
                        : a.error("Method %s does not exist on jQuery.countdown".replace(/\%s/gi, e));
                } else new j(this, b[0], b[1]);
            });
        });
});

/*-------------------------------------------------------------
  11. Instafeed jQuery
---------------------------------------------------------------*/
/*!
 * jquery.instagramFeed
 *
 * @version 1.3.2
 *
 * @author Javier Sanahuja Liebana <bannss1@gmail.com>
 * @contributor csanahuja <csanahuja10@gmail.com>
 *
 * https://github.com/jsanahuja/jquery.instagramFeed
 *
 */
(function (a) {
    function b(a) {
        return a.replace(/[&<>"'`=\/]/g, function (a) {
            return e[a];
        });
    }
    var c = {
            host: "https://www.instagram.com/",
            username: "",
            tag: "",
            container: "",
            display_profile: !0,
            display_biography: !0,
            display_gallery: !0,
            display_igtv: !1,
            callback: null,
            styling: !0,
            items: 8,
            items_per_row: 4,
            margin: 0.5,
            image_size: 640,
            lazy_load: !1,
            on_error: console.error,
        },
        d = { 150: 0, 240: 1, 320: 2, 480: 3, 640: 4 },
        e = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;", "/": "&#x2F;", "`": "&#x60;", "=": "&#x3D;" };
    a.instagramFeed = function (e) {
        var f = a.fn.extend({}, c, e);
        if ("" == f.username && "" == f.tag) return f.on_error("Instagram Feed: Error, no username nor tag defined.", 1), !1;
        if (("undefined" != typeof f.get_data && console.warn("Instagram Feed: options.get_data is deprecated, options.callback is always called if defined"), null == f.callback && "" == f.container))
            return f.on_error("Instagram Feed: Error, neither container found nor callback defined.", 2), !1;
        var g = "" == f.username,
            h = g ? f.host + "explore/tags/" + f.tag + "/" : f.host + f.username + "/";
        return (
            a
                .get(h, function (c) {
                    try {
                        c = c.split("window._sharedData = ")[1].split("</script>")[0];
                    } catch (a) {
                        return void f.on_error("Instagram Feed: It looks like the profile you are trying to fetch is age restricted. See https://github.com/jsanahuja/InstagramFeed/issues/26", 3);
                    }
                    if (((c = JSON.parse(c.substr(0, c.length - 1))), (c = c.entry_data.ProfilePage || c.entry_data.TagPage), "undefined" == typeof c))
                        return void f.on_error("Instagram Feed: It looks like YOUR network has been temporary banned because of too many requests. See https://github.com/jsanahuja/jquery.instagramFeed/issues/25", 4);
                    if (((c = c[0].graphql.user || c[0].graphql.hashtag), "" != f.container)) {
                        var e = { profile_container: "", profile_image: "", profile_name: "", profile_biography: "", gallery_image: "" };
                        if (f.styling) {
                            (e.profile_container = " style='text-align:center;'"),
                                (e.profile_image = " style='border-radius:10em;width:15%;max-width:125px;min-width:50px;'"),
                                (e.profile_name = " style='font-size:1.2em;'"),
                                (e.profile_biography = " style='font-size:1em;'");
                            var h = (100 - 2 * f.margin * f.items_per_row) / f.items_per_row;
                            e.gallery_image = " style='margin:" + f.margin + "% " + f.margin + "%;width:" + h + "%;float:left;'";
                        }
                        var j = "";
                        f.display_profile &&
                            ((j += "<div class='instagram_profile'" + e.profile_container + ">"),
                            (j +=
                                "<img class='instagram_profile_image' src='" +
                                c.profile_pic_url +
                                "' alt='" +
                                (g ? c.name + " tag pic" : c.username + " profile pic") +
                                "'" +
                                e.profile_image +
                                (f.lazy_load ? " loading='lazy'" : "") +
                                " />"),
                            (j += g
                                ? "<p class='instagram_tag'" + e.profile_name + "><a href='https://www.instagram.com/explore/tags/" + f.tag + "' rel='noopener' target='_blank'>#" + f.tag + "</a></p>"
                                : "<p class='instagram_username'" + e.profile_name + ">@" + c.full_name + " (<a href='https://www.instagram.com/" + f.username + "' rel='noopener' target='_blank'>@" + f.username + "</a>)</p>"),
                            !g && f.display_biography && (j += "<p class='instagram_biography'" + e.profile_biography + ">" + c.biography + "</p>"),
                            (j += "</div>"));
                        var k = "undefined" == typeof d[f.image_size] ? d[640] : d[f.image_size];
                        if (f.display_gallery)
                            if ("undefined" != typeof c.is_private && !0 === c.is_private) j += "<p class='instagram_private'><strong>This profile is private</strong></p>";
                            else {
                                var l = (c.edge_owner_to_timeline_media || c.edge_hashtag_to_media).edges;
                                (s = l.length > f.items ? f.items : l.length), (j += "<div class='instagram_gallery'>");
                                for (var m = 0; m < s; m++) {
                                    var n,
                                        o,
                                        p,
                                        q = "https://www.instagram.com/p/" + l[m].node.shortcode;
                                    switch (l[m].node.__typename) {
                                        case "GraphSidecar":
                                            (o = "sidecar"), (n = l[m].node.thumbnail_resources[k].src);
                                            break;
                                        case "GraphVideo":
                                            (o = "video"), (n = l[m].node.thumbnail_src);
                                            break;
                                        default:
                                            (o = "image"), (n = l[m].node.thumbnail_resources[k].src);
                                    }
                                    (p =
                                        "undefined" != typeof l[m].node.edge_media_to_caption.edges[0] &&
                                        "undefined" != typeof l[m].node.edge_media_to_caption.edges[0].node &&
                                        "undefined" != typeof l[m].node.edge_media_to_caption.edges[0].node.text &&
                                        null !== l[m].node.edge_media_to_caption.edges[0].node.text
                                            ? l[m].node.edge_media_to_caption.edges[0].node.text
                                            : "undefined" != typeof l[m].node.accessibility_caption && null !== l[m].node.accessibility_caption
                                            ? l[m].node.accessibility_caption
                                            : (g ? c.name : c.username) + " image " + m),
                                        (j += "<a href='" + q + "' class='instagram-" + o + "' rel='noopener' target='_blank'>"),
                                        (j += "<img" + (f.lazy_load ? " loading='lazy'" : "") + " src='" + n + "' alt='" + b(p) + "'" + e.gallery_image + " />"),
                                        (j += "</a>");
                                }
                                j += "</div>";
                            }
                        if (f.display_igtv && "undefined" != typeof c.edge_felix_video_timeline) {
                            var r = c.edge_felix_video_timeline.edges,
                                s = r.length > f.items ? f.items : r.length;
                            if (0 < r.length) {
                                j += "<div class='instagram_igtv'>";
                                for (var m = 0; m < s; m++)
                                    (j += "<a href='https://www.instagram.com/p/" + r[m].node.shortcode + "' rel='noopener' target='_blank'>"),
                                        (j += "<img" + (f.lazy_load ? " loading='lazy'" : "") + " src='" + r[m].node.thumbnail_src + "' alt='" + f.username + " instagram image " + m + "'" + e.gallery_image + " />"),
                                        (j += "</a>");
                                j += "</div>";
                            }
                        }
                        a(f.container).html(j);
                    }
                    null != f.callback && f.callback(c);
                })
                .fail(function (a) {
                    f.on_error("Instagram Feed: Unable to fetch the given user/tag. Instagram responded with the status code: " + a.status, 5);
                }),
            !0
        );
    };
})(jQuery);

/*-------------------------------------------------------------
  12. Waypoints jQuery
---------------------------------------------------------------*/
/*!
Waypoints - 4.0.1
Copyright Â© 2011-2016 Caleb Troughton
Licensed under the MIT license.
https://github.com/imakewebthings/waypoints/blob/master/licenses.txt
*/
!(function () {
    "use strict";
    function t(o) {
        if (!o) throw new Error("No options passed to Waypoint constructor");
        if (!o.element) throw new Error("No element option passed to Waypoint constructor");
        if (!o.handler) throw new Error("No handler option passed to Waypoint constructor");
        (this.key = "waypoint-" + e),
            (this.options = t.Adapter.extend({}, t.defaults, o)),
            (this.element = this.options.element),
            (this.adapter = new t.Adapter(this.element)),
            (this.callback = o.handler),
            (this.axis = this.options.horizontal ? "horizontal" : "vertical"),
            (this.enabled = this.options.enabled),
            (this.triggerPoint = null),
            (this.group = t.Group.findOrCreate({ name: this.options.group, axis: this.axis })),
            (this.context = t.Context.findOrCreateByElement(this.options.context)),
            t.offsetAliases[this.options.offset] && (this.options.offset = t.offsetAliases[this.options.offset]),
            this.group.add(this),
            this.context.add(this),
            (i[this.key] = this),
            (e += 1);
    }
    var e = 0,
        i = {};
    (t.prototype.queueTrigger = function (t) {
        this.group.queueTrigger(this, t);
    }),
        (t.prototype.trigger = function (t) {
            this.enabled && this.callback && this.callback.apply(this, t);
        }),
        (t.prototype.destroy = function () {
            this.context.remove(this), this.group.remove(this), delete i[this.key];
        }),
        (t.prototype.disable = function () {
            return (this.enabled = !1), this;
        }),
        (t.prototype.enable = function () {
            return this.context.refresh(), (this.enabled = !0), this;
        }),
        (t.prototype.next = function () {
            return this.group.next(this);
        }),
        (t.prototype.previous = function () {
            return this.group.previous(this);
        }),
        (t.invokeAll = function (t) {
            var e = [];
            for (var o in i) e.push(i[o]);
            for (var n = 0, r = e.length; r > n; n++) e[n][t]();
        }),
        (t.destroyAll = function () {
            t.invokeAll("destroy");
        }),
        (t.disableAll = function () {
            t.invokeAll("disable");
        }),
        (t.enableAll = function () {
            t.Context.refreshAll();
            for (var e in i) i[e].enabled = !0;
            return this;
        }),
        (t.refreshAll = function () {
            t.Context.refreshAll();
        }),
        (t.viewportHeight = function () {
            return window.innerHeight || document.documentElement.clientHeight;
        }),
        (t.viewportWidth = function () {
            return document.documentElement.clientWidth;
        }),
        (t.adapters = []),
        (t.defaults = { context: window, continuous: !0, enabled: !0, group: "default", horizontal: !1, offset: 0 }),
        (t.offsetAliases = {
            "bottom-in-view": function () {
                return this.context.innerHeight() - this.adapter.outerHeight();
            },
            "right-in-view": function () {
                return this.context.innerWidth() - this.adapter.outerWidth();
            },
        }),
        (window.Waypoint = t);
})(),
    (function () {
        "use strict";
        function t(t) {
            window.setTimeout(t, 1e3 / 60);
        }
        function e(t) {
            (this.element = t),
                (this.Adapter = n.Adapter),
                (this.adapter = new this.Adapter(t)),
                (this.key = "waypoint-context-" + i),
                (this.didScroll = !1),
                (this.didResize = !1),
                (this.oldScroll = { x: this.adapter.scrollLeft(), y: this.adapter.scrollTop() }),
                (this.waypoints = { vertical: {}, horizontal: {} }),
                (t.waypointContextKey = this.key),
                (o[t.waypointContextKey] = this),
                (i += 1),
                n.windowContext || ((n.windowContext = !0), (n.windowContext = new e(window))),
                this.createThrottledScrollHandler(),
                this.createThrottledResizeHandler();
        }
        var i = 0,
            o = {},
            n = window.Waypoint,
            r = window.onload;
        (e.prototype.add = function (t) {
            var e = t.options.horizontal ? "horizontal" : "vertical";
            (this.waypoints[e][t.key] = t), this.refresh();
        }),
            (e.prototype.checkEmpty = function () {
                var t = this.Adapter.isEmptyObject(this.waypoints.horizontal),
                    e = this.Adapter.isEmptyObject(this.waypoints.vertical),
                    i = this.element == this.element.window;
                t && e && !i && (this.adapter.off(".waypoints"), delete o[this.key]);
            }),
            (e.prototype.createThrottledResizeHandler = function () {
                function t() {
                    e.handleResize(), (e.didResize = !1);
                }
                var e = this;
                this.adapter.on("resize.waypoints", function () {
                    e.didResize || ((e.didResize = !0), n.requestAnimationFrame(t));
                });
            }),
            (e.prototype.createThrottledScrollHandler = function () {
                function t() {
                    e.handleScroll(), (e.didScroll = !1);
                }
                var e = this;
                this.adapter.on("scroll.waypoints", function () {
                    (!e.didScroll || n.isTouch) && ((e.didScroll = !0), n.requestAnimationFrame(t));
                });
            }),
            (e.prototype.handleResize = function () {
                n.Context.refreshAll();
            }),
            (e.prototype.handleScroll = function () {
                var t = {},
                    e = {
                        horizontal: { newScroll: this.adapter.scrollLeft(), oldScroll: this.oldScroll.x, forward: "right", backward: "left" },
                        vertical: { newScroll: this.adapter.scrollTop(), oldScroll: this.oldScroll.y, forward: "down", backward: "up" },
                    };
                for (var i in e) {
                    var o = e[i],
                        n = o.newScroll > o.oldScroll,
                        r = n ? o.forward : o.backward;
                    for (var s in this.waypoints[i]) {
                        var a = this.waypoints[i][s];
                        if (null !== a.triggerPoint) {
                            var l = o.oldScroll < a.triggerPoint,
                                h = o.newScroll >= a.triggerPoint,
                                p = l && h,
                                u = !l && !h;
                            (p || u) && (a.queueTrigger(r), (t[a.group.id] = a.group));
                        }
                    }
                }
                for (var c in t) t[c].flushTriggers();
                this.oldScroll = { x: e.horizontal.newScroll, y: e.vertical.newScroll };
            }),
            (e.prototype.innerHeight = function () {
                return this.element == this.element.window ? n.viewportHeight() : this.adapter.innerHeight();
            }),
            (e.prototype.remove = function (t) {
                delete this.waypoints[t.axis][t.key], this.checkEmpty();
            }),
            (e.prototype.innerWidth = function () {
                return this.element == this.element.window ? n.viewportWidth() : this.adapter.innerWidth();
            }),
            (e.prototype.destroy = function () {
                var t = [];
                for (var e in this.waypoints) for (var i in this.waypoints[e]) t.push(this.waypoints[e][i]);
                for (var o = 0, n = t.length; n > o; o++) t[o].destroy();
            }),
            (e.prototype.refresh = function () {
                var t,
                    e = this.element == this.element.window,
                    i = e ? void 0 : this.adapter.offset(),
                    o = {};
                this.handleScroll(),
                    (t = {
                        horizontal: { contextOffset: e ? 0 : i.left, contextScroll: e ? 0 : this.oldScroll.x, contextDimension: this.innerWidth(), oldScroll: this.oldScroll.x, forward: "right", backward: "left", offsetProp: "left" },
                        vertical: { contextOffset: e ? 0 : i.top, contextScroll: e ? 0 : this.oldScroll.y, contextDimension: this.innerHeight(), oldScroll: this.oldScroll.y, forward: "down", backward: "up", offsetProp: "top" },
                    });
                for (var r in t) {
                    var s = t[r];
                    for (var a in this.waypoints[r]) {
                        var l,
                            h,
                            p,
                            u,
                            c,
                            d = this.waypoints[r][a],
                            f = d.options.offset,
                            w = d.triggerPoint,
                            y = 0,
                            g = null == w;
                        d.element !== d.element.window && (y = d.adapter.offset()[s.offsetProp]),
                            "function" == typeof f ? (f = f.apply(d)) : "string" == typeof f && ((f = parseFloat(f)), d.options.offset.indexOf("%") > -1 && (f = Math.ceil((s.contextDimension * f) / 100))),
                            (l = s.contextScroll - s.contextOffset),
                            (d.triggerPoint = Math.floor(y + l - f)),
                            (h = w < s.oldScroll),
                            (p = d.triggerPoint >= s.oldScroll),
                            (u = h && p),
                            (c = !h && !p),
                            !g && u
                                ? (d.queueTrigger(s.backward), (o[d.group.id] = d.group))
                                : !g && c
                                ? (d.queueTrigger(s.forward), (o[d.group.id] = d.group))
                                : g && s.oldScroll >= d.triggerPoint && (d.queueTrigger(s.forward), (o[d.group.id] = d.group));
                    }
                }
                return (
                    n.requestAnimationFrame(function () {
                        for (var t in o) o[t].flushTriggers();
                    }),
                    this
                );
            }),
            (e.findOrCreateByElement = function (t) {
                return e.findByElement(t) || new e(t);
            }),
            (e.refreshAll = function () {
                for (var t in o) o[t].refresh();
            }),
            (e.findByElement = function (t) {
                return o[t.waypointContextKey];
            }),
            (window.onload = function () {
                r && r(), e.refreshAll();
            }),
            (n.requestAnimationFrame = function (e) {
                var i = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || t;
                i.call(window, e);
            }),
            (n.Context = e);
    })(),
    (function () {
        "use strict";
        function t(t, e) {
            return t.triggerPoint - e.triggerPoint;
        }
        function e(t, e) {
            return e.triggerPoint - t.triggerPoint;
        }
        function i(t) {
            (this.name = t.name), (this.axis = t.axis), (this.id = this.name + "-" + this.axis), (this.waypoints = []), this.clearTriggerQueues(), (o[this.axis][this.name] = this);
        }
        var o = { vertical: {}, horizontal: {} },
            n = window.Waypoint;
        (i.prototype.add = function (t) {
            this.waypoints.push(t);
        }),
            (i.prototype.clearTriggerQueues = function () {
                this.triggerQueues = { up: [], down: [], left: [], right: [] };
            }),
            (i.prototype.flushTriggers = function () {
                for (var i in this.triggerQueues) {
                    var o = this.triggerQueues[i],
                        n = "up" === i || "left" === i;
                    o.sort(n ? e : t);
                    for (var r = 0, s = o.length; s > r; r += 1) {
                        var a = o[r];
                        (a.options.continuous || r === o.length - 1) && a.trigger([i]);
                    }
                }
                this.clearTriggerQueues();
            }),
            (i.prototype.next = function (e) {
                this.waypoints.sort(t);
                var i = n.Adapter.inArray(e, this.waypoints),
                    o = i === this.waypoints.length - 1;
                return o ? null : this.waypoints[i + 1];
            }),
            (i.prototype.previous = function (e) {
                this.waypoints.sort(t);
                var i = n.Adapter.inArray(e, this.waypoints);
                return i ? this.waypoints[i - 1] : null;
            }),
            (i.prototype.queueTrigger = function (t, e) {
                this.triggerQueues[e].push(t);
            }),
            (i.prototype.remove = function (t) {
                var e = n.Adapter.inArray(t, this.waypoints);
                e > -1 && this.waypoints.splice(e, 1);
            }),
            (i.prototype.first = function () {
                return this.waypoints[0];
            }),
            (i.prototype.last = function () {
                return this.waypoints[this.waypoints.length - 1];
            }),
            (i.findOrCreate = function (t) {
                return o[t.axis][t.name] || new i(t);
            }),
            (n.Group = i);
    })(),
    (function () {
        "use strict";
        function t(t) {
            this.$element = e(t);
        }
        var e = window.jQuery,
            i = window.Waypoint;
        e.each(["innerHeight", "innerWidth", "off", "offset", "on", "outerHeight", "outerWidth", "scrollLeft", "scrollTop"], function (e, i) {
            t.prototype[i] = function () {
                var t = Array.prototype.slice.call(arguments);
                return this.$element[i].apply(this.$element, t);
            };
        }),
            e.each(["extend", "inArray", "isEmptyObject"], function (i, o) {
                t[o] = e[o];
            }),
            i.adapters.push({ name: "jquery", Adapter: t }),
            (i.Adapter = t);
    })(),
    (function () {
        "use strict";
        function t(t) {
            return function () {
                var i = [],
                    o = arguments[0];
                return (
                    t.isFunction(arguments[0]) && ((o = t.extend({}, arguments[1])), (o.handler = arguments[0])),
                    this.each(function () {
                        var n = t.extend({}, o, { element: this });
                        "string" == typeof n.context && (n.context = t(this).closest(n.context)[0]), i.push(new e(n));
                    }),
                    i
                );
            };
        }
        var e = window.Waypoint;
        window.jQuery && (window.jQuery.fn.waypoint = t(window.jQuery)), window.Zepto && (window.Zepto.fn.waypoint = t(window.Zepto));
    })();

/*-------------------------------------------------------------
  13. Nice Select
---------------------------------------------------------------*/
/*  jQuery Nice Select - v1.0
    https://github.com/hernansartorio/jquery-nice-select
    Made by Hernán Sartorio  */
!(function (e) {
    e.fn.niceSelect = function (t) {
        function s(t) {
            t.after(
                e("<div></div>")
                    .addClass("nice-select")
                    .addClass(t.attr("class") || "")
                    .addClass(t.attr("disabled") ? "disabled" : "")
                    .attr("tabindex", t.attr("disabled") ? null : "0")
                    .html('<span class="current"></span><ul class="list"></ul>')
            );
            var s = t.next(),
                n = t.find("option"),
                i = t.find("option:selected");
            s.find(".current").html(i.data("display") || i.text()),
                n.each(function (t) {
                    var n = e(this),
                        i = n.data("display");
                    s.find("ul").append(
                        e("<li></li>")
                            .attr("data-value", n.val())
                            .attr("data-display", i || null)
                            .addClass("option" + (n.is(":selected") ? " selected" : "") + (n.is(":disabled") ? " disabled" : ""))
                            .html(n.text())
                    );
                });
        }
        if ("string" == typeof t)
            return (
                "update" == t
                    ? this.each(function () {
                          var t = e(this),
                              n = e(this).next(".nice-select"),
                              i = n.hasClass("open");
                          n.length && (n.remove(), s(t), i && t.next().trigger("click"));
                      })
                    : "destroy" == t
                    ? (this.each(function () {
                          var t = e(this),
                              s = e(this).next(".nice-select");
                          s.length && (s.remove(), t.css("display", ""));
                      }),
                      0 == e(".nice-select").length && e(document).off(".nice_select"))
                    : console.log('Method "' + t + '" does not exist.'),
                this
            );
        this.hide(),
            this.each(function () {
                var t = e(this);
                t.next().hasClass("nice-select") || s(t);
            }),
            e(document).off(".nice_select"),
            e(document).on("click.nice_select", ".nice-select", function (t) {
                var s = e(this);
                e(".nice-select").not(s).removeClass("open"), s.toggleClass("open"), s.hasClass("open") ? (s.find(".option"), s.find(".focus").removeClass("focus"), s.find(".selected").addClass("focus")) : s.focus();
            }),
            e(document).on("click.nice_select", function (t) {
                0 === e(t.target).closest(".nice-select").length && e(".nice-select").removeClass("open").find(".option");
            }),
            e(document).on("click.nice_select", ".nice-select .option:not(.disabled)", function (t) {
                var s = e(this),
                    n = s.closest(".nice-select");
                n.find(".selected").removeClass("selected"), s.addClass("selected");
                var i = s.data("display") || s.text();
                n.find(".current").text(i), n.prev("select").val(s.data("value")).trigger("change");
            }),
            e(document).on("keydown.nice_select", ".nice-select", function (t) {
                var s = e(this),
                    n = e(s.find(".focus") || s.find(".list .option.selected"));
                if (32 == t.keyCode || 13 == t.keyCode) return s.hasClass("open") ? n.trigger("click") : s.trigger("click"), !1;
                if (40 == t.keyCode) {
                    if (s.hasClass("open")) {
                        var i = n.nextAll(".option:not(.disabled)").first();
                        i.length > 0 && (s.find(".focus").removeClass("focus"), i.addClass("focus"));
                    } else s.trigger("click");
                    return !1;
                }
                if (38 == t.keyCode) {
                    if (s.hasClass("open")) {
                        var l = n.prevAll(".option:not(.disabled)").first();
                        l.length > 0 && (s.find(".focus").removeClass("focus"), l.addClass("focus"));
                    } else s.trigger("click");
                    return !1;
                }
                if (27 == t.keyCode) s.hasClass("open") && s.trigger("click");
                else if (9 == t.keyCode && s.hasClass("open")) return !1;
            });
        var n = document.createElement("a").style;
        return (n.cssText = "pointer-events:auto"), "auto" !== n.pointerEvents && e("html").addClass("no-csspointerevents"), this;
    };
})(jQuery);

/*-------------------------------------------------------------
  14. jQuery UI / price range 
---------------------------------------------------------------*/
/*! jQuery UI - v1.11.4 - 2016-06-07
 * http://jqueryui.com
 * Includes: core.js, widget.js, mouse.js, slider.js
 * Copyright jQuery Foundation and other contributors; Licensed MIT */

(function (e) {
    "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery);
})(function (e) {
    function t(t, s) {
        var n,
            a,
            o,
            r = t.nodeName.toLowerCase();
        return "area" === r
            ? ((n = t.parentNode), (a = n.name), t.href && a && "map" === n.nodeName.toLowerCase() ? ((o = e("img[usemap='#" + a + "']")[0]), !!o && i(o)) : !1)
            : (/^(input|select|textarea|button|object)$/.test(r) ? !t.disabled : "a" === r ? t.href || s : s) && i(t);
    }
    function i(t) {
        return (
            e.expr.filters.visible(t) &&
            !e(t)
                .parents()
                .addBack()
                .filter(function () {
                    return "hidden" === e.css(this, "visibility");
                }).length
        );
    }
    (e.ui = e.ui || {}),
        e.extend(e.ui, { version: "1.11.4", keyCode: { BACKSPACE: 8, COMMA: 188, DELETE: 46, DOWN: 40, END: 35, ENTER: 13, ESCAPE: 27, HOME: 36, LEFT: 37, PAGE_DOWN: 34, PAGE_UP: 33, PERIOD: 190, RIGHT: 39, SPACE: 32, TAB: 9, UP: 38 } }),
        e.fn.extend({
            scrollParent: function (t) {
                var i = this.css("position"),
                    s = "absolute" === i,
                    n = t ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
                    a = this.parents()
                        .filter(function () {
                            var t = e(this);
                            return s && "static" === t.css("position") ? !1 : n.test(t.css("overflow") + t.css("overflow-y") + t.css("overflow-x"));
                        })
                        .eq(0);
                return "fixed" !== i && a.length ? a : e(this[0].ownerDocument || document);
            },
            uniqueId: (function () {
                var e = 0;
                return function () {
                    return this.each(function () {
                        this.id || (this.id = "ui-id-" + ++e);
                    });
                };
            })(),
            removeUniqueId: function () {
                return this.each(function () {
                    /^ui-id-\d+$/.test(this.id) && e(this).removeAttr("id");
                });
            },
        }),
        e.extend(e.expr[":"], {
            data: e.expr.createPseudo
                ? e.expr.createPseudo(function (t) {
                      return function (i) {
                          return !!e.data(i, t);
                      };
                  })
                : function (t, i, s) {
                      return !!e.data(t, s[3]);
                  },
            focusable: function (i) {
                return t(i, !isNaN(e.attr(i, "tabindex")));
            },
            tabbable: function (i) {
                var s = e.attr(i, "tabindex"),
                    n = isNaN(s);
                return (n || s >= 0) && t(i, !n);
            },
        }),
        e("<a>").outerWidth(1).jquery ||
            e.each(["Width", "Height"], function (t, i) {
                function s(t, i, s, a) {
                    return (
                        e.each(n, function () {
                            (i -= parseFloat(e.css(t, "padding" + this)) || 0), s && (i -= parseFloat(e.css(t, "border" + this + "Width")) || 0), a && (i -= parseFloat(e.css(t, "margin" + this)) || 0);
                        }),
                        i
                    );
                }
                var n = "Width" === i ? ["Left", "Right"] : ["Top", "Bottom"],
                    a = i.toLowerCase(),
                    o = { innerWidth: e.fn.innerWidth, innerHeight: e.fn.innerHeight, outerWidth: e.fn.outerWidth, outerHeight: e.fn.outerHeight };
                (e.fn["inner" + i] = function (t) {
                    return void 0 === t
                        ? o["inner" + i].call(this)
                        : this.each(function () {
                              e(this).css(a, s(this, t) + "px");
                          });
                }),
                    (e.fn["outer" + i] = function (t, n) {
                        return "number" != typeof t
                            ? o["outer" + i].call(this, t)
                            : this.each(function () {
                                  e(this).css(a, s(this, t, !0, n) + "px");
                              });
                    });
            }),
        e.fn.addBack ||
            (e.fn.addBack = function (e) {
                return this.add(null == e ? this.prevObject : this.prevObject.filter(e));
            }),
        e("<a>").data("a-b", "a").removeData("a-b").data("a-b") &&
            (e.fn.removeData = (function (t) {
                return function (i) {
                    return arguments.length ? t.call(this, e.camelCase(i)) : t.call(this);
                };
            })(e.fn.removeData)),
        (e.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase())),
        e.fn.extend({
            focus: (function (t) {
                return function (i, s) {
                    return "number" == typeof i
                        ? this.each(function () {
                              var t = this;
                              setTimeout(function () {
                                  e(t).focus(), s && s.call(t);
                              }, i);
                          })
                        : t.apply(this, arguments);
                };
            })(e.fn.focus),
            disableSelection: (function () {
                var e = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown";
                return function () {
                    return this.bind(e + ".ui-disableSelection", function (e) {
                        e.preventDefault();
                    });
                };
            })(),
            enableSelection: function () {
                return this.unbind(".ui-disableSelection");
            },
            zIndex: function (t) {
                if (void 0 !== t) return this.css("zIndex", t);
                if (this.length)
                    for (var i, s, n = e(this[0]); n.length && n[0] !== document; ) {
                        if (((i = n.css("position")), ("absolute" === i || "relative" === i || "fixed" === i) && ((s = parseInt(n.css("zIndex"), 10)), !isNaN(s) && 0 !== s))) return s;
                        n = n.parent();
                    }
                return 0;
            },
        }),
        (e.ui.plugin = {
            add: function (t, i, s) {
                var n,
                    a = e.ui[t].prototype;
                for (n in s) (a.plugins[n] = a.plugins[n] || []), a.plugins[n].push([i, s[n]]);
            },
            call: function (e, t, i, s) {
                var n,
                    a = e.plugins[t];
                if (a && (s || (e.element[0].parentNode && 11 !== e.element[0].parentNode.nodeType))) for (n = 0; a.length > n; n++) e.options[a[n][0]] && a[n][1].apply(e.element, i);
            },
        });
    var s = 0,
        n = Array.prototype.slice;
    (e.cleanData = (function (t) {
        return function (i) {
            var s, n, a;
            for (a = 0; null != (n = i[a]); a++)
                try {
                    (s = e._data(n, "events")), s && s.remove && e(n).triggerHandler("remove");
                } catch (o) {}
            t(i);
        };
    })(e.cleanData)),
        (e.widget = function (t, i, s) {
            var n,
                a,
                o,
                r,
                h = {},
                l = t.split(".")[0];
            return (
                (t = t.split(".")[1]),
                (n = l + "-" + t),
                s || ((s = i), (i = e.Widget)),
                (e.expr[":"][n.toLowerCase()] = function (t) {
                    return !!e.data(t, n);
                }),
                (e[l] = e[l] || {}),
                (a = e[l][t]),
                (o = e[l][t] = function (e, t) {
                    return this._createWidget ? (arguments.length && this._createWidget(e, t), void 0) : new o(e, t);
                }),
                e.extend(o, a, { version: s.version, _proto: e.extend({}, s), _childConstructors: [] }),
                (r = new i()),
                (r.options = e.widget.extend({}, r.options)),
                e.each(s, function (t, s) {
                    return e.isFunction(s)
                        ? ((h[t] = (function () {
                              var e = function () {
                                      return i.prototype[t].apply(this, arguments);
                                  },
                                  n = function (e) {
                                      return i.prototype[t].apply(this, e);
                                  };
                              return function () {
                                  var t,
                                      i = this._super,
                                      a = this._superApply;
                                  return (this._super = e), (this._superApply = n), (t = s.apply(this, arguments)), (this._super = i), (this._superApply = a), t;
                              };
                          })()),
                          void 0)
                        : ((h[t] = s), void 0);
                }),
                (o.prototype = e.widget.extend(r, { widgetEventPrefix: a ? r.widgetEventPrefix || t : t }, h, { constructor: o, namespace: l, widgetName: t, widgetFullName: n })),
                a
                    ? (e.each(a._childConstructors, function (t, i) {
                          var s = i.prototype;
                          e.widget(s.namespace + "." + s.widgetName, o, i._proto);
                      }),
                      delete a._childConstructors)
                    : i._childConstructors.push(o),
                e.widget.bridge(t, o),
                o
            );
        }),
        (e.widget.extend = function (t) {
            for (var i, s, a = n.call(arguments, 1), o = 0, r = a.length; r > o; o++)
                for (i in a[o]) (s = a[o][i]), a[o].hasOwnProperty(i) && void 0 !== s && (t[i] = e.isPlainObject(s) ? (e.isPlainObject(t[i]) ? e.widget.extend({}, t[i], s) : e.widget.extend({}, s)) : s);
            return t;
        }),
        (e.widget.bridge = function (t, i) {
            var s = i.prototype.widgetFullName || t;
            e.fn[t] = function (a) {
                var o = "string" == typeof a,
                    r = n.call(arguments, 1),
                    h = this;
                return (
                    o
                        ? this.each(function () {
                              var i,
                                  n = e.data(this, s);
                              return "instance" === a
                                  ? ((h = n), !1)
                                  : n
                                  ? e.isFunction(n[a]) && "_" !== a.charAt(0)
                                      ? ((i = n[a].apply(n, r)), i !== n && void 0 !== i ? ((h = i && i.jquery ? h.pushStack(i.get()) : i), !1) : void 0)
                                      : e.error("no such method '" + a + "' for " + t + " widget instance")
                                  : e.error("cannot call methods on " + t + " prior to initialization; " + "attempted to call method '" + a + "'");
                          })
                        : (r.length && (a = e.widget.extend.apply(null, [a].concat(r))),
                          this.each(function () {
                              var t = e.data(this, s);
                              t ? (t.option(a || {}), t._init && t._init()) : e.data(this, s, new i(a, this));
                          })),
                    h
                );
            };
        }),
        (e.Widget = function () {}),
        (e.Widget._childConstructors = []),
        (e.Widget.prototype = {
            widgetName: "widget",
            widgetEventPrefix: "",
            defaultElement: "<div>",
            options: { disabled: !1, create: null },
            _createWidget: function (t, i) {
                (i = e(i || this.defaultElement || this)[0]),
                    (this.element = e(i)),
                    (this.uuid = s++),
                    (this.eventNamespace = "." + this.widgetName + this.uuid),
                    (this.bindings = e()),
                    (this.hoverable = e()),
                    (this.focusable = e()),
                    i !== this &&
                        (e.data(i, this.widgetFullName, this),
                        this._on(!0, this.element, {
                            remove: function (e) {
                                e.target === i && this.destroy();
                            },
                        }),
                        (this.document = e(i.style ? i.ownerDocument : i.document || i)),
                        (this.window = e(this.document[0].defaultView || this.document[0].parentWindow))),
                    (this.options = e.widget.extend({}, this.options, this._getCreateOptions(), t)),
                    this._create(),
                    this._trigger("create", null, this._getCreateEventData()),
                    this._init();
            },
            _getCreateOptions: e.noop,
            _getCreateEventData: e.noop,
            _create: e.noop,
            _init: e.noop,
            destroy: function () {
                this._destroy(),
                    this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)),
                    this.widget()
                        .unbind(this.eventNamespace)
                        .removeAttr("aria-disabled")
                        .removeClass(this.widgetFullName + "-disabled " + "ui-state-disabled"),
                    this.bindings.unbind(this.eventNamespace),
                    this.hoverable.removeClass("ui-state-hover"),
                    this.focusable.removeClass("ui-state-focus");
            },
            _destroy: e.noop,
            widget: function () {
                return this.element;
            },
            option: function (t, i) {
                var s,
                    n,
                    a,
                    o = t;
                if (0 === arguments.length) return e.widget.extend({}, this.options);
                if ("string" == typeof t)
                    if (((o = {}), (s = t.split(".")), (t = s.shift()), s.length)) {
                        for (n = o[t] = e.widget.extend({}, this.options[t]), a = 0; s.length - 1 > a; a++) (n[s[a]] = n[s[a]] || {}), (n = n[s[a]]);
                        if (((t = s.pop()), 1 === arguments.length)) return void 0 === n[t] ? null : n[t];
                        n[t] = i;
                    } else {
                        if (1 === arguments.length) return void 0 === this.options[t] ? null : this.options[t];
                        o[t] = i;
                    }
                return this._setOptions(o), this;
            },
            _setOptions: function (e) {
                var t;
                for (t in e) this._setOption(t, e[t]);
                return this;
            },
            _setOption: function (e, t) {
                return (this.options[e] = t), "disabled" === e && (this.widget().toggleClass(this.widgetFullName + "-disabled", !!t), t && (this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus"))), this;
            },
            enable: function () {
                return this._setOptions({ disabled: !1 });
            },
            disable: function () {
                return this._setOptions({ disabled: !0 });
            },
            _on: function (t, i, s) {
                var n,
                    a = this;
                "boolean" != typeof t && ((s = i), (i = t), (t = !1)),
                    s ? ((i = n = e(i)), (this.bindings = this.bindings.add(i))) : ((s = i), (i = this.element), (n = this.widget())),
                    e.each(s, function (s, o) {
                        function r() {
                            return t || (a.options.disabled !== !0 && !e(this).hasClass("ui-state-disabled")) ? ("string" == typeof o ? a[o] : o).apply(a, arguments) : void 0;
                        }
                        "string" != typeof o && (r.guid = o.guid = o.guid || r.guid || e.guid++);
                        var h = s.match(/^([\w:-]*)\s*(.*)$/),
                            l = h[1] + a.eventNamespace,
                            u = h[2];
                        u ? n.delegate(u, l, r) : i.bind(l, r);
                    });
            },
            _off: function (t, i) {
                (i = (i || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace),
                    t.unbind(i).undelegate(i),
                    (this.bindings = e(this.bindings.not(t).get())),
                    (this.focusable = e(this.focusable.not(t).get())),
                    (this.hoverable = e(this.hoverable.not(t).get()));
            },
            _delay: function (e, t) {
                function i() {
                    return ("string" == typeof e ? s[e] : e).apply(s, arguments);
                }
                var s = this;
                return setTimeout(i, t || 0);
            },
            _hoverable: function (t) {
                (this.hoverable = this.hoverable.add(t)),
                    this._on(t, {
                        mouseenter: function (t) {
                            e(t.currentTarget).addClass("ui-state-hover");
                        },
                        mouseleave: function (t) {
                            e(t.currentTarget).removeClass("ui-state-hover");
                        },
                    });
            },
            _focusable: function (t) {
                (this.focusable = this.focusable.add(t)),
                    this._on(t, {
                        focusin: function (t) {
                            e(t.currentTarget).addClass("ui-state-focus");
                        },
                        focusout: function (t) {
                            e(t.currentTarget).removeClass("ui-state-focus");
                        },
                    });
            },
            _trigger: function (t, i, s) {
                var n,
                    a,
                    o = this.options[t];
                if (((s = s || {}), (i = e.Event(i)), (i.type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase()), (i.target = this.element[0]), (a = i.originalEvent))) for (n in a) n in i || (i[n] = a[n]);
                return this.element.trigger(i, s), !((e.isFunction(o) && o.apply(this.element[0], [i].concat(s)) === !1) || i.isDefaultPrevented());
            },
        }),
        e.each({ show: "fadeIn", hide: "fadeOut" }, function (t, i) {
            e.Widget.prototype["_" + t] = function (s, n, a) {
                "string" == typeof n && (n = { effect: n });
                var o,
                    r = n ? (n === !0 || "number" == typeof n ? i : n.effect || i) : t;
                (n = n || {}),
                    "number" == typeof n && (n = { duration: n }),
                    (o = !e.isEmptyObject(n)),
                    (n.complete = a),
                    n.delay && s.delay(n.delay),
                    o && e.effects && e.effects.effect[r]
                        ? s[t](n)
                        : r !== t && s[r]
                        ? s[r](n.duration, n.easing, a)
                        : s.queue(function (i) {
                              e(this)[t](), a && a.call(s[0]), i();
                          });
            };
        }),
        e.widget;
    var a = !1;
    e(document).mouseup(function () {
        a = !1;
    }),
        e.widget("ui.mouse", {
            version: "1.11.4",
            options: { cancel: "input,textarea,button,select,option", distance: 1, delay: 0 },
            _mouseInit: function () {
                var t = this;
                this.element
                    .bind("mousedown." + this.widgetName, function (e) {
                        return t._mouseDown(e);
                    })
                    .bind("click." + this.widgetName, function (i) {
                        return !0 === e.data(i.target, t.widgetName + ".preventClickEvent") ? (e.removeData(i.target, t.widgetName + ".preventClickEvent"), i.stopImmediatePropagation(), !1) : void 0;
                    }),
                    (this.started = !1);
            },
            _mouseDestroy: function () {
                this.element.unbind("." + this.widgetName), this._mouseMoveDelegate && this.document.unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate);
            },
            _mouseDown: function (t) {
                if (!a) {
                    (this._mouseMoved = !1), this._mouseStarted && this._mouseUp(t), (this._mouseDownEvent = t);
                    var i = this,
                        s = 1 === t.which,
                        n = "string" == typeof this.options.cancel && t.target.nodeName ? e(t.target).closest(this.options.cancel).length : !1;
                    return s && !n && this._mouseCapture(t)
                        ? ((this.mouseDelayMet = !this.options.delay),
                          this.mouseDelayMet ||
                              (this._mouseDelayTimer = setTimeout(function () {
                                  i.mouseDelayMet = !0;
                              }, this.options.delay)),
                          this._mouseDistanceMet(t) && this._mouseDelayMet(t) && ((this._mouseStarted = this._mouseStart(t) !== !1), !this._mouseStarted)
                              ? (t.preventDefault(), !0)
                              : (!0 === e.data(t.target, this.widgetName + ".preventClickEvent") && e.removeData(t.target, this.widgetName + ".preventClickEvent"),
                                (this._mouseMoveDelegate = function (e) {
                                    return i._mouseMove(e);
                                }),
                                (this._mouseUpDelegate = function (e) {
                                    return i._mouseUp(e);
                                }),
                                this.document.bind("mousemove." + this.widgetName, this._mouseMoveDelegate).bind("mouseup." + this.widgetName, this._mouseUpDelegate),
                                t.preventDefault(),
                                (a = !0),
                                !0))
                        : !0;
                }
            },
            _mouseMove: function (t) {
                if (this._mouseMoved) {
                    if (e.ui.ie && (!document.documentMode || 9 > document.documentMode) && !t.button) return this._mouseUp(t);
                    if (!t.which) return this._mouseUp(t);
                }
                return (
                    (t.which || t.button) && (this._mouseMoved = !0),
                    this._mouseStarted
                        ? (this._mouseDrag(t), t.preventDefault())
                        : (this._mouseDistanceMet(t) && this._mouseDelayMet(t) && ((this._mouseStarted = this._mouseStart(this._mouseDownEvent, t) !== !1), this._mouseStarted ? this._mouseDrag(t) : this._mouseUp(t)), !this._mouseStarted)
                );
            },
            _mouseUp: function (t) {
                return (
                    this.document.unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate),
                    this._mouseStarted && ((this._mouseStarted = !1), t.target === this._mouseDownEvent.target && e.data(t.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(t)),
                    (a = !1),
                    !1
                );
            },
            _mouseDistanceMet: function (e) {
                return Math.max(Math.abs(this._mouseDownEvent.pageX - e.pageX), Math.abs(this._mouseDownEvent.pageY - e.pageY)) >= this.options.distance;
            },
            _mouseDelayMet: function () {
                return this.mouseDelayMet;
            },
            _mouseStart: function () {},
            _mouseDrag: function () {},
            _mouseStop: function () {},
            _mouseCapture: function () {
                return !0;
            },
        }),
        e.widget("ui.slider", e.ui.mouse, {
            version: "1.11.4",
            widgetEventPrefix: "slide",
            options: { animate: !1, distance: 0, max: 100, min: 0, orientation: "horizontal", range: !1, step: 1, value: 0, values: null, change: null, slide: null, start: null, stop: null },
            numPages: 5,
            _create: function () {
                (this._keySliding = !1),
                    (this._mouseSliding = !1),
                    (this._animateOff = !0),
                    (this._handleIndex = null),
                    this._detectOrientation(),
                    this._mouseInit(),
                    this._calculateNewMax(),
                    this.element.addClass("ui-slider ui-slider-" + this.orientation + " ui-widget" + " ui-widget-content" + " ui-corner-all"),
                    this._refresh(),
                    this._setOption("disabled", this.options.disabled),
                    (this._animateOff = !1);
            },
            _refresh: function () {
                this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue();
            },
            _createHandles: function () {
                var t,
                    i,
                    s = this.options,
                    n = this.element.find(".ui-slider-handle").addClass("ui-state-default ui-corner-all"),
                    a = "<span class='ui-slider-handle ui-state-default ui-corner-all' tabindex='0'></span>",
                    o = [];
                for (i = (s.values && s.values.length) || 1, n.length > i && (n.slice(i).remove(), (n = n.slice(0, i))), t = n.length; i > t; t++) o.push(a);
                (this.handles = n.add(e(o.join("")).appendTo(this.element))),
                    (this.handle = this.handles.eq(0)),
                    this.handles.each(function (t) {
                        e(this).data("ui-slider-handle-index", t);
                    });
            },
            _createRange: function () {
                var t = this.options,
                    i = "";
                t.range
                    ? (t.range === !0 &&
                          (t.values ? (t.values.length && 2 !== t.values.length ? (t.values = [t.values[0], t.values[0]]) : e.isArray(t.values) && (t.values = t.values.slice(0))) : (t.values = [this._valueMin(), this._valueMin()])),
                      this.range && this.range.length
                          ? this.range.removeClass("ui-slider-range-min ui-slider-range-max").css({ left: "", bottom: "" })
                          : ((this.range = e("<div></div>").appendTo(this.element)), (i = "ui-slider-range ui-widget-header ui-corner-all")),
                      this.range.addClass(i + ("min" === t.range || "max" === t.range ? " ui-slider-range-" + t.range : "")))
                    : (this.range && this.range.remove(), (this.range = null));
            },
            _setupEvents: function () {
                this._off(this.handles), this._on(this.handles, this._handleEvents), this._hoverable(this.handles), this._focusable(this.handles);
            },
            _destroy: function () {
                this.handles.remove(), this.range && this.range.remove(), this.element.removeClass("ui-slider ui-slider-horizontal ui-slider-vertical ui-widget ui-widget-content ui-corner-all"), this._mouseDestroy();
            },
            _mouseCapture: function (t) {
                var i,
                    s,
                    n,
                    a,
                    o,
                    r,
                    h,
                    l,
                    u = this,
                    c = this.options;
                return c.disabled
                    ? !1
                    : ((this.elementSize = { width: this.element.outerWidth(), height: this.element.outerHeight() }),
                      (this.elementOffset = this.element.offset()),
                      (i = { x: t.pageX, y: t.pageY }),
                      (s = this._normValueFromMouse(i)),
                      (n = this._valueMax() - this._valueMin() + 1),
                      this.handles.each(function (t) {
                          var i = Math.abs(s - u.values(t));
                          (n > i || (n === i && (t === u._lastChangedValue || u.values(t) === c.min))) && ((n = i), (a = e(this)), (o = t));
                      }),
                      (r = this._start(t, o)),
                      r === !1
                          ? !1
                          : ((this._mouseSliding = !0),
                            (this._handleIndex = o),
                            a.addClass("ui-state-active").focus(),
                            (h = a.offset()),
                            (l = !e(t.target).parents().addBack().is(".ui-slider-handle")),
                            (this._clickOffset = l
                                ? { left: 0, top: 0 }
                                : {
                                      left: t.pageX - h.left - a.width() / 2,
                                      top: t.pageY - h.top - a.height() / 2 - (parseInt(a.css("borderTopWidth"), 10) || 0) - (parseInt(a.css("borderBottomWidth"), 10) || 0) + (parseInt(a.css("marginTop"), 10) || 0),
                                  }),
                            this.handles.hasClass("ui-state-hover") || this._slide(t, o, s),
                            (this._animateOff = !0),
                            !0));
            },
            _mouseStart: function () {
                return !0;
            },
            _mouseDrag: function (e) {
                var t = { x: e.pageX, y: e.pageY },
                    i = this._normValueFromMouse(t);
                return this._slide(e, this._handleIndex, i), !1;
            },
            _mouseStop: function (e) {
                return (
                    this.handles.removeClass("ui-state-active"),
                    (this._mouseSliding = !1),
                    this._stop(e, this._handleIndex),
                    this._change(e, this._handleIndex),
                    (this._handleIndex = null),
                    (this._clickOffset = null),
                    (this._animateOff = !1),
                    !1
                );
            },
            _detectOrientation: function () {
                this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal";
            },
            _normValueFromMouse: function (e) {
                var t, i, s, n, a;
                return (
                    "horizontal" === this.orientation
                        ? ((t = this.elementSize.width), (i = e.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)))
                        : ((t = this.elementSize.height), (i = e.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0))),
                    (s = i / t),
                    s > 1 && (s = 1),
                    0 > s && (s = 0),
                    "vertical" === this.orientation && (s = 1 - s),
                    (n = this._valueMax() - this._valueMin()),
                    (a = this._valueMin() + s * n),
                    this._trimAlignValue(a)
                );
            },
            _start: function (e, t) {
                var i = { handle: this.handles[t], value: this.value() };
                return this.options.values && this.options.values.length && ((i.value = this.values(t)), (i.values = this.values())), this._trigger("start", e, i);
            },
            _slide: function (e, t, i) {
                var s, n, a;
                this.options.values && this.options.values.length
                    ? ((s = this.values(t ? 0 : 1)),
                      2 === this.options.values.length && this.options.range === !0 && ((0 === t && i > s) || (1 === t && s > i)) && (i = s),
                      i !== this.values(t) && ((n = this.values()), (n[t] = i), (a = this._trigger("slide", e, { handle: this.handles[t], value: i, values: n })), (s = this.values(t ? 0 : 1)), a !== !1 && this.values(t, i)))
                    : i !== this.value() && ((a = this._trigger("slide", e, { handle: this.handles[t], value: i })), a !== !1 && this.value(i));
            },
            _stop: function (e, t) {
                var i = { handle: this.handles[t], value: this.value() };
                this.options.values && this.options.values.length && ((i.value = this.values(t)), (i.values = this.values())), this._trigger("stop", e, i);
            },
            _change: function (e, t) {
                if (!this._keySliding && !this._mouseSliding) {
                    var i = { handle: this.handles[t], value: this.value() };
                    this.options.values && this.options.values.length && ((i.value = this.values(t)), (i.values = this.values())), (this._lastChangedValue = t), this._trigger("change", e, i);
                }
            },
            value: function (e) {
                return arguments.length ? ((this.options.value = this._trimAlignValue(e)), this._refreshValue(), this._change(null, 0), void 0) : this._value();
            },
            values: function (t, i) {
                var s, n, a;
                if (arguments.length > 1) return (this.options.values[t] = this._trimAlignValue(i)), this._refreshValue(), this._change(null, t), void 0;
                if (!arguments.length) return this._values();
                if (!e.isArray(arguments[0])) return this.options.values && this.options.values.length ? this._values(t) : this.value();
                for (s = this.options.values, n = arguments[0], a = 0; s.length > a; a += 1) (s[a] = this._trimAlignValue(n[a])), this._change(null, a);
                this._refreshValue();
            },
            _setOption: function (t, i) {
                var s,
                    n = 0;
                switch (
                    ("range" === t &&
                        this.options.range === !0 &&
                        ("min" === i ? ((this.options.value = this._values(0)), (this.options.values = null)) : "max" === i && ((this.options.value = this._values(this.options.values.length - 1)), (this.options.values = null))),
                    e.isArray(this.options.values) && (n = this.options.values.length),
                    "disabled" === t && this.element.toggleClass("ui-state-disabled", !!i),
                    this._super(t, i),
                    t)
                ) {
                    case "orientation":
                        this._detectOrientation(),
                            this.element.removeClass("ui-slider-horizontal ui-slider-vertical").addClass("ui-slider-" + this.orientation),
                            this._refreshValue(),
                            this.handles.css("horizontal" === i ? "bottom" : "left", "");
                        break;
                    case "value":
                        (this._animateOff = !0), this._refreshValue(), this._change(null, 0), (this._animateOff = !1);
                        break;
                    case "values":
                        for (this._animateOff = !0, this._refreshValue(), s = 0; n > s; s += 1) this._change(null, s);
                        this._animateOff = !1;
                        break;
                    case "step":
                    case "min":
                    case "max":
                        (this._animateOff = !0), this._calculateNewMax(), this._refreshValue(), (this._animateOff = !1);
                        break;
                    case "range":
                        (this._animateOff = !0), this._refresh(), (this._animateOff = !1);
                }
            },
            _value: function () {
                var e = this.options.value;
                return (e = this._trimAlignValue(e));
            },
            _values: function (e) {
                var t, i, s;
                if (arguments.length) return (t = this.options.values[e]), (t = this._trimAlignValue(t));
                if (this.options.values && this.options.values.length) {
                    for (i = this.options.values.slice(), s = 0; i.length > s; s += 1) i[s] = this._trimAlignValue(i[s]);
                    return i;
                }
                return [];
            },
            _trimAlignValue: function (e) {
                if (this._valueMin() >= e) return this._valueMin();
                if (e >= this._valueMax()) return this._valueMax();
                var t = this.options.step > 0 ? this.options.step : 1,
                    i = (e - this._valueMin()) % t,
                    s = e - i;
                return 2 * Math.abs(i) >= t && (s += i > 0 ? t : -t), parseFloat(s.toFixed(5));
            },
            _calculateNewMax: function () {
                var e = this.options.max,
                    t = this._valueMin(),
                    i = this.options.step,
                    s = Math.floor(+(e - t).toFixed(this._precision()) / i) * i;
                (e = s + t), (this.max = parseFloat(e.toFixed(this._precision())));
            },
            _precision: function () {
                var e = this._precisionOf(this.options.step);
                return null !== this.options.min && (e = Math.max(e, this._precisionOf(this.options.min))), e;
            },
            _precisionOf: function (e) {
                var t = "" + e,
                    i = t.indexOf(".");
                return -1 === i ? 0 : t.length - i - 1;
            },
            _valueMin: function () {
                return this.options.min;
            },
            _valueMax: function () {
                return this.max;
            },
            _refreshValue: function () {
                var t,
                    i,
                    s,
                    n,
                    a,
                    o = this.options.range,
                    r = this.options,
                    h = this,
                    l = this._animateOff ? !1 : r.animate,
                    u = {};
                this.options.values && this.options.values.length
                    ? this.handles.each(function (s) {
                          (i = 100 * ((h.values(s) - h._valueMin()) / (h._valueMax() - h._valueMin()))),
                              (u["horizontal" === h.orientation ? "left" : "bottom"] = i + "%"),
                              e(this).stop(1, 1)[l ? "animate" : "css"](u, r.animate),
                              h.options.range === !0 &&
                                  ("horizontal" === h.orientation
                                      ? (0 === s && h.range.stop(1, 1)[l ? "animate" : "css"]({ left: i + "%" }, r.animate), 1 === s && h.range[l ? "animate" : "css"]({ width: i - t + "%" }, { queue: !1, duration: r.animate }))
                                      : (0 === s && h.range.stop(1, 1)[l ? "animate" : "css"]({ bottom: i + "%" }, r.animate), 1 === s && h.range[l ? "animate" : "css"]({ height: i - t + "%" }, { queue: !1, duration: r.animate }))),
                              (t = i);
                      })
                    : ((s = this.value()),
                      (n = this._valueMin()),
                      (a = this._valueMax()),
                      (i = a !== n ? 100 * ((s - n) / (a - n)) : 0),
                      (u["horizontal" === this.orientation ? "left" : "bottom"] = i + "%"),
                      this.handle.stop(1, 1)[l ? "animate" : "css"](u, r.animate),
                      "min" === o && "horizontal" === this.orientation && this.range.stop(1, 1)[l ? "animate" : "css"]({ width: i + "%" }, r.animate),
                      "max" === o && "horizontal" === this.orientation && this.range[l ? "animate" : "css"]({ width: 100 - i + "%" }, { queue: !1, duration: r.animate }),
                      "min" === o && "vertical" === this.orientation && this.range.stop(1, 1)[l ? "animate" : "css"]({ height: i + "%" }, r.animate),
                      "max" === o && "vertical" === this.orientation && this.range[l ? "animate" : "css"]({ height: 100 - i + "%" }, { queue: !1, duration: r.animate }));
            },
            _handleEvents: {
                keydown: function (t) {
                    var i,
                        s,
                        n,
                        a,
                        o = e(t.target).data("ui-slider-handle-index");
                    switch (t.keyCode) {
                        case e.ui.keyCode.HOME:
                        case e.ui.keyCode.END:
                        case e.ui.keyCode.PAGE_UP:
                        case e.ui.keyCode.PAGE_DOWN:
                        case e.ui.keyCode.UP:
                        case e.ui.keyCode.RIGHT:
                        case e.ui.keyCode.DOWN:
                        case e.ui.keyCode.LEFT:
                            if ((t.preventDefault(), !this._keySliding && ((this._keySliding = !0), e(t.target).addClass("ui-state-active"), (i = this._start(t, o)), i === !1))) return;
                    }
                    switch (((a = this.options.step), (s = n = this.options.values && this.options.values.length ? this.values(o) : this.value()), t.keyCode)) {
                        case e.ui.keyCode.HOME:
                            n = this._valueMin();
                            break;
                        case e.ui.keyCode.END:
                            n = this._valueMax();
                            break;
                        case e.ui.keyCode.PAGE_UP:
                            n = this._trimAlignValue(s + (this._valueMax() - this._valueMin()) / this.numPages);
                            break;
                        case e.ui.keyCode.PAGE_DOWN:
                            n = this._trimAlignValue(s - (this._valueMax() - this._valueMin()) / this.numPages);
                            break;
                        case e.ui.keyCode.UP:
                        case e.ui.keyCode.RIGHT:
                            if (s === this._valueMax()) return;
                            n = this._trimAlignValue(s + a);
                            break;
                        case e.ui.keyCode.DOWN:
                        case e.ui.keyCode.LEFT:
                            if (s === this._valueMin()) return;
                            n = this._trimAlignValue(s - a);
                    }
                    this._slide(t, o, n);
                },
                keyup: function (t) {
                    var i = e(t.target).data("ui-slider-handle-index");
                    this._keySliding && ((this._keySliding = !1), this._stop(t, i), this._change(t, i), e(t.target).removeClass("ui-state-active"));
                },
            },
        });
});

/*-------------------------------------------------------------
  15. scrollup jquery 
---------------------------------------------------------------*/
/*!
 * scrollup v2.4.1
 * Url: http://markgoodyear.com/labs/scrollup/
 * Copyright (c) Mark Goodyear â€” @markgdyr â€” http://markgoodyear.com
 * License: MIT
 */
!(function (l, o, e) {
    "use strict";
    (l.fn.scrollUp = function (o) {
        l.data(e.body, "scrollUp") || (l.data(e.body, "scrollUp", !0), l.fn.scrollUp.init(o));
    }),
        (l.fn.scrollUp.init = function (r) {
            var s,
                t,
                c,
                i,
                n,
                a,
                d,
                p = (l.fn.scrollUp.settings = l.extend({}, l.fn.scrollUp.defaults, r)),
                f = !1;
            switch (
                ((d = p.scrollTrigger ? l(p.scrollTrigger) : l("<a/>", { id: p.scrollName, href: "#top" })),
                p.scrollTitle && d.attr("title", p.scrollTitle),
                d.appendTo("body"),
                p.scrollImg || p.scrollTrigger || d.html(p.scrollText),
                d.css({ display: "none", position: "fixed", zIndex: p.zIndex }),
                p.activeOverlay &&
                    l("<div/>", { id: p.scrollName + "-active" })
                        .css({ position: "absolute", top: p.scrollDistance + "px", width: "100%", borderTop: "1px dotted" + p.activeOverlay, zIndex: p.zIndex })
                        .appendTo("body"),
                p.animation)
            ) {
                case "fade":
                    (s = "fadeIn"), (t = "fadeOut"), (c = p.animationSpeed);
                    break;
                case "slide":
                    (s = "slideDown"), (t = "slideUp"), (c = p.animationSpeed);
                    break;
                default:
                    (s = "show"), (t = "hide"), (c = 0);
            }
            (i = "top" === p.scrollFrom ? p.scrollDistance : l(e).height() - l(o).height() - p.scrollDistance),
                (n = l(o).scroll(function () {
                    l(o).scrollTop() > i ? f || (d[s](c), (f = !0)) : f && (d[t](c), (f = !1));
                })),
                p.scrollTarget ? ("number" == typeof p.scrollTarget ? (a = p.scrollTarget) : "string" == typeof p.scrollTarget && (a = Math.floor(l(p.scrollTarget).offset().top))) : (a = 0),
                d.click(function (o) {
                    o.preventDefault(), l("html, body").animate({ scrollTop: a }, p.scrollSpeed, p.easingType);
                });
        }),
        (l.fn.scrollUp.defaults = {
            scrollName: "scrollUp",
            scrollDistance: 300,
            scrollFrom: "top",
            scrollSpeed: 300,
            easingType: "linear",
            animation: "fade",
            animationSpeed: 200,
            scrollTrigger: !1,
            scrollTarget: !1,
            scrollText: "Scroll to top",
            scrollTitle: !1,
            scrollImg: !1,
            activeOverlay: !1,
            zIndex: 2147483647,
        }),
        (l.fn.scrollUp.destroy = function (r) {
            l.removeData(e.body, "scrollUp"),
                l("#" + l.fn.scrollUp.settings.scrollName).remove(),
                l("#" + l.fn.scrollUp.settings.scrollName + "-active").remove(),
                l.fn.jquery.split(".")[1] >= 7 ? l(o).off("scroll", r) : l(o).unbind("scroll", r);
        }),
        (l.scrollUp = l.fn.scrollUp);
})(jQuery, window, document);

/*-------------------------------------------------------------
  16. One Page Navigation ( jQuery Easing Plugin )
---------------------------------------------------------------*/
/*
 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
 *
 * Uses the built in easing capabilities added In jQuery 1.1
 * to offer multiple easing options
 *
 *
 */
jQuery.easing.jswing = jQuery.easing.swing;
jQuery.extend(jQuery.easing, {
    def: "easeOutQuad",
    swing: function (e, f, a, h, g) {
        return jQuery.easing[jQuery.easing.def](e, f, a, h, g);
    },
    easeInQuad: function (e, f, a, h, g) {
        return h * (f /= g) * f + a;
    },
    easeOutQuad: function (e, f, a, h, g) {
        return -h * (f /= g) * (f - 2) + a;
    },
    easeInOutQuad: function (e, f, a, h, g) {
        if ((f /= g / 2) < 1) {
            return (h / 2) * f * f + a;
        }
        return (-h / 2) * (--f * (f - 2) - 1) + a;
    },
    easeInCubic: function (e, f, a, h, g) {
        return h * (f /= g) * f * f + a;
    },
    easeOutCubic: function (e, f, a, h, g) {
        return h * ((f = f / g - 1) * f * f + 1) + a;
    },
    easeInOutCubic: function (e, f, a, h, g) {
        if ((f /= g / 2) < 1) {
            return (h / 2) * f * f * f + a;
        }
        return (h / 2) * ((f -= 2) * f * f + 2) + a;
    },
    easeInQuart: function (e, f, a, h, g) {
        return h * (f /= g) * f * f * f + a;
    },
    easeOutQuart: function (e, f, a, h, g) {
        return -h * ((f = f / g - 1) * f * f * f - 1) + a;
    },
    easeInOutQuart: function (e, f, a, h, g) {
        if ((f /= g / 2) < 1) {
            return (h / 2) * f * f * f * f + a;
        }
        return (-h / 2) * ((f -= 2) * f * f * f - 2) + a;
    },
    easeInQuint: function (e, f, a, h, g) {
        return h * (f /= g) * f * f * f * f + a;
    },
    easeOutQuint: function (e, f, a, h, g) {
        return h * ((f = f / g - 1) * f * f * f * f + 1) + a;
    },
    easeInOutQuint: function (e, f, a, h, g) {
        if ((f /= g / 2) < 1) {
            return (h / 2) * f * f * f * f * f + a;
        }
        return (h / 2) * ((f -= 2) * f * f * f * f + 2) + a;
    },
    easeInSine: function (e, f, a, h, g) {
        return -h * Math.cos((f / g) * (Math.PI / 2)) + h + a;
    },
    easeOutSine: function (e, f, a, h, g) {
        return h * Math.sin((f / g) * (Math.PI / 2)) + a;
    },
    easeInOutSine: function (e, f, a, h, g) {
        return (-h / 2) * (Math.cos((Math.PI * f) / g) - 1) + a;
    },
    easeInExpo: function (e, f, a, h, g) {
        return f == 0 ? a : h * Math.pow(2, 10 * (f / g - 1)) + a;
    },
    easeOutExpo: function (e, f, a, h, g) {
        return f == g ? a + h : h * (-Math.pow(2, (-10 * f) / g) + 1) + a;
    },
    easeInOutExpo: function (e, f, a, h, g) {
        if (f == 0) {
            return a;
        }
        if (f == g) {
            return a + h;
        }
        if ((f /= g / 2) < 1) {
            return (h / 2) * Math.pow(2, 10 * (f - 1)) + a;
        }
        return (h / 2) * (-Math.pow(2, -10 * --f) + 2) + a;
    },
    easeInCirc: function (e, f, a, h, g) {
        return -h * (Math.sqrt(1 - (f /= g) * f) - 1) + a;
    },
    easeOutCirc: function (e, f, a, h, g) {
        return h * Math.sqrt(1 - (f = f / g - 1) * f) + a;
    },
    easeInOutCirc: function (e, f, a, h, g) {
        if ((f /= g / 2) < 1) {
            return (-h / 2) * (Math.sqrt(1 - f * f) - 1) + a;
        }
        return (h / 2) * (Math.sqrt(1 - (f -= 2) * f) + 1) + a;
    },
    easeInElastic: function (f, h, e, l, k) {
        var i = 1.70158;
        var j = 0;
        var g = l;
        if (h == 0) {
            return e;
        }
        if ((h /= k) == 1) {
            return e + l;
        }
        if (!j) {
            j = k * 0.3;
        }
        if (g < Math.abs(l)) {
            g = l;
            var i = j / 4;
        } else {
            var i = (j / (2 * Math.PI)) * Math.asin(l / g);
        }
        return -(g * Math.pow(2, 10 * (h -= 1)) * Math.sin(((h * k - i) * (2 * Math.PI)) / j)) + e;
    },
    easeOutElastic: function (f, h, e, l, k) {
        var i = 1.70158;
        var j = 0;
        var g = l;
        if (h == 0) {
            return e;
        }
        if ((h /= k) == 1) {
            return e + l;
        }
        if (!j) {
            j = k * 0.3;
        }
        if (g < Math.abs(l)) {
            g = l;
            var i = j / 4;
        } else {
            var i = (j / (2 * Math.PI)) * Math.asin(l / g);
        }
        return g * Math.pow(2, -10 * h) * Math.sin(((h * k - i) * (2 * Math.PI)) / j) + l + e;
    },
    easeInOutElastic: function (f, h, e, l, k) {
        var i = 1.70158;
        var j = 0;
        var g = l;
        if (h == 0) {
            return e;
        }
        if ((h /= k / 2) == 2) {
            return e + l;
        }
        if (!j) {
            j = k * (0.3 * 1.5);
        }
        if (g < Math.abs(l)) {
            g = l;
            var i = j / 4;
        } else {
            var i = (j / (2 * Math.PI)) * Math.asin(l / g);
        }
        if (h < 1) {
            return -0.5 * (g * Math.pow(2, 10 * (h -= 1)) * Math.sin(((h * k - i) * (2 * Math.PI)) / j)) + e;
        }
        return g * Math.pow(2, -10 * (h -= 1)) * Math.sin(((h * k - i) * (2 * Math.PI)) / j) * 0.5 + l + e;
    },
    easeInBack: function (e, f, a, i, h, g) {
        if (g == undefined) {
            g = 1.70158;
        }
        return i * (f /= h) * f * ((g + 1) * f - g) + a;
    },
    easeOutBack: function (e, f, a, i, h, g) {
        if (g == undefined) {
            g = 1.70158;
        }
        return i * ((f = f / h - 1) * f * ((g + 1) * f + g) + 1) + a;
    },
    easeInOutBack: function (e, f, a, i, h, g) {
        if (g == undefined) {
            g = 1.70158;
        }
        if ((f /= h / 2) < 1) {
            return (i / 2) * (f * f * (((g *= 1.525) + 1) * f - g)) + a;
        }
        return (i / 2) * ((f -= 2) * f * (((g *= 1.525) + 1) * f + g) + 2) + a;
    },
    easeInBounce: function (e, f, a, h, g) {
        return h - jQuery.easing.easeOutBounce(e, g - f, 0, h, g) + a;
    },
    easeOutBounce: function (e, f, a, h, g) {
        if ((f /= g) < 1 / 2.75) {
            return h * (7.5625 * f * f) + a;
        } else {
            if (f < 2 / 2.75) {
                return h * (7.5625 * (f -= 1.5 / 2.75) * f + 0.75) + a;
            } else {
                if (f < 2.5 / 2.75) {
                    return h * (7.5625 * (f -= 2.25 / 2.75) * f + 0.9375) + a;
                } else {
                    return h * (7.5625 * (f -= 2.625 / 2.75) * f + 0.984375) + a;
                }
            }
        }
    },
    easeInOutBounce: function (e, f, a, h, g) {
        if (f < g / 2) {
            return jQuery.easing.easeInBounce(e, f * 2, 0, h, g) * 0.5 + a;
        }
        return jQuery.easing.easeOutBounce(e, f * 2 - g, 0, h, g) * 0.5 + h * 0.5 + a;
    },
});

/*-------------------------------------------------------------
  17. WOW jQuery 
---------------------------------------------------------------*/
/*! WOW - v1.1.3 - 2016-05-06
 * Copyright (c) 2016 Matthieu Aussaguel;*/
(function () {
    var a,
        b,
        c,
        d,
        e,
        f = function (a, b) {
            return function () {
                return a.apply(b, arguments);
            };
        },
        g =
            [].indexOf ||
            function (a) {
                for (var b = 0, c = this.length; c > b; b++) if (b in this && this[b] === a) return b;
                return -1;
            };
    (b = (function () {
        function a() {}
        return (
            (a.prototype.extend = function (a, b) {
                var c, d;
                for (c in b) (d = b[c]), null == a[c] && (a[c] = d);
                return a;
            }),
            (a.prototype.isMobile = function (a) {
                return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(a);
            }),
            (a.prototype.createEvent = function (a, b, c, d) {
                var e;
                return (
                    null == b && (b = !1),
                    null == c && (c = !1),
                    null == d && (d = null),
                    null != document.createEvent
                        ? ((e = document.createEvent("CustomEvent")), e.initCustomEvent(a, b, c, d))
                        : null != document.createEventObject
                        ? ((e = document.createEventObject()), (e.eventType = a))
                        : (e.eventName = a),
                    e
                );
            }),
            (a.prototype.emitEvent = function (a, b) {
                return null != a.dispatchEvent ? a.dispatchEvent(b) : b in (null != a) ? a[b]() : "on" + b in (null != a) ? a["on" + b]() : void 0;
            }),
            (a.prototype.addEvent = function (a, b, c) {
                return null != a.addEventListener ? a.addEventListener(b, c, !1) : null != a.attachEvent ? a.attachEvent("on" + b, c) : (a[b] = c);
            }),
            (a.prototype.removeEvent = function (a, b, c) {
                return null != a.removeEventListener ? a.removeEventListener(b, c, !1) : null != a.detachEvent ? a.detachEvent("on" + b, c) : delete a[b];
            }),
            (a.prototype.innerHeight = function () {
                return "innerHeight" in window ? window.innerHeight : document.documentElement.clientHeight;
            }),
            a
        );
    })()),
        (c =
            this.WeakMap ||
            this.MozWeakMap ||
            (c = (function () {
                function a() {
                    (this.keys = []), (this.values = []);
                }
                return (
                    (a.prototype.get = function (a) {
                        var b, c, d, e, f;
                        for (f = this.keys, b = d = 0, e = f.length; e > d; b = ++d) if (((c = f[b]), c === a)) return this.values[b];
                    }),
                    (a.prototype.set = function (a, b) {
                        var c, d, e, f, g;
                        for (g = this.keys, c = e = 0, f = g.length; f > e; c = ++e) if (((d = g[c]), d === a)) return void (this.values[c] = b);
                        return this.keys.push(a), this.values.push(b);
                    }),
                    a
                );
            })())),
        (a =
            this.MutationObserver ||
            this.WebkitMutationObserver ||
            this.MozMutationObserver ||
            (a = (function () {
                function a() {
                    "undefined" != typeof console && null !== console && console.warn("MutationObserver is not supported by your browser."),
                        "undefined" != typeof console && null !== console && console.warn("WOW.js cannot detect dom mutations, please call .sync() after loading new content.");
                }
                return (a.notSupported = !0), (a.prototype.observe = function () {}), a;
            })())),
        (d =
            this.getComputedStyle ||
            function (a, b) {
                return (
                    (this.getPropertyValue = function (b) {
                        var c;
                        return (
                            "float" === b && (b = "styleFloat"),
                            e.test(b) &&
                                b.replace(e, function (a, b) {
                                    return b.toUpperCase();
                                }),
                            (null != (c = a.currentStyle) ? c[b] : void 0) || null
                        );
                    }),
                    this
                );
            }),
        (e = /(\-([a-z]){1})/g),
        (this.WOW = (function () {
            function e(a) {
                null == a && (a = {}),
                    (this.scrollCallback = f(this.scrollCallback, this)),
                    (this.scrollHandler = f(this.scrollHandler, this)),
                    (this.resetAnimation = f(this.resetAnimation, this)),
                    (this.start = f(this.start, this)),
                    (this.scrolled = !0),
                    (this.config = this.util().extend(a, this.defaults)),
                    null != a.scrollContainer && (this.config.scrollContainer = document.querySelector(a.scrollContainer)),
                    (this.animationNameCache = new c()),
                    (this.wowEvent = this.util().createEvent(this.config.boxClass));
            }
            return (
                (e.prototype.defaults = { boxClass: "wow", animateClass: "animated", offset: 0, mobile: !0, live: !0, callback: null, scrollContainer: null }),
                (e.prototype.init = function () {
                    var a;
                    return (
                        (this.element = window.document.documentElement), "interactive" === (a = document.readyState) || "complete" === a ? this.start() : this.util().addEvent(document, "DOMContentLoaded", this.start), (this.finished = [])
                    );
                }),
                (e.prototype.start = function () {
                    var b, c, d, e;
                    if (
                        ((this.stopped = !1),
                        (this.boxes = function () {
                            var a, c, d, e;
                            for (d = this.element.querySelectorAll("." + this.config.boxClass), e = [], a = 0, c = d.length; c > a; a++) (b = d[a]), e.push(b);
                            return e;
                        }.call(this)),
                        (this.all = function () {
                            var a, c, d, e;
                            for (d = this.boxes, e = [], a = 0, c = d.length; c > a; a++) (b = d[a]), e.push(b);
                            return e;
                        }.call(this)),
                        this.boxes.length)
                    )
                        if (this.disabled()) this.resetStyle();
                        else for (e = this.boxes, c = 0, d = e.length; d > c; c++) (b = e[c]), this.applyStyle(b, !0);
                    return (
                        this.disabled() ||
                            (this.util().addEvent(this.config.scrollContainer || window, "scroll", this.scrollHandler), this.util().addEvent(window, "resize", this.scrollHandler), (this.interval = setInterval(this.scrollCallback, 50))),
                        this.config.live
                            ? new a(
                                  (function (a) {
                                      return function (b) {
                                          var c, d, e, f, g;
                                          for (g = [], c = 0, d = b.length; d > c; c++)
                                              (f = b[c]),
                                                  g.push(
                                                      function () {
                                                          var a, b, c, d;
                                                          for (c = f.addedNodes || [], d = [], a = 0, b = c.length; b > a; a++) (e = c[a]), d.push(this.doSync(e));
                                                          return d;
                                                      }.call(a)
                                                  );
                                          return g;
                                      };
                                  })(this)
                              ).observe(document.body, { childList: !0, subtree: !0 })
                            : void 0
                    );
                }),
                (e.prototype.stop = function () {
                    return (
                        (this.stopped = !0),
                        this.util().removeEvent(this.config.scrollContainer || window, "scroll", this.scrollHandler),
                        this.util().removeEvent(window, "resize", this.scrollHandler),
                        null != this.interval ? clearInterval(this.interval) : void 0
                    );
                }),
                (e.prototype.sync = function (b) {
                    return a.notSupported ? this.doSync(this.element) : void 0;
                }),
                (e.prototype.doSync = function (a) {
                    var b, c, d, e, f;
                    if ((null == a && (a = this.element), 1 === a.nodeType)) {
                        for (a = a.parentNode || a, e = a.querySelectorAll("." + this.config.boxClass), f = [], c = 0, d = e.length; d > c; c++)
                            (b = e[c]), g.call(this.all, b) < 0 ? (this.boxes.push(b), this.all.push(b), this.stopped || this.disabled() ? this.resetStyle() : this.applyStyle(b, !0), f.push((this.scrolled = !0))) : f.push(void 0);
                        return f;
                    }
                }),
                (e.prototype.show = function (a) {
                    return (
                        this.applyStyle(a),
                        (a.className = a.className + " " + this.config.animateClass),
                        null != this.config.callback && this.config.callback(a),
                        this.util().emitEvent(a, this.wowEvent),
                        this.util().addEvent(a, "animationend", this.resetAnimation),
                        this.util().addEvent(a, "oanimationend", this.resetAnimation),
                        this.util().addEvent(a, "webkitAnimationEnd", this.resetAnimation),
                        this.util().addEvent(a, "MSAnimationEnd", this.resetAnimation),
                        a
                    );
                }),
                (e.prototype.applyStyle = function (a, b) {
                    var c, d, e;
                    return (
                        (d = a.getAttribute("data-wow-duration")),
                        (c = a.getAttribute("data-wow-delay")),
                        (e = a.getAttribute("data-wow-iteration")),
                        this.animate(
                            (function (f) {
                                return function () {
                                    return f.customStyle(a, b, d, c, e);
                                };
                            })(this)
                        )
                    );
                }),
                (e.prototype.animate = (function () {
                    return "requestAnimationFrame" in window
                        ? function (a) {
                              return window.requestAnimationFrame(a);
                          }
                        : function (a) {
                              return a();
                          };
                })()),
                (e.prototype.resetStyle = function () {
                    var a, b, c, d, e;
                    for (d = this.boxes, e = [], b = 0, c = d.length; c > b; b++) (a = d[b]), e.push((a.style.visibility = "visible"));
                    return e;
                }),
                (e.prototype.resetAnimation = function (a) {
                    var b;
                    return a.type.toLowerCase().indexOf("animationend") >= 0 ? ((b = a.target || a.srcElement), (b.className = b.className.replace(this.config.animateClass, "").trim())) : void 0;
                }),
                (e.prototype.customStyle = function (a, b, c, d, e) {
                    return (
                        b && this.cacheAnimationName(a),
                        (a.style.visibility = b ? "hidden" : "visible"),
                        c && this.vendorSet(a.style, { animationDuration: c }),
                        d && this.vendorSet(a.style, { animationDelay: d }),
                        e && this.vendorSet(a.style, { animationIterationCount: e }),
                        this.vendorSet(a.style, { animationName: b ? "none" : this.cachedAnimationName(a) }),
                        a
                    );
                }),
                (e.prototype.vendors = ["moz", "webkit"]),
                (e.prototype.vendorSet = function (a, b) {
                    var c, d, e, f;
                    d = [];
                    for (c in b)
                        (e = b[c]),
                            (a["" + c] = e),
                            d.push(
                                function () {
                                    var b, d, g, h;
                                    for (g = this.vendors, h = [], b = 0, d = g.length; d > b; b++) (f = g[b]), h.push((a["" + f + c.charAt(0).toUpperCase() + c.substr(1)] = e));
                                    return h;
                                }.call(this)
                            );
                    return d;
                }),
                (e.prototype.vendorCSS = function (a, b) {
                    var c, e, f, g, h, i;
                    for (h = d(a), g = h.getPropertyCSSValue(b), f = this.vendors, c = 0, e = f.length; e > c; c++) (i = f[c]), (g = g || h.getPropertyCSSValue("-" + i + "-" + b));
                    return g;
                }),
                (e.prototype.animationName = function (a) {
                    var b;
                    try {
                        b = this.vendorCSS(a, "animation-name").cssText;
                    } catch (c) {
                        b = d(a).getPropertyValue("animation-name");
                    }
                    return "none" === b ? "" : b;
                }),
                (e.prototype.cacheAnimationName = function (a) {
                    return this.animationNameCache.set(a, this.animationName(a));
                }),
                (e.prototype.cachedAnimationName = function (a) {
                    return this.animationNameCache.get(a);
                }),
                (e.prototype.scrollHandler = function () {
                    return (this.scrolled = !0);
                }),
                (e.prototype.scrollCallback = function () {
                    var a;
                    return !this.scrolled ||
                        ((this.scrolled = !1),
                        (this.boxes = function () {
                            var b, c, d, e;
                            for (d = this.boxes, e = [], b = 0, c = d.length; c > b; b++) (a = d[b]), a && (this.isVisible(a) ? this.show(a) : e.push(a));
                            return e;
                        }.call(this)),
                        this.boxes.length || this.config.live)
                        ? void 0
                        : this.stop();
                }),
                (e.prototype.offsetTop = function (a) {
                    for (var b; void 0 === a.offsetTop; ) a = a.parentNode;
                    for (b = a.offsetTop; (a = a.offsetParent); ) b += a.offsetTop;
                    return b;
                }),
                (e.prototype.isVisible = function (a) {
                    var b, c, d, e, f;
                    return (
                        (c = a.getAttribute("data-wow-offset") || this.config.offset),
                        (f = (this.config.scrollContainer && this.config.scrollContainer.scrollTop) || window.pageYOffset),
                        (e = f + Math.min(this.element.clientHeight, this.util().innerHeight()) - c),
                        (d = this.offsetTop(a)),
                        (b = d + a.clientHeight),
                        e >= d && b >= f
                    );
                }),
                (e.prototype.util = function () {
                    return null != this._util ? this._util : (this._util = new b());
                }),
                (e.prototype.disabled = function () {
                    return !this.config.mobile && this.util().isMobile(navigator.userAgent);
                }),
                e
            );
        })());
}.call(this));

/*-------------------------------------------------------------
  18. Parallax jQuery
---------------------------------------------------------------*/
/**
 * Parallax.js
 * @author Matthew Wagerfield - @wagerfield, René Roth - mail@reneroth.org
 * @description Creates a parallax effect between an array of layers,
 *              driving the motion from the gyroscope output of a smartdevice.
 *              If no gyroscope is available, the cursor position is used.
 * https://cdnjs.cloudflare.com/ajax/libs/parallax/3.1.0/parallax.min.js
 */

!(function (t) {
    if ("object" == typeof exports && "undefined" != typeof module) module.exports = t();
    else if ("function" == typeof define && define.amd) define([], t);
    else {
        ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).Parallax = t();
    }
})(function () {
    return (function t(e, i, n) {
        function o(r, a) {
            if (!i[r]) {
                if (!e[r]) {
                    var l = "function" == typeof require && require;
                    if (!a && l) return l(r, !0);
                    if (s) return s(r, !0);
                    var h = new Error("Cannot find module '" + r + "'");
                    throw ((h.code = "MODULE_NOT_FOUND"), h);
                }
                var u = (i[r] = { exports: {} });
                e[r][0].call(
                    u.exports,
                    function (t) {
                        var i = e[r][1][t];
                        return o(i || t);
                    },
                    u,
                    u.exports,
                    t,
                    e,
                    i,
                    n
                );
            }
            return i[r].exports;
        }
        for (var s = "function" == typeof require && require, r = 0; r < n.length; r++) o(n[r]);
        return o;
    })(
        {
            1: [
                function (t, e, i) {
                    "use strict";
                    function n(t) {
                        if (null === t || void 0 === t) throw new TypeError("Object.assign cannot be called with null or undefined");
                        return Object(t);
                    }
                    var o = Object.getOwnPropertySymbols,
                        s = Object.prototype.hasOwnProperty,
                        r = Object.prototype.propertyIsEnumerable;
                    e.exports = (function () {
                        try {
                            if (!Object.assign) return !1;
                            var t = new String("abc");
                            if (((t[5] = "de"), "5" === Object.getOwnPropertyNames(t)[0])) return !1;
                            for (var e = {}, i = 0; i < 10; i++) e["_" + String.fromCharCode(i)] = i;
                            if (
                                "0123456789" !==
                                Object.getOwnPropertyNames(e)
                                    .map(function (t) {
                                        return e[t];
                                    })
                                    .join("")
                            )
                                return !1;
                            var n = {};
                            return (
                                "abcdefghijklmnopqrst".split("").forEach(function (t) {
                                    n[t] = t;
                                }),
                                "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, n)).join("")
                            );
                        } catch (t) {
                            return !1;
                        }
                    })()
                        ? Object.assign
                        : function (t, e) {
                              for (var i, a, l = n(t), h = 1; h < arguments.length; h++) {
                                  i = Object(arguments[h]);
                                  for (var u in i) s.call(i, u) && (l[u] = i[u]);
                                  if (o) {
                                      a = o(i);
                                      for (var c = 0; c < a.length; c++) r.call(i, a[c]) && (l[a[c]] = i[a[c]]);
                                  }
                              }
                              return l;
                          };
                },
                {},
            ],
            2: [
                function (t, e, i) {
                    (function (t) {
                        (function () {
                            var i, n, o, s, r, a;
                            "undefined" != typeof performance && null !== performance && performance.now
                                ? (e.exports = function () {
                                      return performance.now();
                                  })
                                : void 0 !== t && null !== t && t.hrtime
                                ? ((e.exports = function () {
                                      return (i() - r) / 1e6;
                                  }),
                                  (n = t.hrtime),
                                  (s = (i = function () {
                                      var t;
                                      return 1e9 * (t = n())[0] + t[1];
                                  })()),
                                  (a = 1e9 * t.uptime()),
                                  (r = s - a))
                                : Date.now
                                ? ((e.exports = function () {
                                      return Date.now() - o;
                                  }),
                                  (o = Date.now()))
                                : ((e.exports = function () {
                                      return new Date().getTime() - o;
                                  }),
                                  (o = new Date().getTime()));
                        }.call(this));
                    }.call(this, t("_process")));
                },
                { _process: 3 },
            ],
            3: [
                function (t, e, i) {
                    function n() {
                        throw new Error("setTimeout has not been defined");
                    }
                    function o() {
                        throw new Error("clearTimeout has not been defined");
                    }
                    function s(t) {
                        if (c === setTimeout) return setTimeout(t, 0);
                        if ((c === n || !c) && setTimeout) return (c = setTimeout), setTimeout(t, 0);
                        try {
                            return c(t, 0);
                        } catch (e) {
                            try {
                                return c.call(null, t, 0);
                            } catch (e) {
                                return c.call(this, t, 0);
                            }
                        }
                    }
                    function r(t) {
                        if (d === clearTimeout) return clearTimeout(t);
                        if ((d === o || !d) && clearTimeout) return (d = clearTimeout), clearTimeout(t);
                        try {
                            return d(t);
                        } catch (e) {
                            try {
                                return d.call(null, t);
                            } catch (e) {
                                return d.call(this, t);
                            }
                        }
                    }
                    function a() {
                        v && p && ((v = !1), p.length ? (f = p.concat(f)) : (y = -1), f.length && l());
                    }
                    function l() {
                        if (!v) {
                            var t = s(a);
                            v = !0;
                            for (var e = f.length; e; ) {
                                for (p = f, f = []; ++y < e; ) p && p[y].run();
                                (y = -1), (e = f.length);
                            }
                            (p = null), (v = !1), r(t);
                        }
                    }
                    function h(t, e) {
                        (this.fun = t), (this.array = e);
                    }
                    function u() {}
                    var c,
                        d,
                        m = (e.exports = {});
                    !(function () {
                        try {
                            c = "function" == typeof setTimeout ? setTimeout : n;
                        } catch (t) {
                            c = n;
                        }
                        try {
                            d = "function" == typeof clearTimeout ? clearTimeout : o;
                        } catch (t) {
                            d = o;
                        }
                    })();
                    var p,
                        f = [],
                        v = !1,
                        y = -1;
                    (m.nextTick = function (t) {
                        var e = new Array(arguments.length - 1);
                        if (arguments.length > 1) for (var i = 1; i < arguments.length; i++) e[i - 1] = arguments[i];
                        f.push(new h(t, e)), 1 !== f.length || v || s(l);
                    }),
                        (h.prototype.run = function () {
                            this.fun.apply(null, this.array);
                        }),
                        (m.title = "browser"),
                        (m.browser = !0),
                        (m.env = {}),
                        (m.argv = []),
                        (m.version = ""),
                        (m.versions = {}),
                        (m.on = u),
                        (m.addListener = u),
                        (m.once = u),
                        (m.off = u),
                        (m.removeListener = u),
                        (m.removeAllListeners = u),
                        (m.emit = u),
                        (m.prependListener = u),
                        (m.prependOnceListener = u),
                        (m.listeners = function (t) {
                            return [];
                        }),
                        (m.binding = function (t) {
                            throw new Error("process.binding is not supported");
                        }),
                        (m.cwd = function () {
                            return "/";
                        }),
                        (m.chdir = function (t) {
                            throw new Error("process.chdir is not supported");
                        }),
                        (m.umask = function () {
                            return 0;
                        });
                },
                {},
            ],
            4: [
                function (t, e, i) {
                    (function (i) {
                        for (
                            var n = t("performance-now"), o = "undefined" == typeof window ? i : window, s = ["moz", "webkit"], r = "AnimationFrame", a = o["request" + r], l = o["cancel" + r] || o["cancelRequest" + r], h = 0;
                            !a && h < s.length;
                            h++
                        )
                            (a = o[s[h] + "Request" + r]), (l = o[s[h] + "Cancel" + r] || o[s[h] + "CancelRequest" + r]);
                        if (!a || !l) {
                            var u = 0,
                                c = 0,
                                d = [];
                            (a = function (t) {
                                if (0 === d.length) {
                                    var e = n(),
                                        i = Math.max(0, 1e3 / 60 - (e - u));
                                    (u = i + e),
                                        setTimeout(function () {
                                            var t = d.slice(0);
                                            d.length = 0;
                                            for (var e = 0; e < t.length; e++)
                                                if (!t[e].cancelled)
                                                    try {
                                                        t[e].callback(u);
                                                    } catch (t) {
                                                        setTimeout(function () {
                                                            throw t;
                                                        }, 0);
                                                    }
                                        }, Math.round(i));
                                }
                                return d.push({ handle: ++c, callback: t, cancelled: !1 }), c;
                            }),
                                (l = function (t) {
                                    for (var e = 0; e < d.length; e++) d[e].handle === t && (d[e].cancelled = !0);
                                });
                        }
                        (e.exports = function (t) {
                            return a.call(o, t);
                        }),
                            (e.exports.cancel = function () {
                                l.apply(o, arguments);
                            }),
                            (e.exports.polyfill = function () {
                                (o.requestAnimationFrame = a), (o.cancelAnimationFrame = l);
                            });
                    }.call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}));
                },
                { "performance-now": 2 },
            ],
            5: [
                function (t, e, i) {
                    "use strict";
                    function n(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                    }
                    var o = (function () {
                            function t(t, e) {
                                for (var i = 0; i < e.length; i++) {
                                    var n = e[i];
                                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
                                }
                            }
                            return function (e, i, n) {
                                return i && t(e.prototype, i), n && t(e, n), e;
                            };
                        })(),
                        s = t("raf"),
                        r = t("object-assign"),
                        a = {
                            propertyCache: {},
                            vendors: [null, ["-webkit-", "webkit"], ["-moz-", "Moz"], ["-o-", "O"], ["-ms-", "ms"]],
                            clamp: function (t, e, i) {
                                return e < i ? (t < e ? e : t > i ? i : t) : t < i ? i : t > e ? e : t;
                            },
                            data: function (t, e) {
                                return a.deserialize(t.getAttribute("data-" + e));
                            },
                            deserialize: function (t) {
                                return "true" === t || ("false" !== t && ("null" === t ? null : !isNaN(parseFloat(t)) && isFinite(t) ? parseFloat(t) : t));
                            },
                            camelCase: function (t) {
                                return t.replace(/-+(.)?/g, function (t, e) {
                                    return e ? e.toUpperCase() : "";
                                });
                            },
                            accelerate: function (t) {
                                a.css(t, "transform", "translate3d(0,0,0) rotate(0.0001deg)"), a.css(t, "transform-style", "preserve-3d"), a.css(t, "backface-visibility", "hidden");
                            },
                            transformSupport: function (t) {
                                for (var e = document.createElement("div"), i = !1, n = null, o = !1, s = null, r = null, l = 0, h = a.vendors.length; l < h; l++)
                                    if ((null !== a.vendors[l] ? ((s = a.vendors[l][0] + "transform"), (r = a.vendors[l][1] + "Transform")) : ((s = "transform"), (r = "transform")), void 0 !== e.style[r])) {
                                        i = !0;
                                        break;
                                    }
                                switch (t) {
                                    case "2D":
                                        o = i;
                                        break;
                                    case "3D":
                                        if (i) {
                                            var u = document.body || document.createElement("body"),
                                                c = document.documentElement,
                                                d = c.style.overflow,
                                                m = !1;
                                            document.body || ((m = !0), (c.style.overflow = "hidden"), c.appendChild(u), (u.style.overflow = "hidden"), (u.style.background = "")),
                                                u.appendChild(e),
                                                (e.style[r] = "translate3d(1px,1px,1px)"),
                                                (o = void 0 !== (n = window.getComputedStyle(e).getPropertyValue(s)) && n.length > 0 && "none" !== n),
                                                (c.style.overflow = d),
                                                u.removeChild(e),
                                                m && (u.removeAttribute("style"), u.parentNode.removeChild(u));
                                        }
                                }
                                return o;
                            },
                            css: function (t, e, i) {
                                var n = a.propertyCache[e];
                                if (!n)
                                    for (var o = 0, s = a.vendors.length; o < s; o++)
                                        if (((n = null !== a.vendors[o] ? a.camelCase(a.vendors[o][1] + "-" + e) : e), void 0 !== t.style[n])) {
                                            a.propertyCache[e] = n;
                                            break;
                                        }
                                t.style[n] = i;
                            },
                        },
                        l = {
                            relativeInput: !1,
                            clipRelativeInput: !1,
                            inputElement: null,
                            hoverOnly: !1,
                            calibrationThreshold: 100,
                            calibrationDelay: 500,
                            supportDelay: 500,
                            calibrateX: !1,
                            calibrateY: !0,
                            invertX: !0,
                            invertY: !0,
                            limitX: !1,
                            limitY: !1,
                            scalarX: 10,
                            scalarY: 10,
                            frictionX: 0.1,
                            frictionY: 0.1,
                            originX: 0.5,
                            originY: 0.5,
                            pointerEvents: !1,
                            precision: 1,
                            onReady: null,
                            selector: null,
                        },
                        h = (function () {
                            function t(e, i) {
                                n(this, t), (this.element = e);
                                var o = {
                                    calibrateX: a.data(this.element, "calibrate-x"),
                                    calibrateY: a.data(this.element, "calibrate-y"),
                                    invertX: a.data(this.element, "invert-x"),
                                    invertY: a.data(this.element, "invert-y"),
                                    limitX: a.data(this.element, "limit-x"),
                                    limitY: a.data(this.element, "limit-y"),
                                    scalarX: a.data(this.element, "scalar-x"),
                                    scalarY: a.data(this.element, "scalar-y"),
                                    frictionX: a.data(this.element, "friction-x"),
                                    frictionY: a.data(this.element, "friction-y"),
                                    originX: a.data(this.element, "origin-x"),
                                    originY: a.data(this.element, "origin-y"),
                                    pointerEvents: a.data(this.element, "pointer-events"),
                                    precision: a.data(this.element, "precision"),
                                    relativeInput: a.data(this.element, "relative-input"),
                                    clipRelativeInput: a.data(this.element, "clip-relative-input"),
                                    hoverOnly: a.data(this.element, "hover-only"),
                                    inputElement: document.querySelector(a.data(this.element, "input-element")),
                                    selector: a.data(this.element, "selector"),
                                };
                                for (var s in o) null === o[s] && delete o[s];
                                r(this, l, o, i),
                                    this.inputElement || (this.inputElement = this.element),
                                    (this.calibrationTimer = null),
                                    (this.calibrationFlag = !0),
                                    (this.enabled = !1),
                                    (this.depthsX = []),
                                    (this.depthsY = []),
                                    (this.raf = null),
                                    (this.bounds = null),
                                    (this.elementPositionX = 0),
                                    (this.elementPositionY = 0),
                                    (this.elementWidth = 0),
                                    (this.elementHeight = 0),
                                    (this.elementCenterX = 0),
                                    (this.elementCenterY = 0),
                                    (this.elementRangeX = 0),
                                    (this.elementRangeY = 0),
                                    (this.calibrationX = 0),
                                    (this.calibrationY = 0),
                                    (this.inputX = 0),
                                    (this.inputY = 0),
                                    (this.motionX = 0),
                                    (this.motionY = 0),
                                    (this.velocityX = 0),
                                    (this.velocityY = 0),
                                    (this.onMouseMove = this.onMouseMove.bind(this)),
                                    (this.onDeviceOrientation = this.onDeviceOrientation.bind(this)),
                                    (this.onDeviceMotion = this.onDeviceMotion.bind(this)),
                                    (this.onOrientationTimer = this.onOrientationTimer.bind(this)),
                                    (this.onMotionTimer = this.onMotionTimer.bind(this)),
                                    (this.onCalibrationTimer = this.onCalibrationTimer.bind(this)),
                                    (this.onAnimationFrame = this.onAnimationFrame.bind(this)),
                                    (this.onWindowResize = this.onWindowResize.bind(this)),
                                    (this.windowWidth = null),
                                    (this.windowHeight = null),
                                    (this.windowCenterX = null),
                                    (this.windowCenterY = null),
                                    (this.windowRadiusX = null),
                                    (this.windowRadiusY = null),
                                    (this.portrait = !1),
                                    (this.desktop = !navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|BB10|mobi|tablet|opera mini|nexus 7)/i)),
                                    (this.motionSupport = !!window.DeviceMotionEvent && !this.desktop),
                                    (this.orientationSupport = !!window.DeviceOrientationEvent && !this.desktop),
                                    (this.orientationStatus = 0),
                                    (this.motionStatus = 0),
                                    this.initialise();
                            }
                            return (
                                o(t, [
                                    {
                                        key: "initialise",
                                        value: function () {
                                            void 0 === this.transform2DSupport && ((this.transform2DSupport = a.transformSupport("2D")), (this.transform3DSupport = a.transformSupport("3D"))),
                                                this.transform3DSupport && a.accelerate(this.element),
                                                "static" === window.getComputedStyle(this.element).getPropertyValue("position") && (this.element.style.position = "relative"),
                                                this.pointerEvents || (this.element.style.pointerEvents = "none"),
                                                this.updateLayers(),
                                                this.updateDimensions(),
                                                this.enable(),
                                                this.queueCalibration(this.calibrationDelay);
                                        },
                                    },
                                    {
                                        key: "doReadyCallback",
                                        value: function () {
                                            this.onReady && this.onReady();
                                        },
                                    },
                                    {
                                        key: "updateLayers",
                                        value: function () {
                                            this.selector ? (this.layers = this.element.querySelectorAll(this.selector)) : (this.layers = this.element.children),
                                                this.layers.length || console.warn("ParallaxJS: Your scene does not have any layers."),
                                                (this.depthsX = []),
                                                (this.depthsY = []);
                                            for (var t = 0; t < this.layers.length; t++) {
                                                var e = this.layers[t];
                                                this.transform3DSupport && a.accelerate(e), (e.style.position = t ? "absolute" : "relative"), (e.style.display = "block"), (e.style.left = 0), (e.style.top = 0);
                                                var i = a.data(e, "depth") || 0;
                                                this.depthsX.push(a.data(e, "depth-x") || i), this.depthsY.push(a.data(e, "depth-y") || i);
                                            }
                                        },
                                    },
                                    {
                                        key: "updateDimensions",
                                        value: function () {
                                            (this.windowWidth = window.innerWidth),
                                                (this.windowHeight = window.innerHeight),
                                                (this.windowCenterX = this.windowWidth * this.originX),
                                                (this.windowCenterY = this.windowHeight * this.originY),
                                                (this.windowRadiusX = Math.max(this.windowCenterX, this.windowWidth - this.windowCenterX)),
                                                (this.windowRadiusY = Math.max(this.windowCenterY, this.windowHeight - this.windowCenterY));
                                        },
                                    },
                                    {
                                        key: "updateBounds",
                                        value: function () {
                                            (this.bounds = this.inputElement.getBoundingClientRect()),
                                                (this.elementPositionX = this.bounds.left),
                                                (this.elementPositionY = this.bounds.top),
                                                (this.elementWidth = this.bounds.width),
                                                (this.elementHeight = this.bounds.height),
                                                (this.elementCenterX = this.elementWidth * this.originX),
                                                (this.elementCenterY = this.elementHeight * this.originY),
                                                (this.elementRangeX = Math.max(this.elementCenterX, this.elementWidth - this.elementCenterX)),
                                                (this.elementRangeY = Math.max(this.elementCenterY, this.elementHeight - this.elementCenterY));
                                        },
                                    },
                                    {
                                        key: "queueCalibration",
                                        value: function (t) {
                                            clearTimeout(this.calibrationTimer), (this.calibrationTimer = setTimeout(this.onCalibrationTimer, t));
                                        },
                                    },
                                    {
                                        key: "enable",
                                        value: function () {
                                            this.enabled ||
                                                ((this.enabled = !0),
                                                this.orientationSupport
                                                    ? ((this.portrait = !1), window.addEventListener("deviceorientation", this.onDeviceOrientation), (this.detectionTimer = setTimeout(this.onOrientationTimer, this.supportDelay)))
                                                    : this.motionSupport
                                                    ? ((this.portrait = !1), window.addEventListener("devicemotion", this.onDeviceMotion), (this.detectionTimer = setTimeout(this.onMotionTimer, this.supportDelay)))
                                                    : ((this.calibrationX = 0), (this.calibrationY = 0), (this.portrait = !1), window.addEventListener("mousemove", this.onMouseMove), this.doReadyCallback()),
                                                window.addEventListener("resize", this.onWindowResize),
                                                (this.raf = s(this.onAnimationFrame)));
                                        },
                                    },
                                    {
                                        key: "disable",
                                        value: function () {
                                            this.enabled &&
                                                ((this.enabled = !1),
                                                this.orientationSupport
                                                    ? window.removeEventListener("deviceorientation", this.onDeviceOrientation)
                                                    : this.motionSupport
                                                    ? window.removeEventListener("devicemotion", this.onDeviceMotion)
                                                    : window.removeEventListener("mousemove", this.onMouseMove),
                                                window.removeEventListener("resize", this.onWindowResize),
                                                s.cancel(this.raf));
                                        },
                                    },
                                    {
                                        key: "calibrate",
                                        value: function (t, e) {
                                            (this.calibrateX = void 0 === t ? this.calibrateX : t), (this.calibrateY = void 0 === e ? this.calibrateY : e);
                                        },
                                    },
                                    {
                                        key: "invert",
                                        value: function (t, e) {
                                            (this.invertX = void 0 === t ? this.invertX : t), (this.invertY = void 0 === e ? this.invertY : e);
                                        },
                                    },
                                    {
                                        key: "friction",
                                        value: function (t, e) {
                                            (this.frictionX = void 0 === t ? this.frictionX : t), (this.frictionY = void 0 === e ? this.frictionY : e);
                                        },
                                    },
                                    {
                                        key: "scalar",
                                        value: function (t, e) {
                                            (this.scalarX = void 0 === t ? this.scalarX : t), (this.scalarY = void 0 === e ? this.scalarY : e);
                                        },
                                    },
                                    {
                                        key: "limit",
                                        value: function (t, e) {
                                            (this.limitX = void 0 === t ? this.limitX : t), (this.limitY = void 0 === e ? this.limitY : e);
                                        },
                                    },
                                    {
                                        key: "origin",
                                        value: function (t, e) {
                                            (this.originX = void 0 === t ? this.originX : t), (this.originY = void 0 === e ? this.originY : e);
                                        },
                                    },
                                    {
                                        key: "setInputElement",
                                        value: function (t) {
                                            (this.inputElement = t), this.updateDimensions();
                                        },
                                    },
                                    {
                                        key: "setPosition",
                                        value: function (t, e, i) {
                                            (e = e.toFixed(this.precision) + "px"),
                                                (i = i.toFixed(this.precision) + "px"),
                                                this.transform3DSupport
                                                    ? a.css(t, "transform", "translate3d(" + e + "," + i + ",0)")
                                                    : this.transform2DSupport
                                                    ? a.css(t, "transform", "translate(" + e + "," + i + ")")
                                                    : ((t.style.left = e), (t.style.top = i));
                                        },
                                    },
                                    {
                                        key: "onOrientationTimer",
                                        value: function () {
                                            this.orientationSupport && 0 === this.orientationStatus ? (this.disable(), (this.orientationSupport = !1), this.enable()) : this.doReadyCallback();
                                        },
                                    },
                                    {
                                        key: "onMotionTimer",
                                        value: function () {
                                            this.motionSupport && 0 === this.motionStatus ? (this.disable(), (this.motionSupport = !1), this.enable()) : this.doReadyCallback();
                                        },
                                    },
                                    {
                                        key: "onCalibrationTimer",
                                        value: function () {
                                            this.calibrationFlag = !0;
                                        },
                                    },
                                    {
                                        key: "onWindowResize",
                                        value: function () {
                                            this.updateDimensions();
                                        },
                                    },
                                    {
                                        key: "onAnimationFrame",
                                        value: function () {
                                            this.updateBounds();
                                            var t = this.inputX - this.calibrationX,
                                                e = this.inputY - this.calibrationY;
                                            (Math.abs(t) > this.calibrationThreshold || Math.abs(e) > this.calibrationThreshold) && this.queueCalibration(0),
                                                this.portrait
                                                    ? ((this.motionX = this.calibrateX ? e : this.inputY), (this.motionY = this.calibrateY ? t : this.inputX))
                                                    : ((this.motionX = this.calibrateX ? t : this.inputX), (this.motionY = this.calibrateY ? e : this.inputY)),
                                                (this.motionX *= this.elementWidth * (this.scalarX / 100)),
                                                (this.motionY *= this.elementHeight * (this.scalarY / 100)),
                                                isNaN(parseFloat(this.limitX)) || (this.motionX = a.clamp(this.motionX, -this.limitX, this.limitX)),
                                                isNaN(parseFloat(this.limitY)) || (this.motionY = a.clamp(this.motionY, -this.limitY, this.limitY)),
                                                (this.velocityX += (this.motionX - this.velocityX) * this.frictionX),
                                                (this.velocityY += (this.motionY - this.velocityY) * this.frictionY);
                                            for (var i = 0; i < this.layers.length; i++) {
                                                var n = this.layers[i],
                                                    o = this.depthsX[i],
                                                    r = this.depthsY[i],
                                                    l = this.velocityX * (o * (this.invertX ? -1 : 1)),
                                                    h = this.velocityY * (r * (this.invertY ? -1 : 1));
                                                this.setPosition(n, l, h);
                                            }
                                            this.raf = s(this.onAnimationFrame);
                                        },
                                    },
                                    {
                                        key: "rotate",
                                        value: function (t, e) {
                                            var i = (t || 0) / 30,
                                                n = (e || 0) / 30,
                                                o = this.windowHeight > this.windowWidth;
                                            this.portrait !== o && ((this.portrait = o), (this.calibrationFlag = !0)),
                                                this.calibrationFlag && ((this.calibrationFlag = !1), (this.calibrationX = i), (this.calibrationY = n)),
                                                (this.inputX = i),
                                                (this.inputY = n);
                                        },
                                    },
                                    {
                                        key: "onDeviceOrientation",
                                        value: function (t) {
                                            var e = t.beta,
                                                i = t.gamma;
                                            null !== e && null !== i && ((this.orientationStatus = 1), this.rotate(e, i));
                                        },
                                    },
                                    {
                                        key: "onDeviceMotion",
                                        value: function (t) {
                                            var e = t.rotationRate.beta,
                                                i = t.rotationRate.gamma;
                                            null !== e && null !== i && ((this.motionStatus = 1), this.rotate(e, i));
                                        },
                                    },
                                    {
                                        key: "onMouseMove",
                                        value: function (t) {
                                            var e = t.clientX,
                                                i = t.clientY;
                                            if (this.hoverOnly && (e < this.elementPositionX || e > this.elementPositionX + this.elementWidth || i < this.elementPositionY || i > this.elementPositionY + this.elementHeight))
                                                return (this.inputX = 0), void (this.inputY = 0);
                                            this.relativeInput
                                                ? (this.clipRelativeInput &&
                                                      ((e = Math.max(e, this.elementPositionX)),
                                                      (e = Math.min(e, this.elementPositionX + this.elementWidth)),
                                                      (i = Math.max(i, this.elementPositionY)),
                                                      (i = Math.min(i, this.elementPositionY + this.elementHeight))),
                                                  this.elementRangeX &&
                                                      this.elementRangeY &&
                                                      ((this.inputX = (e - this.elementPositionX - this.elementCenterX) / this.elementRangeX), (this.inputY = (i - this.elementPositionY - this.elementCenterY) / this.elementRangeY)))
                                                : this.windowRadiusX && this.windowRadiusY && ((this.inputX = (e - this.windowCenterX) / this.windowRadiusX), (this.inputY = (i - this.windowCenterY) / this.windowRadiusY));
                                        },
                                    },
                                    {
                                        key: "destroy",
                                        value: function () {
                                            this.disable(), clearTimeout(this.calibrationTimer), clearTimeout(this.detectionTimer), this.element.removeAttribute("style");
                                            for (var t = 0; t < this.layers.length; t++) this.layers[t].removeAttribute("style");
                                            delete this.element, delete this.layers;
                                        },
                                    },
                                    {
                                        key: "version",
                                        value: function () {
                                            return "3.1.0";
                                        },
                                    },
                                ]),
                                t
                            );
                        })();
                    e.exports = h;
                },
                { "object-assign": 1, raf: 4 },
            ],
        },
        {},
        [5]
    )(5);
});

/*-------------------------------------------------------------
  19. Maplace.js
---------------------------------------------------------------*/
/**
 * Maplace.js
 *
 * Copyright (c) 2013 Daniele Moraschi
 * Licensed under the MIT license
 * For all details and documentation:
 * http://maplacejs.com
 *
 * @version  0.2.10
 * @preserve
 */
!(function (a, b) {
    "function" == typeof define && define.amd ? define(["jquery"], b) : "object" == typeof exports ? (module.exports = b(require("jquery"))) : (a.Maplace = b(a.jQuery));
})(this, function (a) {
    "use strict";
    function b(b) {
        (this.VERSION = "0.2.10"),
            (this.loaded = !1),
            (this.markers = []),
            (this.circles = []),
            (this.oMap = !1),
            (this.view_all_key = "all"),
            (this.infowindow = null),
            (this.maxZIndex = 0),
            (this.ln = 0),
            (this.oMap = !1),
            (this.oBounds = null),
            (this.map_div = null),
            (this.canvas_map = null),
            (this.controls_wrapper = null),
            (this.current_control = null),
            (this.current_index = null),
            (this.Polyline = null),
            (this.Polygon = null),
            (this.Fusion = null),
            (this.directionsService = null),
            (this.directionsDisplay = null),
            (this.o = {
                debug: !1,
                map_div: "#gmap",
                controls_div: "#controls",
                generate_controls: !0,
                controls_type: "dropdown",
                controls_cssclass: "",
                controls_title: "",
                controls_on_map: !0,
                controls_applycss: !0,
                controls_position: google.maps.ControlPosition.RIGHT_TOP,
                type: "marker",
                view_all: !0,
                view_all_text: "View All",
                pan_on_click: !0,
                start: 0,
                locations: [],
                shared: {},
                map_options: { mapTypeId: google.maps.MapTypeId.ROADMAP },
                stroke_options: { strokeColor: "#0000FF", strokeOpacity: 0.8, strokeWeight: 2, fillColor: "#0000FF", fillOpacity: 0.4 },
                directions_options: { travelMode: google.maps.TravelMode.DRIVING, unitSystem: google.maps.UnitSystem.METRIC, optimizeWaypoints: !1, provideRouteAlternatives: !1, avoidHighways: !1, avoidTolls: !1 },
                circle_options: { radius: 100, visible: !0 },
                styles: {},
                fusion_options: {},
                directions_panel: null,
                draggable: !1,
                editable: !1,
                show_infowindows: !0,
                show_markers: !0,
                infowindow_type: "bubble",
                listeners: {},
                beforeViewAll: function () {},
                afterViewAll: function () {},
                beforeShow: function (a, b, c) {},
                afterShow: function (a, b, c) {},
                afterCreateMarker: function (a, b, c) {},
                beforeCloseInfowindow: function (a, b) {},
                afterCloseInfowindow: function (a, b) {},
                beforeOpenInfowindow: function (a, b, c) {},
                afterOpenInfowindow: function (a, b, c) {},
                afterRoute: function (a, b, c) {},
                onPolylineClick: function (a) {},
                onPolygonClick: function (a) {},
                circleRadiusChanged: function (a, b, c) {},
                circleCenterChanged: function (a, b, c) {},
                drag: function (a, b, c) {},
                dragEnd: function (a, b, c) {},
                dragStart: function (a, b, c) {},
            }),
            this.AddControl("dropdown", c),
            this.AddControl("list", d),
            b && "directions" === b.type && (!b.show_markers && (b.show_markers = !1), !b.show_infowindows && (b.show_infowindows = !1)),
            a.extend(!0, this.o, b);
    }
    var c, d;
    return (
        (c = {
            activateCurrent: function (a) {
                this.html_element.find("select").val(a);
            },
            getHtml: function () {
                var b,
                    c,
                    d = this,
                    e = "";
                if (this.ln > 1) {
                    for (
                        e += '<select class="dropdown controls ' + this.o.controls_cssclass + '">', this.ShowOnMenu(this.view_all_key) && (e += '<option value="' + this.view_all_key + '">' + this.o.view_all_text + "</option>"), c = 0;
                        c < this.ln;
                        c += 1
                    )
                        this.ShowOnMenu(c) && (e += '<option value="' + (c + 1) + '">' + (this.o.locations[c].title || "#" + (c + 1)) + "</option>");
                    (e += "</select>"),
                        (e = a(e).bind("change", function () {
                            d.ViewOnMap(this.value);
                        }));
                }
                return (
                    (b = this.o.controls_title),
                    this.o.controls_title &&
                        (b = a('<div class="controls_title"></div>')
                            .css(this.o.controls_applycss ? { fontWeight: "bold", fontSize: this.o.controls_on_map ? "12px" : "inherit", padding: "3px 10px 5px 0" } : {})
                            .append(this.o.controls_title)),
                    (this.html_element = a('<div class="wrap_controls"></div>').append(b).append(e)),
                    this.html_element
                );
            },
        }),
        (d = {
            html_a: function (b, c, d) {
                var e = this,
                    f = c || b + 1,
                    g = d || this.o.locations[b].title,
                    h = a('<a data-load="' + f + '" id="ullist_a_' + f + '" href="#' + f + '" title="' + g + '"><span>' + (g || "#" + (b + 1)) + "</span></a>");
                return (
                    h.css(this.o.controls_applycss ? { color: "#666", display: "block", padding: "5px", fontSize: this.o.controls_on_map ? "12px" : "inherit", textDecoration: "none" } : {}),
                    h.on("click", function (b) {
                        b.preventDefault();
                        var c = a(this).attr("data-load");
                        e.ViewOnMap(c);
                    }),
                    h
                );
            },
            activateCurrent: function (a) {
                this.html_element.find("li").removeClass("active"),
                    this.html_element
                        .find("#ullist_a_" + a)
                        .parent()
                        .addClass("active");
            },
            getHtml: function () {
                var b,
                    c,
                    e = a("<ul class='ullist controls " + this.o.controls_cssclass + "'></ul>").css(this.o.controls_applycss ? { margin: 0, padding: 0, listStyleType: "none" } : {});
                for (this.ShowOnMenu(this.view_all_key) && e.append(a("<li></li>").append(d.html_a.call(this, !1, this.view_all_key, this.o.view_all_text))), c = 0; c < this.ln; c++)
                    this.ShowOnMenu(c) && e.append(a("<li></li>").append(d.html_a.call(this, c)));
                return (
                    (b = this.o.controls_title),
                    this.o.controls_title &&
                        (b = a('<div class="controls_title"></div>')
                            .css(this.o.controls_applycss ? { fontWeight: "bold", padding: "3px 10px 5px 0", fontSize: this.o.controls_on_map ? "12px" : "inherit" } : {})
                            .append(this.o.controls_title)),
                    (this.html_element = a('<div class="wrap_controls"></div>').append(b).append(e)),
                    this.html_element
                );
            },
        }),
        (b.prototype.controls = {}),
        (b.prototype.create_objMap = function () {
            var b,
                c = this,
                d = 0;
            for (b in this.o.styles)
                this.o.styles.hasOwnProperty(b) && (0 === d && (this.o.map_options.mapTypeControlOptions = { mapTypeIds: [google.maps.MapTypeId.ROADMAP] }), d++, this.o.map_options.mapTypeControlOptions.mapTypeIds.push("map_style_" + d));
            if (this.loaded) c.oMap.setOptions(this.o.map_options);
            else
                try {
                    this.map_div.css({ position: "relative", overflow: "hidden" }),
                        (this.canvas_map = a("<div>").addClass("canvas_map").css({ width: "100%", height: "100%" }).appendTo(this.map_div)),
                        (this.oMap = new google.maps.Map(this.canvas_map.get(0), this.o.map_options));
                } catch (e) {
                    this.debug("create_objMap::" + this.map_div.selector, e.toString());
                }
            d = 0;
            for (b in this.o.styles) this.o.styles.hasOwnProperty(b) && (d++, this.oMap.mapTypes.set("map_style_" + d, new google.maps.StyledMapType(this.o.styles[b], { name: b })), this.oMap.setMapTypeId("map_style_" + d));
        }),
        (b.prototype.add_markers_to_objMap = function () {
            var a,
                b,
                c = this.o.type || "marker";
            switch (c) {
                case "marker":
                    for (a = 0; a < this.ln; a++) (b = this.create_objPoint(a)), this.create.marker.call(this, a, b);
                    break;
                default:
                    this.create[c].apply(this);
            }
        }),
        (b.prototype.create_objPoint = function (b) {
            var c = a.extend({}, this.o.locations[b]),
                d = void 0 === c.visible ? void 0 : c.visible;
            return (
                !c.type && (c.type = this.o.type),
                (c.map = this.oMap),
                (c.position = new google.maps.LatLng(c.lat, c.lon)),
                (c.zIndex = void 0 === c.zIndex ? 1e4 : c.zIndex + 100),
                (c.visible = void 0 === d ? this.o.show_markers : d),
                (this.o.maxZIndex = c.zIndex > this.maxZIndex ? c.zIndex : this.maxZIndex),
                c.image && (c.icon = new google.maps.MarkerImage(c.image, new google.maps.Size(c.image_w || 32, c.image_h || 32), new google.maps.Point(0, 0), new google.maps.Point((c.image_w || 32) / 2, (c.image_h || 32) / 2))),
                c
            );
        }),
        (b.prototype.create_objCircle = function (b) {
            var c, d, e;
            return (
                (e = a.extend({}, b)),
                (c = a.extend({}, this.o.stroke_options)),
                (d = a.extend({}, this.o.circle_options)),
                a.extend(c, b.stroke_options || {}),
                a.extend(e, c),
                a.extend(d, b.circle_options || {}),
                a.extend(e, d),
                (e.center = b.position),
                (e.draggable = !1),
                (e.zIndex = b.zIndex > 0 ? b.zIndex - 10 : 1),
                e
            );
        }),
        (b.prototype.add_markerEv = function (a, b, c) {
            var d = this;
            google.maps.event.addListener(c, "click", function (e) {
                d.CloseInfoWindow(),
                    d.o.beforeShow.call(d, a, b, c),
                    d.o.show_infowindows && b.show_infowindow !== !1 && d.open_infowindow(a, c, e),
                    d.o.pan_on_click && b.pan_on_click !== !1 && (d.oMap.panTo(b.position), b.zoom && d.oMap.setZoom(b.zoom)),
                    d.current_control && d.o.generate_controls && d.current_control.activateCurrent && d.current_control.activateCurrent.call(d, a + 1),
                    (d.current_index = a),
                    d.o.afterShow.call(d, a, b, c);
            }),
                b.draggable && this.add_dragEv(a, b, c);
        }),
        (b.prototype.add_circleEv = function (a, b, c) {
            var d = this;
            google.maps.event.addListener(c, "click", function () {
                d.ViewOnMap(a + 1);
            }),
                google.maps.event.addListener(c, "center_changed", function () {
                    d.o.circleCenterChanged.call(d, a, b, c);
                }),
                google.maps.event.addListener(c, "radius_changed", function () {
                    d.o.circleRadiusChanged.call(d, a, b, c);
                }),
                b.draggable && this.add_dragEv(a, b, c);
        }),
        (b.prototype.add_dragEv = function (a, b, c) {
            var d = this;
            google.maps.event.addListener(c, "drag", function (e) {
                var f, g;
                if (c.getPosition) f = c.getPosition();
                else {
                    if (!c.getCenter) return;
                    f = c.getCenter();
                }
                if ((d.circles[a] && d.circles[a].setCenter(f), d.Polyline ? (g = "Polyline") : d.Polygon && (g = "Polygon"), g)) {
                    for (var h = d[g].getPath(), i = h.getArray(), j = [], k = 0; k < i.length; ++k) j[k] = a === k ? new google.maps.LatLng(f.lat(), f.lng()) : new google.maps.LatLng(i[k].lat(), i[k].lng());
                    d[g].setPath(new google.maps.MVCArray(j)), d.add_polyEv(g);
                }
                d.o.drag.call(d, a, b, c);
            }),
                google.maps.event.addListener(c, "dragend", function () {
                    d.o.dragEnd.call(d, a, b, c);
                }),
                google.maps.event.addListener(c, "dragstart", function () {
                    d.o.dragStart.call(d, a, b, c);
                }),
                google.maps.event.addListener(c, "center_changed", function () {
                    d.markers[a] && c.getCenter && d.markers[a].setPosition(c.getCenter()), d.o.drag.call(d, a, b, c);
                });
        }),
        (b.prototype.add_polyEv = function (a) {
            var b = this;
            google.maps.event.addListener(this[a].getPath(), "set_at", function (c, d) {
                b.trigger_polyEv(a, c, d);
            }),
                google.maps.event.addListener(this[a].getPath(), "insert_at", function (c, d) {
                    b.trigger_polyEv(a, c, d);
                });
        }),
        (b.prototype.trigger_polyEv = function (a, b, c) {
            var d = this[a].getPath().getAt(b),
                e = new google.maps.LatLng(d.lat(), d.lng());
            this.markers[b] && this.markers[b].setPosition(e), this.circles[b] && this.circles[b].setCenter(e), this.o["on" + a + "Changed"](b, c, this[a].getPath().getArray());
        }),
        (b.prototype.create = {
            marker: function (a, b, c) {
                if ("circle" === b.type && !c) {
                    var d = this.create_objCircle(b);
                    b.visible || (d.draggable = b.draggable), (c = new google.maps.Circle(d)), this.add_circleEv(a, d, c), (this.circles[a] = c);
                }
                return (b.type = "marker"), (c = new google.maps.Marker(b)), this.add_markerEv(a, b, c), this.oBounds.extend(b.position), (this.markers[a] = c), this.o.afterCreateMarker.call(this, a, b, c), c;
            },
            circle: function () {
                var a, b, c, d;
                for (a = 0; a < this.ln; a++)
                    (b = this.create_objPoint(a)),
                        "circle" === b.type && ((c = this.create_objCircle(b)), b.visible || (c.draggable = b.draggable), (d = new google.maps.Circle(c)), this.add_circleEv(a, c, d), (this.circles[a] = d)),
                        (b.type = "marker"),
                        this.create.marker.call(this, a, b, d);
            },
            polyline: function () {
                var b,
                    c,
                    d = a.extend({}, this.o.stroke_options);
                for (d.path = [], d.draggable = this.o.draggable, d.editable = this.o.editable, d.map = this.oMap, d.zIndex = this.o.maxZIndex + 100, b = 0; b < this.ln; b++)
                    (c = this.create_objPoint(b)), this.create.marker.call(this, b, c), d.path.push(c.position);
                this.Polyline ? this.Polyline.setOptions(d) : (this.Polyline = new google.maps.Polyline(d)), this.add_polyEv("Polyline");
            },
            polygon: function () {
                var b,
                    c,
                    d = this,
                    e = a.extend({}, this.o.stroke_options);
                for (e.path = [], e.draggable = this.o.draggable, e.editable = this.o.editable, e.map = this.oMap, e.zIndex = this.o.maxZIndex + 100, b = 0; b < this.ln; b++)
                    (c = this.create_objPoint(b)), this.create.marker.call(this, b, c), e.path.push(c.position);
                this.Polygon ? this.Polygon.setOptions(e) : (this.Polygon = new google.maps.Polygon(e)),
                    google.maps.event.addListener(this.Polygon, "click", function (a) {
                        d.o.onPolygonClick.call(d, a);
                    }),
                    this.add_polyEv("Polygon");
            },
            fusion: function () {
                (this.o.fusion_options.styles = [this.o.stroke_options]),
                    (this.o.fusion_options.map = this.oMap),
                    this.Fusion ? this.Fusion.setOptions(this.o.fusion_options) : (this.Fusion = new google.maps.FusionTablesLayer(this.o.fusion_options));
            },
            directions: function () {
                var b,
                    c,
                    d,
                    e,
                    f,
                    g = this,
                    h = [],
                    i = 0;
                for (b = 0; b < this.ln; b++)
                    (c = this.create_objPoint(b)),
                        0 === b ? (e = c.position) : b === this.ln - 1 ? (f = c.position) : ((d = this.o.locations[b].stopover === !0), h.push({ location: c.position, stopover: d })),
                        this.create.marker.call(this, b, c);
                (this.o.directions_options.origin = e),
                    (this.o.directions_options.destination = f),
                    (this.o.directions_options.waypoints = h),
                    this.directionsService || (this.directionsService = new google.maps.DirectionsService()),
                    this.directionsDisplay ? this.directionsDisplay.setOptions({ draggable: this.o.draggable }) : (this.directionsDisplay = new google.maps.DirectionsRenderer({ draggable: this.o.draggable })),
                    this.directionsDisplay.setMap(this.oMap),
                    this.o.directions_panel && ((this.o.directions_panel = a(this.o.directions_panel)), this.directionsDisplay.setPanel(this.o.directions_panel.get(0))),
                    this.o.draggable &&
                        google.maps.event.addListener(this.directionsDisplay, "directions_changed", function () {
                            var a = g.directionsDisplay.getDirections();
                            (i = g.compute_distance(g.directionsDisplay.directions)), g.o.afterRoute.call(g, i, a.status, a);
                        }),
                    this.directionsService.route(this.o.directions_options, function (a, b) {
                        b === google.maps.DirectionsStatus.OK && ((i = g.compute_distance(a)), g.directionsDisplay.setDirections(a)), g.o.afterRoute.call(g, i, b, a);
                    });
            },
        }),
        (b.prototype.compute_distance = function (a) {
            var b,
                c = 0,
                d = a.routes[0],
                e = d.legs.length;
            for (b = 0; b < e; b++) c += d.legs[b].distance.value;
            return c;
        }),
        (b.prototype.type_to_open = {
            bubble: function (a) {
                var b = this,
                    c = { content: a.html || "" };
                a.infoWindowMaxWidth && (c.maxWidth = a.infoWindowMaxWidth),
                    (this.infowindow = new google.maps.InfoWindow(c)),
                    google.maps.event.addListener(this.infowindow, "closeclick", function () {
                        b.CloseInfoWindow();
                    });
            },
        }),
        (b.prototype.open_infowindow = function (a, b, c) {
            var d = this.o.locations[a],
                e = this.o.infowindow_type;
            d.html && this.type_to_open[e] && (this.o.beforeOpenInfowindow.call(this, a, d, b), this.type_to_open[e].call(this, d), this.infowindow.open(this.oMap, b), this.o.afterOpenInfowindow.call(this, a, d, b));
        }),
        (b.prototype.get_html_controls = function () {
            return this.controls[this.o.controls_type] && this.controls[this.o.controls_type].getHtml ? ((this.current_control = this.controls[this.o.controls_type]), this.current_control.getHtml.apply(this)) : "";
        }),
        (b.prototype.generate_controls = function () {
            if (!this.o.controls_on_map) return this.controls_wrapper.empty(), void this.controls_wrapper.append(this.get_html_controls());
            var b = a('<div class="on_gmap ' + this.o.controls_type + ' gmap_controls"></div>').css(this.o.controls_applycss ? { margin: "5px" } : {}),
                c = a(this.get_html_controls()).css(
                    this.o.controls_applycss
                        ? {
                              background: "#fff",
                              padding: "5px",
                              border: "1px solid #eee",
                              boxShadow: "rgba(0, 0, 0, 0.298039) 0px 1px 4px -1px",
                              maxHeight: this.map_div.find(".canvas_map").outerHeight() - 80,
                              minWidth: 100,
                              overflowY: "auto",
                              overflowX: "hidden",
                          }
                        : {}
                );
            b.append(c), this.oMap.controls[this.o.controls_position].clear(), this.oMap.controls[this.o.controls_position].push(b.get(0));
        }),
        (b.prototype.init_map = function () {
            var a = this;
            this.Polyline && this.Polyline.setMap(null), this.Polygon && this.Polygon.setMap(null), this.Fusion && this.Fusion.setMap(null), this.directionsDisplay && this.directionsDisplay.setMap(null);
            for (var b = this.markers.length - 1; b >= 0; b -= 1)
                try {
                    this.markers[b] && this.markers[b].setMap(null);
                } catch (c) {
                    a.debug("init_map::markers::setMap", c.stack);
                }
            (this.markers.length = 0), (this.markers = []);
            for (var d = this.circles.length - 1; d >= 0; d -= 1)
                try {
                    this.circles[d] && this.circles[d].setMap(null);
                } catch (c) {
                    a.debug("init_map::circles::setMap", c.stack);
                }
            (this.circles.length = 0),
                (this.circles = []),
                this.o.controls_on_map &&
                    this.oMap.controls &&
                    this.oMap.controls[this.o.controls_position].forEach(function (b, c) {
                        try {
                            a.oMap.controls[this.o.controls_position].removeAt(c);
                        } catch (d) {
                            a.debug("init_map::removeAt", d.stack);
                        }
                    }),
                (this.oBounds = new google.maps.LatLngBounds());
        }),
        (b.prototype.perform_load = function () {
            this.CloseInfoWindow(),
                1 === this.ln
                    ? (this.o.map_options.set_center ? this.oMap.setCenter(new google.maps.LatLng(this.o.map_options.set_center[0], this.o.map_options.set_center[1])) : (this.oMap.fitBounds(this.oBounds), this.ViewOnMap(1)),
                      this.o.map_options.zoom && this.oMap.setZoom(this.o.map_options.zoom))
                    : 0 === this.ln
                    ? (this.o.map_options.set_center ? this.oMap.setCenter(new google.maps.LatLng(this.o.map_options.set_center[0], this.o.map_options.set_center[1])) : this.oMap.fitBounds(this.oBounds),
                      this.oMap.setZoom(this.o.map_options.zoom || 1))
                    : (this.oMap.fitBounds(this.oBounds),
                      "number" == typeof (this.o.start - 0) && this.o.start > 0 && this.o.start <= this.ln
                          ? this.ViewOnMap(this.o.start)
                          : this.o.map_options.set_center
                          ? this.oMap.setCenter(new google.maps.LatLng(this.o.map_options.set_center[0], this.o.map_options.set_center[1]))
                          : this.ViewOnMap(this.view_all_key),
                      this.o.map_options.zoom && this.oMap.setZoom(this.o.map_options.zoom));
        }),
        (b.prototype.debug = function (a, b) {
            return this.o.debug && console.log(a, b), this;
        }),
        (b.prototype.AddControl = function (a, b) {
            return a && b ? ((this.controls[a] = b), this) : (self.debug("AddControl", 'Missing "name" and "func" callback.'), !1);
        }),
        (b.prototype.CloseInfoWindow = function () {
            return (
                this.infowindow &&
                    (this.current_index || 0 === this.current_index) &&
                    (this.o.beforeCloseInfowindow.call(this, this.current_index, this.o.locations[this.current_index]),
                    this.infowindow.close(),
                    (this.infowindow = null),
                    this.o.afterCloseInfowindow.call(this, this.current_index, this.o.locations[this.current_index])),
                this
            );
        }),
        (b.prototype.ShowOnMenu = function (a) {
            if (a === this.view_all_key && this.o.view_all && this.ln > 1) return !0;
            if (((a = parseInt(a, 10)), "number" == typeof (a - 0) && a >= 0 && a < this.ln)) {
                var b = this.o.locations[a].on_menu !== !1;
                if (b) return !0;
            }
            return !1;
        }),
        (b.prototype.ViewOnMap = function (a) {
            if (a === this.view_all_key)
                this.o.beforeViewAll.call(this),
                    (this.current_index = a),
                    this.o.locations.length > 0 && this.o.generate_controls && this.current_control && this.current_control.activateCurrent && this.current_control.activateCurrent.apply(this, [a]),
                    this.oMap.fitBounds(this.oBounds),
                    this.o.afterViewAll.call(this);
            else if (((a = parseInt(a, 10)), "number" == typeof (a - 0) && a > 0 && a <= this.ln))
                try {
                    google.maps.event.trigger(this.markers[a - 1], "click");
                } catch (b) {
                    this.debug("ViewOnMap::trigger", b.stack);
                }
            return this;
        }),
        (b.prototype.SetLocations = function (a, b) {
            return (this.o.locations = a), b && this.Load(), this;
        }),
        (b.prototype.AddLocations = function (b, c) {
            var d = this;
            return (
                a.isArray(b) &&
                    a.each(b, function (a, b) {
                        d.o.locations.push(b);
                    }),
                a.isPlainObject(b) && this.o.locations.push(b),
                c && this.Load(),
                this
            );
        }),
        (b.prototype.AddLocation = function (b, c, d) {
            return a.isPlainObject(b) && this.o.locations.splice(c, 0, b), d && this.Load(), this;
        }),
        (b.prototype.RemoveLocations = function (b, c) {
            var d = this,
                e = 0;
            return (
                a.isArray(b)
                    ? a.each(b, function (a, b) {
                          b - e < d.ln && d.o.locations.splice(b - e, 1), e++;
                      })
                    : b < this.ln && this.o.locations.splice(b, 1),
                c && this.Load(),
                this
            );
        }),
        (b.prototype.Loaded = function () {
            return this.loaded;
        }),
        (b.prototype._init = function () {
            this.ln = this.o.locations.length;
            for (var b = 0; b < this.ln; b++) {
                var c = a.extend({}, this.o.shared);
                (this.o.locations[b] = a.extend(c, this.o.locations[b])),
                    this.o.locations[b].html && ((this.o.locations[b].html = this.o.locations[b].html.replace("%index", b + 1)), (this.o.locations[b].html = this.o.locations[b].html.replace("%title", this.o.locations[b].title || "")));
            }
            return (this.map_div = a(this.o.map_div)), (this.controls_wrapper = a(this.o.controls_div)), this;
        }),
        (b.prototype.Load = function (b) {
            a.extend(!0, this.o, b),
                b && b.locations && (this.o.locations = b.locations),
                this._init(),
                this.o.visualRefresh === !1 ? (google.maps.visualRefresh = !1) : (google.maps.visualRefresh = !0),
                this.init_map(),
                this.create_objMap(),
                this.add_markers_to_objMap(),
                (this.ln > 1 && this.o.generate_controls) || this.o.force_generate_controls ? ((this.o.generate_controls = !0), this.generate_controls()) : (this.o.generate_controls = !1);
            var c = this;
            if (this.loaded) this.perform_load();
            else {
                google.maps.event.addListenerOnce(this.oMap, "idle", function () {
                    c.perform_load();
                });
                for (var d in this.o.listeners) this.o.listeners.hasOwnProperty(d) && google.maps.event.addListener(this.oMap, d, this.o.listeners[d]);
            }
            return (this.loaded = !0), this;
        }),
        b
    );
});

/*-------------------------------------------------------------
  jQuery End
---------------------------------------------------------------*/
