 

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/assets/new_assets/css/special.css?'. time() )); ?>" rel="stylesheet" />
<!-- start breadcrumb -->

<!-- end breadcrumb -->
<section class="container" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" >
    <div class="order text-center bg-light p-3">
            
            <form action="<?php echo e(route('storespecialorder')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                
                  
                  
                
                  
                  
                  
                      
                  
                  <h3><?php echo e(__('Your order')); ?></h3>

              
                    
                  <?php $__errorArgs = ['flavor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small class="form-text text-danger"><?php echo e($message); ?></small>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <select name="flavor" class="" aria-label="Default select example" maxlength="100" required >
                  <option value=""> <?php echo e(__('Choose the flavor')); ?></option> 
                  <?php if(old('flavor')): ?> 
                  <option selected value=" <?php echo e(old('flavor')); ?> "> <?php echo e(old('flavor')); ?> </option>
                  <?php endif; ?>
                    <?php $__currentLoopData = $flavors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ca->name); ?>"><?php if($ca->name_en != null): ?>
                                    <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
                                    <?php echo e($ca->name); ?>

                                    <?php else: ?>
                                    <?php echo e($ca->name_en); ?>

                                    <?php endif; ?> <?php else: ?>
                                    <?php echo e($ca->name); ?>

                                    <?php endif; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select> 
                    
                    <?php $__errorArgs = ['Weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <!-- <select name="Weight" class="form-control" aria-label="Default select example" maxlength="100" required > -->
                    <div class="flex gap-3 w-100 align-items-center">
                      <h6><?php echo e(__('Select Size')); ?></h6>
                      <div class="d-flex gap-3 size pro-qty">
                        <input type="text" name="quantity" value="1" style="width:25px;">
                      </div>
                    </div>

                    <input name="Weight" type="text" class="d-none" value="1" id="weight">



                    
                  </select>

                    <hr>
                    <div class="row justify-content-between my-2" >
                                       
                    <h6 class="col-6 text-end" ><?php echo e(__('Add image')); ?></h6>
                    
                    <?php $__errorArgs = ['main_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input class="col-6" type="file" name="main_image" accept="image/*"  onchange="readURL(this);" value="<?php echo e(old('main_image')); ?>" />  
                    <img id="blah" src="#" style="display:none" />
 
                    
                </div> 

                <div class="row justify-content-between my-2" >
                                      
                  <h6 class="col-6 text-end"><?php echo e(__('Add a design')); ?></h6>
                  <?php $__errorArgs = ['design'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small class="form-text text-danger"><?php echo e($message); ?></small>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <input class="col-6" type="file" name="design" value="<?php echo e(old('design')); ?>" />  

                  </div> 
                  <div class="mb-3">
                    
                    <textarea class="w-100 mt-5 text-end p-2" name="nots" id="add-nots" cols="30" maxlength="300"  rows="5" placeholder="<?php echo e(__('Message on the cake')); ?>"></textarea>
                  </div>
                  
                  <div class="text-center" >
                      
                  <div id="btn_div">
                    <!-- Button trigger modal -->
                    <?php if(auth()->user()): ?>
                        <?php
                         $address=\App\Models\Address::where('user_id',auth()->user()->id)->count();
                        ?>
                        <?php if($address==0): ?>
                          <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#staticBackdrop2">
                            <?php echo e(__('Send order')); ?> 
                        </button>
                        <?php else: ?>
                          <input id="main" type="submit" class="btn btn-secondary" value=" <?php echo e(__("Send order")); ?> ">
                        <?php endif; ?>

                    <?php else: ?>
                      
                        <button id="login" type="button" class="btn btn-secondary" data-bs-toggle="modal" 
                          data-bs-target="#staticBackdrop">
                          <?php echo e(__('Send order')); ?> 
                        </button>
                     
                    <?php endif; ?>
                  </div>
                    
                    
                  </form> 
  
          <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdrop2Label" aria-hidden="true">
              <div class="modal-dialog">
                  <div class="modal-content">

                    <div class="modal-header justify-content-between px-4">
                      <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Add an address')); ?></h5>
                      <button type="button" class="btn-close m-0" data-bs-dismiss="modal" aria-label="Close" id="close-add-address"></button>
                    </div>
                    <!-- Modal -->
                    <div class="modal-body px-4">
                      <h3 class="mb-4"></h3>
                      <form id="address_form" onsubmit="return handleAddAddress(event)" method="POST" >
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <input type="text" required name="name" placeholder="<?php echo e(__('Name')); ?>">
                        </div>
                        <div class="mb-3">
                          <input type="text" required name="email" placeholder="<?php echo e(__('Email')); ?>">
                        </div>
                        <select required name="area" id="region">
                          <option value="1" selected disabled><?php echo e(__('Choose the region')); ?></option>
                          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                        <div class="mb-3">
                          <input required type="text" name="street" placeholder="<?php echo e(__('Street')); ?>">
                        </div>
                        <div class="mb-3">
                          <input required type="text" name="Blvd" placeholder="<?php echo e(__('Blvd')); ?>">
                        </div>
                        <div class="mb-3">
                          <input required type="text" name="house" placeholder="<?php echo e(__('Apartment/House')); ?>">
                        </div>
                        <div class="mb-3">
                          <input required type="text" name="phone" placeholder="<?php echo e(__('Mobile number')); ?>">
                        </div>
                        <div class="w-100 text-center">
                          <button class="w-50 btn btn-outline-secondary" type="submit"> <?php echo e(__('Add an address')); ?></button>
                        </div>
                      </form>
                    </div>

                  </div>
              </div>
          </div>
          <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
              <div class="modal-dialog">
                  <div class="modal-content">

                    <div class="modal-header justify-content-between px-4">
                      <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Login')); ?></h5>
                      <button type="button" class="btn-close m-0" data-bs-dismiss="modal" aria-label="Close" id="close-login"></button>
                    </div>
                    <!-- Modal -->
                    <div class="modal-body px-4">
                      <h3 class="mb-4"><?php echo e(__('Please login first')); ?></h3>
                      <form id="login_form" onsubmit="return handleLogin(event)" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <input type="text" required name="email" placeholder="<?php echo e(__('Email')); ?>">
                        </div>
                        <div class="mb-3">
                          <label id="hidden_label" style="color: red" for=""><?php echo e(__('The password or email does not match our records.')); ?></label>
                          <input type="password" required name="password" placeholder="<?php echo e(__('Password')); ?>">
                        </div>
                        <div class="w-100 text-center">
                          <button class="btn btn-secondary" type="submit"><?php echo e(__('Login')); ?></button>
                        </div>
                      </form>
                    </div>

                  </div>
              </div>
          </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>  
 
<script>
    function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah').show()
                        .attr('src', e.target.result)
                        .width(100);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function handleAddAddress(event) {
          event.preventDefault();
          // document.getElementById("close-add-address").click();
        }

        function handleLogin(event) {
          event.preventDefault()
          // document.getElementById("close-login").click();
        }

        
 </script>

 <script>
    $(document).ready(function(){
      $('#hidden_label').hide();
      $('#login_form').on('submit',function(e){
        $('#hidden_label').hide();
        var data=$('#login_form').serialize();
        e.preventDefault();
        $.ajax({
          'url':'<?php echo e(Route("ajax.login")); ?>',
          'type':'post',
          'data':data,
          success:function(response){
            
            if(response.status=='success'){
              document.getElementById("close-login").click();
              $('#hidden_label').hide();
              if(response.address=='0'){
                $('#btn_div').html(` <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#staticBackdrop2">
                       <?php echo e(__('Send order')); ?> 
                    </button>`);
              }else{
                $('#btn_div').html('<input id="main" type="submit" class="btn btn-secondary" value=" <?php echo e(__("Send order")); ?> ">');
              }
            }else{
              $('#hidden_label').show();
            }
          }
        });
      });

      $('#address_form').on('submit',function(e){
        var data=$('#address_form').serialize();
        e.preventDefault();
        $.ajax({
          'url':'<?php echo e(Route("ajax.address")); ?>',
          'type':'post',
          'data':data,
          success:function(response){
            
            if(response.status=='success'){
              document.getElementById("close-add-address").click();
              $('#btn_div').html('<input id="main" type="submit" class="btn btn-secondary" value=" <?php echo e(__("Send order")); ?> ">');
            }else{
              alert('error');
            }
          }
        });
      });

    });
 </script>
    
    <?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/homePage/specialorder.blade.php ENDPATH**/ ?>