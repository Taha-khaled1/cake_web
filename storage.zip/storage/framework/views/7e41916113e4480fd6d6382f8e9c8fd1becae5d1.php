<?php $__env->startSection('title','تسجيل الدخول'); ?>
<?php $__env->startSection('content'); ?>

 
<!-- breadcrumb area start -->

    <div class="content">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-sm-10 col-10 text-center">
                    <h1><?php echo e(__('Sign In')); ?></h1>

                    <form method="POST" action="<?php echo e(route('login')); ?>" class="ltn__form-box contact-form-box">
                        <?php echo csrf_field(); ?>
                            <!-- <label for="user-name-or-email" class="form-label"> <?php echo e(__('Email')); ?></label> -->
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="w-100 text-end p-2" id="user-name-or-email" placeholder="<?php echo e(__('Email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e(__('The password or email does not match our records.')); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="p-0">
                                <input type="password" name="password" class="w-100 text-end p-2 my-2" aria-label="user-password" aria-describedby="user-password" placeholder="<?php echo e(__('Password')); ?>">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <a ><button type="submit"><?php echo e(__('Sign In')); ?></button> </a>
                            <p class="h6 pb-10"> <?php echo e(__('or')); ?> </p>
                            <a href="<?php echo e(route('register')); ?>" class="btn"> <?php echo e(__('Register')); ?></a>                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('layouts.layoutSite.SitePage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limogesd/public_html/resources/views/site/auth/loginPage.blade.php ENDPATH**/ ?>